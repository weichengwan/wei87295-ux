"""Draw original, editable schematics of ADN and the current B273 candidate.

Requires matplotlib and Noto Sans CJK SC (or another installed CJK font).
No paper figure, research data, weights, or performance claims are included.
"""
from pathlib import Path
import os

os.environ.setdefault("MPLCONFIGDIR", "/tmp/adn-diagram-mpl")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

OUT = Path(__file__).resolve().parent
for fontfile in ("NotoSansCJK-Regular.ttc", "NotoSansCJK-Bold.ttc"):
    fontpath = Path("/usr/share/fonts/opentype/noto") / fontfile
    if fontpath.exists():
        font_manager.fontManager.addfont(str(fontpath))
        # The first face in a system TTC can be named JP; its CJK glyphs
        # still cover this schematic. Register and use its actual family.
        FONT_FAMILY = font_manager.FontProperties(fname=str(fontpath)).get_name()
plt.rcParams.update({
    "font.family": [globals().get("FONT_FAMILY", "Noto Sans CJK SC"), "DejaVu Sans"],
    "axes.unicode_minus": False,
    "svg.fonttype": "none",
    # Noto CJK TTC uses CFF outlines. Type 3 embeds their vector glyphs
    # without falsely labelling the embedded font as a TrueType program.
    "pdf.fonttype": 3,
    "savefig.facecolor": "white",
})
C = {
    "base": ("#EAF0F5", "#526B82"),
    "l1": ("#FFF1DC", "#B16A16"),
    "b271": ("#E6F5F1", "#258A7B"),
    "b273": ("#F0EAFB", "#795AB1"),
}
INK = "#203247"
EDGE = "#52687B"


def text(ax, x, y, s, size=15, weight="normal", color=INK, **kwargs):
    return ax.text(x, y, s, ha="center", va="center", fontsize=size,
                   fontweight=weight, color=color, linespacing=1.45, **kwargs)


def box(ax, x, y, w, h, s, kind="base", size=15, weight="normal"):
    face, edge = C[kind]
    ax.add_patch(FancyBboxPatch((x-w/2, y-h/2), w, h,
                              boxstyle="round,pad=0.12,rounding_size=0.45",
                              linewidth=1.35, edgecolor=edge, facecolor=face,
                              zorder=2))
    text(ax, x, y, s, size=size, weight=weight, zorder=3)


def arrow(ax, points, color=EDGE, dashed=False, width=1.5):
    xs, ys = zip(*points)
    ls = (0, (4, 3)) if dashed else "solid"
    if len(points) > 2:
        ax.plot(xs[:-1], ys[:-1], color=color, linewidth=width,
                linestyle=ls, zorder=1)
    ax.add_patch(FancyArrowPatch(points[-2], points[-1],
                                arrowstyle="-|>", mutation_scale=13,
                                linewidth=width, color=color, linestyle=ls,
                                shrinkA=0, shrinkB=2.0, zorder=1))


def frame(ax, x, y, w, h, color="#CFD8E1", fill="#FBFCFE", dashed=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h,
                              boxstyle="round,pad=0.1,rounding_size=0.6",
                              edgecolor=color, facecolor=fill, linewidth=1.15,
                              linestyle=(0, (4, 3)) if dashed else "solid",
                              zorder=0))


def save(fig, stem):
    for suffix in ("svg", "pdf", "png"):
        fig.savefig(OUT / f"{stem}.{suffix}", dpi=150,
                    bbox_inches="tight", pad_inches=0.2,
                    metadata={"Creator": "Original schematic from paper and source inspection"})
    plt.close(fig)


def overview():
    fig, ax = plt.subplots(figsize=(22, 20))
    fig.subplots_adjust(left=.015, right=.985, top=.985, bottom=.015)
    ax.set(xlim=(0, 100), ylim=(-12, 111))
    ax.axis("off")
    text(ax, 50, 107, "原始 ADN 与当前 B273 候选：网络结构对照", 25, "bold")
    legends = [(13, "base", "ADN 骨架／原有算子"),
               (38, "l1", "L1-Tail 已有改动"),
               (63, "b271", "B271 已有改动"),
               (87, "b273", "B273 本轮前端")]
    for x, kind, label in legends:
        box(ax, x, 101, 22, 3.5, label, kind, 13.4)

    frame(ax, 1, 3, 35, 94)
    frame(ax, 39, 3, 60, 94)
    text(ax, 18.5, 94, "A  原始 ADN（Qu 等，2023）", 19, "bold")
    text(ax, 18.5, 90.5, "ResNet18 型拓扑 + ACB + SimAM", 13.3)
    text(ax, 69, 94, "B  当前 B273：残差 SPWVD 候选", 19, "bold")
    text(ax, 69, 90.5, "沿用 L1-Tail / B271；图中只有一套图像骨干", 13.3)

    # A: the original paper, not the project's 512-pulse adaptation.
    box(ax, 18.5, 84.5, 25, 5.7, "复数 IQ 回波：1024 脉冲", size=15.5)
    box(ax, 18.5, 74.6, 28, 9.0,
        "WVD 时频变换\nRGB 映射 → 224×224×3", size=16)
    arrow(ax, [(18.5, 81.65), (18.5, 79.1)])
    frame(ax, 4, 29, 29, 39, dashed=True)
    text(ax, 18.5, 66.2, "一套 ADN 图像骨干", 14.4, "bold")
    box(ax, 18.5, 61, 25, 5.5, "7×7 卷积 / BN / ReLU\n64×112×112", size=14.4)
    box(ax, 18.5, 53.1, 25, 5.3, "3×3 MaxPool\n64×56×56", size=14.4)
    box(ax, 18.5, 41.8, 25, 13.0,
        "Stage 1：64×56×56，2 块\n"
        "Stage 2：128×28×28，2 块\n"
        "Stage 3：256×14×14，2 块\n"
        "Stage 4：512×7×7，2 块\n"
        "每块：ACB + 3×3 + SimAM + 残差", size=13.4)
    box(ax, 18.5, 31.7, 25, 4.2, "全局平均池化 → 512 维", size=14.4)
    for start, end in [(70.1, 68.1), (58.25, 55.75), (50.45, 48.3), (35.3, 33.8)]:
        arrow(ax, [(18.5, start), (18.5, end)])
    box(ax, 18.5, 22.6, 25, 6.2, "全连接 512→2 + Softmax\n输出 P(H₀)、P(H₁)", size=14.4)
    arrow(ax, [(18.5, 29.6), (18.5, 25.7)])
    box(ax, 18.5, 11.1, 28, 10,
        "训练杂波分位阈值 p\nP(H₀)<p → H₁，否则 H₀\n原论文的 Pfa 控制", size=14.4)
    arrow(ax, [(18.5, 19.5), (18.5, 16.1)])

    # B: one image backbone plus a small, non-ResNet IQ evidence path.
    box(ax, 58.3, 84.5, 25, 5.7, "同一段复数 IQ：512 脉冲", size=15.4)
    box(ax, 50.8, 75, 10.8, 5.5, "原 WVD：W", size=14.3)
    box(ax, 65.4, 75, 14.2, 5.5, "SPWVD：S\n时间 / 时滞平滑", "b273", 13.5)
    for x in (50.8, 65.4):
        arrow(ax, [(58.3, 81.65), (58.3, 80), (x, 80), (x, 77.75)])
    box(ax, 58.3, 65.3, 28, 8.5,
        "有符号谱残差混合\nR = W + α(S−W)，0≤α≤0.75\nα 为一个全局可学习标量", "b273", 14.3)
    for x in (50.8, 65.4):
        arrow(ax, [(x, 72.25), (x, 70.5), (58.3, 70.5), (58.3, 69.55)])
    box(ax, 58.3, 54.5, 28, 8.3,
        "取绝对值 / 对数 / 峰值相对归一化\n128² → 224²，灰度复制成 3 通道\nWCSG 输入门控（沿用 L1-Tail）", "l1", 13.6)
    arrow(ax, [(58.3, 61.05), (58.3, 58.65)])

    frame(ax, 43.4, 4.2, 29.8, 45, dashed=True)
    text(ax, 58.3, 47.4, "同一套 ADN 型图像骨干", 14.0, "bold")
    box(ax, 58.3, 43.1, 26.3, 4.5, "7×7 卷积 / BN / ReLU：64×112²", size=13.7)
    box(ax, 58.3, 37.1, 26.3, 4.5, "R₁：相位引导有界重采样", "b271", 14.3)
    box(ax, 58.3, 28.9, 26.3, 9.2,
        "MaxPool → Stage 1：64×56²，2 块\n"
        "Stage 2：128×28²，2 块\n"
        "ACB 保留，SimAM → TFCG", "l1", 13.5)
    box(ax, 58.3, 21.2, 26.3, 4.5, "R₃：相位引导有界重采样", "b271", 14.3)
    box(ax, 58.3, 13.6, 26.3, 8.6,
        "Stage 3：256×14²，2 块\n"
        "Stage 4：512×7²，2 块\n"
        "ACB 保留，SimAM → TFCG", "l1", 13.5)
    box(ax, 58.3, 6.9, 26.3, 3.8, "全局平均池化 → 512 维", size=14.0)
    for start, end in [(50.35, 49.3), (40.85, 39.35), (34.85, 33.5),
                       (24.3, 23.45), (18.95, 17.9), (9.3, 8.8)]:
        arrow(ax, [(58.3, start), (58.3, end)])

    box(ax, 87.3, 75.2, 19.7, 13,
        "IQ 相位证据\n8×64 点分块 FFT\n能量 + 二阶相位一致性\n输出 2×128×128", "b271", 14.0)
    arrow(ax, [(70.8, 84.5), (87.3, 84.5), (87.3, 81.7)])
    box(ax, 87.3, 56.4, 19.7, 10.5,
        "轻量相位编码器\n2 层卷积 + Avg/Max 聚合\n输出 16 维\n不是第二套 ResNet18", "b271", 13.7)
    arrow(ax, [(87.3, 68.7), (87.3, 61.65)], color=C["b271"][1])
    # Shared guide bus feeds the actual insertion points: before maxpool and layer3.
    guide_color = C["b271"][1]
    ax.plot([77.45, 74.9, 74.9], [75.2, 75.2, 21.2],
            color=guide_color, linestyle=(0, (4, 3)), linewidth=1.4, zorder=1)
    for y in (37.1, 21.2):
        arrow(ax, [(74.9, y), (71.45, y)], color=guide_color, dashed=True)
    text(ax, 75.5, 45.6, "引导", 11.7, color=guide_color, rotation=90)

    box(ax, 87.3, 33.0, 19.7, 25.5,
        "有界得分修正头（沿用 B271）\n"
        "图像 512 维 → 原 FC → m=z₁−z₀\n"
        "图像投影 16 维 + 相位 16 维\n"
        "+ clip/stopgrad(m) 1 维\n"
        "MLP 33→16→1；|δ|<3\n"
        "最终得分 s=m+δ", "b271", 13.5)
    arrow(ax, [(87.3, 51.15), (87.3, 45.75)], color=guide_color)
    arrow(ax, [(71.45, 6.9), (75.6, 6.9), (75.6, 25.1), (77.45, 25.1)])
    box(ax, 87.3, 10.6, 19.7, 9.3,
        "独立 H₀ CAL 阈值 τ\ns>τ → H₁，否则 H₀", size=14.2)
    arrow(ax, [(87.3, 20.25), (87.3, 15.25)])

    text(ax, 50, -.3,
         "训练说明：L1-Tail 是训练方法名，不是额外网络层；本轮冻结原 ADN / WCSG / TFCG，微调 B271 新增模块与 α。",
         13.4)
    text(ax, 50, -4.4,
         "结构依据：ADN 原文表 III、算法 1；本项目 b271_model.py、b273_model.py、b273_frontend.py 与冻结源码。",
         13.4)
    text(ax, 50, -8.5,
         "注意：原始 ADN 利用部分 WVD 交叉项；残差平滑能否改善检测仍待实验。B273 是候选结构，图中不表示已取得增益。",
         13.4)
    save(fig, "ADN_vs_B273_architecture")


def block_detail():
    fig, ax = plt.subplots(figsize=(20, 13))
    fig.subplots_adjust(left=.015, right=.985, top=.985, bottom=.02)
    ax.set(xlim=(0, 100), ylim=(-8, 107))
    ax.axis("off")
    text(ax, 50, 103, "残差块对照：保留 ACB 与捷径，替换注意力模块", 24, "bold")
    text(ax, 50, 97, "四个 Stage 均为 2 个块；共 8 处 SimAM → TFCG。这是 L1-Tail 既有改动，非 B273 新增。", 15)
    for x, name, attention, kind in [(25, "原始 ADN 残差块", "SimAM", "base"),
                                      (75, "当前 L1-Tail / B271 / B273 残差块", "TFCG", "l1")]:
        frame(ax, x-23, 1, 46, 91)
        text(ax, x, 89, name, 17.5, "bold")
        text(ax, x, 83, "输入 x", 15)
        # Three parallel ACB branches are summed; not concatenated.
        for dx, label in [(-12, "3×3 + BN"), (0, "1×3 + BN"), (12, "3×1 + BN")]:
            box(ax, x+dx, 73.5, 10.6, 6.5, label, size=13.5)
            arrow(ax, [(x, 80.5), (x, 78.6), (x+dx, 78.6), (x+dx, 76.75)])
            arrow(ax, [(x+dx, 70.25), (x+dx, 67.7), (x, 67.7), (x, 66)])
        text(ax, x-19.0, 73.5, "ACB", 14, "bold")
        box(ax, x, 63.8, 20, 4.6, "逐元素求和 → ReLU", size=14.3)
        box(ax, x, 55.5, 20, 5.2, "3×3 卷积", size=15)
        box(ax, x, 46.2, 20, 6, attention, kind, 17, "bold")
        box(ax, x, 36.9, 20, 5.1, "BN", size=15)
        box(ax, x, 26.7, 20, 5.7, "与捷径相加", size=15)
        box(ax, x, 17.0, 20, 5.4, "ReLU", size=15)
        text(ax, x, 7.2, "输出 y", 15)
        for ya, yb in [(61.5, 58.1), (52.9, 49.2), (43.2, 39.45),
                       (34.35, 29.55), (23.85, 19.7), (14.3, 10)]:
            arrow(ax, [(x, ya), (x, yb)])
        # Identity / projection shortcut, at the stage's first block when needed.
        arrow(ax, [(x, 81), (x+20.7, 81), (x+20.7, 26.7), (x+10, 26.7)])
        text(ax, x+18.3, 50, "捷径\n必要时\n1×1+BN", 12.8)
    arrow(ax, [(35.1, 46.2), (64.9, 46.2)], color=C["l1"][1], dashed=True, width=1.8)
    text(ax, 50, 50.9, "对应替换 ×8", 15.3, "bold", C["l1"][1])
    text(ax, 50, -2.3,
         "左侧拓扑对应 ADN 原文表 III；BN / ReLU 顺序按项目冻结 ADN 实现展开。右侧来自当前可运行代码。", 13.3)
    text(ax, 50, -6.0,
         "B273 本轮只改输入前端；B271 两处重采样分别位于 stem 后与 Stage 3 前，不是新增 ResNet18 分支。", 13.3)
    save(fig, "ADN_vs_current_residual_block")


if __name__ == "__main__":
    overview()
    block_detail()
    print("Wrote two original schematics, each as SVG, PDF and PNG.")
