# ADN 与当前 B273 候选结构对照

这两张图是依据论文和项目代码重新绘制的结构示意图，没有复制原论文图片。B273 是当前的 residual 实验候选，不代表已经获得新的检测增益，也不代表已经确定最终论文方法。

## 交付文件

- `ADN_vs_B273_architecture.{png,pdf,svg}`：原始 ADN 与当前 B273 并排框图。
- `ADN_vs_current_residual_block.{png,pdf,svg}`：ADN 残差块与当前残差块的对应替换。
- `draw_architecture.py`：绘图源代码，依赖 matplotlib 与可用中文字体；SVG 保留文本，PDF 为矢量图。
- `SOURCE_SNAPSHOT.json`：绘图所依据的项目源码 SHA256，便于核对本图对应的版本。未包含数据或权重。

## 原文依据与“ResNet18”的准确含义

Qu et al., *Enhanced CNN-Based Small Target Detection in Sea Clutter With Controllable False Alarm*, IEEE Sensors Journal, 23(9), 10193–10205, 2023. DOI: https://doi.org/10.1109/JSEN.2023.3259953

1. 原文 III.B 节写明以 ResNet 为骨干，并集成 ACB 与 SimAM。
2. 表 III（印刷页 10199，用户上传 PDF 第 7 页）列出 8 个 attention module，按 64/128/256/512 通道各 2 个块组织，即 ResNet18 型的 `[2,2,2,2]` 拓扑。它不是未经修改的普通 ResNet18；ACB 的额外并行卷积不宜被忽略后机械数成标准 18 层。
3. ACB 的 3×3、1×3、3×1 三个卷积分支求和；这些局部分支不是 3 个独立骨干。
4. 原文算法 1（印刷页 10200，PDF 第 8 页）使用 1024 脉冲，TF 图转成 224×224×3 RGB 图；以训练杂波的 H0 概率分位数控制 Pfa。
5. 原文 III.A 明确利用部分目标/杂波交叉项形成的条纹作为检测线索。因此，不能把所有 WVD 交叉项都说成有害，也不能预设 SPWVD 平滑必然优于 WVD。

## 当前实际推理路径

当前图对应 B273 的 `arm='residual'`，继承 B271 guided 模型。两边各只有一套图像骨干。

| 部位 | 原始 ADN | 当前 B273 | 改动来自哪一轮 |
|---|---|---|---|
| 图像前端 | WVD → RGB 图 | 有符号谱 `R=W+alpha*(S-W)` → 绝对值/对数/归一化 → 灰度复制 3 通道 | B273 残差 SPWVD 候选 |
| 图像骨干前 | 无 WCSG | WCSG 输入门控 | L1-Tail 已有 |
| 8 个残差块 | ACB + 3×3 + SimAM + 捷径 | ACB + 3×3 + TFCG + 捷径 | L1-Tail 已有 |
| 取样位置 | 原始特征流 | stem 后、Stage 3 前各一处相位引导有界重采样 | B271 已有 |
| IQ 旁路 | 无 | 分块 FFT 的能量/二阶相位一致性证据；小型 2 层卷积编码器 | B271 已有，不是第二套 ResNet18 |
| 分类头 | GAP 512 → FC 2 → Softmax | 保留原 FC；图像 16 维 + 相位 16 维 + 截断/停梯度 margin 1 维输入 MLP，输出有界修正 delta | B271 已有 |
| 最终判决 | H0 概率与训练杂波阈值比较 | 最终 margin `s=(z1-z0)+delta` 与独立 H0 CAL 阈值比较 | 本项目评估协议 |

残差块细节图的 BN / ReLU 次序按项目冻结的 ADN 实现展开；首块下采样时，捷径采用 1×1 卷积 + BN。TFCG 对应替换全部 8 处 SimAM；并不是把 TFCG 再叠到 SimAM 后面。

原 FC 得到的原始 margin 只在修正头输入中被 `detach` 并截断到 [-15,15]；最终 `s` 使用的是未截断 margin 加有界修正。`delta=3*tanh(raw/3)`。

SPWVD 前端源于已有时频方法，并参考 Wang & Wang, *A Triple-Channel Network for Maritime Radar Targets Detection Based on Multi-Modal Features*, Remote Sensing 2024, 16, 4662，式 (4)，DOI https://doi.org/10.3390/rs16244662 。本轮没有移入 Wang 的整条 ResNet18 分支，也没有使用 Wang 的旧训练权重。Hann9 时间窗、Hann129 时滞窗是当前实现公开声明的工程选择，不声称恢复了用户历史 Wang 实验。

混合在取绝对值和对数之前进行。alpha 是一个全局可学习标量，不是逐样本或逐像素注意力；完整进度时 `alpha=0.75*sigmoid(theta)`，训练初期再乘 warmup progress。第 0 轮 residual 使用冻结 WVD 图精确重放 B271。普通 SPWVD `plain` 是另一个独立对照实验，不是这张图里额外并联的神经网络。

## 训练与对比边界

- L1-Tail 涉及 CE 与 tail ranking 训练策略，不是推理图中的一个网络层，更不能把名字中的 L1 理解成新增网络分支。
- B273 当前训练冻结原 ADN / WCSG / TFCG 及其 BN；继续微调 B271 新增模块，并学习残差前端系数。固定权重模块仍参与前向计算，必要时允许梯度经过其输入。
- 训练专用的困难负样本、排序/一致性/偏移约束不画成推理分支。
- 图左是原论文，图右是当前项目的 512 脉冲适配。正式做 ADN 指标对照时应使用同一批 512 脉冲数据、同一显示协议与独立阈值方案；不能把原论文 1024 脉冲结果直接当成同条件基线。
- 本轮没有 AHPM。WCSG/TFCG 的历史贡献不能重新归到 B273，B271 的收益也不能全部归因于重采样而忽略相位修正头和训练策略。
- 共同采用 ResNet18 型骨干并不自动意味着信息冗余；若真的再并联完整 Wang 分支，需要验证额外收益和计算代价。当前实现选择保留一套图像骨干。

## 如何据实说明贡献

“以 ADN 为基础骨干，在保持 ACB 残差结构的基础上，引入已有的时频门控与相位条件取样，并进一步研究保留 WVD 信息的残差平滑表示。”这是当前结构的客观描述。能否作为论文贡献，要由原始 ADN、L1-Tail、B271、普通 SPWVD 与残差 SPWVD 的匹配消融支持，不能仅凭增加模块或更换名称认定创新成立。

这些图不含原论文 PDF、用户实验数据、指标结果或权重；图片中没有虚构检测提升。
