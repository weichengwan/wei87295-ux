# B289：两组DHiF新模型训练，三组大规模Pd曲线

按2026-10-17确认的用户要求，三组为：

1. **ADN＋TFSE固定对照**：复用B282 `control`，就是B287橙色曲线的固定权重；不续训。
2. **ADN＋DHiF**：从B280 A0副本启动，只有这个新模型接受优化。
3. **ADN＋TFSE＋DHiF**：从原B280 A1副本启动，保留其已学TFSE前端并冻结前端。

原始ADN、固定TFSE的检查点和结果不改写。B289只允许写入新建 `output_b289_*` 目录。
原始ADN只用于初始化副本和只读VAL校验，不单独续训，也不增加第四条曲线。
已有B287/B284/B282分数只读，且只复用与固定TFSE检查点一致的那一列。

## 论文与模块

**Dynamic High-Frequency Convolution for Infrared Small Target Detection**，
Li et al.，IEEE Transactions on Circuits and Systems for Video Technology2026。
DOI：10.1109/TCSVT.2026.3661285。
原文作者仓库：https://github.com/TinaLRJ/DHiF ，核对commit
`06862c844bc16a3b5ee0d0019e5ae24f0f1bb4e7` 的 `model/basic.py`。

本包按原文式(5)–(8)独立实现相同核心计算，并对照作者代码检查输出和梯度。
不重新设计频率掩模、专家路由、注意力、Tail损失或附加零门。
对应论文提出的独立DHiF算子；不是将整套红外分割网络称为我们的模型。

```text
DHIF:
IQ512 → 原WVD输入处理 → 原ADN Stem、Layer1、Layer2
      → DHiF(128→128,k3,s1,p1) → 原Layer3、Layer4、GAP、FC

FULL:
IQ512 → 已学且冻结的TFSE前端 → 原ADN Stem、Layer1、Layer2
      → 同一DHiF → 原Layer3、Layer4、GAP、FC

TFSE固定对照:
IQ512 → 固定TFSE前端 → 固定原ADN全网 → 两类输出
```

DHiF直接接收128×28×28中层特征，保持尺寸。保留全部8个原生SimAM。
它读取局部3×3特征的通道L2范数，经Linear9→81和Tanh生成每位置9×9动态算子，
算子处理局部特征后与原始局部特征相加，再以基础卷积核聚合。
Tanh限制范围[-1,1]，但不严格保证核和为零；本包没有补入原文代码没有的零均值约束。

### 明确披露的warm-start适配

模块基础核初始化为Dirac恒等映射，动态Linear权重和偏置初始化为零。
因此初始整体函数与各自原检查点一致；新模块的基础核与动态算子均会收到梯度。
没有额外的外层残差乘子。这是为保留既有权重函数做的初始化适配，
区别于作者从头训练时的默认随机初始化，不能写成原文完全相同的训练协议。

中间特征图上的局部变化不能直接等同于回波的多普勒频率，也不假设所有高频都是目标。
引用原文模块后，是否有新贡献与稳定增益，仍需实验验证。

## 今晚默认流程

- 使用既有冻结IQ **30,000 TRAIN＋5,000 VAL**。
- 每个新模型 **15epoch**；前3epoch只优化DHiF，再12epoch优化CNN与DHiF。
- Adam，原CNN学习率1e-5，DHiF3e-4，weight_decay1e-4，CE。
- 原生BN仿射参数和运行统计冻结；TFSE前端冻结。
- 根据完整VAL的pAUC@FPR≤0.01选择已训练epoch，CE作平分判据。
  epoch0仅做初始化诊断；没有旧实验的CE+0.01硬门槛。
- 两组训练结束且权重锁定后，再进行 **H0 CAL3,000,000、H0 AUDIT1,000,000、
  H1每SCR1,024个、-24到+12dB共37点**。
- 输出 **Pfa=1e-4、1e-5** 两组图。每图恰好三条曲线。
- 固定TFSE已有分数在协议、权重SHA、运行时和数值前缀检查通过时复用；
  缺少副本时只重新推理固定权重，绝不重训对照。
- WVD和SPWVD表征在线计算，不生成额外数GB的时频图缓存，不依赖被删除的旧WVD缓存。
- 新结果、权重和分数预计需要约1GiB以内；启动要求预留2GiB以容纳原子写入临时文件。

**这是固定历史对照与两个新候选的大规模筛选，不是同训练预算的严格消融。**
固定TFSE的历史续训使用16k/6epoch，新候选使用30k/15epoch。
本包完整记录差异，不能把全部收益直接归因于模块。
VAL的2500个H0也不能直接验证1e-4/1e-5；pAUC01只是预先指定的选择代理。
真实低虚警检测表现由CAL和独立AUDIT、H1推理得到，不通过DEV反选epoch。

## 启动

解压到 `/root/autodl-tmp/MTDSP_NATIVE_LMDA_V1` 后：

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
bash B289_DHIF_FULL_V1/start_on_autodl.sh
tail -F codex_b289_dhif_full.log
```

调用 `conda run -n mpdnet-r10`，无需conda activate。
如果B288或其他实验仍持有共享GPU锁，本实验等待，不中止它们。
采用nohup，SSH/手机热点断线不终止任务；服务器关机、进程被杀或磁盘满仍会中断。
重新运行相同命令可恢复最近完整epoch及最近已提交的评分块/SCR。
代码或训练配置改变时会拒绝复用旧结果，请另设 `--out-dir .../output_b289_其他名称`。

原始路径默认：

```text
SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1/
output_b280_full_ablation_v1/A0/{best.pt,training_contract.json}
output_b280_full_ablation_v1/A1/{best.pt,training_contract.json}
output_b280_full_ablation_v1/pd_scr_full/{protocol_frozen.json,progress.json}
output_b282_a1_cfexpert_v1/control/{best.pt,training_contract.json}
```

缺失时会指出精确路径；不自动重训任何原始对照。

## 结果与图形

目录：`output_b289_dhif_full_v1/pd_scr_full/`。

- `figures/b289_pd_scr_pfa_1e-04.pdf`
- `figures/b289_pd_scr_pfa_1e-05.pdf`
- `figures/b289_empty_pfa_ci95_pfa_1e-04.pdf`
- `figures/b289_empty_pfa_ci95_pfa_1e-05.pdf`
- `b289_metrics.csv`、`b289_curves.csv`、`b289_comparisons.csv`、`b289_report.json`
- `b289_training_table.csv` 明示权重版本与不同训练预算。

最终候选为黑色实线、空心倒三角；固定TFSE仍为橙色方形；
ADN＋DHiF为绿色菱形。横轴SCR(dB)，纵轴Pd，上方标虚警率。
不平滑、不平移、不强制单调；D90未达到则空值，不外推。

## 验证

本地函数测试与CPU运行只验证代码，不证明真实Pd增益。真实AutoDL启动会在实际TRAIN上
检验batch32的三次优化和显存占用，确认两条DHiF路径都有梯度，然后丢弃预检模型。
开始前与结束后核对三个源检查点及contract SHA，保留旧模型文件。

```bash
python -m unittest discover -s tests -v
```

耗时通常为数小时；日志会按实际epoch用时及每万条H0速度给出阶段剩余时间。
未在你的RTX3080Ti实际运行前，不保证一个固定的总时长。
