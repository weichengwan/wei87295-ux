"""Exactly three raw37-point curves at1e-4 and1e-5; no baseline retraining."""
import math
import numpy as np
from b289_common import LABELS,NAMES,FILES,need,read_json,write_json,save_csv,fingerprint,digest_file


def wilson(k,n):
    z=1.959963984540054;q=k/n;den=1+z*z/n
    mid=(q+z*z/(2*n))/den;rad=z*math.sqrt(q*(1-q)/n+z*z/(4*n*n))/den
    return max(0.,mid-rad),min(1.,mid+rad)


def crossing(x,y,level):
    if y[0]>=level:return float(x[0])
    for i in range(1,len(x)):
        if y[i-1]<level<=y[i]:return float(x[i-1]+(level-y[i-1])*(x[i]-x[i-1])/(y[i]-y[i-1]))
    return None


def cutoff(scores,pfa):
    scores=np.asarray(scores);k=int(math.floor(len(scores)*pfa))
    need(scores.ndim==1 and np.isfinite(scores).all() and 10<=k<len(scores),'Insufficient/invalid CAL tail support')
    th=float(np.partition(scores,len(scores)-k-1)[len(scores)-k-1])
    return th,k,int((scores>th).sum())


def generate(folder):
    p=read_json(folder/'protocol_frozen.json');pr=read_json(folder/'progress.json')
    need(p['version']=='B289_DHIF_THREE_MODEL_FULL_SCORE_V1' and p['labels']==list(LABELS),'Wrong three-model report')
    need(p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==pr['fingerprint'],'Scoring report identity differs')
    need(pr['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=37),'Scoring incomplete')
    arrays={}
    for split,file in FILES.items():
        n=p['h1_scenes_n'] if split=='h1' else p[split+'_n'];shape=(37,n,3) if split=='h1' else (n,3)
        value=np.load(folder/file,mmap_mode='r',allow_pickle=False)
        need(value.shape==shape and value.dtype==np.float64 and np.isfinite(value).all(),'Malformed score array '+file)
        arrays[split]=value
    curves=[];metrics=[];table=[];lookup={}
    for col,label in enumerate(LABELS):
        for nominal in p['nominal_pfas']:
            th,k,calfp=cutoff(arrays['h0_cal'][:,col],nominal)
            fp=int((arrays['h0_audit'][:,col]>th).sum());n=p['h0_audit_n'];low,high=wilson(fp,n)
            hits=(arrays['h1'][:,:,col]>th).sum(1);pd=hits/p['h1_scenes_n']
            m=dict(method=NAMES[label],nominal_pfa=nominal,actual_pfa=fp/n,audit_false_alarms=fp,audit_n=n,
                actual_pfa_ci95_low=low,actual_pfa_ci95_high=high,threshold=th,cal_n=p['h0_cal_n'],cal_tail_support=k,cal_exceedances=calfp,
                D50_db=crossing(p['scr_grid_db'],pd,.5),D80_db=crossing(p['scr_grid_db'],pd,.8),D90_db=crossing(p['scr_grid_db'],pd,.9),
                pd_at_0=float(pd[p['scr_grid_db'].index(0)]),pd_at_6=float(pd[p['scr_grid_db'].index(6)]),pd_at_12=float(pd[-1]),max_pd=float(pd.max()))
            metrics.append(m);lookup[label,nominal]=m
            ct=p['training_contracts'][label];cfg=ct['run_config']
            table.append(dict(group=label,TFSE=label!='DHIF',DHiF=label!='TFSE',
                new_training=label!='TFSE',training_rows=cfg['selected_rows']['train']['count'],
                training_epochs=cfg['epochs'],selected_epoch=ct['best_epoch'],**m))
            for scr,count in zip(p['scr_grid_db'],hits):
                lo,hi=wilson(int(count),p['h1_scenes_n'])
                curves.append(dict(method=NAMES[label],nominal_pfa=nominal,scr_db=scr,hits=int(count),n_h1=p['h1_scenes_n'],
                    pd=float(count/p['h1_scenes_n']),pd_ci95_low=lo,pd_ci95_high=hi))
    comparisons=[]
    for nominal in p['nominal_pfas']:
        ref=lookup['TFSE',nominal]
        for label in ('DHIF','FULL'):
            c=lookup[label,nominal]
            delta=lambda key:None if c[key] is None or ref[key] is None else c[key]-ref[key]
            comparisons.append(dict(candidate=NAMES[label],reference=NAMES['TFSE'],nominal_pfa=nominal,
                delta_D80_db=delta('D80_db'),delta_D90_db=delta('D90_db'),pd_at_0_gain_pp=100*delta('pd_at_0'),
                candidate_H0_false_alarms=c['audit_false_alarms'],reference_H0_false_alarms=ref['audit_false_alarms'],
                negative_delta_means_left=True,equal_training_budget=False))
    for name,rows in [('b289_curves.csv',curves),('b289_metrics.csv',metrics),('b289_training_table.csv',table),('b289_comparisons.csv',comparisons)]:
        save_csv(folder/name,rows)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    figures=folder/'figures';figures.mkdir(exist_ok=True)
    styles=dict(TFSE=dict(color='#ff7f0e',marker='s'),DHIF=dict(color='#2ca02c',marker='D'),FULL=dict(color='black',marker='v'))
    for nominal in p['nominal_pfas']:
        fig,ax=plt.subplots(figsize=(7.5,4.8))
        for label in LABELS:
            rows=[r for r in curves if r['method']==NAMES[label] and r['nominal_pfa']==nominal]
            ax.plot([r['scr_db'] for r in rows],[r['pd'] for r in rows],label=NAMES[label],linestyle='-',linewidth=1.7,
                markevery=3,markersize=5,markerfacecolor='white',**styles[label])
        ax.set(xlabel='SCR (dB)',ylabel=r'$P_d$',xlim=(-24,12),ylim=(0,1.02),
            title=r'Nominal $P_{\mathrm{fa}}=10^{'+str(int(round(np.log10(nominal))))+'}$')
        ax.grid(alpha=.25);ax.legend(fontsize=8);fig.tight_layout()
        for ext in ('pdf','png','svg'):fig.savefig(figures/f'b289_pd_scr_pfa_{nominal:.0e}.{ext}',dpi=300)
        plt.close(fig)
        selected=[m for m in metrics if m['nominal_pfa']==nominal]
        fig,ax=plt.subplots(figsize=(7.5,3));pos=np.arange(3)
        vals=np.array([m['actual_pfa'] for m in selected]);lo=np.array([m['actual_pfa_ci95_low'] for m in selected]);hi=np.array([m['actual_pfa_ci95_high'] for m in selected])
        ax.errorbar(pos,vals,yerr=[vals-lo,hi-vals],fmt='o',capsize=4)
        ax.axhline(nominal,color='black',linestyle='--');ax.set_xticks(pos,[m['method'] for m in selected],fontsize=7)
        ax.set_ylabel('Audited Pfa');ax.set_title(f'Nominal Pfa={nominal:g}; Wilson95% interval');fig.tight_layout()
        fig.savefig(figures/f'b289_empty_pfa_ci95_pfa_{nominal:.0e}.pdf');plt.close(fig)
    def d90_status(nominal):
        own,ref=lookup['FULL',nominal]['D90_db'],lookup['TFSE',nominal]['D90_db']
        if own is None:return 'both_unreached' if ref is None else 'unreached'
        if ref is None:return 'newly_reaches'
        return 'left' if own<ref else 'tie' if own==ref else 'right'
    report=dict(status='PASS_B289_THREE_MODEL_FULL_REPORT',labels=list(LABELS),metrics=metrics,comparisons=comparisons,
        source_lineage=p['source_lineage'],training_contracts=p['training_contracts'],
        raw_score_sha256={name:digest_file(folder/name) for name in FILES.values()},
        pure_ADN_trained=False,fixed_TFSE_trained=False,fixed_TFSE_reused=True,
        equal_budget_ablation=False,independent_final=False,source_Pd_unchanged=True,curve_shifting=False,smoothing=False,
        interpretation='Three-model full DEV screening. The two new candidates use30k/15epochs; the frozen TFSE continuation used16k/6epochs. Any gain is descriptive and does not isolate the effect of DHiF from extra training.',
        ours_D90_left_of_fixed_TFSE=[dict(nominal_pfa=n,D90_comparison=d90_status(n),
            descriptive_D90_left=(lookup['FULL',n]['D90_db'] is not None and lookup['TFSE',n]['D90_db'] is not None and
                lookup['FULL',n]['D90_db']<lookup['TFSE',n]['D90_db'])) for n in p['nominal_pfas']])
    write_json(folder/'b289_report.json',report)
    for row in comparisons:
        print(f'Pfa={row["nominal_pfa"]:.0e} {row["candidate"]} vs fixed TFSE: '
              f'delta_D80={row["delta_D80_db"]}; delta_D90={row["delta_D90_db"]}; '
              f'H0 FP={row["candidate_H0_false_alarms"]} vs {row["reference_H0_false_alarms"]}',flush=True)
    print('PASS_B289_THREE_MODEL_FULL_TRAIN_SCORE_REPORT_COMPLETE: '+str(folder),flush=True)
    return report
