"""Read-only original A0/A1 initializations and the already-fixed TFSE control."""
import torch
from b289_common import ROOT, need, read_json, digest_file, load_checkpoint, fingerprint, generator
from b289_model import PlainADN, TFSECore

SCENE_KEYS=('master_seed','generator_sha','h0_cal_n','h0_audit_n','h1_scenes_n','scr_grid_db',
    'h0_cal_split','h0_audit_split','h1_split','family_names','scr_definition')


def checked(folder, status, code, arm):
    ct_path, path=folder/'training_contract.json',folder/'best.pt'
    need(ct_path.is_file() and path.is_file(),f'Missing fixed source {arm}: {folder}; no automatic baseline retraining')
    ct=read_json(ct_path);cfg=ct['run_config']
    need(ct['status']==status and cfg['arm']==arm and cfg['code_sha256']==code,'Source release/arm differs: '+arm)
    need(digest_file(path)==ct['checkpoint_sha256'],'Source checkpoint SHA differs: '+arm)
    state=load_checkpoint(path)
    need(state['run_config']==cfg and state['run_fingerprint']==ct['run_fingerprint']==fingerprint(cfg)
         and state['epoch']==ct['best_epoch'],'Source checkpoint internal identity differs: '+arm)
    return ct,state


def load_sources(a,context):
    expected=read_json(ROOT/'expected_source_code.json')
    a0_ct,a0_state=checked(a.b280_run/'A0','PASS_B280_FULL_TRAIN_VAL_ONLY',expected['B280'],'A0')
    a1_ct,a1_state=checked(a.b280_run/'A1','PASS_B280_FULL_TRAIN_VAL_ONLY',expected['B280'],'A1')
    for ct in (a0_ct,a1_ct):
        cfg=ct['run_config']
        need(cfg['bank_sha256']==context['bc']['file_sha256'] and not cfg['factor_B_TFCG_Tail'],'Wrong initial bank or Tail/TFCG arm')
        need((cfg['selected_rows']['train']['count'],cfg['selected_rows']['val']['count'])==(30000,5000),'Expected frozen full B280 source')
    need(not a0_ct['run_config']['factor_A_joint_SPWVD'] and a1_ct['run_config']['factor_A_joint_SPWVD'],'A0/A1 frontend factors differ')
    a0=PlainADN();a0.load_state_dict(a0_state['state_dict'],strict=True)
    a1=TFSECore(a1_ct['run_config']['scale']);a1.load_state_dict(a1_state['state_dict'],strict=True)
    control_ct,control_state=checked(a.b282_run/'control','PASS_B282_A1_CROSS_FREQUENCY_TRAIN_VAL_ONLY',expected['B282'],'control')
    cfg=control_ct['run_config']
    need(cfg['bank_sha256']==context['bc']['file_sha256'] and cfg['scale']==a1.scale and cfg['frontend_frozen'],'Fixed TFSE control bank/frontend differs')
    need(cfg['source_identity']['A1_checkpoint_sha256']==a1_ct['checkpoint_sha256'] and
         cfg['source_identity']['A1_run_fingerprint']==a1_ct['run_fingerprint'],'Fixed TFSE came from another A1')
    for size in ('full','medium'):
        old_path=a.root/'output_b287_tfse_lcbr_factorial_v1'/('pd_scr_'+size)/'protocol_frozen.json'
        if old_path.is_file():
            old=read_json(old_path)
            need(old['version']=='B287_TFSE_LCBR_SCORE_V1' and
                 old['fingerprint']==fingerprint({k:v for k,v in old.items() if k!='fingerprint'}),'Previous B287 metadata changed')
            need(old['training_contracts']['TFSE']==control_ct,'Fixed TFSE is no longer the checkpoint in your B287 orange curve')
    weights=control_state['state_dict']
    need(all(k.startswith('net.') for k in weights),'TFSE control unexpectedly contains another module')
    control=TFSECore(cfg['scale'])
    control.load_state_dict({k[4:]:v for k,v in weights.items()},strict=True)
    p_path=a.b280_run/'pd_scr_full/protocol_frozen.json';p=read_json(p_path)
    pr=read_json(p_path.with_name('progress.json'))
    need(p['version']=='B280_FULL_FACTORIAL_SCORE_V1' and p['labels']==['A0','A1','A2','A3'],'Wrong original scene metadata')
    need(p['checkpoints'][0]==a0_ct and p['checkpoints'][1]==a1_ct,'Original scores used different initial checkpoints')
    need(p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==pr['fingerprint'],'Original scene fingerprint differs')
    need(pr['completed']==dict(h0_cal=3000000,h0_audit=1000000,h1=37),'Original full scene metadata is incomplete')
    scene={k:p[k] for k in SCENE_KEYS}
    need(p['scene_fingerprint']==fingerprint(scene) and p['scr_grid_db']==list(range(-24,13)),'Scene grid/identity differs')
    need((p['h0_cal_n'],p['h0_audit_n'],p['h1_scenes_n'])==(3000000,1000000,1024),'Require existing full3M/1M/1024 scene definition')
    g=generator()
    need(p['generator_sha']==context['bc']['generator_sha256']==digest_file(g.__file__) and
         p['master_seed']==context['bc']['seed'] and tuple(p['family_names'])==g.TRAIN_FAMILIES,'Scene generator/seed differs')
    need(cfg['source_identity']['source_protocol_sha256']==digest_file(p_path),'TFSE control source protocol differs')
    models=dict(A0=a0,A1=a1,TFSE=control)
    for m in models.values():m.to(a.device).eval().requires_grad_(False)
    protected={str(folder/'best.pt'):ct['checkpoint_sha256'] for folder,ct in
        [(a.b280_run/'A0',a0_ct),(a.b280_run/'A1',a1_ct),(a.b282_run/'control',control_ct)]}
    protected.update({str(folder/'training_contract.json'):digest_file(folder/'training_contract.json') for folder in
        (a.b280_run/'A0',a.b280_run/'A1',a.b282_run/'control')})
    lineage=dict(B280_A0=a0_ct['checkpoint_sha256'],B280_A1=a1_ct['checkpoint_sha256'],
        fixed_B282_TFSE=control_ct['checkpoint_sha256'],fixed_TFSE_training_fingerprint=control_ct['run_fingerprint'])
    return dict(models=models,contracts=dict(A0=a0_ct,A1=a1_ct,TFSE=control_ct),
        scene=scene,generator=g,lineage=lineage,protected_sources=protected)


def verify_protected(info):
    for path,sha in info['protected_sources'].items():
        need(digest_file(path)==sha,'A protected source checkpoint/contract changed: '+path)
    return dict(unchanged=True,sha256=info['protected_sources'])
