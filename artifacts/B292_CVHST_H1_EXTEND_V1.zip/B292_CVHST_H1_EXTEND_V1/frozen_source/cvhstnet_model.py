#!/usr/bin/env python3
"""CVHSTNet IEEE GRSL 2025, Table II + Eqs (1)-(8), original-source-absent reimplementation.
Declared adaptations: CNN padding/stride to match published shapes, STFT center=False,
complex STFT interpolation separately on real and imaginary parts, TRAIN-fitted global IQ RMS.
No original-author equivalence is claimed.
"""
from __future__ import annotations
import math
import torch
import torch.nn as nn
import torch.nn.functional as F

PAPER_DOI = '10.1109/LGRS.2025.3557817'


def stft_iq512(iq:torch.Tensor, scale:float=1.0)->torch.Tensor:
    """[B,512] complex64 -> [B,1,224,224] complex64. No per-scene normalization."""
    if iq.ndim!=2 or iq.shape[1]!=512 or not torch.is_complex(iq):
        raise ValueError('Expected complex [B,512] IQ')
    if not (math.isfinite(float(scale)) and scale>0): raise ValueError('scale must be finite positive TRAIN-only RMS')
    x=iq/float(scale)
    w=torch.hamming_window(64,periodic=True,device=iq.device,dtype=x.real.dtype)
    s=torch.stft(x,n_fft=64,hop_length=16,win_length=64,window=w,
        center=False,normalized=False,onesided=False,return_complex=True)
    assert s.shape[1:]==(64,29),s.shape
    xr=F.interpolate(s.real[:,None],size=(224,224),mode='bilinear',align_corners=False)
    xi=F.interpolate(s.imag[:,None],size=(224,224),mode='bilinear',align_corners=False)
    return torch.complex(xr,xi)


class CVConv2d(nn.Module):
    def __init__(self,cin,cout,kernel_size,stride=1,padding=0,bias=True):
        super().__init__()
        self.real=nn.Conv2d(cin,cout,kernel_size,stride=stride,padding=padding,bias=False)
        self.imag=nn.Conv2d(cin,cout,kernel_size,stride=stride,padding=padding,bias=False)
        self.bias_real=nn.Parameter(torch.zeros(cout)) if bias else None
        self.bias_imag=nn.Parameter(torch.zeros(cout)) if bias else None
    def forward(self,z):
        r,i=z.real,z.imag
        yr=self.real(r)-self.imag(i)
        yi=self.real(i)+self.imag(r)
        if self.bias_real is not None:
            yr=yr+self.bias_real[None,:,None,None];yi=yi+self.bias_imag[None,:,None,None]
        return torch.complex(yr,yi)


class CVLinear(nn.Module):
    def __init__(self,inc,out):
        super().__init__();self.real=nn.Linear(inc,out,bias=False);self.imag=nn.Linear(inc,out,bias=False)
        self.bias_real=nn.Parameter(torch.zeros(out));self.bias_imag=nn.Parameter(torch.zeros(out))
    def forward(self,z):
        yr=self.real(z.real)-self.imag(z.imag)+self.bias_real
        yi=self.real(z.imag)+self.imag(z.real)+self.bias_imag
        return torch.complex(yr,yi)


def crelu(z):return torch.complex(F.relu(z.real),F.relu(z.imag))
def cavgpool(z):return torch.complex(F.avg_pool2d(z.real,2),F.avg_pool2d(z.imag,2))


class CVBiLSTM(nn.Module):
    """Complex LSTM as published Eq.(4): cross-coupled real LSTMCell outputs and cell states.
    Two independent sets of real LSTMCell parameters for each direction; 4 cell calls/step.
    """
    def __init__(self,input_size=13,hidden_size=64):
        super().__init__()
        self.input_size=input_size;self.hidden_size=hidden_size
        self.fr=nn.LSTMCell(input_size,hidden_size);self.fi=nn.LSTMCell(input_size,hidden_size)
        self.br=nn.LSTMCell(input_size,hidden_size);self.bi=nn.LSTMCell(input_size,hidden_size)
    def _run(self,z,cell_r,cell_i,reverse=False):
        B,T,D=z.shape
        h_r=z.real.new_zeros(B,self.hidden_size);h_i=h_r.clone()
        c_r=h_r.clone();c_i=h_r.clone()
        outputs=[]
        ids=range(T-1,-1,-1) if reverse else range(T)
        for t in ids:
            xr=z.real[:,t,:];xi=z.imag[:,t,:]
            rr,crr=cell_r(xr,(h_r,c_r))
            ii,cii=cell_i(xi,(h_i,c_i))
            ri,cri=cell_r(xi,(h_i,c_i))
            ir,cir=cell_i(xr,(h_r,c_r))
            h_r,h_i=rr-ii,ri+ir
            c_r,c_i=crr-cii,cri+cir
            outputs.append(torch.complex(h_r,h_i))
        if reverse:outputs.reverse()
        return torch.stack(outputs,dim=1)
    def forward(self,z):
        if not torch.is_complex(z) or z.ndim!=3 or z.shape[-1]!=13:
            raise ValueError('Expected complex [B,13,13]')
        return torch.cat([self._run(z,self.fr,self.fi),self._run(z,self.br,self.bi,True)],dim=-1)


class CVHSTNet(nn.Module):
    """Table II geometry [B,1,224,224] complex => CNN [B,1,13,13], CVBiLSTM [B,13,128]."""
    def __init__(self):
        super().__init__()
        # Paper discloses kernel/channel/output shape; padding/strides here are declared adapters.
        self.conv1=CVConv2d(1,64,5,padding=2)
        self.conv2=CVConv2d(64,128,7,padding=2)
        self.conv3=CVConv2d(128,256,7,stride=2,padding=1)
        self.conv4=CVConv2d(256,1,1)
        self.seq=CVBiLSTM(13,64)
        self.fc=CVLinear(13*128,2)
    def conv_features(self,z):
        z=cavgpool(crelu(self.conv1(z)))
        z=cavgpool(crelu(self.conv2(z)))
        z=cavgpool(crelu(self.conv3(z)))
        z=self.conv4(z)
        return z
    def forward(self,tf):
        z=self.conv_features(tf)
        if tuple(z.shape[1:])!=(1,13,13):raise RuntimeError('CNN geometry mismatch '+str(z.shape))
        f=z[:,0,:,:].transpose(1,2).contiguous()  # STFT [frequency,time] -> BiLSTM [time,frequency]
        h=self.seq(f)
        logits_complex=self.fc(h.reshape(h.shape[0],-1))
        # Original Eq.(7)-(8): magnitude of complex binary logits -> softmax/CE.
        return torch.abs(logits_complex)


def model_info():
    net=CVHSTNet()
    return {'params':sum(p.numel() for p in net.parameters()),'expected_paper_approx_params':4_110_000,
        'description':'complex CNN 64/128/256 + complex BiLSTM hidden64 bidirectional + complex FC'}


def unit_smoke(device='cpu',backward=False):
    torch.manual_seed(9021)
    d=torch.device(device);net=CVHSTNet().to(d)
    n=torch.arange(512,device=d)
    x=(torch.exp(1j*2*math.pi*0.14*n).to(torch.complex64)*0.1)[None,:]
    tf=stft_iq512(x)
    assert tf.shape==(1,1,224,224) and tf.dtype==torch.complex64
    with torch.set_grad_enabled(backward):
        feat=net.conv_features(tf)
        assert feat.shape==(1,1,13,13),feat.shape
        out=net(tf)
        assert out.shape==(1,2) and torch.isfinite(out).all()
        if backward:
            loss=F.cross_entropy(out,torch.ones(1,device=d,dtype=torch.long))
            loss.backward()
            assert torch.isfinite(net.conv3.real.weight.grad).all()
    print('PASS_CVHSTNET_MODEL_SMOKE',device,'backward',backward,'parameters',model_info()['params'],flush=True)

if __name__=='__main__':unit_smoke()
