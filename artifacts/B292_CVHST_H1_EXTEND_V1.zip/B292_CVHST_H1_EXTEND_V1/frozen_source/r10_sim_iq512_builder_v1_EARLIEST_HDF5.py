#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SIM-R10 v1: reproducible 512-pulse complex-IQ scene generator (CPU only).
Compatible HDF5 writer edition: libver='earliest' (no IQ/physics changes).

Not a reproduction of Bai/Wen datasets. A new controlled simulation protocol for
A3/ADN-compatible *input format*, with matched train/cal/test scene families.
No deep model, scores, thresholds, Pd, FINAL real data or prior checkpoints read.

Uses scene-separated deterministic seeds, a target/background additive equation,
a power-defined *pre-Doppler* SCR, and independent H0 CAL and H0 AUDIT sets.

Two evaluation banks: in-distribution (ID) and unseen family (OOD) with a
fixed signal-generator domain shift. Test banks are not used to select models.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path
import sys
import h5py
import numpy as np

VERSION = 'SIM_R10_IQ512_GENERATOR_V1'
N = 512
TRAIN_FAMILIES = ('gaussian_colored', 'compound_gamma', 'nonstationary', 'sea_spikes', 'mixed')
OOD_FAMILY = 'unseen_multilobe'
PRESETS = {
    'pilot': dict(train=768, val=256, dev_h1=96, dev_ood_h1=64, h0_cal=4096, h0_audit=4096, h0_ood_audit=2048),
    'full': dict(train=30000, val=5000, dev_h1=2000, dev_ood_h1=2000, h0_cal=300000, h0_audit=300000, h0_ood_audit=150000),
}
SPLIT_NAMES = ('train', 'val', 'dev_h1', 'dev_ood_h1', 'h0_cal', 'h0_audit', 'h0_ood_audit')
DEFAULT_SCR_GRID = list(range(-30, 11, 5))


def fail(msg):
    raise RuntimeError(msg)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for piece in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(piece)
    return h.hexdigest()


def seed_for(master, stage, index):
    """Stable per-scene seed, independent of iteration order and other split sizes."""
    tag = f'SIM-R10-V1|{master}|{stage}|{index}'.encode()
    return int.from_bytes(hashlib.sha256(tag).digest()[:8], 'little', signed=False)


def prng(master, split, i):
    return np.random.default_rng(seed_for(master, split, i))


def cnormal(rng, size):
    return (rng.standard_normal(size) + 1j * rng.standard_normal(size)) / np.sqrt(2)


def normalize(x):
    x = np.asarray(x, dtype=np.complex128)
    return x / np.sqrt(np.mean(np.abs(x) ** 2) + 1e-30)


def colored_speckle(rng, lobes=1, wider=False):
    f = np.fft.fftfreq(N)
    p = np.full(N, 0.0015, dtype=np.float64)
    for j in range(lobes):
        ctr = float(rng.uniform(-0.08, 0.08)) if j == 0 else float(rng.uniform(-0.26, 0.26))
        width = float(rng.uniform(0.008, 0.045)) * (1.6 if wider else 1.0)
        # Circular normalized-frequency distance: no artificial Nyquist discontinuity.
        d = (f - ctr + 0.5) % 1.0 - 0.5
        p += float(rng.uniform(.35, 1.5)) * np.exp(-0.5 * (d / width) ** 2)
    y = np.fft.ifft(np.fft.fft(cnormal(rng, N)) * np.sqrt(p))
    return normalize(y)


def smooth_positive(rng, rho, sigma):
    u = rng.standard_normal(N)
    x = np.empty(N, np.float64)
    x[0] = float(u[0])
    scale = math.sqrt(1 - rho * rho)
    for k in range(1, N):
        x[k] = rho * x[k-1] + scale * u[k]
    return np.exp(sigma * x - 0.5 * sigma * sigma)


def transient_sea_spikes(rng, nspikes):
    t = np.arange(N, dtype=np.float64)
    y = np.zeros(N, np.complex128)
    for _ in range(nspikes):
        center = rng.uniform(12, N-12)
        width = rng.uniform(3, 34)
        amp = rng.uniform(1.0, 4.5)
        freq = rng.uniform(-.18, .18)
        chirp = rng.uniform(-.00025, .00025)
        tau = t - center
        env = np.exp(-0.5 * (tau / width) ** 2)
        ph = rng.uniform(-np.pi, np.pi) + 2 * np.pi * (freq * tau + chirp * tau * tau / 2)
        y += amp * env * np.exp(1j * ph)
    return y


def make_clutter(rng, family):
    # All families are zero-mean complex stochastic processes prior to target addition.
    if family == 'gaussian_colored':
        c = colored_speckle(rng)
    elif family == 'compound_gamma':
        shape = rng.uniform(0.35, 2.5)
        texture = rng.gamma(shape, 1.0 / shape)
        c = math.sqrt(texture) * colored_speckle(rng)
        c *= np.sqrt(smooth_positive(rng, rng.uniform(.965, .993), rng.uniform(.25, .75)))
    elif family == 'nonstationary':
        c = colored_speckle(rng, lobes=2)
        c *= np.sqrt(smooth_positive(rng, rng.uniform(.985, .997), rng.uniform(.6, 1.2)))
    elif family == 'sea_spikes':
        c = colored_speckle(rng)
        c += rng.uniform(.5, 2.1) * transient_sea_spikes(rng, int(rng.integers(1, 5)))
    elif family == 'mixed':
        shape = rng.uniform(.3, 1.6)
        c = math.sqrt(rng.gamma(shape, 1.0 / shape)) * colored_speckle(rng, lobes=2)
        c *= np.sqrt(smooth_positive(rng, rng.uniform(.975, .995), rng.uniform(.3, 1.0)))
        c += rng.uniform(.2, 1.4) * transient_sea_spikes(rng, int(rng.integers(1, 4)))
    elif family == OOD_FAMILY:
        # Held-out OOD generator: 3 wider Doppler lobes and more persistent textures.
        c = colored_speckle(rng, lobes=3, wider=True)
        c *= np.sqrt(smooth_positive(rng, rng.uniform(.991, .999), rng.uniform(.7, 1.3)))
        c += rng.uniform(.3, 1.5) * transient_sea_spikes(rng, int(rng.integers(2, 6)))
    else:
        fail(f'unknown clutter family {family}')
    # Nuisance scene power changes: do NOT globally normalize the final observation.
    nominal_power = 10.0 ** float(rng.uniform(-0.7, .7))
    # Preserve the compound-gamma scene texture and sea-spike amplitude tail.
    # The underlying Gaussian speckle is already normalized in colored_speckle().
    c = c * math.sqrt(nominal_power)
    return c.astype(np.complex64)


def make_unit_target(rng, overlap_probability=0.70):
    """Coherent target with Doppler, small acceleration, slow micro-motion, scintillation.

    One CUT = one point-target return across 512 pulses. This is intentionally
    NOT a 7x7 RD Gaussian and must not be claimed to reproduce Bai's input.
    """
    t = np.arange(N, dtype=np.float64)
    overlap = bool(rng.random() < overlap_probability)
    if overlap:
        doppler = float(rng.uniform(-.085, .085))
    else:
        doppler = float(rng.choice([-1, 1]) * rng.uniform(.09, .28))
    accel = float(rng.uniform(-8e-5, 8e-5))
    md_rate = float(rng.uniform(.002, .035))
    md_depth = float(rng.uniform(.0, .30))
    phase0 = float(rng.uniform(-np.pi, np.pi))
    phase_noise = np.cumsum(rng.standard_normal(N) * rng.uniform(.002, .024))
    phase = (phase0 + 2 * np.pi * (doppler * t + .5 * accel * t * t)
             + md_depth * np.sin(2 * np.pi * md_rate * t + phase0) + phase_noise)
    # Slowly varying return with physically plausible positive scintillation.
    envelope = np.sqrt(smooth_positive(rng, rng.uniform(.94, .995), rng.uniform(.05, .48)))
    unit = normalize(envelope * np.exp(1j * phase)).astype(np.complex64)
    return unit, doppler, overlap


def scene(rng, family, make_target):
    clutter = make_clutter(rng, family)
    clutter_power = float(np.mean(np.abs(clutter.astype(np.complex128)) ** 2))
    # Independent thermal noise, 8..17 dB below the mean sea-clutter power.
    noise_to_clutter_db = float(rng.uniform(-17, -8))
    nvar = clutter_power * 10.0 ** (noise_to_clutter_db / 10)
    noise = (cnormal(rng, N) * math.sqrt(nvar)).astype(np.complex64)
    unit, fd, overlap = make_unit_target(rng) if make_target else (
        np.zeros(N, np.complex64), float('nan'), False)
    return clutter, noise, unit, clutter_power, noise_to_clutter_db, fd, overlap


def family_for(rng, i, split):
    if split in ('dev_ood_h1','h0_ood_audit'):
        return OOD_FAMILY
    # Equal expected family mix; no detector-conditioned sampling.
    return TRAIN_FAMILIES[int(rng.integers(len(TRAIN_FAMILIES)))]


def chunk_iter(n, b):
    for a in range(0, n, b):
        yield a, min(n, a+b)


def create_dsets(h, name, count, *, trainlike, eval_h1, chunk):
    g = h.create_group(name)
    g.attrs['seed_isolated_split'] = name
    g.attrs['pulse_count'] = N
    kw = dict(chunks=(min(chunk, max(1, count)), N), compression='lzf', shuffle=True)
    if trainlike:
        for k in ('iq', 'target_iq', 'clutter_iq', 'noise_iq'):
            g.create_dataset(k, (count, N), dtype='complex64', **kw)
        g.create_dataset('label', (count,), dtype='uint8')
        g.create_dataset('scr_db', (count,), dtype='float32')
    elif eval_h1:
        for k in ('base_iq', 'unit_target_iq', 'clutter_iq', 'noise_iq'):
            g.create_dataset(k, (count, N), dtype='complex64', **kw)
        g.create_dataset('clutter_power', (count,), dtype='float64')
    else:
        g.create_dataset('iq', (count, N), dtype='complex64', **kw)
        g.create_dataset('clutter_power', (count,), dtype='float64')
    for k, ty in [('scene_seed', 'uint64'), ('family_index', 'uint8'),
                  ('noise_to_clutter_db', 'float32'), ('target_fd', 'float32'),
                  ('target_clutter_overlap', 'uint8')]:
        g.create_dataset(k, (count,), dtype=ty)
    return g


def make_one(master, split, i, scr_lo, scr_hi):
    rng = prng(master, split, i)
    family = family_for(rng, i, split)
    is_train = split in ('train', 'val')
    is_eval = split in ('dev_h1', 'dev_ood_h1')
    label = (i % 2) if is_train else (1 if is_eval else 0)
    clutter, noise, unit, cp, noise_db, fd, overlap = scene(rng, family, make_target=bool(label))
    base = (clutter.astype(np.complex128) + noise.astype(np.complex128)).astype(np.complex64)
    scr_db = float(rng.uniform(scr_lo, scr_hi)) if bool(label) and is_train else float('nan')
    amp = math.sqrt(cp * 10.0 ** (scr_db / 10)) if label and is_train else 0.0
    target = (unit.astype(np.complex128) * amp).astype(np.complex64)
    x = (base.astype(np.complex128) + target.astype(np.complex128)).astype(np.complex64)
    idx = 255 if family == OOD_FAMILY else TRAIN_FAMILIES.index(family)
    return dict(iq=x, base=base, target=target, unit=unit, clutter=clutter, noise=noise,
                cp=cp, label=int(label), scr=scr_db, family=idx, seed=seed_for(master, split, i),
                noise_db=noise_db, fd=fd, overlap=int(overlap))


def write_split(g, master, split, count, scr_lo, scr_hi, chunk):
    scr_errs = []
    h0_max = 0.0
    for a, b in chunk_iter(count, chunk):
        batch = [make_one(master, split, i, scr_lo, scr_hi) for i in range(a, b)]
        def v(field, dtype):
            return np.asarray([r[field] for r in batch], dtype=dtype)
        if split in ('train', 'val'):
            g['iq'][a:b] = v('iq', np.complex64)
            g['target_iq'][a:b] = v('target', np.complex64)
            g['clutter_iq'][a:b] = v('clutter', np.complex64)
            g['noise_iq'][a:b] = v('noise', np.complex64)
            g['label'][a:b] = v('label', np.uint8)
            g['scr_db'][a:b] = v('scr', np.float32)
            for r in batch:
                if r['label']:
                    ptarget = np.mean(np.abs(r['target'].astype(np.complex128)) ** 2)
                    scr_real = 10 * math.log10(ptarget / r['cp'])
                    scr_errs.append(abs(scr_real-r['scr']))
                else:
                    h0_max = max(h0_max, float(np.max(np.abs(r['target']))))
        elif split in ('dev_h1', 'dev_ood_h1'):
            for key, field in [('base_iq','base'),('unit_target_iq','unit'),
                               ('clutter_iq','clutter'),('noise_iq','noise')]:
                g[key][a:b] = v(field, np.complex64)
            g['clutter_power'][a:b] = v('cp', np.float64)
        else:
            g['iq'][a:b] = v('base', np.complex64)
            g['clutter_power'][a:b] = v('cp', np.float64)
        for key, field, dtype in (
            ('scene_seed', 'seed', np.uint64), ('family_index','family',np.uint8),
            ('noise_to_clutter_db','noise_db',np.float32),
            ('target_fd','fd',np.float32), ('target_clutter_overlap','overlap',np.uint8)):
            g[key][a:b] = v(field, dtype)
        if (b == count or (count >= 30000 and b % 10000 < chunk)):
            print(f'    {split}: {b}/{count}', flush=True)
    if scr_errs:
        req = float(max(scr_errs))
        if req > 0.0002: fail(f'{split}: injected SCR mismatch {req:.6f} dB')
    if h0_max > 0: fail(f'{split}: H0 with nonzero target signal')
    return max(scr_errs) if scr_errs else 0.0


def build(args):
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    hp = out / 'sim_r10_iq512_v1.h5'
    contract = out / 'sim_r10_iq512_v1_contract.json'
    if hp.exists() or contract.exists():
        fail(f'output already exists, will not overwrite: {hp} / {contract}')
    counts = PRESETS[args.preset].copy()
    for split in counts:
        val = getattr(args, split)
        if val is not None: counts[split] = val
    if any(int(n) <= 0 for n in counts.values()): fail('all split counts must be positive')
    if counts['train'] % 2 or counts['val'] % 2: fail('train/val counts must be even for balanced labels')
    if args.seed < 0: fail('seed must be non-negative')
    if args.scr_min >= args.scr_max: fail('SCR min must be less than max')
    if args.chunk < 1: fail('chunk must be >=1')

    print('SIM-R10 — IQ512 PHYSICS-FIRST BUILDER V1 (EARLIEST-HDF5 EDITION)')
    print(f'  preset={args.preset} seed={args.seed} counts={counts}')
    print(f'  train target SCR = Uniform({args.scr_min}, {args.scr_max}) dB')
    print('  model/score/threshold access = NO')
    print('  final real-data access = NO')
    print('  independent H0 CAL and H0 AUDIT = YES')
    print('  dataset is NOT Bai or Wen exact reproduction')
    tmp = out / '.sim_r10_iq512_v1.tmp.h5'
    try:
        with h5py.File(tmp, 'w', libver='earliest') as h:
            h.attrs['version'] = VERSION
            h.attrs['seed'] = int(args.seed)
            h.attrs['pulse_count'] = N
            h.attrs['scr_definition'] = '10log10(mean(|clean target|^2)/mean(|clean clutter|^2)), pre-Doppler'
            h.attrs['h0_definition'] = 'no target; clutter plus independent thermal noise'
            h.attrs['units'] = 'normalized complex baseband IQ per pulse'
            h.attrs['family_names_json'] = json.dumps(list(TRAIN_FAMILIES) + [OOD_FAMILY])
            h.attrs['default_development_scnr_grid_json'] = json.dumps(DEFAULT_SCR_GRID)
            h.attrs['train_scr_min_db'] = float(args.scr_min)
            h.attrs['train_scr_max_db'] = float(args.scr_max)
            for split in SPLIT_NAMES:
                print(f'[{SPLIT_NAMES.index(split)+1}/7] {split}: n={counts[split]}', flush=True)
                g = create_dsets(h, split, counts[split], trainlike=split in ('train','val'),
                                  eval_h1=split in ('dev_h1','dev_ood_h1'), chunk=args.chunk)
                err = write_split(g, args.seed, split, counts[split], args.scr_min, args.scr_max, args.chunk)
                g.attrs['max_realized_scr_error_db'] = float(err)
            h.flush()
        tmp.replace(hp)
    except Exception:
        tmp.unlink(missing_ok=True)
        raise
    data = dict(version=VERSION, status='PASS_SIM_R10_IQ512_BUILDER_V1__SEVEN_DISJOINT_SPLITS__NO_MODEL_SCORES',
                created_utc=datetime.now(timezone.utc).isoformat(), preset=args.preset,
                seed=args.seed, counts=counts, n_pulses=N,
                file=hp.name, file_sha256=sha(hp), generator_sha256=sha(Path(__file__)),
                train_scr_db=[args.scr_min, args.scr_max],
                development_scnr_grid_db=DEFAULT_SCR_GRID,
                train_families=list(TRAIN_FAMILIES), heldout_ood_family=OOD_FAMILY,
                target_signal_model='coherent phase-continuous Doppler plus mild chirp/micro-motion/amplitude fluctuation',
                background_model='colored Gaussian; compound-gamma; nonstationary; sea-spikes; mixed; held-out multi-lobe',
                scr_definition='10log10(mean(|target IQ|^2)/mean(|clutter IQ|^2)); noise excluded from denominator',
                pfa=None, pfa_claim='NONE: pilot H0 samples cannot calibrate Pfa=1e-4',
                scientific_role='DEVELOPMENT generator; no independent locked final test generated yet',
                train_and_test_share_realizations=False,
                simulation_is_not_a_digital_twin_of_measured_2025_clutter=True)
    contract.write_text(json.dumps(data, indent=2, ensure_ascii=False)+'\n', encoding='utf8')
    print('\n'+data['status'])
    print('  h5      =', hp)
    print('  contract=', contract)
    print('  SHA256  =',data['file_sha256'])


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--preset', choices=('pilot','full'), default='pilot')
    ap.add_argument('--out', required=True)
    ap.add_argument('--seed', type=int, default=20261008)
    ap.add_argument('--scr-min', type=float, default=-30.0)
    ap.add_argument('--scr-max', type=float, default=10.0)
    ap.add_argument('--chunk', type=int, default=128)
    for k in PRESETS['pilot']:
        ap.add_argument('--'+k.replace('_','-'), dest=k, type=int)
    args=ap.parse_args()
    build(args)


if __name__ == '__main__':
    main()
