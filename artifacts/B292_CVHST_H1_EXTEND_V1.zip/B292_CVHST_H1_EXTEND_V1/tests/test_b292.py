"""Synthetic regression tests. No real CVHSTNet checkpoint/Pd is available here."""
import contextlib
import io
import shutil
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import numpy as np
import torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from b292_common import ROOT,PFAS,OLD_GRID,NAME,readj,writej,writecsv,fp,sha,frozen,unchanged
from b292_stats import cutoff
from b292_source import inputs,load_model,h1_iq,predict,overlap
from b292_extend import cli,has_sustained90,extend,report,main

def fixture(root):
    torch.manual_seed(42);root.mkdir(parents=True,exist_ok=True)
    a=SimpleNamespace(root=root,train_dir=root/'old_train',score_dir=root/'old_score',out_dir=root/'output_b292_cvhst_fixture',
        device=torch.device('cpu'),batch=2,chunk=128,cpu_threads=2,max_scr=20,run_to_max=False)
    a.out_dir.mkdir();train=a.train_dir/'CVHSTNet_2025/seed_20261022';train.mkdir(parents=True);a.score_dir.mkdir()
    expected=root/'expected';(expected/'frozen_source').mkdir(parents=True)
    shutil.copy2(ROOT/'frozen_source/cvhstnet_model.py',expected/'frozen_source/cvhstnet_model.py')
    c=readj(ROOT/'expected_training_contract.json');contract=readj(ROOT/'expected_score_contract.json')
    model=frozen('cvhstnet_model.py').CVHSTNet().eval()
    torch.save(dict(signature=c['signature'],train_only_input_rms=c['signature']['input_scale_train_only_rms'],state_dict=model.state_dict()),train/'sim_r10_final.pt')
    c['checkpoint_sha256']=sha(train/'sim_r10_final.pt');contract['model_checkpoint_sha256']=c['checkpoint_sha256']
    writej(train/'training_contract.json',c);writej(a.score_dir/'contract.json',contract)
    writej(expected/'expected_training_contract.json',c);writej(expected/'expected_score_contract.json',contract)
    writej(a.score_dir/'progress.json',dict(done=True,h0_cal=3000000,h0_audit=1000000,h1_scr_done=37))
    cal=np.linspace(-1,1,3000000);audit=np.linspace(-1,1,1000000)
    h1=np.tile(np.linspace(-2,2,1024),(37,1))+np.arange(37)[:,None]/100
    for name,v in [('h0_cal_scores.npy',cal),('h0_audit_scores.npy',audit),('dev_h1_scores_37.npy',h1)]:np.save(a.score_dir/name,v)
    ms=[];curves=[]
    for pfa in PFAS:
        t,k,count=cutoff(cal,pfa);hits=int((audit>t).sum())
        ms.append(dict(method=NAME,nominal_pfa=pfa,threshold=t,h0_cal_hits=count,h0_cal_n=len(cal),
            h0_audit_hits=hits,h0_audit_n=len(audit),actual_pfa=hits/len(audit)))
        for scr,row in zip(OLD_GRID,h1):
            count=int((row>t).sum());curves.append(dict(method=NAME,nominal_pfa=pfa,scr_db=scr,pd=count/1024,hits=count,n_h1=1024))
    writecsv(a.score_dir/'b241_metrics.csv',ms);writecsv(a.score_dir/'b241_curves.csv',curves)
    with patch('b292_source.ROOT',expected):info=inputs(a)
    p=dict(extension_grid_db=list(range(13,21)),h1_per_scr=1024,fixture_only=True)
    p['fingerprint']=fp(p)
    return a,info,p,expected

def fake_infer(scr,indices):
    hits={13:800,14:940,15:960,16:980}.get(scr,990)
    return np.where(np.asarray(indices)<hits,2.,-2.).astype('float64')

class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):torch.set_num_threads(2)

    def test_readonly_source_validation_native_forward_and_old_H1_reconstruction(self):
        with tempfile.TemporaryDirectory() as tmp:
            a,info,p,expected=fixture(Path(tmp));model,scale,mm=load_model(a,info)
            ids=np.array([0]);iq=h1_iq(info,13,ids)
            value=predict(model,mm,scale,iq,a)
            with torch.inference_mode():
                z=model(mm.stft_iq512(torch.from_numpy(iq),scale));reference=(z[:,1]-z[:,0]).numpy().astype('float64')
            np.testing.assert_array_equal(value,reference);self.assertTrue(np.isfinite(value).all())
            self.assertFalse(any(v.requires_grad for v in model.parameters()));self.assertTrue(unchanged(info))
            np.save(a.score_dir/'dev_h1_scores_37.npy',np.zeros((37,1024)))
            with patch('b292_source.ROOT',expected):
                with self.assertRaisesRegex(RuntimeError,'disagrees'):inputs(a)

    def test_overlap_requires_both_numeric_and_decision_agreement(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            a,info,p,_=fixture(Path(tmp))
            def exact(scr,ids):return info['arrays']['h1'][OLD_GRID.index(scr),ids].copy()
            checks=overlap(a,info,exact);self.assertEqual(len(checks),2)
            def wrong(scr,ids):return exact(scr,ids)+1.
            with self.assertRaisesRegex(RuntimeError,'overlap mismatch'):overlap(a,info,wrong)
            t=info['thresholds'][1e-4];info['arrays']['h1']=np.full((37,1024),t)
            with self.assertRaisesRegex(RuntimeError,'overlap mismatch'):
                overlap(a,info,lambda scr,ids:np.full(len(ids),t+1e-8))

    def test_interruption_resume_sustained_stop_and_exact_old_prefix_report(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            a,info,p,_=fixture(Path(tmp));stopped=[]
            def interrupted(scr,ids):
                if scr==14 and not stopped:stopped.append(True);raise RuntimeError('synthetic network interruption')
                return fake_infer(scr,ids)
            with self.assertRaisesRegex(RuntimeError,'interruption'):extend(a,info,interrupted,p)
            self.assertEqual(readj(a.out_dir/'progress.json')['completed_scr'],1)
            values,pr=extend(a,info,fake_infer,p);self.assertEqual(pr['completed_scr'],4);self.assertTrue(pr['finished'])
            old_sha=sha(a.out_dir/'extended_h1_scores.npy');again,_=extend(a,info,fake_infer,p)
            self.assertEqual(sha(a.out_dir/'extended_h1_scores.npy'),old_sha);np.testing.assert_array_equal(values,again)
            result=report(a,info,values,p,pr)
            self.assertTrue(all(r['reached_pd_0_9'] for r in result['metrics']))
            self.assertTrue(all(r['first_observed_scr_pd_ge_0_9']==14 for r in result['metrics']))
            self.assertTrue(result['thresholds_reused']);self.assertFalse(result['training_executed']);self.assertFalse(result['H0_inference_executed'])
            self.assertTrue((a.out_dir/'b292_cvhst_pd_scr_pfa_1e-05.pdf').is_file())
            from b292_common import readcsv
            rows=readcsv(a.out_dir/'b292_curves.csv')
            for q in PFAS:
                new=[r for r in rows if float(r['nominal_pfa'])==q and int(r['scr_db'])<=12]
                old=sorted([r for r in info['curves'] if float(r['nominal_pfa'])==q],key=lambda r:int(r['scr_db']))
                self.assertEqual([(r['pd'],r['hits']) for r in new],[(str(float(r['pd'])),str(int(r['hits']))) for r in old])
            self.assertTrue(unchanged(info))

    def test_cap_reports_not_reached_and_never_forces_monotonicity(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            a,info,p,_=fixture(Path(tmp));p['extension_grid_db']=[13,14,15];p.pop('fingerprint');p['fingerprint']=fp(p)
            values,pr=extend(a,info,lambda scr,ids:np.full(len(ids),-scr,dtype='float64'),p)
            self.assertEqual(pr['stop_reason'],'reached_predeclared_SCR_cap')
            result=report(a,info,values,p,pr)
            self.assertTrue(all(not r['reached_pd_0_9'] and r['D90_db'] is None for r in result['metrics']))
            self.assertTrue(np.all(np.diff(values[:,0])<0))
        self.assertFalse(has_sustained90(np.ones((3,1024)),{1e-4:1.,1e-5:1.}))
        self.assertFalse(has_sustained90(np.ones((2,1024))*2,{1e-4:1.}))

    def test_CLI_preserves_old_directories(self):
        with tempfile.TemporaryDirectory() as tmp:
            a=cli(['--root',tmp,'--device','cpu']);self.assertEqual(a.max_scr,60);self.assertEqual(a.batch,4)
            with self.assertRaisesRegex(RuntimeError,'fresh'):
                cli(['--root',tmp,'--device','cpu','--out-dir',str(Path(tmp)/'output_sim_r10_b241_cvhstnet_paired_v1')])

    def test_main_entrypoint_resume_and_report_without_H0_model_calls(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            a,info,_,_=fixture(Path(tmp));calls=[];epsilon=[0.]
            args=['--root',tmp,'--device','cpu','--out-dir',str(a.out_dir),'--max-scr','13']
            def prediction(model,mm,scale,tag,args):
                scr,ids=tag;calls.append(scr)
                if scr<=12:return info['arrays']['h1'][OLD_GRID.index(scr),ids].copy()+epsilon[0]
                return np.full(len(ids),2.)+epsilon[0]
            with patch('b292_extend.inputs',return_value=info),patch('b292_extend.load_model',return_value=(object(),1.,object())),\
                 patch('b292_extend.h1_iq',side_effect=lambda info,scr,ids:(scr,ids)),patch('b292_extend.predict',side_effect=prediction):
                main(args);first=sha(a.out_dir/'extended_h1_scores.npy');epsilon[0]=1e-7;main(args)
                self.assertEqual(first,sha(a.out_dir/'extended_h1_scores.npy'))
                self.assertTrue(readj(a.out_dir/'resume_overlap_last.json')['passed'])
                with patch('b292_extend.load_model',side_effect=AssertionError('report must not load model')):main(args+['--report-only'])
            self.assertEqual(set(calls),{0,12,13});self.assertTrue(unchanged(info))

if __name__=='__main__':unittest.main()
