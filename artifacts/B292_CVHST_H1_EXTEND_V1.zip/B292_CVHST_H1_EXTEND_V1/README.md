# B292：CVHSTNet 旧模型 H1 曲线右延伸

只加载原 **B241 final25 CVHSTNet-2025-SIM-adapt**，保持模型、输入预处理、全局 TRAIN RMS 和已有两个 H0 CAL 阈值不变，不训练、不跑 H0 推理、不运行 ADN 或 Ours。不是 B241R 的 VAL-best 变体，也不会自动换成该权重。

原复现是论文 *Overcoming Data Scarcity in Maritime Radar Target Detection via a Complex-Valued Hybrid Spatiotemporal Network* 的 SIM-R10 接口适配实现，DOI `10.1109/LGRS.2025.3557817`；没有作者原代码等价性保证。本包逐字保留已有 `cvhstnet_model.py`，模型 SHA 为 `db857eb65f5c7e549e085650191a2e59bcdfef721468d6c1dd159c7b32b3afad`。

## 默认行为

1. 核对旧训练 contract、评分 contract、完成进度、权重 SHA、模型/生成器 SHA。
2. 读取已有 H0 CAL/AUDIT 数组，核对保存阈值和实际虚警；读取原 H1 分数，核对每一个旧 Pd 点。仅做 CPU 数组运算，**没有 H0 神经网络推理**。
3. 用原权重复算 SCR=0、+12 dB，各1024场景。要求分数在数值容差内，且两个阈值下判决完全一致，再接续曲线。
4. 从 **+13 dB** 开始每1 dB补1024个 H1，最多到 **+60 dB**。沿用原 `dev_h1` 场景 ID、杂波底、目标单位波形及注入公式。
5. **两个 Pfa 都连续三个新点 Pd≥0.9** 就停止；否则到上限。首次观察到 Pd≥0.9 的 SCR、插值 D90、真实最大 Pd及所有峰值位置均报告。停止条件依据观测 Pd，不是置信区间保证。
6. 合并旧 -24…+12 dB 的37个原始数值，画更宽范围的曲线。两个虚警率为 **1e-4、1e-5**。不做单调包络、曲线平移、阈值重调或模型替换；高 SCR 若性能下降也原样显示。

旧名义虚警1e-4的实际虚警为145/1M，1e-5为18/1M，延伸不改变它们。原先曲线在高 SCR 已下降，推到更右边也可能达不到0.9。未达到时 D90 为空，并报告 `reached_pd_0_9=false`，不是程序失败。

## 上传后启动

把 ZIP 上传到项目目录，并执行解压和启动：

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
unzip -n B292_CVHST_H1_EXTEND_V1.zip
bash B292_CVHST_H1_EXTEND_V1/start_on_autodl.sh
tail -F codex_b292_cvhst_extend.log
```

默认 CUDA，使用共享 `codex_b271_night.lock` 排队等待 B291 等使用同一锁的任务。不会终止其他任务。启动器使用 `nohup` 和 `conda run -n mpdnet-r10`，普通热点/SSH断开不影响后台进程。服务器停止、关机或进程被杀会中断，重复相同命令会从最后完成的 SCR 恢复；未完成的一个 SCR 会重算。

独立 CPU 运行也支持，CPU 将不会等待 GPU，但可能慢很多；二选一启动，不要重复启动两份：

```bash
bash B292_CVHST_H1_EXTEND_V1/start_on_autodl.sh --device cpu
```

默认额外最多48×1024=49,152条 H1，另有2,048条接续核对。相比重新评分400万H0工作量少很多，真实耗时以日志中每个SCR的秒数为准。

## 依赖旧文件

默认权重目录：

```
output_sim_r10_b241_cvhstnet_train_v1/CVHSTNet_2025/seed_20261022/
  sim_r10_final.pt
  training_contract.json
```

预期权重 SHA：`c9bcc8616f8d5242afda2831b0c900c5daf211d751261da0759f6b7f0b6fe8a6`。

默认原评分目录：

```
output_sim_r10_b241_cvhstnet_paired_v1/
  contract.json
  progress.json
  h0_cal_scores.npy             # [3000000] float64
  h0_audit_scores.npy           # [1000000] float64
  dev_h1_scores_37.npy          # [37,1024] float64
  b241_metrics.csv
  b241_curves.csv
```

无需旧 B222、Rank mix、原训练 IQ bank或其他模型文件。本包已带原 CVHSTNet 和原场景生成器。若两个目录只是移动，可传 `--train-dir /实际训练根目录 --score-dir /实际评分目录`。缺权重/分数时明确报错，不会偷偷重训或改阈值。

## 新结果

输出 `output_b292_cvhst_h1_extend_v1`，与所有旧文件分开：

- `b292_cvhst_pd_scr_pfa_1e-04.pdf/png`、`b292_cvhst_pd_scr_pfa_1e-05.pdf/png`。
- `b292_metrics.csv`：最大Pd、峰值SCR、D50/D80/D90、首次实测≥0.9位置、最后点Pd、实际虚警及区间。
- `b292_curves.csv`、`b292_pd_source_pfa_*.csv`：合并的逐点Pd和H1计数。
- `extended_h1_scores.npy`：仅新增部分的分数；只读取 progress 中已提交的行，预分配未使用行不代表结果。
- `protocol_frozen.json`、`progress.json`、`b292_report.json`：来源、接续检查、停止原因和文件校验。

默认最多+60；若到该上限未达到，可另开一个新输出目录进行更大上限诊断（最多+80）。`--run-to-max` 会关闭提前停止。更改上限/运行设备/配置需要新的 `--out-dir`，不覆盖已有结果。

完成后只重画图，CPU即可：

```bash
/root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  bash B292_CVHST_H1_EXTEND_V1/run_b292.sh --report-only
```

## 验证范围

`VALIDATION.json` 记录 CPU 合成测试。测试覆盖原结构前向、冻结权重、旧阈值与逐点CSV一致性、接续分数和判决检查、H1中断恢复、提前停止/上限未达、两个虚警率绘图和旧文件不变。测试权重/分数为临时合成fixture，未获得 AutoDL 实际权重或原始分数，因此没有实际延伸结果、GPU性能或Pd提升声明。所有结果仍为已暴露的 SIM-R10 DEV 范围扩展诊断。
