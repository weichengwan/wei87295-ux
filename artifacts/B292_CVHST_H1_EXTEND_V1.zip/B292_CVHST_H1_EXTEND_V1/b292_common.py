import csv
import hashlib
import importlib.util
import json
import sys
from functools import lru_cache
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PFAS=(1e-4,1e-5)
OLD_GRID=list(range(-24,13))
NAME='CVHSTNet-2025-SIM-adapt'

def need(v,msg):
    if not bool(v):raise RuntimeError('B292 STOP: '+msg)
def readj(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(8<<20),b''):h.update(b)
    return h.hexdigest()
def fp(obj):return hashlib.sha256(json.dumps(obj,sort_keys=True,allow_nan=False).encode()).hexdigest()
def writej(path,obj):
    path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8');tmp.replace(path)
def readcsv(path):
    with Path(path).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def writecsv(path,rows):
    need(bool(rows),'No CSV rows')
    with Path(path).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def validate():
    for name,value in readj(ROOT/'frozen_sources.json').items():need(sha(ROOT/name)==value,'Bundled original source changed: '+name)
def code_hashes():
    paths=list(ROOT.glob('*.py'))+list((ROOT/'frozen_source').glob('*.py'))+list(ROOT.glob('expected_*.json'))+[ROOT/'frozen_sources.json']
    return {p.relative_to(ROOT).as_posix():sha(p) for p in sorted(paths)}
@lru_cache(None)
def frozen(name):
    path=ROOT/'frozen_source'/name
    need(sha(path)==readj(ROOT/'frozen_sources.json')['frozen_source/'+name],'Frozen implementation changed')
    spec=importlib.util.spec_from_file_location('b292_'+name.replace('.','_'),path)
    m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);return m

def unchanged(info):
    need(all(sha(p)==s for p,s in info['protected'].items()),'A protected CVHSTNet source changed')
    return True
