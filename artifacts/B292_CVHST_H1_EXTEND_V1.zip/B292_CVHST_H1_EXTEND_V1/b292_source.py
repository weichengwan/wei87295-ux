"""Read existing B241 final25 scores/checkpoint only; never switch to B241R."""
import numpy as np
import torch
from b292_common import ROOT,PFAS,OLD_GRID,NAME,need,readj,readcsv,sha,frozen
from b292_stats import cutoff

def inputs(a):
    train=a.train_dir/'CVHSTNet_2025/seed_20261022';folder=a.score_dir
    ck=train/'sim_r10_final.pt';tc=train/'training_contract.json'
    need(ck.is_file() and tc.is_file(),'Missing existing B241 checkpoint/contract: '+str(train)+'; no retraining attempted')
    c=readj(tc);contract=readj(folder/'contract.json');pr=readj(folder/'progress.json')
    need(c==readj(ROOT/'expected_training_contract.json'),'Existing training contract differs from historical B241 final25')
    need(contract==readj(ROOT/'expected_score_contract.json'),'Existing score contract differs from historical B241 curve')
    need(pr==dict(done=True,h0_cal=3000000,h0_audit=1000000,h1_scr_done=37),'Old scoring is incomplete')
    need(sha(ck)==c['checkpoint_sha256']==contract['model_checkpoint_sha256'],'Checkpoint SHA differs')
    need(sha(ROOT/'frozen_source/cvhstnet_model.py')==contract['model_source_sha256'],'Model source differs')
    gen=frozen('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
    need(sha(gen.__file__)==contract['generator_sha256'],'Generator differs')
    shapes=dict(h0_cal=(3000000,),h0_audit=(1000000,),h1=(37,1024))
    files=dict(h0_cal='h0_cal_scores.npy',h0_audit='h0_audit_scores.npy',h1='dev_h1_scores_37.npy')
    arrays={}
    for key,name in files.items():
        arr=np.load(folder/name,mmap_mode='r',allow_pickle=False)
        need(arr.shape==shapes[key] and arr.dtype==np.float64 and np.isfinite(arr).all(),'Old score array malformed: '+name)
        arrays[key]=arr
    metrics=readcsv(folder/'b241_metrics.csv');curves=readcsv(folder/'b241_curves.csv')
    thresholds={}
    for pfa in PFAS:
        ms=[r for r in metrics if float(r['nominal_pfa'])==pfa]
        need(len(ms)==1,'Ambiguous old metric');m=ms[0];threshold=float(m['threshold'])
        derived,k,cfp=cutoff(arrays['h0_cal'],pfa)
        need(threshold==derived and int(m['h0_cal_hits'])==cfp and int(m['h0_cal_n'])==len(arrays['h0_cal']),'Saved threshold disagrees with old CAL')
        n0=len(arrays['h0_audit']);hits=int((arrays['h0_audit']>threshold).sum())
        need(hits==int(m['h0_audit_hits']) and int(m['h0_audit_n'])==n0 and float(m['actual_pfa'])==hits/n0,'Old audit metric differs')
        rows=sorted([r for r in curves if float(r['nominal_pfa'])==pfa],key=lambda r:int(r['scr_db']))
        need([int(r['scr_db']) for r in rows]==OLD_GRID,'Old curve grid differs')
        for j,r in enumerate(rows):
            count=int((arrays['h1'][j]>threshold).sum())
            need(r['method']==NAME and int(r['hits'])==count and int(r['n_h1'])==1024 and float(r['pd'])==count/1024,'Old Pd CSV disagrees with raw scores')
        thresholds[pfa]=threshold
    protected=[ck,tc,folder/'contract.json',folder/'progress.json',folder/'b241_metrics.csv',folder/'b241_curves.csv']
    protected.extend(folder/x for x in files.values())
    return dict(contract=contract,training=c,checkpoint=ck,generator=gen,arrays=arrays,thresholds=thresholds,
        metrics=metrics,curves=curves,protected={str(p):sha(p) for p in protected})

def load_model(a,info):
    try:ck=torch.load(info['checkpoint'],map_location='cpu',weights_only=True)
    except TypeError:ck=torch.load(info['checkpoint'],map_location='cpu')
    need(ck['signature']==info['training']['signature'],'Checkpoint signature differs')
    scale=float(ck['train_only_input_rms'])
    need(scale==info['contract']['input_scale_train_only_rms'],'Checkpoint TRAIN-only input scale differs')
    mm=frozen('cvhstnet_model.py');model=mm.CVHSTNet()
    model.load_state_dict(ck['state_dict'],strict=True)
    return model.to(a.device).eval().requires_grad_(False),scale,mm

def h1_iq(info,scr,indices):
    g=info['generator'];c=info['contract']
    rows=[g.make_one(c['B213_master_seed'],'dev_h1',int(i),-30,10) for i in indices]
    need(all(r['label']==1 for r in rows),'H1 generator label differs')
    base=np.stack([r['base'] for r in rows]).astype('complex128')
    unit=np.stack([r['unit'] for r in rows]).astype('complex128')
    cp=np.asarray([r['cp'] for r in rows],dtype='float64')
    need(np.isfinite(cp).all() and (cp>0).all(),'Invalid original H1 power')
    return (base+unit*np.sqrt(cp*10**(scr/10))[:,None]).astype('complex64')

@torch.inference_mode()
def predict(model,mm,scale,iq,a):
    values=[]
    for start in range(0,len(iq),a.batch):
        x=torch.from_numpy(np.ascontiguousarray(iq[start:start+a.batch])).to(a.device)
        z=model(mm.stft_iq512(x,scale))
        need(z.shape==(len(x),2) and torch.isfinite(z).all(),'Invalid CVHSTNet logits')
        # Preserve original B241 float32 subtraction, then convert to float64.
        values.append((z[:,1]-z[:,0]).cpu().numpy().astype('float64'))
    return np.concatenate(values)

def overlap(a,info,infer):
    results=[]
    for scr in (0,12):
        value=infer(scr,np.arange(1024));old=info['arrays']['h1'][OLD_GRID.index(scr)]
        error=float(np.abs(value-old).max())
        decisions={str(k):int(np.count_nonzero((value>t)!=(old>t))) for k,t in info['thresholds'].items()}
        need(np.allclose(value,old,rtol=2e-4,atol=5e-4) and not any(decisions.values()),
            f'Old-vs-new overlap mismatch at SCR{scr}: maxabs={error}, decisions={decisions}; old curves preserved')
        results.append(dict(scr_db=scr,n=1024,maxabs_score_difference=error,decision_disagreements=decisions))
        print(f'Old CVHSTNet replay passed: SCR={scr:+d}, n=1024, maxabs={error:.3g}',flush=True)
    return results
