"""CVHSTNet H1-only SCR extension; old model, old threshold, old prefix."""
import argparse
import fcntl
import time
from pathlib import Path
import numpy as np
import torch
from b292_common import ROOT,PFAS,OLD_GRID,NAME,need,readj,writej,writecsv,fp,sha,code_hashes,validate,unchanged
from b292_source import inputs,load_model,h1_iq,predict,overlap
from b292_stats import wilson,crossing

def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=ROOT.parent)
    for key in ('train-dir','score-dir','out-dir'):p.add_argument('--'+key,type=Path)
    p.add_argument('--max-scr',type=int,default=60)
    p.add_argument('--batch',type=int,default=4);p.add_argument('--chunk',type=int,default=64)
    p.add_argument('--cpu-threads',type=int,default=2)
    p.add_argument('--device',choices=('cpu','cuda'),default='cuda')
    p.add_argument('--wait-for-gpu',action='store_true')
    p.add_argument('--run-to-max',action='store_true',help='Continue to the cap even after both Pfas reach .9 three times')
    p.add_argument('--report-only',action='store_true')
    a=p.parse_args(argv);a.root=a.root.resolve()
    for key,name in [('train_dir','output_sim_r10_b241_cvhstnet_train_v1'),('score_dir','output_sim_r10_b241_cvhstnet_paired_v1'),('out_dir','output_b292_cvhst_h1_extend_v1')]:
        setattr(a,key,(getattr(a,key) or a.root/name).resolve())
    need(a.root.is_dir() and a.out_dir.parent==a.root and a.out_dir.name.startswith('output_b292_cvhst_'),'Use direct fresh output_b292_cvhst_* directory')
    for source in (a.train_dir,a.score_dir):need(source!=a.out_dir and source not in a.out_dir.parents and a.out_dir not in source.parents,'Output overlaps source')
    need(13<=a.max_scr<=80 and 1<=a.batch<=8 and a.chunk>=a.batch and a.chunk%a.batch==0 and 1<=a.cpu_threads<=4,'Invalid cap/batch/chunk/threads')
    if a.out_dir.exists() and any(a.out_dir.iterdir()):
        need((a.out_dir/'protocol_frozen.json').is_file(),'Unidentified extension output')
        need(not any(f.is_symlink() for f in a.out_dir.rglob('*')),'Output contains symlinks; preserve it')
    if a.report_only:a.device='cpu'
    if a.device=='cuda':need(torch.cuda.is_available(),'CUDA unavailable; --device cpu is supported')
    a.device=torch.device(a.device);return a

def acquire(path,wait):
    lock=path.open('a')
    while True:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);return lock
        except BlockingIOError:
            need(wait,'GPU is reserved by another radar job; use --wait-for-gpu')
            print('Waiting for current radar GPU experiment; CVHSTNet extension has not started.',flush=True);time.sleep(30)

def has_sustained90(values,thresholds):
    return len(values)>=3 and all(np.all((values[-3:]>t).mean(1)>=.9) for t in thresholds.values())

def extend(a,info,infer,p):
    path=a.out_dir/'extended_h1_scores.npy';pp=a.out_dir/'progress.json';grid=p['extension_grid_db'];n=p['h1_per_scr']
    if pp.exists():
        pr=readj(pp);need(pr['fingerprint']==p['fingerprint'],'Resume identity differs')
    else:
        need(not path.exists(),'Scores without progress metadata');pr=dict(fingerprint=p['fingerprint'],completed_scr=0,finished=False,stop_reason=None)
        writej(pp,pr)
    done=pr['completed_scr'];need(isinstance(done,int) and 0<=done<=len(grid) and (done==0 or path.is_file()),'Invalid extension progress')
    values=np.lib.format.open_memmap(path,mode='r+' if path.exists() else 'w+',dtype='float64',shape=(len(grid),n))
    need(values.shape==(len(grid),n) and values.dtype==np.float64,'Extension array shape differs')
    if done:
        for j in sorted({0,done-1}):
            ids=np.r_[np.arange(min(a.batch,n)),np.arange(max(a.batch,n-a.batch),n)]
            new=infer(grid[j],ids);old=values[j,ids]
            need(np.allclose(new,old,rtol=2e-5,atol=5e-5),'Committed extension replay differs')
            need(all(np.array_equal(new>t,old>t) for t in info['thresholds'].values()),'Committed extension decisions differ')
    for j in range(done,len(grid)):
        if pr['finished']:break
        # Recover the stop decision if interrupted after score commit and
        # before recording stop_reason.
        if not a.run_to_max and has_sustained90(values[:j],info['thresholds']):
            pr.update(finished=True,stop_reason='both_Pfas_Pd_ge_0_9_for_three_consecutive_extended_points');writej(pp,pr);break
        began=time.perf_counter()
        for start in range(0,n,a.chunk):
            stop=min(start+a.chunk,n);result=infer(grid[j],np.arange(start,stop))
            need(result.shape==(stop-start,) and np.isfinite(result).all(),'Invalid extension scores')
            values[j,start:stop]=result
        values.flush();pr['completed_scr']=j+1;writej(pp,pr)
        detail='; '.join(f'Pfa={q:.0e}: Pd={float((values[j]>t).mean()):.4f}' for q,t in info['thresholds'].items())
        print(f'[CVHSTNet H1 only] SCR={grid[j]:+d} dB; {detail}; {time.perf_counter()-began:.1f}s',flush=True)
        if not a.run_to_max and has_sustained90(values[:j+1],info['thresholds']):
            pr.update(finished=True,stop_reason='both_Pfas_Pd_ge_0_9_for_three_consecutive_extended_points');writej(pp,pr)
    if pr['completed_scr']==len(grid):
        pr.update(finished=True,stop_reason=pr['stop_reason'] or 'reached_predeclared_SCR_cap');writej(pp,pr)
    need(pr['finished'],'Extension loop ended without a stop reason')
    return values[:pr['completed_scr']],pr

def report(a,info,values,p,progress):
    curves=[];metrics=[];grid=OLD_GRID+p['extension_grid_db'][:len(values)]
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    for pfa in PFAS:
        threshold=info['thresholds'][pfa];oldmetric=next(r for r in info['metrics'] if float(r['nominal_pfa'])==pfa)
        old=sorted([r for r in info['curves'] if float(r['nominal_pfa'])==pfa],key=lambda r:int(r['scr_db']))
        # Numeric old Pd/hits are reused; original files remain byte-identical.
        rows=[]
        for r in old:
            count=int(r['hits']);n=int(r['n_h1']);lo,hi=wilson(count,n)
            rows.append(dict(method=NAME,nominal_pfa=pfa,scr_db=int(r['scr_db']),pd=float(r['pd']),hits=count,n_h1=n,
                pd_ci95_low=lo,pd_ci95_high=hi,source='original_B241_saved_scores'))
        for scr,v in zip(p['extension_grid_db'],values):
            count=int((v>threshold).sum());n=len(v);lo,hi=wilson(count,n)
            rows.append(dict(method=NAME,nominal_pfa=pfa,scr_db=scr,pd=count/n,hits=count,n_h1=n,
                pd_ci95_low=lo,pd_ci95_high=hi,source='B292_H1_extension'))
        curves.extend(rows);pd=np.asarray([r['pd'] for r in rows]);peak=float(pd.max());peak_scr=[s for s,q in zip(grid,pd) if q==peak]
        flo,fhi=wilson(int(oldmetric['h0_audit_hits']),int(oldmetric['h0_audit_n']))
        value=dict(method=NAME,nominal_pfa=pfa,threshold=threshold,actual_pfa=float(oldmetric['actual_pfa']),
            audit_false_alarms=int(oldmetric['h0_audit_hits']),audit_n=int(oldmetric['h0_audit_n']),actual_pfa_ci95_low=flo,actual_pfa_ci95_high=fhi,
            max_pd=peak,max_pd_scr_db=';'.join(map(str,peak_scr)),pd_at_last_scr=float(pd[-1]),last_scr_db=grid[-1],
            D50_db=crossing(grid,pd,.5),D80_db=crossing(grid,pd,.8),D90_db=crossing(grid,pd,.9),
            first_observed_scr_pd_ge_0_9=next((s for s,q in zip(grid,pd) if q>=.9),None),
            reached_pd_0_9=bool(peak>=.9),scr_points=len(grid),stop_reason=progress['stop_reason'])
        metrics.append(value)
        writecsv(a.out_dir/f'b292_pd_source_pfa_{pfa:.0e}.csv',rows)
        fig,ax=plt.subplots(figsize=(9,5))
        ax.plot(grid,pd,color='tab:orange',linestyle='-',marker='o',markersize=3.5,markevery=3,linewidth=1.8,label=NAME)
        ax.axvline(12.5,color='gray',linestyle=':',linewidth=.8)
        ax.set(xlabel='SCR (dB)',ylabel=r'$P_d$',xlim=(grid[0],grid[-1]),ylim=(0,1.02),
            title=r'$P_{\mathrm{fa}}=10^{'+str(int(round(np.log10(pfa))))+'}$')
        ax.grid(alpha=.25);ax.legend(fontsize=8);fig.tight_layout()
        for ext in ('pdf','png'):fig.savefig(a.out_dir/f'b292_cvhst_pd_scr_pfa_{pfa:.0e}.{ext}',dpi=250)
        plt.close(fig)
        print(f'CVHSTNet Pfa={pfa:.0e}: MAX Pd={peak:.4%} at SCR={peak_scr}; D90={value["D90_db"]}; '
            f'Pd@{grid[-1]:+d}={pd[-1]:.4%}; reached0.9={value["reached_pd_0_9"]}',flush=True)
    writecsv(a.out_dir/'b292_curves.csv',curves);writecsv(a.out_dir/'b292_metrics.csv',metrics)
    result=dict(status='PASS_B292_CVHST_H1_EXTENSION_COMPLETE',metrics=metrics,original_37_points_unchanged=True,
        thresholds_reused=True,training_executed=False,H0_inference_executed=False,only_CVHSTNet_executed=True,
        checkpoint_sha256=info['training']['checkpoint_sha256'],model_source_sha256=info['contract']['model_source_sha256'],
        original_CVHSTNet_variant='B241 final25; not B241R VAL-best',protocol=p,progress=progress,
        raw_extension_sha256=sha(a.out_dir/'extended_h1_scores.npy'),source_files_unchanged=unchanged(info),
        no_curve_shifting=True,no_smoothing=True,no_monotonic_envelope=True,
        scope='Extended exposed SIM-R10 DEV diagnostic; not independent test; stopping is based on observed Pd, not a confidence guarantee')
    writej(a.out_dir/'b292_report.json',result);return result

def main(argv=None):
    a=cli(argv);validate();torch.set_num_threads(a.cpu_threads);torch.manual_seed(20261022)
    torch.backends.cudnn.benchmark=False;torch.backends.cudnn.allow_tf32=False;torch.backends.cuda.matmul.allow_tf32=False
    if a.report_only:
        info=inputs(a);p=readj(a.out_dir/'protocol_frozen.json');pr=readj(a.out_dir/'progress.json')
        need(p['fingerprint']==fp({k:v for k,v in p.items() if k!='fingerprint'})==pr['fingerprint'],'Report identity differs')
        need(p['code_sha256']==code_hashes() and p['protected_old_files']==info['protected'],'Report sources/code differ')
        need(pr['finished'],'Extension not complete; use normal startup to resume')
        arr=np.load(a.out_dir/'extended_h1_scores.npy',mmap_mode='r',allow_pickle=False)
        report(a,info,arr[:pr['completed_scr']],p,pr);return
    if a.device.type=='cuda':
        lock=acquire(a.root/'codex_b271_night.lock',a.wait_for_gpu)
    else:lock=acquire(a.root/'codex_b292_cvhst_cpu.lock',False)
    with lock:
        info=inputs(a);model,scale,mm=load_model(a,info)
        infer=lambda scr,ids:predict(model,mm,scale,h1_iq(info,scr,ids),a)
        print('CVHSTNet existing model only; no training/H0 inference; checking old SCR0/+12 first.',flush=True)
        checks=overlap(a,info,infer)
        p=dict(version='B292_CVHST_H1_EXTEND_V1',extension_grid_db=list(range(13,a.max_scr+1)),h1_per_scr=1024,
            protected_old_files=info['protected'],old_contract=info['contract'],device=a.device.type,
            torch_version=str(torch.__version__),batch=a.batch,chunk=a.chunk,cpu_threads=a.cpu_threads,
            frozen_thresholds={str(k):v for k,v in info['thresholds'].items()},code_sha256=code_hashes(),
            stop_rule='both Pfas Pd>=.9 for3 consecutive extension points, otherwise cap',run_to_max=a.run_to_max,
            overlap_checks=checks,training_executed=False,H0_inference_executed=False)
        p['fingerprint']=fp(p);a.out_dir.mkdir(exist_ok=True);pp=a.out_dir/'protocol_frozen.json'
        if pp.exists():
            previous=readj(pp)
            need(previous['fingerprint']==fp({k:v for k,v in previous.items() if k!='fingerprint'}),'Saved extension identity is invalid')
            # Numerical max errors may vary slightly between processes. The
            # overlap test above must still pass, but it is diagnostic rather
            # than an input that changes the original run identity.
            keys=set(p)-{'overlap_checks','fingerprint'}
            need(set(previous)==set(p) and all(previous[k]==p[k] for k in keys),
                'Extension settings/runtime changed; preserve output and use fresh output_b292_cvhst_*')
            writej(a.out_dir/'resume_overlap_last.json',dict(checks=checks,passed=True))
            p=previous
        else:
            need(not any(a.out_dir.iterdir()),'Unidentified output contents');writej(pp,p)
        values,pr=extend(a,info,infer,p);report(a,info,values,p,pr)
        print('PASS_B292_CVHST_EXTENSION: '+str(a.out_dir),flush=True)

if __name__=='__main__':main()
