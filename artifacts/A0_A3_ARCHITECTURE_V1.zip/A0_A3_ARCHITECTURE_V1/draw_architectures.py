"""Draw research architecture figures from verified A0/A3 implementation facts."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.font_manager import FontProperties, fontManager

ROOT=Path(__file__).resolve().parent
FONT=ROOT/'fonts/RadarArchitectureSubset-Regular.ttf'
fontManager.addfont(FONT)
fontManager.addfont(ROOT/'fonts/RadarArchitectureSubset-Bold.ttf')
plt.rcParams.update({'font.family':FontProperties(fname=FONT).get_name(),
    'axes.unicode_minus':False,'svg.fonttype':'none','pdf.fonttype':42,
    'savefig.facecolor':'white'})
BLUE='#24639A';BLUE_BG='#EDF5FC';TEAL='#167D79';TEAL_BG='#E9F7F3'
PURPLE='#7951AA';PURPLE_BG='#F3EDFA';GRAY='#697586';GRAY_BG='#F3F5F7'
DARK='#263445';ORANGE='#B77918';ORANGE_BG='#FFF5E4'


def canvas(title,subtitle,size=(12,14)):
    fig,ax=plt.subplots(figsize=size)
    fig.subplots_adjust(left=.015,right=.985,bottom=.015,top=.985)
    ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
    ax.text(.5,.987,title,ha='center',va='top',fontsize=19,color=DARK,weight='bold')
    ax.text(.5,.956,subtitle,ha='center',va='top',fontsize=10.3,color=GRAY)
    return fig,ax


def box(ax,x,y,w,h,label,edge=BLUE,fill=BLUE_BG,fs=11.5,dashed=False,bold=False):
    p=FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle='round,pad=0.005,rounding_size=0.008',
        facecolor=fill,edgecolor=edge,linewidth=1.4,linestyle='--' if dashed else '-')
    ax.add_patch(p)
    ax.text(x,y,label,ha='center',va='center',fontsize=fs,color=DARK,
            linespacing=1.4,weight='bold' if bold else 'normal')
    return (x,y,w,h)


def arrow(ax,a,b,color=GRAY,style='-',lw=1.3):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=11,
        linewidth=lw,color=color,linestyle=style,connectionstyle='arc3,rad=0'))


def line(ax,points,color=GRAY,lw=1.2):
    ax.plot([x for x,y in points],[y for x,y in points],color=color,lw=lw)


def vertical(ax,upper,lower,color=GRAY):
    arrow(ax,(upper[0],upper[1]-upper[3]/2-.006),(lower[0],lower[1]+lower[3]/2+.006),color)


def save(fig,name):
    for suffix in ('png','pdf','svg'):
        fig.savefig(ROOT/(name+'.'+suffix),dpi=180,bbox_inches='tight',pad_inches=.15)
    plt.close(fig)


def overview():
    fig,ax=canvas('A0 与当前 A3：整网结构对比','按本项目实际实现绘制；省略批量维 B；A3 对应 B276/B277 的无 ARS、CE 完整组')
    stages=[(64,56,11),(128,28,9),(256,14,7),(512,7,5)]
    for x,new in ((.25,False),(.75,True)):
        color=TEAL if new else BLUE
        ax.text(x,.923,'A3  SPWVD ADN/WCSG/TFCG' if new else 'A0  原始 ADN 复现',ha='center',fontsize=14,color=color,weight='bold')
        nodes=[]
        nodes.append(box(ax,x,.881,.405,.043,'复数 IQ 回波：I + jQ，长度 512',edge=color,fs=11.7))
        if new:
            label='SPWVD：滞后半宽24，49点 Hann型窗\nFFT 128；5格时间均值平滑\nlog(1+|S|) / 固定 TRAIN 尺度\n128×128 → 224×224；灰度复制3通道'
        else:
            label='WVD：本项目冻结的离散重建\n|Re(W)| → dB → 逐样本峰值参考\n截断[-60,0] dB并映射至[0,1]\n128×128 → 224×224；灰度复制3通道'
        nodes.append(box(ax,x,.794,.405,.101,label,edge=color,fill=TEAL_BG if new else BLUE_BG,fs=10.9))
        nodes.append(box(ax,x,.699,.405,.053,
            'WCSG 空间门控（居中初始化）\n输入/输出：3×224×224' if new else '此处无输入门控：直接连接\n输入骨干：3×224×224',
            edge=TEAL if new else GRAY,fill=TEAL_BG if new else GRAY_BG,fs=11.2,dashed=not new))
        nodes.append(box(ax,x,.611,.405,.071,
            'Conv 7×7，s=2，3→64；BN + ReLU\n64×112×112\nMaxPool 3×3，s=2 → 64×56×56',edge=color,fs=11.1))
        for i,(channels,hw,k) in enumerate(stages,1):
            label=f'Stage {i}：ADN 残差块 ×2\nACB + '+(f'TFCG（k={k}）' if new else 'SimAM')+f'；输出 {channels}×{hw}×{hw}'
            nodes.append(box(ax,x,.517-(i-1)*.084,.405,.060,label,
                edge=PURPLE if new else BLUE,fill=PURPLE_BG if new else BLUE_BG,fs=11.0))
        nodes.append(box(ax,x,.173,.405,.062,'全局平均池化 → 512×1×1\n展平 → FC：512→2，得到两个 logits',edge=color,fs=11.3))
        nodes.append(box(ax,x,.082,.405,.063,'检测得分 s = z1 − z0\n独立 H0 标定阈值 τ；s > τ 判为目标',edge=ORANGE,fill=ORANGE_BG,fs=11.2))
        for up,down in zip(nodes,nodes[1:]):vertical(ax,up,down)
    ax.text(.5,.032,'训练目标：两组均为 CE；A3 当前没有 Tail 损失，也没有 phase-ARS。',ha='center',fontsize=10.7,color=DARK)
    ax.text(.5,.012,'参数量：A0 14,330,946；A3 14,533,299。SPWVD 在当前 A3 中仍是固定窗口变换。',ha='center',fontsize=10.3,color=GRAY)
    save(fig,'01_A0_A3_overview')


def blocks():
    fig,ax=canvas('A0 与 A3：一个 ADN 残差块的内部结构','四个 Stage 各含两个块，共8块；只在 Stage 2/3/4 的第一个块使用 s=2',size=(12,12))
    for x,new in ((.26,False),(.76,True)):
        color=PURPLE if new else BLUE
        ax.text(x,.920,'A3：TFCG 替换 SimAM' if new else 'A0：原 ADN 残差块',ha='center',fontsize=14,color=color,weight='bold')
        input_node=box(ax,x,.873,.25,.047,'输入 X：C_in×H×W',edge=color)
        positions=(x-.135,x,x+.135)
        ports=[]
        for xpos,label in zip(positions,('Conv 3×3\nstride=s\nBN','Conv 3×1\nstride=s\nBN','Conv 1×3\nstride=s\nBN')):
            ports.append(box(ax,xpos,.775,.110,.072,label,fs=10.1))
        line(ax,[(positions[0],.828),(positions[-1],.828)])
        line(ax,[(x,.849),(x,.828)])
        for port in ports:arrow(ax,(port[0],.828),(port[0],.817))
        summed=box(ax,x,.665,.282,.064,'三路逐元素相加 + ReLU\nACB：非对称卷积模块',edge=BLUE,fs=11.0)
        for port in ports:
            line(ax,[(port[0],port[1]-port[3]/2-.006),(port[0],.712)])
        line(ax,[(positions[0],.712),(positions[-1],.712)])
        arrow(ax,(x,.712),(x,.703))
        conv=box(ax,x,.571,.282,.051,'Conv 3×3，s=1，C→C',edge=BLUE,fs=11.2)
        attention=box(ax,x,.477,.282,.067,'TFCG：两轴上下文门控\n结构见第3张图' if new else 'SimAM：无额外可学习参数\n按通道内空间统计加权',edge=color,
            fill=PURPLE_BG if new else BLUE_BG,fs=11.1)
        bn=box(ax,x,.385,.282,.047,'BN',edge=BLUE,fs=12)
        addition=box(ax,x,.289,.282,.050,'主分支 + 捷径分支',edge=BLUE,fs=11.2)
        out=box(ax,x,.195,.282,.060,'ReLU\n输出：C_out×H′×W′',edge=color,fs=11.4)
        for a,b in zip((summed,conv,attention,bn,addition),(conv,attention,bn,addition,out)):vertical(ax,a,b)
        sx=x-.202
        line(ax,[(x-.131,.873),(sx,.873),(sx,.611)])
        shortcut=box(ax,sx,.526,.103,.141,'捷径\nIdentity\n或\n1×1 + BN',edge=GRAY,fill=GRAY_BG,fs=9.5)
        arrow(ax,(sx,.611),(sx,.608))
        line(ax,[(sx,.450),(sx,.289)])
        arrow(ax,(sx,.289),(x-.148,.289))
    ax.text(.5,.112,'捷径规则：通道和尺寸不变时为 Identity；降采样时用 Conv 1×1、s=2、BN。',ha='center',fontsize=10.6,color=GRAY)
    ax.text(.5,.080,'实际顺序：ACB → ReLU → Conv3×3 → SimAM/TFCG → BN → 残差相加 → ReLU。',ha='center',fontsize=10.8,color=DARK)
    ax.text(.5,.042,'A3 保留全部8个 ACB；8个 SimAM 全部被 TFCG 替换，未再并联一个 ResNet18。',ha='center',fontsize=10.6,color=DARK)
    save(fig,'02_ADN_residual_block_comparison')


def modules():
    fig,ax=canvas('当前 A3：WCSG 与 TFCG 内部结构','左：骨干输入前的空间门控；右：各残差块内部、Conv3×3 后与 BN 前的时频上下文门控',size=(12,14))
    ax.text(.25,.923,'WCSG（居中版本）',ha='center',fontsize=15,color=TEAL,weight='bold')
    ax.text(.75,.923,'TFCG（替换 SimAM）',ha='center',fontsize=15,color=PURPLE,weight='bold')
    x=.25
    left=[]
    left.append(box(ax,x,.878,.35,.044,'输入图像 X：3×224×224',edge=TEAL,fill=TEAL_BG))
    left.append(box(ax,x,.797,.35,.057,'取第1个灰度通道\n双线性缩放 → g：1×128×128',edge=TEAL,fill=TEAL_BG,fs=11.0))
    vertical(ax,left[0],left[1])
    centers=[.097,.199,.301,.403]
    line(ax,[(centers[0],.746),(centers[-1],.746)]);line(ax,[(x,.763),(x,.746)])
    branches=[]
    for c,label in zip(centers,('g\n原图','AvgPool\n3×3','AvgPool\n7×7','AvgPool\n15×15')):
        node=box(ax,c,.698,.090,.057,label,edge=TEAL,fill=TEAL_BG,fs=9.9);branches.append(node)
        arrow(ax,(c,.746),(c,.734))
    concat=box(ax,x,.610,.35,.047,'通道拼接：4×128×128',edge=TEAL,fill=TEAL_BG,fs=11.0)
    for b in branches:line(ax,[(b[0],.663),(b[0],.651)])
    line(ax,[(centers[0],.651),(centers[-1],.651)]);arrow(ax,(x,.651),(x,.640))
    left2=[concat,
        box(ax,x,.532,.35,.055,'Conv3×3：4→8\nBN + GELU',edge=TEAL,fill=TEAL_BG),
        box(ax,x,.450,.35,.055,'Depthwise Conv5×5：8通道\nBN + GELU',edge=TEAL,fill=TEAL_BG),
        box(ax,x,.366,.35,.055,'Conv1×1：8→1\nSigmoid → M',edge=TEAL,fill=TEAL_BG),
        box(ax,x,.268,.35,.077,'G = 0.05 + 0.95M\n双线性上采样至224×224\n居中增益：G / g0',edge=TEAL,fill=TEAL_BG,fs=11),
        box(ax,x,.157,.35,.052,'Y = X ⊙ (G / g0)\n输出：3×224×224',edge=TEAL,fill=TEAL_BG,fs=11)]
    for a,b in zip(left2,left2[1:]):vertical(ax,a,b)
    line(ax,[(.070,.878),(.040,.878),(.040,.157)])
    arrow(ax,(.040,.157),(.067,.157),color=TEAL)
    ax.text(.033,.50,'原\n图\nX',ha='center',va='center',fontsize=10,color=TEAL)
    ax.text(.25,.080,'g0 = 0.05 + 0.95σ(4) ≈ 0.982913\n末层权重置0，初始 Y=X\n参数量：529',ha='center',va='center',fontsize=10.5,color=TEAL,linespacing=1.5)
    x=.75
    right=[]
    right.append(box(ax,x,.878,.35,.044,'输入特征 F：C×H×W',edge=PURPLE,fill=PURPLE_BG))
    right.append(box(ax,x,.797,.35,.057,'Conv1×1：C→h，h=max(8,C/8)\nBN + GELU',edge=PURPLE,fill=PURPLE_BG,fs=10.8))
    right.append(box(ax,x,.713,.35,.047,'AvgPool3×3，保持尺寸',edge=PURPLE,fill=PURPLE_BG,fs=11.1))
    for a,b in zip(right,right[1:]):vertical(ax,a,b)
    branch=[]
    for xpos,label in ((.654,'时间轴 DWConv\n1×k'),(.846,'频率轴 DWConv\nk×1')):
        branch.append(box(ax,xpos,.622,.164,.060,label,edge=PURPLE,fill=PURPLE_BG,fs=10.5))
    line(ax,[(x,.681),(x,.667)]);line(ax,[(.654,.667),(.846,.667)])
    for b in branch:arrow(ax,(b[0],.667),(b[0],.659))
    fused=box(ax,x,.532,.35,.055,'拼接为2h通道 → Conv1×1：2h→h\nBN + GELU',edge=PURPLE,fill=PURPLE_BG,fs=10.7)
    for b in branch:line(ax,[(b[0],.585),(b[0],.573)])
    line(ax,[(.654,.573),(.846,.573)]);arrow(ax,(x,.573),(x,.566))
    expand=box(ax,x,.438,.35,.060,'Conv1×1：h→C\nSigmoid → A',edge=PURPLE,fill=PURPLE_BG,fs=11.1)
    gain=box(ax,x,.335,.35,.068,'R = 1 + 0.20(2A − 1)\n增益范围：[0.8, 1.2]',edge=PURPLE,fill=PURPLE_BG,fs=11.2)
    output=box(ax,x,.222,.35,.060,'Y = F ⊙ R\n输出形状保持 C×H×W',edge=PURPLE,fill=PURPLE_BG,fs=11.1)
    for a,b in zip((fused,expand,gain),(expand,gain,output)):vertical(ax,a,b)
    line(ax,[(.930,.878),(.967,.878),(.967,.222)])
    arrow(ax,(.967,.222),(.933,.222),color=PURPLE)
    ax.text(.974,.53,'原\n特\n征\nF',ha='center',va='center',fontsize=10,color=PURPLE)
    ax.text(.75,.116,'各Stage：(C,h,k)\n(64,8,11)；(128,16,9)\n(256,32,7)；(512,64,5)',ha='center',fontsize=10.5,color=PURPLE,linespacing=1.5)
    ax.text(.75,.045,'末层权重/偏置置0 → 初始 A=0.5，Y=F',ha='center',fontsize=10.1,color=PURPLE)
    ax.text(.5,.012,'⊙ 表示逐元素乘法；BN 表示批归一化；DWConv 表示逐通道卷积。图中为已实现结构。',ha='center',fontsize=10.2,color=GRAY)
    save(fig,'03_WCSG_TFCG_details')


if __name__=='__main__':
    overview();blocks();modules()
    print(json.dumps({'figures':3,'formats':['PNG','PDF','SVG'],'output':str(ROOT)},ensure_ascii=False))
