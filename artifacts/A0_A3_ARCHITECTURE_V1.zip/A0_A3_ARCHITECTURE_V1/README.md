# A0 与当前 A3 的实际网络结构

这是按本项目已发布源码绘制的结构说明，不是论文作者提供的原图，也不将本项目未公开来源的预处理选择描述为作者官方实现。

## 文件

- `01_A0_A3_overview`：整网并排对比，包含IQ、前端、输入门控、四级骨干、分类得分和独立标定阈值。
- `02_ADN_residual_block_comparison`：ACB的三路卷积、注意力的准确位置、BN与残差捷径。
- `03_WCSG_TFCG_details`：WCSG和TFCG内部算子、通道、门控公式及初始化。

每张均有PNG、PDF、SVG。PNG用于查看，PDF用于矢量排版；SVG保留文本，需要精确编辑SVG文字时可安装包内的字体子集或替换为本地中文字体。`draw_architectures.py`可重绘并修改文案，需要matplotlib；已提供当前图中文字的重命名TrueType字体子集。新增中文字符时可使用完整Noto Sans CJK，或用`build_font_subset.py`重新生成。字体授权和来源见`fonts/OFL_NOTICE.txt`与`fonts/DERIVATION.txt`。PDF已嵌入字体，可独立查看。

## 对应实验

A0 = B277中Original ADN (WVD; historical training)一行；A3 = 已完成B276的SPWVD ADN/WCSG/TFCG，即B277复用的完整组。

A0：复数IQ512 → WVD及冻结显示处理 → 3×224×224 → ADN18（8个ACB、8个SimAM）→ 两个logit。

A3：复数IQ512 → 固定窗口SPWVD及固定TRAIN尺度显示 → 3×224×224 → 居中WCSG → ADN18（8个ACB、8个TFCG；不再使用SimAM）→ 两个logit。

图表示结构关系，不表示本轮直接从A0权重继续训练：A3初始化来源是已完成B274的SPWVD ResNet18，复制中心卷积/BN/捷径/FC，ACB侧支置零，WCSG和TFCG初始恒等。

二者均只有一个分类骨干，不包含两个ResNet18并联。三个图像通道是同一灰度图的复制，不是三种模态。当前A3采用CE，没有phase-ARS或Tail损失；B278 A4/A5在同一A3推理结构上修改训练损失，不在推理路径中增加训练记忆操作。

## 精确算子和尺寸

- Stem：Conv7×7,stride2,padding3,3→64；BN；ReLU。输出64×112×112；MaxPool3×3,stride2,padding1后64×56×56。
- Stage1：2个残差块，64×56×56。
- Stage2：2个残差块，第1块stride2，128×28×28。
- Stage3：2个残差块，第1块stride2，256×14×14。
- Stage4：2个残差块，第1块stride2，512×7×7。
- GAP：512×1×1，展平，FC512→2。得分s=z1−z0，严格s>独立H0 CAL阈值判目标；没有在图中虚构固定0.5 softmax决策。
- 残差主分支：ACB三路(3×3/3×1/1×3，各自BN)相加→ReLU→Conv3×3→SimAM或TFCG→BN→加捷径→ReLU。
- SimAM：按每个样本每个通道的空间统计计算。令d=(F−mean_HW(F))²，v=sum_HW(d)/(HW−1)，输出F·sigmoid(d/[4(v+1e-4)]+0.5)，无可学习参数。

WCSG从已缩放到224的输入第1通道再双线性缩放到128，不是跳过输入显示处理直接访问原始SPWVD。拼接g/AvgPool3/7/15，卷积4→8，depthwise5×5，输出1通道门控。G=0.05+0.95sigmoid(a)，上采样后输出X·G/g0；g0=0.05+0.95sigmoid(4)≈0.982913。此处g0为初始化时保存的常量，非每次前向重新估计。初始化末层权重0使其初始为恒等映射。参数529。

TFCG：C→h=max(8,C/8)，BN/GELU，AvgPool3×3，再平行使用1×k与k×1的depthwise卷积；拼接后1×1卷积2h→h、BN/GELU，再1×1卷积h→C和sigmoid，输出F·[1+0.2(2A−1)]。k按四级取11/9/7/5，h取8/16/32/64。末层权重和偏置0使初始乘子1。当前SPWVD图坐标为频率×时间，因此1×k对应时间轴、k×1对应频率轴。

A0参数14,330,946；A3参数14,533,299（包含WCSG529和全部TFCG201,824，相对A0增加202,353）。各阶段输出尺寸及模块计数已由实际模型构造和meta-device前向核对，不依赖图中文字自证。

## 前端与归因

A0项目重建：对称整数滞后积、FFT，abs(real WVD)，10log10，逐样本峰值参考，截断[-60,0]dB并映射[0,1]；缓存128后再显示224。

A3项目重建：SPWVD滞后半宽24、49个滞后样点，使用51点Hann窗去两端得到49点Hann型权重；FFT128，时间中心4j+2，5格时间均值；log1p(abs S)/固定TRAIN前256个所选样本的99%分位尺度。图中简称49点Hann型窗，不等同于标准49点含零端点的Hann窗。

因此A0/A3除了时频变换，还涉及显示归一化、初始化和历史训练预算差异。图不证明WVD→SPWVD的纯因果收益，也不证明每个门控均有显著增益；这些须由对应对照确认。本包不包含用户上传论文或结果数据。

文献：ADN DOI10.1109/JSEN.2023.3259953；SPWVD时频输入借鉴来源 DOI10.3390/rs16244662。SPWVD本身为已有变换，当前图中尚无新设计的自适应平滑核。
