"""Create renamed OFL TrueType subsets for dependable Chinese PDF embedding."""
from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.cu2quPen import Cu2QuPen
import shutil
root=Path(__file__).resolve().parent;out=root/'fonts';out.mkdir(exist_ok=True)
chars=set((root/'draw_architectures.py').read_text())|set(chr(i) for i in range(32,127))
for style in ('Regular','Bold'):
    source=TTFont(f'/usr/share/fonts/opentype/noto/NotoSansCJK-{style}.ttc',fontNumber=2)
    cmap=source.getBestCmap();mapping={ord(c):cmap[ord(c)] for c in chars if ord(c) in cmap}
    names=['.notdef']+sorted(set(mapping.values())-{'.notdef'})
    glyphset=source.getGlyphSet();glyphs={};metrics={}
    for name in names:
        pen=TTGlyphPen(None);convert=Cu2QuPen(pen,max_err=.75,reverse_direction=True)
        glyphset[name].draw(convert);glyphs[name]=pen.glyph();metrics[name]=source['hmtx'].metrics[name]
    fb=FontBuilder(source['head'].unitsPerEm,isTTF=True)
    fb.setupGlyphOrder(names);fb.setupCharacterMap(mapping);fb.setupGlyf(glyphs)
    fb.setupHorizontalMetrics(metrics)
    fb.setupHorizontalHeader(ascent=source['hhea'].ascent,descent=source['hhea'].descent)
    fb.setupOS2(sTypoAscender=source['OS/2'].sTypoAscender,sTypoDescender=source['OS/2'].sTypoDescender,
               usWinAscent=source['OS/2'].usWinAscent,usWinDescent=source['OS/2'].usWinDescent,
               usWeightClass=700 if style=='Bold' else 400,fsSelection=32 if style=='Bold' else 64)
    fb.setupNameTable(dict(familyName='Radar Architecture Subset',styleName=style,
        uniqueFontIdentifier='RadarArchitectureSubset-'+style,fullName='Radar Architecture Subset '+style,
        psName='RadarArchitectureSubset-'+style,
        copyright='Subset derivative of Noto Sans CJK, SIL Open Font License 1.1. See OFL_NOTICE.txt.'))
    fb.setupPost();fb.setupMaxp();fb.font['head'].macStyle=1 if style=='Bold' else 0;fb.save(out/f'RadarArchitectureSubset-{style}.ttf')
shutil.copyfile('/usr/share/doc/fonts-noto-cjk/copyright',out/'OFL_NOTICE.txt')
(out/'DERIVATION.txt').write_text('Renamed subset and CFF-to-TrueType outline conversion of Noto Sans CJK SC Regular/Bold for these architecture figures. Original copyright and SIL OFL are in OFL_NOTICE.txt. The subset includes the characters used by draw_architectures.py plus printable ASCII.\n')
print('Built renamed TrueType subsets for current figure text.')
