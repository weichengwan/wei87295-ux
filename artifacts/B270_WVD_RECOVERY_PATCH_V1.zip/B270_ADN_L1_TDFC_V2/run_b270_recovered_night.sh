#!/usr/bin/env bash
# Recover the missing frozen cache, then train and score sequentially.
set -euo pipefail
b270_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$b270_dir"
exec 9>../codex_b270_recovery_night.lock
flock -n 9 || { printf '已有恢复/训练任务运行；不要重复启动。\n' >&2; exit 1; }
date -Is
python -u b270_cache_recovery.py --device cuda --wvd-batch 32 --batch 32
date -Is
bash run_b270_train.sh --cache-dir ../output_sim_r10_b270_wvd_rebuilt_v1 \
  --methods adaptive --epochs 15 --batch 32 --device cuda --resume
date -Is
bash run_b270_score.sh --batch 32 --chunk 512 --device cuda
date -Is
