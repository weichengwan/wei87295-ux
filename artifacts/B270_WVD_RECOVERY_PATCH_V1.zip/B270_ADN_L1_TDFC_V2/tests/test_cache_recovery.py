"""Cache recovery tests use small artificial IQ, never real radar results."""
from __future__ import annotations

import copy
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import h5py
import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT / "package" if (ROOT / "package").is_dir() else ROOT
sys.path.insert(0, str(PACKAGE))

import b270_cache_recovery as recovery
import r10_sim_stage_b270_tdfc_train as training
from b270_data import cache_reference, digest_file, evaluate, load_checkpoint, read_json, verify_l1_checkpoint, write_json
from b270_model import B270Net
from source_loader import load_frozen_file, load_frozen_sources


def recovery_fixture(root):
    source, trainer, original = load_frozen_sources()
    b210 = load_frozen_file("r10_sim_stage_b210_a3_adn_earlystop_v1.py")
    bank, old = root / "bank", root / "old_cache"
    bank.mkdir(); old.mkdir()
    hp = bank / b210.H5_NAME
    rng = np.random.default_rng(123)
    with h5py.File(hp, "w") as h:
        for split in ("train", "val"):
            g = h.create_group(split)
            iq = (rng.normal(size=(4, 512)) + 1j * rng.normal(size=(4, 512))).astype("complex64")
            g.create_dataset("iq", data=iq)
            g.create_dataset("label", data=np.array([0, 1, 0, 1], dtype="uint8"))
    bc = dict(file_sha256=digest_file(hp), counts={"train":4,"val":4})
    write_json(bank / b210.CT_NAME, bc)
    a = SimpleNamespace(bank_dir=bank, device_resolved=torch.device("cpu"), wvd_batch=2)
    b210.cache_source(source, hp, old, a, bc)
    # File metadata differs while map arrays are exactly those produced by the
    # frozen implementation; recovery must record an actual new file identity.
    with h5py.File(old / b210.CACHE_H5, "r+") as h:
        h.attrs["internal_test_historical_metadata"] = "not a radar experiment"
    cc = read_json(old / b210.CACHE_CT)
    cc["wvd_cache_sha256"] = digest_file(old / b210.CACHE_H5)
    write_json(old / b210.CACHE_CT, cc)
    model = trainer.ProposedWrapper(source, dict(original.CFG))
    with h5py.File(old / b210.CACHE_H5, "r") as h:
        val = evaluate(model, source, h["val"], torch.device("cpu"), 2)
    path = root / "l1" / "best_val_ce.pt"
    path.parent.mkdir()
    ck = dict(method="L1_TAIL", seed=20261022, epoch=1, cfg=original.CFG,
              state_dict=model.state_dict(), val_metrics=val,
              source_sha256=b210.SOURCE_SHA, trainer_sha256=b210.TRAINER_SHA,
              bank_sha256=bc["file_sha256"], wvd_cache_sha256=cc["wvd_cache_sha256"])
    torch.save(ck, path)
    contract = dict(status=original.PASS, method="L1_TAIL", seed=20261022,
                    params_loss=original.PARAMS, best_checkpoint_sha256=digest_file(path),
                    **{k:ck[k] for k in ("bank_sha256", "wvd_cache_sha256", "source_sha256", "trainer_sha256")})
    write_json(path.with_name("training_contract.json"), contract)
    context = dict(root=root, bank_dir=bank, cache_dir=old, bc=bc, cc=cc, b210=b210)
    initialization, sha = verify_l1_checkpoint(path, context, 20261022)
    (old / b210.CACHE_H5).unlink()
    a = SimpleNamespace(out_dir=root / "rebuilt", device="cpu", wvd_batch=2, batch=2,
                        l1_checkpoint=path, seed=20261022)
    return a, context, initialization, sha, hp


class RecoveryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)

    def test_rebuild_real_wvd_preserve_lineage_and_train(self):
        with tempfile.TemporaryDirectory(prefix="b270_synthetic_recovery_") as directory:
            a, old, ck, sha, hp = recovery_fixture(Path(directory))
            old_contract_bytes = (old["cache_dir"] / old["b210"].CACHE_CT).read_bytes()
            original_checkpoint_bytes = a.l1_checkpoint.read_bytes()
            cache = recovery.recover_from_context(a, old, ck, sha, hp)
            cc = read_json(a.out_dir / old["b210"].CACHE_CT)
            self.assertNotEqual(cc["wvd_cache_sha256"], old["cc"]["wvd_cache_sha256"])
            context = dict(old, cc=cc, cache_dir=a.out_dir, cache=cache,
                           source=load_frozen_sources()[0], device=torch.device("cpu"))
            self.assertEqual(cache_reference(context)[0], old["cc"]["wvd_cache_sha256"])
            self.assertEqual(verify_l1_checkpoint(a.l1_checkpoint, context, a.seed)[1], sha)
            self.assertEqual((old["cache_dir"] / old["b210"].CACHE_CT).read_bytes(), old_contract_bytes)
            self.assertEqual(a.l1_checkpoint.read_bytes(), original_checkpoint_bytes)
            self.assertEqual(digest_file(cache), cc["wvd_cache_sha256"])
            first_hash = digest_file(cache)
            recovery.recover_from_context(a, old, ck, sha, hp)
            self.assertEqual(digest_file(cache), first_hash)
            args = training.cli(["--root", str(old["root"]), "--out-dir", str(old["root"] / "trained"),
                                 "--epochs", "1", "--min-epochs", "1", "--batch", "2", "--device", "cpu"])
            result = training.train_one(args, context, "adaptive", ck, sha)
            self.assertEqual(result["wvd_cache_sha256"], cc["wvd_cache_sha256"])
            self.assertEqual(result["initialization_checkpoint_sha256"], sha)
            self.assertEqual(result["epochs_executed"], 1)

    def test_wrong_historical_validation_stops_without_recovery_pass(self):
        with tempfile.TemporaryDirectory() as directory:
            a, old, ck, sha, hp = recovery_fixture(Path(directory))
            incorrect = copy.deepcopy(ck)
            incorrect["val_metrics"]["val_ce"] += 0.1
            with self.assertRaisesRegex(RuntimeError, "validation CE"):
                recovery.recover_from_context(a, old, incorrect, sha, hp)
            self.assertNotIn("recovery", read_json(a.out_dir / old["b210"].CACHE_CT))
            self.assertFalse((a.out_dir / "recovery_validation.json").exists())
            # A completed cache with failed validation can be revalidated after
            # the actual unchanged checkpoint is supplied; no costly rebuild.
            recovery.recover_from_context(a, old, ck, sha, hp)

    def test_corrupted_report_and_wrong_historical_checkpoint_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            a, old, ck, sha, hp = recovery_fixture(Path(directory))
            recovery.recover_from_context(a, old, ck, sha, hp)
            cc = read_json(a.out_dir / old["b210"].CACHE_CT)
            context = dict(old, cc=cc, cache_dir=a.out_dir)
            path = a.out_dir / "recovery_validation.json"
            valid = path.read_bytes()
            path.write_bytes(valid + b" ")
            with self.assertRaisesRegex(RuntimeError, "report checksum"):
                verify_l1_checkpoint(a.l1_checkpoint, context, a.seed)
            path.write_bytes(valid)
            wrong = copy.deepcopy(cc)
            wrong["recovery"]["original_cache_sha256"] = "wrong-original-hash"
            with self.assertRaisesRegex(RuntimeError, "original cache identity"):
                cache_reference(dict(context, cc=wrong))
            # A different otherwise valid original checkpoint is not accepted
            # merely because it used the same old cache.
            other = a.l1_checkpoint.parent.parent / "different_l1" / "best_val_ce.pt"
            other.parent.mkdir()
            payload = copy.deepcopy(ck)
            payload["epoch"] = 9
            torch.save(payload, other)
            c = read_json(a.l1_checkpoint.with_name("training_contract.json"))
            c["best_checkpoint_sha256"] = digest_file(other)
            write_json(other.with_name("training_contract.json"), c)
            with self.assertRaisesRegex(RuntimeError, "different L1 checkpoint"):
                verify_l1_checkpoint(other, context, a.seed)

    def test_labels_and_wvd_corruption_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            a, old, ck, sha, hp = recovery_fixture(Path(directory))
            cache = recovery.recover_from_context(a, old, ck, sha, hp)
            source = load_frozen_sources()[0]
            with h5py.File(cache, "r+") as h:
                h["train"]["label"][0] = 1
            with self.assertRaisesRegex(RuntimeError, "label/order"):
                recovery.replay_samples(hp, cache, source, torch.device("cpu"))
            with h5py.File(cache, "r+") as h:
                h["train"]["label"][0] = 0
                h["train"]["wvd"][0] = 0
            with self.assertRaisesRegex(RuntimeError, "sample replay failed"):
                recovery.replay_samples(hp, cache, source, torch.device("cpu"))
            with self.assertRaisesRegex(RuntimeError, "HDF5 checksum"):
                recovery.recover_from_context(a, old, ck, sha, hp)


if __name__ == "__main__":
    unittest.main()
