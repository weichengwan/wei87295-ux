# 恢复缺失的 30K/5K WVD 缓存

本补丁只增加缓存恢复与来源验证，不更改模型、损失或评估场景。
它使用包内冻结的 B210 缓存生成函数和 ADN WVD 源码，从现有 SHA 验证
通过的 TRAIN=30000 / VAL=5000 IQ 数据重建；不重新生成 IQ，不读取 H0
CAL/AUDIT 或 DEV-H1 来恢复/验证缓存。

原 `output_sim_r10_b210_30k_5k_wvd_cache_v1/` 中的历史合同和原 B215
L1-Tail checkpoint 不改写。新缓存写入独立目录
`output_sim_r10_b270_wvd_rebuilt_v1/`。所需空间按未压缩浮点数组加 512 MiB
余量检查，约 2.64 GiB；实际文件采用原 LZF 压缩方式。

重建 HDF5 的文件校验值可能因元数据或库版本不同而改变。补丁分别保存
旧缓存校验值与新文件实测校验值，不伪造旧文件指纹。它验证全部标签顺序、
抽样 WVD 重算及原 L1-Tail 在完整 5000 条 VAL 上的 CE；与 checkpoint
历史 VAL CE 的绝对差必须小于 1e-4，否则停止，不进入训练。
原缓存已不可用，因此不能从历史元数据证明全部数组逐位相等；该限制
明确记录在 `recovery_validation.json`。

新训练 checkpoint 引用新缓存 SHA；原 L1 checkpoint 继续引用旧 SHA，
并通过经 SHA 校验的旧合同、恢复报告和原 checkpoint 身份关联。
验证报告或原合同损坏、使用其他 checkpoint、数据来源变化都会拒绝运行。

激活 `mpdnet-r10` 后在本包目录运行：

```bash
bash run_b270_recovered_night.sh
```

依次执行：缓存恢复与验证 → 自适应 TDFC 训练 15 epoch → 完整评分与绘图。
任一步失败都会停止。用 `flock` 防止重复启动相同后台任务。
训练默认输出仍为 `../output_b270_adn_l1_tdfc_v2`，评分读取训练中记录的
新缓存路径。已验证完成的缓存可直接复用，训练与评分保留原断点恢复行为。

单独恢复：

```bash
python -u b270_cache_recovery.py --device cuda --wvd-batch 32 --batch 32
```

原生成函数不支持中断后接着写未完成的临时 HDF5；若重建时进程中断且留下
临时文件，脚本会明确停止。可保留该目录，显式选择新的 `--out-dir` 重建，
并在训练命令中使用同一新 `--cache-dir`，不要删除历史原始数据或权重。

本地 17 项 CPU 功能测试通过，包括人工小型 IQ 的实际 WVD 重建、原权重/
合同保留、验证损失错误时停止、恢复后的实际训练、重复调用及损坏拒绝。
这些不是 AutoDL 真实数据、GPU 耗时或检测性能验证。
