#!/usr/bin/env python3
"""Rebuild a missing TRAIN/VAL WVD cache from frozen IQ; preserve old identities."""
from __future__ import annotations

import argparse
import gc
import json
import shutil
import time
from pathlib import Path
from types import SimpleNamespace

import h5py
import numpy as np
import torch

from b270_data import cache_reference, device_for, digest_file, evaluate, need, read_json, resolve_data, verify_l1_checkpoint, write_json
from b270_model import B270Net
from source_loader import load_frozen_sources

VERSION = "B270_WVD_RECOVERY_V1"
PASS = "PASS_REBUILT_FROM_FROZEN_IQ__L1_VAL_CE_REPLAY"


def replay_samples(hp, cache, source, device):
    """Recompute rows independently from the IQ file, preserving row/label order."""
    details, total = {}, 0
    with h5py.File(hp, "r") as iq_bank, h5py.File(cache, "r") as maps:
        for split in ("train", "val"):
            labels = iq_bank[split]["label"][:].astype(np.uint8)
            need(np.array_equal(labels, maps[split]["label"][:]), f"Rebuilt {split} label/order differs from original IQ")
            n = len(labels)
            need(maps[split]["wvd"].shape == (n, 128, 128) and maps[split]["wvd"].dtype == np.dtype("float32"), f"Unexpected rebuilt {split} WVD")
            rows = sorted(set([0, n // 4, n // 2, 3 * n // 4, n - 1]))
            maximum = 0.0
            for row in rows:
                iq = np.ascontiguousarray(iq_bank[split]["iq"][row:row+1], dtype=np.complex64)
                actual = source.wvd_base_map(torch.from_numpy(iq).to(device)).cpu().numpy()
                stored = maps[split]["wvd"][row:row+1]
                need(np.isfinite(stored).all(), "Nonfinite rebuilt WVD")
                maximum = max(maximum, float(np.max(np.abs(actual - stored))))
                need(np.allclose(actual, stored, rtol=1e-6, atol=1e-6), f"Rebuilt WVD sample replay failed: {split}/{row}")
            total += len(rows)
            details[split] = dict(rows=rows, maximum_absolute_difference=maximum)
    return dict(status="PASS", n_samples=total, details=details)


def recover_from_context(a, original_context, checkpoint, checkpoint_sha, hp):
    """Worker uses already verified context. Public main enforces 30K/5K data."""
    b210 = original_context["b210"]
    old_contract = original_context["cache_dir"] / b210.CACHE_CT
    original_sha = digest_file(old_contract)
    out = a.out_dir
    need(out != original_context["cache_dir"], "Use a separate recovery directory; preserve the original contract")
    need(out != original_context["bank_dir"], "Recovery output must not be the IQ bank")
    out.mkdir(parents=True, exist_ok=True)
    preserved = out / "original_wvd_cache_contract.json"
    if preserved.exists():
        need(digest_file(preserved) == original_sha, "Recovery directory contains a different original contract")
    else:
        shutil.copyfile(old_contract, preserved)
    source = load_frozen_sources()[0]
    device = device_for(a.device)
    cache = out / b210.CACHE_H5
    cc_path = out / b210.CACHE_CT
    if cc_path.exists():
        cc = read_json(cc_path)
        need(cache.is_file(), "Recovery contract exists but its rebuilt HDF5 is missing")
        need(digest_file(cache) == cc.get("wvd_cache_sha256"), "Existing rebuilt HDF5 checksum mismatch")
        for key in ("bank_sha256", "bank_contract_sha256", "source_sha256", "trainer_sha256"):
            need(cc.get(key) == original_context["cc"].get(key), f"Existing recovery differs in {key}")
        if "recovery" in cc:
            context = dict(original_context, cache_dir=out, cc=cc)
            verify_l1_checkpoint(a.l1_checkpoint, context, a.seed)
            print("Verified completed recovery; no WVD recomputation", flush=True)
            return cache
    else:
        need(not cache.exists(), "Incomplete rebuilt HDF5 without a contract; inspect recovery directory before retrying")
        temporary = out / ("." + b210.CACHE_H5 + ".tmp")
        need(not temporary.exists(), f"Interrupted rebuild file remains: {temporary}; preserve this directory and choose a new --out-dir")
        required = sum(original_context["bc"]["counts"][s] for s in ("train", "val")) * 128 * 128 * 4 + (512 << 20)
        free = shutil.disk_usage(out).free
        need(free >= required, f"Need at least {required / 2**30:.2f} GiB free for rebuilding WVD; available {free / 2**30:.2f} GiB")
        print(f"Rebuilding only TRAIN/VAL: output={out}; free={free / 2**30:.2f} GiB", flush=True)
        args = SimpleNamespace(device_resolved=device, bank_dir=original_context["bank_dir"], wvd_batch=a.wvd_batch)
        b210.cache_source(source, hp, out, args, original_context["bc"])
        cc = read_json(cc_path)
    replay = replay_samples(hp, cache, source, device)
    print("Checking the unchanged L1-Tail on the rebuilt full VAL split", flush=True)
    model = B270Net(enhancement="none")
    model.load_l1_checkpoint(checkpoint)
    model.to(device).eval()
    with h5py.File(cache, "r") as h:
        validation = evaluate(model, source, h["val"], device, a.batch)
    historical = checkpoint["val_metrics"]
    difference = abs(validation["val_ce"] - historical["val_ce"])
    print(f"L1 VAL CE: historical={historical['val_ce']:.8f}; rebuilt={validation['val_ce']:.8f}; difference={difference:.3g}", flush=True)
    need(difference < 1e-4, "Rebuilt WVD does not reproduce original L1 validation CE; training stopped without changing the old checkpoint/contract")
    report = dict(
        version=VERSION, status=PASS,
        original_contract_sha256=original_sha,
        original_cache_sha256=original_context["cc"]["wvd_cache_sha256"],
        rebuilt_cache_sha256=cc["wvd_cache_sha256"],
        bank_sha256=cc["bank_sha256"], source_sha256=cc["source_sha256"],
        l1_checkpoint_sha256=checkpoint_sha,
        l1_training_contract_sha256=digest_file(a.l1_checkpoint.with_name("training_contract.json")),
        counts=original_context["bc"]["counts"],
        wvd_sample_replay=replay, historical_validation=historical,
        rebuilt_validation=validation, validation_ce_absolute_difference=difference,
        h0_opened=False, dev_h1_opened=False, device_type=device.type,
        wvd_batch=a.wvd_batch, validation_batch=a.batch,
        recovery_code_sha256=digest_file(Path(__file__)),
        note="Original cache file is unavailable. Rebuilt from the same SHA-verified IQ bank using the unmodified frozen WVD implementation. New file hash is recorded separately. Original array bitwise equality cannot be established from historical metadata alone.",
    )
    report_path = out / "recovery_validation.json"
    write_json(report_path, report)
    cc["recovery"] = dict(version=VERSION, original_contract_sha256=original_sha,
                          original_cache_sha256=report["original_cache_sha256"],
                          validation_report_sha256=digest_file(report_path))
    write_json(cc_path, cc)
    # The same verifier used by training/scoring must accept the completed
    # evidence. If any check fails, no training is launched.
    context = dict(original_context, cache_dir=out, cc=cc)
    verify_l1_checkpoint(a.l1_checkpoint, context, a.seed)
    del model
    gc.collect()
    if device.type == "cuda":
        torch.cuda.empty_cache()
    print(PASS, flush=True)
    return cache


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, default=Path(__file__).resolve().parent.parent)
    p.add_argument("--bank-dir", type=Path)
    p.add_argument("--original-cache-dir", type=Path)
    p.add_argument("--out-dir", type=Path)
    p.add_argument("--l1-checkpoint", type=Path)
    p.add_argument("--seed", type=int, default=20261022)
    p.add_argument("--device", choices=("cuda", "cpu"), default="cuda")
    p.add_argument("--wvd-batch", type=int, default=32)
    p.add_argument("--batch", type=int, default=32)
    p.add_argument("--cpu-threads", type=int, default=4)
    a = p.parse_args(argv)
    need(a.wvd_batch > 0 and a.batch > 0 and a.cpu_threads > 0, "Invalid recovery batch/thread count")
    a.root = a.root.resolve()
    a.original_cache_dir = (a.original_cache_dir or a.root / "output_sim_r10_b210_30k_5k_wvd_cache_v1").resolve()
    a.out_dir = (a.out_dir or a.root / "output_sim_r10_b270_wvd_rebuilt_v1").resolve()
    a.l1_checkpoint = (a.l1_checkpoint or a.root / "output_sim_r10_b215_tpht_train_v1" / f"trainseed_{a.seed}" / "L1_TAIL" / "best_val_ce.pt").resolve()
    torch.set_num_threads(a.cpu_threads)
    torch.backends.cudnn.benchmark = False
    context = resolve_data(a.root, a.bank_dir, a.original_cache_dir)
    need("recovery" not in context["cc"], "--original-cache-dir must contain the unchanged historical contract")
    need(not (context["cache_dir"] / context["b210"].CACHE_H5).is_file(), "Original WVD is present; use that verified cache directly instead of rebuilding")
    # Verify the actual IQ file and unchanged historical checkpoint before any
    # large cache write. No H0/DEV or regeneration of IQ is performed.
    hp, bank, _ = context["b210"].bank_contract(context["bank_dir"], "pilot")
    checkpoint, sha = verify_l1_checkpoint(a.l1_checkpoint, context, a.seed)
    started = time.perf_counter()
    recover_from_context(a, context, checkpoint, sha, hp)
    print(f"Recovery finished in {time.perf_counter()-started:.1f}s; cache-dir={a.out_dir}", flush=True)


if __name__ == "__main__":
    main()
