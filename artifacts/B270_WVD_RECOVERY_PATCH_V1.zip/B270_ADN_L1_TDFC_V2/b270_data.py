"""Discover and verify existing SIM-R10 artifacts; never generate training data."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

import h5py
import numpy as np
import torch
import torch.nn.functional as F

from source_loader import load_frozen_file, load_frozen_sources


def need(condition, message):
    if not bool(condition):
        raise RuntimeError(message)


def digest_file(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 << 20), b""):
            result.update(block)
    return result.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def find_files(root, filename, max_depth=4):
    root = Path(root).resolve()
    hits = []
    for directory, dirs, files in os.walk(root, followlinks=False):
        relative = Path(directory).relative_to(root)
        dirs[:] = [d for d in dirs if d not in (".git", "__pycache__", "node_modules", ".venv")]
        if len(relative.parts) >= max_depth:
            dirs[:] = []
        if filename in files:
            hits.append(Path(directory) / filename)
    return sorted(hits, key=lambda p: (len(p.relative_to(root).parts), str(p)))


def choose_unique_contract(candidates, label):
    need(candidates, f"Cannot find {label}; pass its directory explicitly on the command line")
    # Multiple byte-identical copies are harmless; different contracts need an
    # explicit path instead of guessing which experimental data the user wants.
    digests = {digest_file(p) for p in candidates}
    need(len(digests) == 1, f"Several different {label} candidates: {[str(p) for p in candidates]}")
    return candidates[0].parent


def resolve_data(root, bank_dir=None, cache_dir=None):
    b210 = load_frozen_file("r10_sim_stage_b210_a3_adn_earlystop_v1.py")
    root = Path(root).resolve()
    need(root.is_dir(), f"Project root does not exist: {root}")
    if bank_dir is None:
        known = root / "SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1"
        if (known / b210.CT_NAME).is_file():
            bank_dir = known
        else:
            valid = []
            for p in find_files(root, b210.CT_NAME):
                c = read_json(p)
                if c.get("preset") == "pilot" and c.get("counts", {}).get("train") == 30000 and c.get("counts", {}).get("val") == 5000:
                    valid.append(p)
            bank_dir = choose_unique_contract(valid, "30K/5K pilot bank")
    bank_dir = Path(bank_dir).resolve()
    bc = read_json(bank_dir / b210.CT_NAME)
    audit = read_json(bank_dir / "sim_r10_iq512_audit_v1.json")
    need(bc.get("version") == "SIM_R10_IQ512_GENERATOR_V1" and bc.get("preset") == "pilot", "Wrong bank protocol")
    need(bc.get("counts", {}).get("train") == 30000 and bc.get("counts", {}).get("val") == 5000, "Wrong frozen TRAIN/VAL counts")
    need(bc.get("n_pulses") == 512, "Wrong IQ observation length")
    need(str(bc.get("status", "")).startswith("PASS_SIM_R10_IQ512_BUILDER_V1__"), "Bank builder has not passed")
    need(str(audit.get("status", "")).startswith("PASS_SIM_R10_IQ512_AUDIT_V1__"), "Bank audit has not passed")
    need(audit.get("bank_sha256") == bc.get("file_sha256"), "Bank/audit fingerprint mismatch")
    if cache_dir is None:
        valid = []
        for p in find_files(root, b210.CACHE_CT):
            c = read_json(p)
            if c.get("bank_sha256") == bc["file_sha256"] and c.get("source_sha256") == b210.SOURCE_SHA and c.get("trainer_sha256") == b210.TRAINER_SHA:
                valid.append(p)
        cache_dir = choose_unique_contract(valid, "frozen WVD cache")
    cache_dir = Path(cache_dir).resolve()
    cc = read_json(cache_dir / b210.CACHE_CT)
    need(cc.get("status") == b210.PASS_CACHE, "WVD cache has not passed")
    need(cc.get("bank_sha256") == bc["file_sha256"], "WVD cache is from another bank")
    need(cc.get("source_sha256") == b210.SOURCE_SHA and cc.get("trainer_sha256") == b210.TRAINER_SHA, "WVD source/trainer lineage mismatch")
    need(cc.get("bank_contract_sha256") == digest_file(bank_dir / b210.CT_NAME), "WVD cache bank contract drift")
    context = dict(root=root, bank_dir=bank_dir, cache_dir=cache_dir, bc=bc, cc=cc, b210=b210)
    # Rebuilt caches have a new file identity. Keep the original identity for
    # checking the unchanged L1 checkpoint; never rewrite its historical hash.
    if "recovery" in cc:
        cache_reference(context)
    return context


def cache_reference(context):
    """Return the original cache identity, after verifying recovery evidence."""
    cc, b210 = context["cc"], context["b210"]
    if "recovery" not in cc:
        return cc["wvd_cache_sha256"], None
    recovery = cc["recovery"]
    need(recovery.get("version") == "B270_WVD_RECOVERY_V1", "Unsupported WVD recovery version")
    original_path = context["cache_dir"] / "original_wvd_cache_contract.json"
    report_path = context["cache_dir"] / "recovery_validation.json"
    need(original_path.is_file() and report_path.is_file(), "Incomplete WVD recovery evidence")
    need(digest_file(original_path) == recovery.get("original_contract_sha256"), "Original cache contract recovery checksum mismatch")
    need(digest_file(report_path) == recovery.get("validation_report_sha256"), "WVD recovery report checksum mismatch")
    original, report = read_json(original_path), read_json(report_path)
    need(original.get("status") == b210.PASS_CACHE, "Original recovery cache was not frozen")
    for key in ("bank_sha256", "bank_contract_sha256", "source_sha256", "trainer_sha256"):
        need(original.get(key) == cc.get(key), f"WVD recovery changed {key}")
    need(report.get("version") == recovery["version"] and report.get("status") == "PASS_REBUILT_FROM_FROZEN_IQ__L1_VAL_CE_REPLAY", "WVD recovery validation did not pass")
    need(report.get("rebuilt_cache_sha256") == cc["wvd_cache_sha256"], "Recovery report references another rebuilt cache")
    need(report.get("original_cache_sha256") == original.get("wvd_cache_sha256") == recovery.get("original_cache_sha256"), "Recovery original cache identity mismatch")
    need(report.get("original_contract_sha256") == recovery["original_contract_sha256"], "Recovery report original contract mismatch")
    need(report.get("bank_sha256") == cc["bank_sha256"] and report.get("source_sha256") == cc["source_sha256"], "Recovery report source/bank mismatch")
    need(report.get("counts") == context["bc"]["counts"], "Recovery report data counts changed")
    need(report.get("h0_opened") is False and report.get("dev_h1_opened") is False, "Recovery must use TRAIN/VAL only")
    delta = report.get("validation_ce_absolute_difference")
    need(isinstance(delta, (int, float)) and np.isfinite(delta) and 0 <= delta < 1e-4, "Recovery L1 validation CE differs from its historical checkpoint")
    replay = report.get("wvd_sample_replay", {})
    need(replay.get("status") == "PASS" and replay.get("n_samples", 0) >= 2, "Recovery WVD sample replay is missing")
    return original["wvd_cache_sha256"], report


def device_for(name):
    device = torch.device("cuda" if name == "auto" and torch.cuda.is_available() else "cpu" if name == "auto" else name)
    need(device.type != "cuda" or torch.cuda.is_available(), "CUDA requested but unavailable")
    return device


def prepare_training(root, bank_dir=None, cache_dir=None, device="auto"):
    context = resolve_data(root, bank_dir, cache_dir)
    b210 = context["b210"]
    hp, bc, _ = b210.bank_contract(context["bank_dir"], "pilot")
    cache = context["cache_dir"] / b210.CACHE_H5
    need(cache.is_file(), f"Missing frozen WVD HDF5: {cache}")
    print("Verifying frozen WVD cache SHA256", flush=True)
    need(digest_file(cache) == context["cc"]["wvd_cache_sha256"], "WVD cache checksum mismatch")
    with h5py.File(cache, "r") as h:
        for split, count in (("train", 30000), ("val", 5000)):
            need(h[split]["wvd"].shape == (count, 128, 128) and h[split]["wvd"].dtype == np.dtype("float32"), f"Unexpected {split} WVD shape/dtype")
            labels = h[split]["label"][:]
            need(labels.shape == (count,) and np.isin(labels, (0, 1)).all() and (labels == 1).sum() == count // 2, f"Unexpected {split} labels")
    context.update(cache=cache, device=device_for(device), source=load_frozen_sources()[0])
    return context


@torch.inference_mode()
def evaluate(model, source, group, device, batch):
    model.eval()
    scores, labels = [], []
    ce, correct = 0.0, 0
    for start in range(0, len(group["label"]), batch):
        stop = min(start + batch, len(group["label"]))
        w = torch.from_numpy(np.ascontiguousarray(group["wvd"][start:stop], dtype=np.float32)).to(device)
        y = torch.from_numpy(group["label"][start:stop].astype("int64")).to(device)
        logits = model(source.map_to_adn_input(w))
        need(logits.shape == (stop - start, 2) and torch.isfinite(logits).all().item(), "Nonfinite or incorrectly shaped validation logits")
        ce += float(F.cross_entropy(logits, y, reduction="sum"))
        correct += int((logits.argmax(1) == y).sum())
        scores.append((logits[:, 1] - logits[:, 0]).cpu().numpy())
        labels.append(y.cpu().numpy())
    score, label = np.concatenate(scores), np.concatenate(labels)
    b214 = load_frozen_file("r10_sim_stage_b214_ablation_train_v1.py")
    return dict(auc=b214.auc(score, label), val_ce=ce / len(label), val_acc=correct / len(label), n_val=len(label), n_h0=int((label == 0).sum()), n_h1=int((label == 1).sum()))


def load_checkpoint(path):
    try:
        return torch.load(path, map_location="cpu", weights_only=True)
    except TypeError:
        return torch.load(path, map_location="cpu")


def verify_l1_checkpoint(path, context, seed):
    path = Path(path).resolve()
    need(path.is_file(), f"Missing original L1-Tail checkpoint: {path}")
    contract_path = path.with_name("training_contract.json")
    need(contract_path.is_file(), f"Missing L1-Tail training contract: {contract_path}")
    contract = read_json(contract_path)
    reference = load_frozen_sources()[2]
    need(contract.get("status") == reference.PASS, "Original L1-Tail training did not complete")
    need(contract.get("method") == "L1_TAIL" and contract.get("seed") == seed, "Wrong L1-Tail method/seed")
    need(contract.get("params_loss") == reference.PARAMS, "Original L1-Tail loss parameters drifted")
    need(digest_file(path) == contract.get("best_checkpoint_sha256"), "Original L1-Tail checkpoint checksum mismatch")
    ck = load_checkpoint(path)
    need(ck.get("method") == "L1_TAIL" and ck.get("seed") == seed, "L1-Tail checkpoint identity mismatch")
    original_cache_sha, recovery = cache_reference(context)
    for key, value in (("bank_sha256", context["bc"]["file_sha256"]), ("wvd_cache_sha256", original_cache_sha), ("source_sha256", context["b210"].SOURCE_SHA), ("trainer_sha256", context["b210"].TRAINER_SHA)):
        need(ck.get(key) == contract.get(key) == value, f"Original L1-Tail lineage mismatch: {key}")
    if recovery is not None:
        need(recovery.get("l1_checkpoint_sha256") == digest_file(path) and recovery.get("l1_training_contract_sha256") == digest_file(contract_path), "Recovery was validated against a different L1 checkpoint/contract")
    return ck, digest_file(path)
