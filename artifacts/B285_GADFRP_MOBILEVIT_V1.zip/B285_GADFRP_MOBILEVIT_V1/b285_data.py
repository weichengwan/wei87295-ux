"""Audited IQ-only TRAIN/VAL data and resumable GADF-RP caches. No model weights."""
import hashlib
import shutil
from pathlib import Path
import h5py
import numpy as np
import torch
from b285_common import need,read_json,write_json,digest_file,fingerprint,frozen,subset,SCENE_KEYS

GENERATOR='r10_sim_iq512_builder_v1_EARLIEST_HDF5.py'

def resolve(a):
    directory=a.bank_dir or a.root/'SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1'
    path=directory/'sim_r10_iq512_v1.h5';bc=read_json(directory/'sim_r10_iq512_v1_contract.json');audit=read_json(directory/'sim_r10_iq512_audit_v1.json')
    need(bc.get('version')=='SIM_R10_IQ512_GENERATOR_V1' and bc.get('preset')=='pilot' and bc.get('n_pulses')==512,'Wrong IQ bank')
    need(bc.get('counts',{}).get('train')==30000 and bc['counts'].get('val')==5000,'Expected frozen30k/5k bank')
    need(str(bc.get('status','')).startswith('PASS_SIM_R10_IQ512_BUILDER_V1__') and str(audit.get('status','')).startswith('PASS_SIM_R10_IQ512_AUDIT_V1__'),'Bank/audit not passed')
    print('Verifying frozen TRAIN/VAL IQ bank SHA256',flush=True)
    need(digest_file(path)==bc['file_sha256']==audit['bank_sha256'],'IQ bank checksum differs')
    with h5py.File(path,'r') as h:
        for split,count in [('train',30000),('val',5000)]:
            need(h[split]['iq'].shape==(count,512) and h[split]['iq'].dtype==np.complex64,'Bank HDF5 counts/IQ type differ from contract')
            labels=h[split]['label'][:]
            need(labels.shape==(count,) and np.isin(labels,(0,1)).all() and int(labels.sum())==count//2,'Unbalanced/malformed bank labels')
    generator=frozen(GENERATOR);need(digest_file(generator.__file__)==bc['generator_sha256'],'IQ generator differs')
    return dict(path=path,bc=bc,generator=generator)

def read_scene(a,context):
    path=a.scene_run/'pd_scr_full/protocol_frozen.json';p=read_json(path);pr=read_json(path.with_name('progress.json'))
    need(p['version']=='B280_FULL_FACTORIAL_SCORE_V1' and p['labels']==['A0','A1','A2','A3'],'Require original B280 scene protocol')
    need(p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==pr['fingerprint'],'Source scene protocol differs')
    need(pr['completed']==dict(h0_cal=3000000,h0_audit=1000000,h1=37),'Original B280 full scene metadata incomplete')
    scene={k:p[k] for k in SCENE_KEYS}
    need((scene['h0_cal_n'],scene['h0_audit_n'],scene['h1_scenes_n'])==(3000000,1000000,1024) and scene['scr_grid_db']==list(range(-24,13)),'Unexpected original scene counts/grid')
    need(p['scene_fingerprint']==fingerprint(scene),'Source scene fingerprint differs')
    need(scene['generator_sha']==context['bc']['generator_sha256'] and scene['master_seed']==context['bc']['seed'],'Scene generator/seed differs')
    need(tuple(scene['family_names'])==context['generator'].TRAIN_FAMILIES,'Scene families differ')
    return scene,dict(path=str(path),sha256=digest_file(path),fingerprint=p['fingerprint'])

class Data:
    def __init__(self,context,count,seed):
        self.values={};self.selection={};self.cache=None
        with h5py.File(context['path'],'r') as h:
            for split,n,offset in [('train',count,27101),('val',5000,27102)]:
                g=h[split];y=g['label'][:].astype('int64');fam=g['family_index'][:] if 'family_index' in g else None
                need(g['iq'].shape==(len(y),512) and g['iq'].dtype==np.complex64,'Wrong IQ array shape/type')
                chosen=subset(y,fam,n,seed+offset)
                self.values[split]=(g['iq'][chosen].astype('complex64'),y[chosen])
                self.selection[split]=dict(count=len(chosen),original_count=len(y),row_indices_sha256=hashlib.sha256(chosen.astype('<i8').tobytes()).hexdigest(),
                    counts_by_label={str(k):int((y[chosen]==k).sum()) for k in (0,1)},family_stratified=fam is not None)

    def prepare_cache(self,folder,frontend,device,batch,identity):
        folder=Path(folder);folder.mkdir(exist_ok=True);path=folder/'images.h5';manifest=folder/'cache_identity.json';progress=folder/'progress.json'
        ct_path=folder/'contract.json';identity=dict(identity,selected_rows=self.selection)
        if manifest.exists():need(read_json(manifest)==identity,'Image cache settings changed')
        else:
            need(not any(folder.iterdir()),'Nonempty image cache without identity');write_json(manifest,identity)
        if ct_path.exists():
            ct=read_json(ct_path);need(ct['identity']==identity and digest_file(path)==ct['sha256'],'Image cache changed')
        else:
            total=sum(len(v[1]) for v in self.values.values())
            need(shutil.disk_usage(folder).free>total*256*256+256*1024**2,'Not enough space for image cache; keep all existing results')
            if progress.exists():pr=read_json(progress);need(pr['fingerprint']==fingerprint(identity),'Cache resume identity differs')
            else:pr=dict(fingerprint=fingerprint(identity),completed=dict(train=0,val=0));write_json(progress,pr)
            need(path.exists() or not any(pr['completed'].values()),'Committed image cache is missing')
            with h5py.File(path,'a') as h:
                for split,(iq,y) in self.values.items():
                    n=len(y)
                    if split not in h:h.create_dataset(split,shape=(n,256,256),dtype='uint8',chunks=(min(16,n),256,256),compression='lzf')
                    need(h[split].shape==(n,256,256) and h[split].dtype==np.uint8,'Wrong cached image shape')
                    for start in range(pr['completed'][split],n,batch):
                        stop=min(start+batch,n);x=torch.from_numpy(np.ascontiguousarray(iq[start:stop])).to(device)
                        h[split][start:stop]=frontend.encode(x).cpu().numpy();h.flush()
                        pr['completed'][split]=stop;write_json(progress,pr)
                        if stop==n or stop%2000<batch:print(f'[GADF-RP cache {split}] {stop:,}/{n:,}',flush=True)
            write_json(ct_path,dict(identity=identity,sha256=digest_file(path),TRAIN_VAL_only=True,H0_CAL_AUDIT_H1_not_opened=True))
        self.cache=h5py.File(path,'r')
        # Compare original IQ rendering with cached boundary images, each run.
        for split,(iq,y) in self.values.items():
            ix=np.array([0,len(y)-1]);expected=frontend.encode(torch.from_numpy(iq[ix]).to(device)).cpu().numpy()
            need(np.array_equal(self.cache[split][ix],expected),'Image cache IQ replay differs')

    def fetch(self,split,index,frontend,device):
        need(self.cache is not None,'Image cache not open');ix=np.arange(len(self.values[split][1]))[index]
        unique,inverse=np.unique(ix,return_inverse=True);codes=self.cache[split][unique][inverse]
        image=frontend.decode(torch.from_numpy(np.ascontiguousarray(codes)).to(device))
        labels=torch.from_numpy(np.ascontiguousarray(self.values[split][1][ix])).to(device)
        return image,labels

    def close(self):
        if self.cache is not None:self.cache.close()
