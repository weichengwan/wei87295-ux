"""JMSE2025 GADF-RP improved MobileViT; medium first, full only by explicit command."""
import argparse
import fcntl
import gc
import shutil
import time
from pathlib import Path
from types import SimpleNamespace
import torch
from b285_common import ROOT,need,read_json,write_json,digest_file,fingerprint,validate_sources,code_hashes,setup
from b285_frontend import GADFRP,FRONTEND_CONFIG
from b285_data import resolve,read_scene,Data
from b285_train import train,optimizer_canary,load_selected
from b285_score import protocol,prefix_cache,numeric_probe,stream

def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=ROOT.parent);p.add_argument('--bank-dir',type=Path)
    p.add_argument('--out-dir',type=Path);p.add_argument('--scene-run',type=Path);p.add_argument('--reference-run',type=Path)
    p.add_argument('--training-size',choices=('medium','full'),default='medium');p.add_argument('--eval-size',choices=('medium','full'),default='medium')
    p.add_argument('--stage',choices=('all','preflight','train','score','report'),default='all');p.add_argument('--epochs',type=int)
    p.add_argument('--device',choices=('cuda','cpu'),default='cuda');p.add_argument('--cpu-threads',type=int,default=4)
    p.add_argument('--seed',type=int,default=20261022);p.add_argument('--batch',type=int,default=32);p.add_argument('--chunk',type=int,default=512)
    p.add_argument('--wait-for-gpu',action='store_true');a=p.parse_args(argv)
    a.root=a.root.resolve();a.out_dir=(a.out_dir or a.root/'output_b285_gadfrp_mobilevit_v1').resolve()
    a.scene_run=(a.scene_run or a.root/'output_b280_full_ablation_v1').resolve()
    need(a.root.is_dir() and a.root in a.out_dir.parents,'Output must be a new directory inside project root')
    for source in [a.scene_run,a.root/'output_b283_tfse_cgcr_full_v1',a.root/'output_b284_tfse_cgcr_factorial_v1']+([a.reference_run.resolve()] if a.reference_run else []):
        need(a.out_dir!=source and source not in a.out_dir.parents and a.out_dir not in source.parents,'Output overlaps existing results')
    if a.epochs is None:a.epochs=30 if a.training_size=='medium' else 150
    need(a.epochs>0 and a.cpu_threads>0 and a.batch==32 and a.chunk>=32 and a.chunk%32==0,'Use inference batch32, chunk multiple32, positive epochs/threads')
    if a.device=='cuda':need(torch.cuda.is_available(),'CUDA unavailable; run in mpdnet-r10 on AutoDL')
    a.device=torch.device(a.device);a.train_dir=a.out_dir/('train_'+a.training_size);a.score_dir=a.out_dir/f'pd_scr_{a.eval_size}_train_{a.training_size}'
    return a

def acquire(lock,wait):
    while True:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);return
        except BlockingIOError:
            need(wait,'Another radar task holds shared GPU lock')
            print('Another radar job is running; waiting for shared GPU lock. B284 is not interrupted.',flush=True);time.sleep(30)

def main(argv=None):
    a=cli(argv);setup(a.cpu_threads,a.seed);validate_sources()
    if a.stage=='report':
        from b285_report import generate
        return generate(a)
    print(f'B285 GADF-RP improved MobileViT | stage={a.stage} | train={a.training_size} | eval={a.eval_size}',flush=True)
    print('Paper-informed SIM adaptation; no TFSE/CGCR/WVD/SPWVD modules. Width/RP choices are disclosed, not recovered author settings.',flush=True)
    with (a.root/'codex_b271_night.lock').open('a') as lock:
        acquire(lock,a.wait_for_gpu);context=resolve(a);scene,scene_record=read_scene(a,context)
        a.out_dir.mkdir(exist_ok=True);a.train_dir.mkdir(exist_ok=True)
        frontend=GADFRP().to(a.device)
        if a.stage in ('all','train','preflight'):
            data=Data(context,16000 if a.training_size=='medium' else 30000,a.seed)
            try:
                identity=dict(bank_sha256=context['bc']['file_sha256'],frontend=FRONTEND_CONFIG,code_sha256=code_hashes())
                data.prepare_cache(a.train_dir/'image_cache',frontend,a.device,a.batch,identity)
                check=a.train_dir/'preflight.json';fp=fingerprint(identity)
                if check.exists():need(read_json(check)['fingerprint']==fp,'Canary implementation changed')
                else:write_json(check,dict(fingerprint=fp,checks=optimizer_canary(a,data,frontend)))
                if a.stage=='preflight':return
                train(a,context,data,frontend)
            finally:data.close()
            if a.stage=='train':return
        model,ct=load_selected(a,context);p=protocol(a,scene,scene_record,ct);cache,records=prefix_cache(a,p)
        p['medium_prefix_sources']=records;p['fingerprint']=fingerprint(p)
        probe=a.train_dir/('medium_cache_probe_for_'+a.eval_size+'.json')
        if probe.exists():need(read_json(probe)['protocol_fingerprint']==p['fingerprint'],'Cached score probe differs')
        else:write_json(probe,dict(protocol_fingerprint=p['fingerprint'],checks=numeric_probe(cache,model,frontend,context['generator'],p,a.device,a.batch)))
        need(shutil.disk_usage(a.out_dir).free>=256*1024**2,'Need256MiB free for raw scores and reports')
        print(f'Evaluation CAL={p["h0_cal_n"]:,}; AUDIT={p["h0_audit_n"]:,}; H1={p["h1_scenes_n"]}x37; Pfa={p["nominal_pfas"]}',flush=True)
        stream(a,p,model,frontend,context['generator'],cache)
        del model,frontend;gc.collect()
        if a.device.type=='cuda':torch.cuda.empty_cache()
        from b285_report import generate
        return generate(a)

if __name__=='__main__':main()
