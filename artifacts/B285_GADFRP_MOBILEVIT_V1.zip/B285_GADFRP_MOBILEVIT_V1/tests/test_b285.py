"""Generated IQ and synthetic metadata only; no user AutoDL performance claim."""
import copy
import gc
import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import h5py
import numpy as np
import torch
import torch.nn.functional as F
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from b285_common import ROOT,FILES,SCENE_KEYS,NAME,need,read_json,write_json,digest_file,fingerprint,validate_sources,setup,frozen,code_hashes,roc_metrics,load_checkpoint
from b285_frontend import GADFRP,FRONTEND_CONFIG
from b285_model import ImprovedMobileViT,MobileViTBlock,Transformer,MV2
from b285_data import Data,read_scene,resolve
from b285_train import evaluate,train,load_selected,optimizer_canary
from b285_score import make_iq,predict,stream,completed_arrays,prefix_cache,numeric_probe,protocol
from b285_report import generate,measures,references
import b285_run as runner
from coordatt import CoordAtt

class TinyData:
    def __init__(self):
        rng=np.random.default_rng(5);self.values={};self.images={};self.selection={}
        for split,n in [('train',16),('val',8)]:
            y=np.arange(n)%2;x=rng.uniform(0,1,(n,3,64,64)).astype('float32')
            self.values[split]=(np.zeros((n,512),'complex64'),y);self.images[split]=torch.from_numpy(x)
            self.selection[split]=dict(count=n,original_count=n,fixture=True)
    def fetch(self,split,index,frontend,device):
        return self.images[split][index].to(device),torch.from_numpy(self.values[split][1][index]).to(device)
    def close(self):pass
    def prepare_cache(self,*args):pass

def fixture(root,epochs=1):
    a=SimpleNamespace(root=root,out_dir=root/'output',train_dir=root/'output/train_medium',score_dir=root/'output/pd_scr_medium_train_medium',
        training_size='medium',eval_size='medium',device=torch.device('cpu'),batch=32,chunk=32,epochs=epochs,seed=42,cpu_threads=2,reference_run=None)
    a.out_dir.mkdir();a.train_dir.mkdir()
    g=frozen('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
    p=dict(master_seed=20261009,generator_sha=digest_file(g.__file__),h0_cal_n=3000000,h0_audit_n=1000000,h1_scenes_n=1024,
        scr_grid_db=list(range(-24,13)),h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',family_names=list(g.TRAIN_FAMILIES),scr_definition='synthetic fixture')
    context=dict(generator=g,bc=dict(file_sha256='synthetic-bank',seed=20261009,generator_sha256=p['generator_sha']))
    return a,context,p,TinyData()

class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):setup(2,42)
    def tearDown(self):gc.collect()

    def test_source_integrity_and_paper_vs_filled_settings(self):
        validate_sources();ct=read_json(ROOT/'paper_contract.json')
        self.assertFalse(ct['public_complete_author_implementation_verified']);self.assertTrue(ct['full_original_reviewed'])
        self.assertEqual(ct['SIM_adaptations']['observation_pulses'],512);self.assertFalse(ct['SIM_adaptations']['padding_or_interpolation_to_fake1024'])
        self.assertEqual(np.load(ROOT/'jet_lut.npy').shape,(256,3))
        with tempfile.TemporaryDirectory() as d:
            a=runner.cli(['--root',d,'--device','cpu'])
            self.assertEqual((a.epochs,a.training_size,a.eval_size,a.stage),(30,'medium','medium','all'))
            b=runner.cli(['--root',d,'--device','cpu','--training-size','full','--eval-size','full'])
            self.assertEqual(b.epochs,150)
            with self.assertRaisesRegex(RuntimeError,'overlaps'):runner.cli(['--root',d,'--device','cpu','--out-dir',str(Path(d)/'output_b284_tfse_cgcr_factorial_v1')])

    def test_GADF_formula_RP_embedding_and_amplitude_invariance(self):
        x=torch.tensor([[1.,2.,3.,2.],[2.,3.,1.,4.]]).to(torch.complex64)
        g,r=GADFRP.matrices(x);z=2*(x.abs()-x.abs().amin(1,keepdim=True))/(x.abs().amax(1,keepdim=True)-x.abs().amin(1,keepdim=True))-1
        expected=torch.sin(z.acos()[:,:,None]-z.acos()[:,None,:]);torch.testing.assert_close(g,expected,atol=2e-7,rtol=1e-6)
        torch.testing.assert_close(g,-g.transpose(1,2));self.assertTrue(torch.equal(torch.diagonal(g,dim1=1,dim2=2),torch.zeros(2,4)))
        self.assertTrue(set(r.flatten().tolist())<={0.,1.});self.assertTrue(torch.equal(r,r.transpose(1,2)))
        g2,r2=GADFRP.matrices(x*torch.polar(torch.tensor(3.),torch.tensor(.75)))
        torch.testing.assert_close(g,g2,atol=1e-6,rtol=1e-6);torch.testing.assert_close(r,r2)
        _,embedded=GADFRP.matrices(x,dimension=2,delay=1);self.assertEqual(embedded.shape,(2,3,3))
        constant,rc=GADFRP.matrices(torch.ones(2,8,dtype=torch.complex64));self.assertTrue(torch.equal(constant,torch.zeros_like(constant)));self.assertTrue((rc==1).all())

    def test_horizontal_fusion_and_cached_decode_equivalence(self):
        f=GADFRP();x=torch.randn(2,512,dtype=torch.complex64);codes=f.encode(x);rgb=f(x)
        self.assertEqual((codes.shape,codes.dtype),((2,256,256),torch.uint8));self.assertEqual(rgb.shape,(2,3,256,256))
        g,r=f.matrices(x);left=F.interpolate(((g+1)/2).unsqueeze(1),size=(256,256),mode='bilinear',align_corners=False)
        right=F.interpolate(r.unsqueeze(1),size=(256,256),mode='bilinear',align_corners=False)
        expected=(F.interpolate(torch.cat([left,right],-1),size=(256,256),mode='bilinear',align_corners=False)[:,0]*255).round().byte()
        torch.testing.assert_close(codes,expected,atol=0,rtol=0);torch.testing.assert_close(rgb,f.decode(codes),atol=0,rtol=0)
        with self.assertRaisesRegex(RuntimeError,'Expected complex'):f.encode(torch.randn(2,512))

    def test_bank_contract_rejects_wrong_HDF5_counts_and_checks_scene_identity(self):
        with tempfile.TemporaryDirectory() as d:
            a,context,p,data=fixture(Path(d));directory=Path(d)/'bank';directory.mkdir();path=directory/'sim_r10_iq512_v1.h5'
            with h5py.File(path,'w') as h:
                h.create_dataset('train/iq',shape=(32,512),dtype='complex64');h.create_dataset('train/label',data=np.arange(32)%2)
            bc=dict(version='SIM_R10_IQ512_GENERATOR_V1',preset='pilot',n_pulses=512,counts=dict(train=30000,val=5000),file_sha256=digest_file(path),generator_sha256=p['generator_sha'],seed=20261009,status='PASS_SIM_R10_IQ512_BUILDER_V1__FIXTURE')
            write_json(directory/'sim_r10_iq512_v1_contract.json',bc);write_json(directory/'sim_r10_iq512_audit_v1.json',dict(status='PASS_SIM_R10_IQ512_AUDIT_V1__FIXTURE',bank_sha256=bc['file_sha256']))
            a.bank_dir=directory
            with self.assertRaisesRegex(RuntimeError,'counts/IQ type'):resolve(a)
            a.scene_run=Path(d)/'source';folder=a.scene_run/'pd_scr_full';folder.mkdir(parents=True)
            source=dict(p,version='B280_FULL_FACTORIAL_SCORE_V1',labels=['A0','A1','A2','A3'],scene_fingerprint=fingerprint(p));source['fingerprint']=fingerprint(source)
            write_json(folder/'protocol_frozen.json',source);write_json(folder/'progress.json',dict(fingerprint=source['fingerprint'],completed=dict(h0_cal=3000000,h0_audit=1000000,h1=37)))
            scene,record=read_scene(a,context);self.assertEqual(scene,p);self.assertEqual(record['sha256'],digest_file(folder/'protocol_frozen.json'))
            source['master_seed']=1;source['scene_fingerprint']=fingerprint({k:source[k] for k in SCENE_KEYS});source['fingerprint']=fingerprint({k:v for k,v in source.items() if k!='fingerprint'})
            write_json(folder/'protocol_frozen.json',source);write_json(folder/'progress.json',dict(fingerprint=source['fingerprint'],completed=dict(h0_cal=3000000,h0_audit=1000000,h1=37)))
            with self.assertRaisesRegex(RuntimeError,'generator/seed'):read_scene(a,context)

    def test_Fig7_topology_patch_mapping_and_real_native_size_gradient(self):
        model=ImprovedMobileViT();blocks=[m for m in model.modules() if isinstance(m,MobileViTBlock)]
        self.assertEqual(len(blocks),3);self.assertEqual([sum(isinstance(v,Transformer) for v in b.global_rep) for b in blocks],[2,4,3])
        self.assertEqual(sum(isinstance(v,CoordAtt) for v in model.modules()),2);self.assertEqual(sum(isinstance(v,MV2) for v in model.modules()),7)
        self.assertFalse(any(type(m).__name__ in ['JointTFGate','SimAM','CrossFrequencyRefiner'] for m in model.modules()))
        x=torch.arange(2*3*4*6).reshape(2,3,4,6)
        torch.testing.assert_close(MobileViTBlock.fold(MobileViTBlock.unfold(x),x.shape),x,atol=0,rtol=0)
        seen={};hooks=[]
        for name in ['stem','layer1','layer2','layer3','layer4','layer5','last']:
            hooks.append(getattr(model,name).register_forward_hook(lambda mod,inp,out,key=name:seen.update({key:list(out.shape)})))
        model.train();image=GADFRP()(torch.randn(2,512,dtype=torch.complex64));before=model.layer1[1].conv_h.weight.detach().clone()
        optimizer=torch.optim.Adam(model.parameters(),lr=1e-3);loss=F.cross_entropy(model(image),torch.tensor([0,1]));loss.backward();optimizer.step()
        self.assertFalse(torch.equal(before,model.layer1[1].conv_h.weight));self.assertTrue(torch.isfinite(loss))
        self.assertEqual([seen[k][1:] for k in seen],[[16,128,128],[16,128,128],[24,64,64],[48,32,32],[64,16,16],[80,8,8],[320,8,8]])
        for h in hooks:h.remove()

    def test_real_HDF5_selected_rows_cache_replay_and_resume(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);a,context,p,_=fixture(root);path=root/'bank.h5';context['path']=path
            with h5py.File(path,'w') as h:
                for split,n in [('train',32),('val',16)]:
                    ss=[context['generator'].make_one(20261009,split,i,-30,10) for i in range(n)]
                    h.create_dataset(split+'/iq',data=np.stack([s['iq'] for s in ss]));h.create_dataset(split+'/label',data=[s['label'] for s in ss]);h.create_dataset(split+'/family_index',data=[s['family'] for s in ss])
            data=Data(context,16,42);self.assertEqual(data.selection['train']['counts_by_label'],{'0':8,'1':8})
            f=GADFRP();folder=root/'image_cache';identity=dict(frontend=FRONTEND_CONFIG,fixture=True)
            try:
                data.prepare_cache(folder,f,a.device,4,identity);ix=np.array([7,1,7,3]);images,y=data.fetch('train',ix,f,a.device)
                expected=f(torch.from_numpy(data.values['train'][0][ix]));torch.testing.assert_close(images,expected,atol=0,rtol=0)
                torch.testing.assert_close(y,torch.from_numpy(data.values['train'][1][ix]));data.close()
                sha=digest_file(folder/'images.h5')
                data.prepare_cache(folder,f,a.device,4,identity);self.assertEqual(digest_file(folder/'images.h5'),sha)
                data.close();(folder/'contract.json').unlink();pr=read_json(folder/'progress.json');pr['completed']['train']=8;write_json(folder/'progress.json',pr)
                data.prepare_cache(folder,f,a.device,4,identity);torch.testing.assert_close(data.fetch('train',ix,f,a.device)[0],expected,atol=0,rtol=0)
            finally:data.close()

    def test_actual_training_completed_skip_and_exact_epoch_resume(self):
        with tempfile.TemporaryDirectory() as d:
            a,context,p,data=fixture(Path(d),epochs=2);f=GADFRP();ct=train(a,context,data,f)
            final=load_checkpoint(a.train_dir/'last_epoch.pt');sha=digest_file(a.train_dir/'best.pt')
            with patch('torch.optim.Adam',side_effect=AssertionError('Complete model must not train')):train(a,context,data,f)
            self.assertEqual(digest_file(a.train_dir/'best.pt'),sha)
            original=a.train_dir;a.train_dir=a.out_dir/'interrupted';a.train_dir.mkdir();calls=[0];real=evaluate
            def interrupt(*args,**kwargs):
                calls[0]+=1
                if calls[0]==3:raise RuntimeError('simulated interruption')
                return real(*args,**kwargs)
            with patch('b285_train.evaluate',side_effect=interrupt):
                with self.assertRaisesRegex(RuntimeError,'simulated'):train(a,context,data,f)
            self.assertEqual(load_checkpoint(a.train_dir/'last_epoch.pt')['epoch'],1)
            train(a,context,data,f);resumed=load_checkpoint(a.train_dir/'last_epoch.pt')
            for k,v in final['state_dict'].items():torch.testing.assert_close(v,resumed['state_dict'][k],atol=0,rtol=0)
            a.train_dir=original;model,contract=load_selected(a,context)
            self.assertEqual(contract,ct);self.assertEqual(model(torch.randn(2,3,64,64)).shape,(2,2))

    def test_real_batch16_native256_optimizer_canary(self):
        with tempfile.TemporaryDirectory() as d:
            a,context,p,data=fixture(Path(d));frontend=GADFRP()
            data.images['train']=frontend(torch.randn(16,512,dtype=torch.complex64))
            result=optimizer_canary(a,data,frontend)
            self.assertTrue(result['three_real_TRAIN_optimizer_steps_discarded']);self.assertEqual(result['scoring_batch'],32)
            self.assertEqual(result['parameters'],952754)

    def test_frozen_scene_generation_and_37_level_score_resume(self):
        with tempfile.TemporaryDirectory() as d:
            a,context,p,data=fixture(Path(d));model=ImprovedMobileViT().eval();f=GADFRP()
            a.batch=2;a.chunk=2
            p=dict(protocol(a,p,dict(fixture=True),dict(fixture=True)),h0_cal_n=4,h0_audit_n=4,h1_scenes_n=2)
            p['fingerprint']=fingerprint(p);x=make_iq(context['generator'],p,'h0_cal',np.arange(2))
            raw=[context['generator'].make_one(p['master_seed'],'h0_cal',i,-30,10) for i in range(2)]
            np.testing.assert_array_equal(x,np.stack([s['base'] for s in raw]).astype('complex64'))
            h1=make_iq(context['generator'],p,'h1',np.arange(2),24);self.assertEqual(h1.shape,(2,512))
            stream(a,p,model,f,context['generator'],{});arrays=completed_arrays(a.score_dir,p)
            self.assertEqual(arrays['h1'].shape,(37,2));before={s:np.array(v) for s,v in arrays.items()}
            pr=read_json(a.score_dir/'progress.json');pr['completed'].update(h0_cal=2,h1=35);write_json(a.score_dir/'progress.json',pr)
            stream(a,p,model,f,context['generator'],{})
            for s,v in completed_arrays(a.score_dir,p).items():np.testing.assert_array_equal(v,before[s])
            (a.score_dir/'h0_audit_scores.npy').unlink()
            with self.assertRaisesRegex(RuntimeError,'missing'):stream(a,p,model,f,context['generator'],{})

    def test_medium_prefix_verified_and_full_infers_only_missing_rows(self):
        with tempfile.TemporaryDirectory() as d:
            a,context,scene,data=fixture(Path(d));model=ImprovedMobileViT().eval();f=GADFRP();ct=dict(fixture=True)
            p=dict(protocol(a,scene,{},ct),h0_cal_n=4,h0_audit_n=4,h1_scenes_n=2);p['medium_prefix_sources']=[];p['fingerprint']=fingerprint(p)
            stream(a,p,model,f,context['generator'],{})
            old=completed_arrays(a.score_dir,p);a.eval_size='full';full=dict(protocol(a,scene,{},ct),h0_cal_n=6,h0_audit_n=6,h1_scenes_n=4)
            cache,records=prefix_cache(a,full);self.assertEqual(len(records),3);numeric_probe(cache,model,f,context['generator'],full,a.device,32)
            a.score_dir=a.out_dir/'pd_scr_full_train_medium';full['medium_prefix_sources']=records;full['fingerprint']=fingerprint(full)
            with patch('b285_score.predict',wraps=predict) as fn:stream(a,full,model,f,context['generator'],cache)
            self.assertEqual(sum(len(call.args[2]) for call in fn.call_args_list),2+2+37*2)
            now=completed_arrays(a.score_dir,full)
            for split,v in old.items():np.testing.assert_array_equal(now[split][:,:2] if split=='h1' else now[split][:4],v)
            bad={k:np.array(v) for k,v in cache.items()};bad['h0_cal'][0]+=1
            with self.assertRaisesRegex(RuntimeError,'replay differs'):numeric_probe(bad,model,f,context['generator'],full,a.device,32)

    def test_dual_Pfa_report_real_counts_and_optional_reference_columns(self):
        with tempfile.TemporaryDirectory() as d:
            a,context,scene,data=fixture(Path(d));a.eval_size='full';a.score_dir=a.out_dir/'pd_scr_full_train_medium';a.score_dir.mkdir()
            n=1000000;cal=np.linspace(-6,6,n);audit=np.linspace(-6,6,20000);q=(np.arange(512)+.5)/512
            h1=np.stack([6+(scr-np.log(q/(1-q)))/3 for scr in range(-24,13)])
            p=dict(protocol(a,scene,{},dict(fixture=True)),h0_cal_n=n,h0_audit_n=len(audit),h1_scenes_n=512)
            p['medium_prefix_sources']=[];p['fingerprint']=fingerprint(p);write_json(a.score_dir/'protocol_frozen.json',p);write_json(a.score_dir/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=n,h0_audit=len(audit),h1=37)))
            for split,v in [('h0_cal',cal),('h0_audit',audit),('h1',h1)]:np.save(a.score_dir/FILES[split],v)
            ref=a.root/'output_b284_tfse_cgcr_factorial_v1/pd_scr_full';ref.mkdir(parents=True)
            old=dict(p,version='B284_TFSE_CGCR_FACTORIAL_SCORE_V1',labels=['ADN','TFSE','CGCR','FULL']);old.pop('fingerprint');old['fingerprint']=fingerprint(old)
            write_json(ref/'protocol_frozen.json',old);write_json(ref/'progress.json',dict(fingerprint=old['fingerprint'],completed=dict(h0_cal=n,h0_audit=len(audit),h1=37)))
            for split,v in [('h0_cal',cal),('h0_audit',audit),('h1',h1)]:np.save(ref/FILES[split],np.stack([v+j*.05 for j in range(4)],-1))
            report=generate(a);self.assertEqual(len(report['metrics']),6)
            self.assertFalse(report['official_code_reproduction']);self.assertTrue(report['source_Pd_unchanged'])
            self.assertTrue((a.score_dir/'figures/b285_pd_scr_pfa_1e-05.pdf').is_file())
            import csv
            with (a.score_dir/'b285_curves.csv').open() as stream:
                rows=list(csv.DictReader(stream));self.assertEqual(len(rows),37*2*3)
                self.assertTrue(all(abs(float(r['pd'])-int(r['hits'])/int(r['n_h1']))<1e-12 for r in rows))

    def test_runner_stops_after_medium_and_preserves_original_outputs(self):
        with tempfile.TemporaryDirectory() as d:
            a,context,scene,data=fixture(Path(d));original=Path(d)/'output_b284_tfse_cgcr_factorial_v1';original.mkdir();sentinel=original/'keep';sentinel.write_text('untouched')
            calls=[]
            def tiny_stream(args,p,model,frontend,generator,cache):
                self.assertEqual((p['h0_cal_n'],p['h0_audit_n'],p['h1_scenes_n'],p['nominal_pfas']),(300000,200000,512,[1e-4]));calls.append('medium')
                p=dict(p,h0_cal_n=2,h0_audit_n=2,h1_scenes_n=2);p['fingerprint']=fingerprint({k:v for k,v in p.items() if k!='fingerprint'})
                stream(args,p,model,frontend,generator,cache)
            with patch('b285_run.resolve',return_value=context),patch('b285_run.read_scene',return_value=(scene,{})),patch('b285_run.Data',return_value=data),patch('b285_run.optimizer_canary',return_value={'fixture':True}),patch('b285_run.stream',side_effect=tiny_stream),patch('b285_report.generate',return_value={'done':True}):
                result=runner.main(['--root',d,'--out-dir',str(a.out_dir),'--device','cpu','--cpu-threads','2','--seed','42','--epochs','1'])
            self.assertTrue(result['done']);self.assertEqual(calls,['medium']);self.assertEqual(sentinel.read_text(),'untouched')
            self.assertFalse((a.out_dir/'train_full').exists());self.assertFalse((a.out_dir/'pd_scr_full_train_medium').exists())

    @unittest.skipUnless(torch.cuda.is_available(),'No local CUDA; AutoDL startup runs real batch16 optimizer/batch32 inference canary')
    def test_CUDA_full_native_size_training_and_inference(self):
        model=ImprovedMobileViT().cuda();f=GADFRP().cuda();x=torch.randn(16,512,dtype=torch.complex64,device='cuda');y=torch.arange(16,device='cuda')%2
        optimizer=torch.optim.Adam(model.parameters(),lr=.003);loss=F.cross_entropy(model(f(x)),y);loss.backward();optimizer.step()
        with torch.inference_mode():self.assertEqual(model.eval()(f(torch.cat([x,x],0))).shape,(32,2))

if __name__=='__main__':unittest.main(verbosity=2)
