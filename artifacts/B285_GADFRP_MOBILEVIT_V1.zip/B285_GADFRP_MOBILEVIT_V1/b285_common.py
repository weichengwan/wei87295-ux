"""Independent JMSE2025 baseline: immutable inputs, atomic progress and provenance."""
import csv
import hashlib
import importlib.util
import json
import random
import sys
from functools import lru_cache
from pathlib import Path
import numpy as np
import torch

ROOT=Path(__file__).resolve().parent
NAME='Improved MobileViT (GADF-RP; SIM-adapt)'
SCENE_KEYS=('master_seed','generator_sha','h0_cal_n','h0_audit_n','h1_scenes_n','scr_grid_db',
    'h0_cal_split','h0_audit_split','h1_split','family_names','scr_definition')
FILES=dict(h0_cal='h0_cal_scores.npy',h0_audit='h0_audit_scores.npy',h1='dev_h1_scores.npy')
PASS='PASS_B285_IMPROVED_MOBILEVIT_TRAIN_VAL_ONLY'

def need(condition,message):
    if not bool(condition):raise RuntimeError(message)

def digest_file(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(8<<20),b''):h.update(b)
    return h.hexdigest()

def read_json(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def fingerprint(obj):return hashlib.sha256(json.dumps(obj,sort_keys=True,allow_nan=False).encode()).hexdigest()

def write_json(path,obj):
    path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8');tmp.replace(path)

def save_csv(path,rows):
    need(bool(rows),'No CSV rows')
    with Path(path).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def atomic_save(path,obj):
    path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp');torch.save(obj,tmp);tmp.replace(path)

def load_checkpoint(path):
    try:return torch.load(path,map_location='cpu',weights_only=False)
    except TypeError:return torch.load(path,map_location='cpu')

def snapshot(model):return {k:v.detach().cpu().clone() for k,v in model.state_dict().items()}

def setup(threads,seed):
    torch.set_num_threads(threads);random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark=False;torch.backends.cudnn.allow_tf32=False;torch.backends.cuda.matmul.allow_tf32=False

def validate_sources():
    for name,sha in read_json(ROOT/'reference_sources.json').items():
        need(digest_file(ROOT/name)==sha,'Frozen source changed: '+name)
    need(digest_file(ROOT/'jet_lut.npy')==read_json(ROOT/'paper_contract.json')['jet_lut_sha256'],'Fixed color lookup changed')

def code_hashes():
    return {p.relative_to(ROOT).as_posix():digest_file(p) for p in sorted(ROOT.glob('*.py'))+[ROOT/'reference_sources.json',ROOT/'paper_contract.json',ROOT/'jet_lut.npy']}

@lru_cache(maxsize=None)
def frozen(name):
    path=ROOT/'frozen_source'/name;manifest=read_json(ROOT/'reference_sources.json')
    need(manifest.get('frozen_source/'+name)==digest_file(path),'Frozen dependency differs')
    spec=importlib.util.spec_from_file_location('b285_'+hashlib.sha256(name.encode()).hexdigest()[:12],path)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module);return module

def subset(labels,families,count,seed):
    labels=np.asarray(labels);need(np.isin(labels,(0,1)).all(),'Invalid labels')
    if count>=len(labels):return np.arange(len(labels),dtype='int64')
    need(count>=2 and count%2==0,'Balanced subset must have positive even size')
    families=np.zeros(len(labels),dtype='int64') if families is None else np.asarray(families)
    selected=[]
    for label in (0,1):
        available=np.flatnonzero(labels==label);n=count//2;need(len(available)>=n,'Insufficient samples')
        groups=[available[families[available]==v] for v in np.unique(families[available])]
        desired=n*np.array([len(g) for g in groups])/len(available);quota=np.floor(desired).astype(int)
        quota[np.argsort(-(desired-quota),kind='stable')[:n-int(quota.sum())]]+=1
        for j,(g,k) in enumerate(zip(groups,quota)):
            selected.extend(np.random.default_rng(seed+1000*label+j).permutation(g)[:k])
    return np.sort(np.asarray(selected,dtype='int64'))

def indices(labels,epoch,batch,seed):
    z=np.flatnonzero(labels==0);o=np.flatnonzero(labels==1);need(len(z)==len(o),'Unbalanced TRAIN')
    rng=np.random.default_rng(seed+997*epoch);z=rng.permutation(z);o=rng.permutation(o)
    for start in range(0,len(z),batch//2):yield rng.permutation(np.r_[z[start:start+batch//2],o[start:start+batch//2]])

def roc_metrics(scores,labels):
    order=np.argsort(-scores,kind='stable');s=np.asarray(scores)[order];y=np.asarray(labels)[order]
    n0=(y==0).sum();n1=(y==1).sum();need(n0 and n1,'VAL needs both classes')
    ends=np.r_[np.flatnonzero(s[1:]!=s[:-1]),len(s)-1]
    x=np.r_[0.,np.cumsum(y==0)[ends]/n0];t=np.r_[0.,np.cumsum(y==1)[ends]/n1]
    integrate=np.trapezoid if hasattr(np,'trapezoid') else np.trapz
    auc=float(integrate(t,x));keep=x<=.01;xp=x[keep];tp=t[keep]
    if xp[-1]<.01:
        r=int(np.searchsorted(x,.01,side='left'));l=r-1
        xp=np.r_[xp,.01];tp=np.r_[tp,t[l]+(t[r]-t[l])*(.01-x[l])/(x[r]-x[l])]
    return dict(val_auc=auc,val_pauc01=float(integrate(tp,xp)/.01))
