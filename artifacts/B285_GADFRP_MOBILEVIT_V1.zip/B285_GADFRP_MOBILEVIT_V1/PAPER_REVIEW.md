# 原文分析与复现边界

原文：Yang Liu, Hongyan Xing, Tianhao Hou. **Sea Surface Floating Small-Target Detection Based on Dual-Feature Images and Improved MobileViT**. JMSE2025,13(3),572. DOI:10.3390/jmse13030572。

已阅读用户提供的27页v3原文，并查看第6、9、12、15页的公式、结构图与输入编码说明。所上传PDF中存在部分重叠的旧版文字层，网络与输入解释以可见的最终版图7、公式和第4.2节为依据。完整PDF不随公开代码发布。

## 论文明确给出的内容

1. 输入是回波幅度时序；论文原实验取1024点、滑窗步长100，使用实测IPIX。
2. 公式1将单条时序映射到[-1,1]；公式7为GADF，`sin(phi_i-phi_j)`，不是GASF。
3. 公式8定义延迟嵌入，公式9按欧氏距离阈值生成RP。
4. 第4.2节（第15页）：GADF、RP分别为256×256；左右拼接为宽512、高256，再沿水平方向压回256×256。这里不是两支CNN，也不是把两幅图作为不同输入通道。
5. 图7（第12页）：stem3×3/stride2；Layer1一个MV2；Layer2下采样MV2加两个MV2；CA分别放在Layer1与Layer2之后；Layer3/4/5采用下采样MV2加MobileViT block，Transformer层数2/4/3、patch2×2；末尾1×1卷积、GAP、linear、post-linear Dropout。
6. MV2前两个卷积后使用SiLU，最后线性投影不加激活；CA按原CA方法的双方向池化与乘性重标定实现。
7. 表2到表4：最终选择batch16、150轮；学习率范围1e-6至3e-3；余弦调度并描述了warm restart。
8. 原文主体在名义Pfa1e-3评价，并包含不设固定Pfa的分类性能表。其98.6%不能当作当前SIM、512点、Pfa1e-4的预期Pd。

## 论文没有充分公开，必须标明的选择

全文没有给出可核实的完整作者源码、预训练权重，也没有完整的通道/Transformer宽度表。图7不能唯一确定XXS、XS或S。因此本包采用**原始Apple MobileViT XXS的标准宽度**，不是宣称找到了作者具体宽度：

- stem16；阶段通道16/24/48/64/80；Transformer宽度64/80/96；FFN128/160/192；四头注意力；MV2扩展2；末尾320。
- CA使用作者公开的MIT许可实现，`reduction=32`。CA位置、MV2数量、Transformer深度/patch和图7一致。
- Dropout值、优化器、weight decay、warm-restart周期、checkpoint选择细则未充分说明。本包固定post-linear及Transformer残差Dropout0.1、Adam、weight_decay0、T0=10/Tmult=2、minimum VAL CE。这些不是原文已证实的具体设置。
- RP的m、tau、epsilon没有数值。本包固定m1、tau1、epsilon为单窗口归一化范围的0.1；按公式9进行二值化。常量输入时保留`distance<=epsilon`，RP全1。
- 第2.2节随后又讨论以颜色表达向量距离，存在二值公式与彩色距离表述的歧义。本包采用明确的二值公式9，不声称作者实际脚本就是如此。
- 颜色、插值、RGB归一化未给出完整配置。本包固定bilinear、jet、标量图压缩后颜色映射、uint8图像和RGB/255。缓存仅存256×256单通道索引，不保存巨量RGB副本。
- 原文没有明确展示多尺度额外跨层旁路，图7就是串行网络。未自行增加跨层融合、其他注意力或我们的模块。

本实现约952,754个参数。该数字是本包标准XXS补齐版本的参数量，不是原作者报告值。可称为“依据原文结构重建的SIM适配版本”，不能称“官方源码逐字复现”或“原文指标完整复现”。

## 当前数据适配

保持当前冻结512点IQ窗口，不拼接独立场景、补零或插值假装得到1024点。对`abs(IQ)`按相同编码公式生成256×256输入。其余监督标签、固定场景、SCR定义、独立H0 CAL/AUDIT沿用现有协议。

默认中规模：16,000TRAIN/5,000VAL、30轮、batch16。训练数据以标签及杂波家族分层抽取，只用完整VAL CE选权重。CAL/AUDIT/H1不会进入训练、学习率或checkpoint选择。

先校准300kH0，审计200k独立H0，评估37个SCR、每点512H1，名义Pfa1e-4。中规模停止后可独立做全量评分，或另起30k/5k、150轮训练。保持网络结构不变，预算与数据来源如实记录。

评分用logit1−logit0，是二分类H1 softmax概率的严格单调变换；按各自H0 CAL定门限，严格`score>threshold`，另外报告实际AUDIT Pfa与Wilson95%区间。未达0.9的D90为NA，不外推。旧方法的参考曲线仅从协议匹配的完成原始分数读取，按当前评价前缀重新校准；不会直接混用历史全量CSV的门限。

## 引用与源码来源

- 本论文：https://doi.org/10.3390/jmse13030572
- MobileViT原始配置：https://github.com/apple/ml-cvnets/blob/main/cvnets/models/classification/config/mobilevit.py
- Coordinate Attention作者实现：https://github.com/houqb/CoordAttention

原始宽度配置、来源哈希与许可证在`upstream_reference/`；CA的`coordatt.py`保持原样。MobileViT主干为独立实现，未引入timm、torchvision权重下载或CUDA扩展。
