"""Paper Eqs1/7/8/9 and Sec4.2; disclosed missing parameters in paper_contract.json."""
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from b285_common import ROOT,need

FRONTEND_CONFIG=dict(version='B285_GADF_RP_AMPLITUDE_V1',input='abs(complex IQ)',observation_pulses=512,
    paper_observation_pulses=1024,image_size=256,rp_dimension=1,rp_delay=1,
    rp_mode='binary_formula9',rp_epsilon_fraction_of_normalized_range=.1,
    fusion='GADF left, RP right; 256x256 each -> horizontal concat -> 256x256 compression',
    resampling='bilinear, align_corners=False',color='fixed matplotlib jet LUT after scalar-image compression',
    quantization='round-to-nearest uint8 scalar image, decoded by fixed RGB LUT',normalization='RGB/255; no augmentation or ImageNet normalization')

class GADFRP(nn.Module):
    def __init__(self):
        super().__init__();self.register_buffer('lut',torch.from_numpy(np.load(ROOT/'jet_lut.npy',allow_pickle=False)),persistent=False)

    @staticmethod
    def matrices(iq,dimension=1,delay=1,epsilon_fraction=.1):
        need(torch.is_complex(iq) and iq.ndim==2 and iq.shape[1]>1,'Expected complex [B,L] IQ')
        need(torch.isfinite(iq).all(),'Nonfinite IQ')
        amp=iq.abs().float();lo=amp.amin(1,keepdim=True);span=amp.amax(1,keepdim=True)-lo
        scaled=2*(amp-lo)/span.clamp_min(1e-12)-1
        scaled=torch.where(span>1e-12,scaled,torch.zeros_like(scaled)).clamp(-1,1)
        sine=(1-scaled.square()).clamp_min(0).sqrt()
        # sin(phi_i-phi_j); an antisymmetric matrix, not GASF.
        gadf=sine[:,:,None]*scaled[:,None,:]-scaled[:,:,None]*sine[:,None,:]
        n=scaled.shape[1]-(dimension-1)*delay;need(dimension>=1 and delay>=1 and n>1,'Invalid RP embedding')
        phase=torch.stack([scaled[:,j*delay:j*delay+n] for j in range(dimension)],-1)
        distance=(phase[:,:,None,:]-phase[:,None,:,:]).square().sum(-1).sqrt()
        threshold=(scaled.amax(1)-scaled.amin(1))*epsilon_fraction*(dimension**.5)
        rp=(distance<=threshold[:,None,None]).float()
        return gadf,rp

    @torch.no_grad()
    def encode(self,iq):
        gadf,rp=self.matrices(iq)
        first=F.interpolate(((gadf+1)/2).unsqueeze(1),size=(256,256),mode='bilinear',align_corners=False)
        second=F.interpolate(rp.unsqueeze(1),size=(256,256),mode='bilinear',align_corners=False)
        merged=F.interpolate(torch.cat([first,second],-1),size=(256,256),mode='bilinear',align_corners=False)
        return (merged[:,0].clamp(0,1)*255).round().to(torch.uint8)

    def decode(self,codes):
        need(codes.ndim==3 and codes.dtype==torch.uint8,'Expected cached uint8 [B,H,W] images')
        return self.lut[codes.long()].permute(0,3,1,2).contiguous().float()/255

    def forward(self,iq):return self.decode(self.encode(iq))
