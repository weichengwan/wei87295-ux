"""Raw37-point Pd and audited Pfa; optional paired historical reference curves."""
from pathlib import Path
import numpy as np
from b285_common import need,read_json,write_json,fingerprint,digest_file,save_csv,frozen,NAME,FILES,SCENE_KEYS
from b285_score import completed_arrays

def crossing(x,y,level):
    if y[0]>=level:return float(x[0])
    for i in range(1,len(x)):
        if y[i-1]<level<=y[i]:return float(x[i-1]+(level-y[i-1])*(x[i]-x[i-1])/(y[i]-y[i-1]))
    return None

def measures(name,arrays,p):
    stats=frozen('r10_sim_stage_b216_pdscr_report_v1.py');curves=[];metrics=[]
    for nominal in p['nominal_pfas']:
        th,k,calfp=stats.cutoff(arrays['h0_cal'],nominal);fp=int((arrays['h0_audit']>th).sum());n=len(arrays['h0_audit']);lo,hi=stats.wilson(fp,n)
        hits=(arrays['h1']>th).sum(1);pd=hits/arrays['h1'].shape[1]
        metric=dict(method=name,nominal_pfa=nominal,actual_pfa=fp/n,audit_false_alarms=fp,audit_n=n,actual_pfa_ci95_low=lo,actual_pfa_ci95_high=hi,
            threshold=th,cal_n=len(arrays['h0_cal']),cal_tail_support=k,cal_exceedances=calfp,
            D50_db=crossing(p['scr_grid_db'],pd,.5),D80_db=crossing(p['scr_grid_db'],pd,.8),D90_db=crossing(p['scr_grid_db'],pd,.9))
        for scr in [0,6,9,12]:metric['pd_at_'+str(scr)]=float(pd[p['scr_grid_db'].index(scr)])
        metrics.append(metric)
        for scr,count in zip(p['scr_grid_db'],hits):
            low,high=stats.wilson(int(count),arrays['h1'].shape[1])
            curves.append(dict(method=name,nominal_pfa=nominal,scr_db=scr,hits=int(count),n_h1=arrays['h1'].shape[1],pd=float(count/arrays['h1'].shape[1]),pd_ci95_low=low,pd_ci95_high=high))
    return curves,metrics

def references(a,p):
    # References are optional, read only after the external baseline is selected.
    candidates=[(a.reference_run or a.root/'output_b284_tfse_cgcr_factorial_v1','B284_TFSE_CGCR_FACTORIAL_SCORE_V1',['ADN','TFSE','CGCR','FULL'],[('ADN (matched continuation)',0),('ADN + TFSE + CGCR (Ours)',3)]),
        (a.root/'output_b283_tfse_cgcr_full_v1','B283_FULL_INCREMENTAL_SCORE_V1',['A1_frozen','control','unguided','guided','ADN'],[('ADN (B280 A0)',4),('ADN + TFSE + CGCR (Ours)',3)])]
    for run,version,labels,columns in candidates:
        folder=run/'pd_scr_full';path=folder/'protocol_frozen.json';progress=folder/'progress.json'
        if not path.is_file() or not progress.is_file():continue
        old=read_json(path);pr=read_json(progress)
        if pr.get('completed')!=dict(h0_cal=old['h0_cal_n'],h0_audit=old['h0_audit_n'],h1=37):continue
        need(old['version']==version and old['labels']==labels,'Unexpected reference model ordering')
        need(old['fingerprint']==fingerprint({k:v for k,v in old.items() if k!='fingerprint'})==pr['fingerprint'],'Reference protocol changed')
        need(all(old[k]==p[k] for k in SCENE_KEYS if not k.endswith('_n')),'Reference scenes differ')
        if not all((folder/f).is_file() for f in FILES.values()):continue
        arrays={};record=dict(source=str(folder),protocol_sha256=digest_file(path),array_sha256={},numerical_replay_of_reference_weights=False,
            note='Historical raw scores are verified by protocol/shape/file hashes; no source weight inference replay in this independent baseline package.')
        for split,file in FILES.items():
            v=np.load(folder/file,mmap_mode='r',allow_pickle=False);n=old['h1_scenes_n'] if split=='h1' else old[split+'_n']
            need(v.shape==((37,n,len(labels)) if split=='h1' else (n,len(labels))) and v.dtype==np.float64 and np.isfinite(v).all(),'Reference raw scores malformed')
            wanted=p['h1_scenes_n'] if split=='h1' else p[split+'_n'];need(n>=wanted,'Reference scoring smaller than requested')
            arrays[split]=v[:,:wanted] if split=='h1' else v[:wanted];record['array_sha256'][file]=digest_file(folder/file)
        return [(name,{s:v[:,:,col] if s=='h1' else v[:,col] for s,v in arrays.items()}) for name,col in columns],record
    return [],dict(note='Complete paired historical raw score arrays unavailable; plot standalone external baseline.')

def generate(a):
    folder=a.score_dir;p=read_json(folder/'protocol_frozen.json');need(p['version']=='B285_MOBILEVIT_SCORE_V1','Unexpected report')
    own=completed_arrays(folder,p);others,ref_record=references(a,p);curves=[];metrics=[]
    for name,arrays in [(NAME,own),*others]:
        cv,mt=measures(name,arrays,p);curves+=cv;metrics+=mt
    save_csv(folder/'b285_curves.csv',curves);save_csv(folder/'b285_metrics.csv',metrics)
    comparisons=[]
    for nominal in p['nominal_pfas']:
        selected=[r for r in metrics if r['nominal_pfa']==nominal];candidate=next(r for r in selected if r['method']==NAME)
        for reference in selected:
            if reference['method']==NAME:continue
            difference=lambda key:None if candidate[key] is None or reference[key] is None else candidate[key]-reference[key]
            comparisons.append(dict(candidate=NAME,reference=reference['method'],nominal_pfa=nominal,
                delta_D80_db=difference('D80_db'),delta_D90_db=difference('D90_db'),pd_at_0_gain_pp=100*difference('pd_at_0'),
                candidate_false_alarms=candidate['audit_false_alarms'],reference_false_alarms=reference['audit_false_alarms'],negative_delta_means_left=True))
    if comparisons:save_csv(folder/'b285_comparisons.csv',comparisons)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    figdir=folder/'figures';figdir.mkdir(exist_ok=True)
    for nominal in p['nominal_pfas']:
        fig,ax=plt.subplots(figsize=(8,5));plot_sources=[]
        for name in dict.fromkeys(r['method'] for r in curves):
            rows=[r for r in curves if r['method']==name and r['nominal_pfa']==nominal]
            if 'Ours' in name:style=dict(color='black',marker='v',markerfacecolor='white',linestyle='-',linewidth=2)
            elif name==NAME:style=dict(color='tab:blue',marker='o',markerfacecolor='white',linestyle='-',linewidth=1.6)
            else:style=dict(color='tab:purple',marker='s',markerfacecolor='white',linestyle='-',linewidth=1.4)
            ax.plot([r['scr_db'] for r in rows],[r['pd'] for r in rows],label=name,markevery=2,markersize=5,**style);plot_sources+=rows
        ax.set(xlabel='SCR (dB)',ylabel=r'$P_d$',xlim=(-24,12),ylim=(0,1.02),title=r'$P_{\mathrm{fa}}=10^{'+str(int(np.log10(nominal)))+'}$')
        ax.grid(alpha=.25);ax.legend(fontsize=8);fig.tight_layout()
        for ext in ['pdf','png','svg']:fig.savefig(figdir/f'b285_pd_scr_pfa_{nominal:.0e}.{ext}',dpi=250)
        plt.close(fig);save_csv(figdir/f'b285_pd_source_pfa_{nominal:.0e}.csv',plot_sources)
        selected=[r for r in metrics if r['nominal_pfa']==nominal]
        fig,ax=plt.subplots(figsize=(8,3));pos=np.arange(len(selected));vals=np.array([r['actual_pfa'] for r in selected]);low=np.array([r['actual_pfa_ci95_low'] for r in selected]);hi=np.array([r['actual_pfa_ci95_high'] for r in selected])
        ax.errorbar(pos,vals,yerr=[vals-low,hi-vals],fmt='o',capsize=4);ax.axhline(nominal,color='black',linestyle='--')
        ax.set_xticks(pos,[r['method'] for r in selected],fontsize=7);ax.set_ylabel('Audited Pfa');ax.set_title(f'Nominal Pfa={nominal:g}; Wilson95% interval');fig.tight_layout();fig.savefig(figdir/f'b285_empty_pfa_{nominal:.0e}.pdf');plt.close(fig)
    ct=p['training_contract']
    report=dict(status='PASS_B285_PDSCR_DEV_ONLY',method=NAME,training_contract=ct,metrics=metrics,comparisons=comparisons,reference_audit=ref_record,
        official_code_reproduction=False,paper_informed_SIM_adaptation=True,independent_final=False,source_Pd_unchanged=True,curve_shifting=False,
        RP_and_width_details_underreported=True,medium_does_not_trigger_full=True)
    write_json(folder/'b285_report.json',report)
    for r in metrics:print(f'{r["method"]} Pfa={r["nominal_pfa"]:g}: D90={r["D90_db"]}; Pd@0={r["pd_at_0"]:.4f}; Pd@12={r["pd_at_12"]:.4f}; H0 FP={r["audit_false_alarms"]}/{r["audit_n"]}',flush=True)
    print(f'PASS_B285_MEDIUM_OR_FULL_REPORT: {folder}; no automatic next scale',flush=True);return report
