"""Fig7 topology; original MobileViT XXS widths fill unpublished width details.

Independent implementation. CA implementation is the unchanged MIT-licensed
author file coordatt.py. Full provenance/uncertainties: PAPER_REVIEW.md.
"""
import torch
from torch import nn
import torch.nn.functional as F
from coordatt import CoordAtt
from b285_common import need

MODEL_CONFIG=dict(version='B285_FIG7_MOBILEVIT_XXS_V1',width_source='Apple original MobileViT XXS; JMSE width variant unspecified',
    stem=16,stage_channels=[16,24,48,64,80],transformer_dims=[64,80,96],transformer_depths=[2,4,3],
    ffn_multiplier=2,mv2_expansion=2,attention_heads=4,patch=[2,2],ca_after_layers=[1,2],ca_reduction=32,
    final_channels=320,classes=2,head='global average pooling -> linear2 -> Dropout0.1',
    transformer_dropout=.1,ffn_dropout=0.,attention_dropout=0.,MV2_activation='SiLU',initialization='random, no pretrained weights')

class Conv(nn.Sequential):
    def __init__(self,ci,co,k=3,s=1,groups=1,activate=True):
        super().__init__(nn.Conv2d(ci,co,k,s,k//2,groups=groups,bias=False),nn.BatchNorm2d(co),nn.SiLU() if activate else nn.Identity())

class MV2(nn.Module):
    def __init__(self,ci,co,stride=1):
        super().__init__();hidden=ci*2
        self.block=nn.Sequential(Conv(ci,hidden,1),Conv(hidden,hidden,3,stride,groups=hidden),Conv(hidden,co,1,activate=False))
        self.skip=stride==1 and ci==co
    def forward(self,x):
        y=self.block(x);return x+y if self.skip else y

class Attention(nn.Module):
    def __init__(self,dim):
        super().__init__();self.heads=4;self.dim=dim;self.qkv=nn.Linear(dim,dim*3);self.out=nn.Linear(dim,dim)
    def forward(self,x):
        b,n,d=x.shape
        q,k,v=self.qkv(x).reshape(b,n,3,4,d//4).permute(2,0,3,1,4).unbind(0)
        z=F.scaled_dot_product_attention(q,k,v,dropout_p=0.)
        return self.out(z.transpose(1,2).reshape(b,n,d))

class Transformer(nn.Module):
    def __init__(self,d):
        super().__init__();self.norm1=nn.LayerNorm(d);self.attn=Attention(d);self.drop1=nn.Dropout(.1)
        self.norm2=nn.LayerNorm(d);self.ffn=nn.Sequential(nn.Linear(d,2*d),nn.SiLU(),nn.Linear(2*d,d),nn.Dropout(.1))
    def forward(self,x):
        x=x+self.drop1(self.attn(self.norm1(x)));return x+self.ffn(self.norm2(x))

class MobileViTBlock(nn.Module):
    def __init__(self,channels,dim,depth):
        super().__init__();self.local=nn.Sequential(Conv(channels,channels,3),nn.Conv2d(channels,dim,1,bias=False))
        self.global_rep=nn.Sequential(*[Transformer(dim) for _ in range(depth)],nn.LayerNorm(dim))
        self.project=Conv(dim,channels,1);self.fuse=Conv(2*channels,channels,3)
    @staticmethod
    def unfold(x):
        b,d,h,w=x.shape;need(h%2==w%2==0,'MobileViT feature map must be divisible by2')
        return x.reshape(b,d,h//2,2,w//2,2).permute(0,3,5,2,4,1).reshape(b*4,(h//2)*(w//2),d)
    @staticmethod
    def fold(x,shape):
        b,d,h,w=shape
        return x.reshape(b,2,2,h//2,w//2,d).permute(0,5,3,1,4,2).reshape(b,d,h,w)
    def forward(self,x):
        z=self.local(x);shape=z.shape;z=self.fold(self.global_rep(self.unfold(z)),shape)
        return self.fuse(torch.cat([x,self.project(z)],1))

class ImprovedMobileViT(nn.Module):
    def __init__(self):
        super().__init__();self.stem=Conv(3,16,3,2)
        self.layer1=nn.Sequential(MV2(16,16),CoordAtt(16,16))
        self.layer2=nn.Sequential(MV2(16,24,2),MV2(24,24),MV2(24,24),CoordAtt(24,24))
        self.layer3=nn.Sequential(MV2(24,48,2),MobileViTBlock(48,64,2))
        self.layer4=nn.Sequential(MV2(48,64,2),MobileViTBlock(64,80,4))
        self.layer5=nn.Sequential(MV2(64,80,2),MobileViTBlock(80,96,3))
        self.last=Conv(80,320,1);self.pool=nn.AdaptiveAvgPool2d(1);self.fc=nn.Linear(320,2);self.dropout=nn.Dropout(.1)
        self.apply(self.initialize)
    @staticmethod
    def initialize(m):
        if isinstance(m,nn.Conv2d):
            nn.init.kaiming_normal_(m.weight,mode='fan_out')
            if m.bias is not None:nn.init.zeros_(m.bias)
        elif isinstance(m,(nn.BatchNorm2d,nn.LayerNorm)):
            nn.init.ones_(m.weight);nn.init.zeros_(m.bias)
        elif isinstance(m,nn.Linear):nn.init.trunc_normal_(m.weight,std=.02);nn.init.zeros_(m.bias)
    def forward(self,x):
        x=self.layer2(self.layer1(self.stem(x)));x=self.layer5(self.layer4(self.layer3(x)))
        return self.dropout(self.fc(self.pool(self.last(x)).flatten(1)))
