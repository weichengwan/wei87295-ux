"""Frozen CUT scenes, own CAL scores and resumable medium/full scoring."""
import time
from pathlib import Path
import numpy as np
import torch
from b285_common import FILES,need,read_json,write_json,fingerprint,digest_file,code_hashes,SCENE_KEYS

def make_iq(generator,p,split,ix,j=None):
    scenes=[generator.make_one(p['master_seed'],p['h1_split'] if split=='h1' else p[split+'_split'],int(i),-30,10) for i in ix]
    if split!='h1':
        need(all(s['label']==0 and not np.any(s['target']) for s in scenes),'Target appeared in H0 split')
        return np.stack([s['base'] for s in scenes]).astype('complex64')
    need(all(s['label']==1 for s in scenes),'H1 label mismatch')
    base=np.stack([s['base'] for s in scenes]).astype('complex64').astype('complex128')
    unit=np.stack([s['unit'] for s in scenes]).astype('complex64').astype('complex128')
    cp=np.asarray([s['cp'] for s in scenes],dtype='float64');need((cp>0).all() and np.isfinite(cp).all(),'Invalid clutter power')
    amplitude=np.sqrt(cp*10**(p['scr_grid_db'][j]/10))
    return (base+unit*amplitude[:,None]).astype('complex64')

@torch.inference_mode()
def predict(model,frontend,iq,device,batch):
    output=[]
    for start in range(0,len(iq),batch):
        x=torch.from_numpy(np.ascontiguousarray(iq[start:start+batch])).to(device);z=model(frontend(x))
        need(z.shape==(len(x),2) and torch.isfinite(z).all(),'Invalid inference output')
        output.append((z[:,1]-z[:,0]).double().cpu().numpy())
    return np.concatenate(output)

def completed_arrays(folder,p):
    folder=Path(folder);progress=read_json(folder/'progress.json')
    need(progress['fingerprint']==p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'}),'Scoring identity differs')
    need(progress['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=37),'Scoring incomplete')
    arrays={}
    for split,file in FILES.items():
        shape=(37,p['h1_scenes_n']) if split=='h1' else (p[split+'_n'],)
        v=np.load(folder/file,mmap_mode='r',allow_pickle=False)
        need(v.shape==shape and v.dtype==np.float64 and np.isfinite(v).all(),'Malformed score array '+file);arrays[split]=v
    return arrays

def prefix_cache(a,p):
    folder=a.out_dir/f'pd_scr_medium_train_{a.training_size}'
    if a.eval_size!='full' or not (folder/'protocol_frozen.json').exists():return {},[]
    old=read_json(folder/'protocol_frozen.json')
    need(old['version']=='B285_MOBILEVIT_SCORE_V1','Unexpected medium scoring identity')
    for key in (*[k for k in SCENE_KEYS if not k.endswith('_n')],'training_contract','code_sha256','batch','device','torch_version','amp','tf32'):
        need(old[key]==p[key],'Medium scores came from another model/runtime/protocol: '+key)
    values=completed_arrays(folder,old)
    return values,[dict(split=s,path=str(folder/f),sha256=digest_file(folder/f)) for s,f in FILES.items()]

def numeric_probe(values,model,frontend,generator,p,device,batch):
    checks=[]
    for split,value in values.items():
        n=value.shape[1] if split=='h1' else len(value);starts=sorted({0,max(0,(n//batch-1)*batch)})
        levels=[18,24,36] if split=='h1' else [None];error=0.
        for j in levels:
            for start in starts:
                stop=min(start+batch,n);actual=predict(model,frontend,make_iq(generator,p,split,np.arange(start,stop),j),device,batch)
                expected=value[j,start:stop] if split=='h1' else value[start:stop]
                error=max(error,float(np.abs(actual-expected).max()))
                need(np.allclose(actual,expected,atol=2e-5,rtol=1e-5),'Medium score replay differs; preserve outputs')
        checks.append(dict(split=split,maxabs_difference=error,full_array_recomputed=False))
    return checks

def stream(a,p,model,frontend,generator,cache):
    folder=a.score_dir;folder.mkdir(exist_ok=True);manifest=folder/'protocol_frozen.json';prpath=folder/'progress.json'
    if manifest.exists():need(read_json(manifest)==p,'Scoring settings changed; use another output')
    else:
        need(not any(folder.iterdir()),'Nonempty scoring output without protocol');write_json(manifest,p)
    if prpath.exists():pr=read_json(prpath);need(pr['fingerprint']==p['fingerprint'],'Score resume fingerprint differs')
    else:pr=dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=0,h0_audit=0,h1=0));write_json(prpath,pr)
    for split,file in FILES.items():
        n=p['h1_scenes_n'] if split=='h1' else p[split+'_n'];shape=(37,n) if split=='h1' else (n,);path=folder/file
        done=pr['completed'][split];need(isinstance(done,int) and 0<=done<=(37 if split=='h1' else n),'Invalid score progress')
        need(done==0 or path.is_file(),'Committed score array missing')
        array=np.lib.format.open_memmap(path,mode='r+' if path.exists() else 'w+',dtype='float64',shape=shape)
        need(array.shape==shape and array.dtype==np.float64,'Score array shape differs')
        began=time.perf_counter();inferred=reused=0;first=done
        def block(start,stop,j=None):
            nonlocal inferred,reused
            value=np.empty(stop-start,dtype='float64');end=start
            if split in cache:
                source=cache[split];count=source.shape[1] if split=='h1' else len(source);end=max(start,min(stop,count))
                value[:end-start]=source[j,start:end] if split=='h1' else source[start:end];reused+=end-start
            if end<stop:
                value[end-start:]=predict(model,frontend,make_iq(generator,p,split,np.arange(end,stop),j),a.device,a.batch);inferred+=stop-end
            return value
        if split=='h1':
            for j in range(done,37):
                for start in range(0,n,a.chunk):array[j,start:min(start+a.chunk,n)]=block(start,min(start+a.chunk,n),j)
                array.flush();pr['completed'][split]=j+1;write_json(prpath,pr)
                print(f'[dev_h1] SCR={p["scr_grid_db"][j]:+d} dB {j+1}/37',flush=True)
        else:
            for start in range(done,n,a.chunk):
                stop=min(start+a.chunk,n);array[start:stop]=block(start,stop);array.flush();pr['completed'][split]=stop;write_json(prpath,pr)
                if stop==n or stop%10000<a.chunk:
                    rate=(stop-first)/max(time.perf_counter()-began,1e-6)
                    print(f'[{split}] {stop:,}/{n:,}; {rate:.1f}/s; remaining~{(n-stop)/max(rate,1e-6)/60:.1f}min; reused={reused:,}; inferred={inferred:,}',flush=True)
        del array

def protocol(a,scene,scene_record,ct):
    p=dict(scene)
    if a.eval_size=='medium':p.update(h0_cal_n=300000,h0_audit_n=200000,h1_scenes_n=512)
    p.update(version='B285_MOBILEVIT_SCORE_V1',training_contract=ct,source_scene=scene_record,
        nominal_pfas=[1e-4] if a.eval_size=='medium' else [1e-4,1e-5],code_sha256=code_hashes(),
        batch=a.batch,device=a.device.type,torch_version=str(torch.__version__),amp=False,tf32=False,
        score_definition='float64(float32 logit1 - float32 logit0); monotonic to H1 softmax',
        strict_decision='score > own H0 CAL threshold',independent_final=False,scope='exposed paired SIM-R10 DEV, paper-informed SIM adaptation')
    return p
