# B285：JMSE2025 GADF-RP Improved MobileViT 外部基线

复现对象：**Sea Surface Floating Small-Target Detection Based on Dual-Feature Images and Improved MobileViT**, JMSE2025,13(3),572，DOI10.3390/jmse13030572。

流程：**IQ幅度→GADF与RP→左右拼接并压缩到256×256→带CA和SiLU的MobileViT→两类输出→H0门限→Pd**。保持图7结构，不含我们的WVD、SPWVD、TFSE、CGCR、TFCG、Tail等模块。

**必须了解：原文未公开完整作者代码和若干数值参数。本包是原文结构重建与SIM适配版；通道宽度采用标准MobileViTXXS，RP等未公开参数固定并明示。**请阅读`PAPER_REVIEW.md`、`paper_contract.json`。不能把这些补齐选择写成原文已经给出的设置。

## 先跑中规模

上传`B285_GADFRP_MOBILEVIT_V1.zip`到项目根目录后执行：

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
unzip -n B285_GADFRP_MOBILEVIT_V1.zip
bash B285_GADFRP_MOBILEVIT_V1/start_on_autodl.sh
tail -F codex_b285_mobilevit.log
```

默认训练、推理、评分、画图自动串联，**中规模结束后停止，不自动跑全量**。

- TRAIN16,000、VAL完整5,000、30轮、batch16、随机初始化。不是沿用ADN权重。
- 256×256输入；CA在第1、2层后；Transformer深度2/4/3；所有MV2使用SiLU。参数约0.953M。
- Adam、LR3e-3至1e-6、余弦warm restarts；按minimum VAL CE选best。
- 先做真实TRAIN的batch16三步优化器预检并丢弃预检模型，同时验证batch32推理。
- CAL300,000、独立AUDIT200,000、SCR−24至+12dB共37点，每点512个H1场景；**仅Pfa1e-4**。
- 独立H0数据定阈值并报告实际虚警及95%区间，不用默认0.5阈值当固定Pfa。

共享GPU锁与B284一致；如果B284仍在运行，本任务打印等待信息并排队，不中止B284。nohup后台运行，SSH断开或手机热点掉线不影响进程。Ctrl+C只退出tail。服务器关机/进程被终止后，确认旧任务已结束再运行相同启动命令，可从最后完成epoch或评分块恢复。

启动器使用`/root/miniconda3/bin/conda run -n mpdnet-r10`，不用conda activate，不需安装新框架或下载预训练权重。仅依赖已有numpy、h5py、PyTorch>=2.0和matplotlib。

## 中规模结果看哪里

```text
output_b285_gadfrp_mobilevit_v1/
  train_medium/
    preflight.json
    run_manifest.json
    best.pt
    last_epoch.pt
    training_contract.json
    train_val_history.csv
    image_cache/
  pd_scr_medium_train_medium/
    b285_metrics.csv
    b285_curves.csv
    b285_report.json
    protocol_frozen.json
    progress.json
    figures/b285_pd_scr_pfa_1e-04.pdf
    figures/b285_empty_pfa_1e-04.pdf
```

如果完成的B284或B283原始评分数组仍在，会自动加入其纯ADN与完整方法参考线。参考线按本次相同前缀重新定门限，取当前同一批场景；不直接挪用历史全量CSV。参考权重不重新推理，协议/形状/文件哈希验证情况写入report；不能称为参考权重的新数值回放。

若参考缓存缺失，则画独立基线曲线，训练和评分继续。B285蓝色实线圆点，Ours参考线仍为黑色实线空心倒三角；横纵轴SCR(dB)、Pd，上方标Pfa。保留原始37点，不平滑或移动。无数据不能补造曲线。

先看训练是否收敛、VAL AUC、Pd@0/Pd@12、D80/D90和实际Pfa。结果不理想时先检查适配与原文未公开项；中规模30轮结果不是原文150轮实测IPIX结果。

## 中规模可用后：仅扩大评价，不重新训练

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
bash B285_GADFRP_MOBILEVIT_V1/start_on_autodl.sh --stage score --eval-size full
tail -F codex_b285_mobilevit.log
```

复用同一份`train_medium/best.pt`，CAL3M、AUDIT1M、每SCR1024H1，双Pfa1e-4/1e-5；中规模原始分数通过身份和数值回放检查后复用，推理新增场景。输出`pd_scr_full_train_medium/`，名称保留其16k/30轮来源，绝不改写成30k训练结果。

## 如果需要完整训练预算：另起30k、150轮

只有确认中规模后再手动执行：

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
bash B285_GADFRP_MOBILEVIT_V1/start_on_autodl.sh --training-size full --eval-size full
tail -F codex_b285_mobilevit.log
```

在`train_full/`从相同声明的随机初始化重新训练，TRAIN30k、VAL5k、150轮。中规模权重与结果保留；不覆盖其他实验。评分结果在`pd_scr_full_train_full/`，不会混用不同模型的medium分数。

## 必需数据与磁盘

必须保留：

```text
SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1/
  sim_r10_iq512_v1.h5
  sim_r10_iq512_v1_contract.json
  sim_r10_iq512_audit_v1.json
output_b280_full_ablation_v1/pd_scr_full/
  protocol_frozen.json
  progress.json
```

B280仅提供既有冻结场景协议，不需要其模型权重。旧WVD缓存不需要。B283/B284完整原始npy可选，用于参考曲线。

中规模图像缓存未压缩上限约1.28GiB，实际lzf压缩后一般更小；请预留至少2GiB。全量30k/5k单独缓存上限约2.14GiB，预留3GiB。只缓存单通道索引、GPU解码RGB，避免存数GB的RGB副本。本包不删除任何旧数据、代码或权重。

目录不同时可指定：

```bash
bash B285_GADFRP_MOBILEVIT_V1/start_on_autodl.sh \
  --bank-dir /你的冻结数据目录 \
  --scene-run /你的B280输出目录 \
  --reference-run /你的B284输出目录
```

其他入口：`--stage preflight`仅检查/建缓存/优化器预检；`--stage train`仅训练；`--stage report`重画已有评分。临时更改`--epochs`会改变训练契约，已有输出设置不符时停止；应使用新`--out-dir`保存不同试验。

该包不能访问真实AutoDL。所附本地测试只使用生成IQ、合成契约和检查点，验证数学、网络、优化、断点恢复、缓存及37点双Pfa报告，不宣称已经测得用户数据的新Pd。
