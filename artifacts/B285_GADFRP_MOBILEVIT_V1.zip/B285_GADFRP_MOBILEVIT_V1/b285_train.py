"""CE-only reconstruction; min VAL CE selection, no Pd/CAL-based tuning."""
import gc
import time
import numpy as np
import torch
import torch.nn.functional as F
from b285_common import need,read_json,write_json,fingerprint,code_hashes,digest_file,save_csv,atomic_save,load_checkpoint,snapshot,setup,indices,roc_metrics,PASS
from b285_model import ImprovedMobileViT,MODEL_CONFIG
from b285_frontend import FRONTEND_CONFIG

def config(a,context,data):
    return dict(version='B285_JMSE_MOBILEVIT_TRAIN_V1',training_size=a.training_size,epochs=a.epochs,batch=16,seed=a.seed,
        selected_rows=data.selection,bank_sha256=context['bc']['file_sha256'],model=MODEL_CONFIG,frontend=FRONTEND_CONFIG,
        optimizer='Adam',lr=.003,eta_min=1e-6,weight_decay=0.,loss='cross entropy; no label smoothing',
        schedule='CosineAnnealingWarmRestarts, T0=10,Tmult=2, per step',selection='minimum full VAL CE; epoch0 eligible',
        code_sha256=code_hashes(),device=a.device.type,torch_version=str(torch.__version__),amp=False,tf32=False,
        architecture_exactly_from_authors_code=False,unpublished_parameters_filled_from_declared_standard=True)

@torch.inference_mode()
def evaluate(model,data,frontend,device,batch):
    model.eval();n=len(data.values['val'][1]);loss=correct=0;zs=[];ys=[]
    for start in range(0,n,batch):
        x,y=data.fetch('val',slice(start,min(start+batch,n)),frontend,device);z=model(x)
        need(z.shape==(len(y),2) and torch.isfinite(z).all(),'Invalid VAL logits')
        loss+=float(F.cross_entropy(z,y,reduction='sum'));correct+=int((z.argmax(1)==y).sum())
        zs.append((z[:,1]-z[:,0]).double().cpu().numpy());ys.append(y.cpu().numpy())
    return dict(val_ce=loss/n,val_acc=correct/n,n_val=n,**roc_metrics(np.concatenate(zs),np.concatenate(ys)))

def optimizer_canary(a,data,frontend):
    setup(a.cpu_threads,a.seed);model=ImprovedMobileViT().to(a.device);optimizer=torch.optim.Adam(model.parameters(),lr=.003)
    labels=data.values['train'][1];ix=np.r_[np.flatnonzero(labels==0)[:8],np.flatnonzero(labels==1)[:8]];need(len(ix)==16,'Canary needs16 balanced TRAIN rows')
    x,y=data.fetch('train',ix,frontend,a.device);before=model.fc.weight.detach().clone()
    if a.device.type=='cuda':torch.cuda.reset_peak_memory_stats(a.device)
    model.train()
    for _ in range(3):
        optimizer.zero_grad(set_to_none=True);loss=F.cross_entropy(model(x),y);need(torch.isfinite(loss),'Nonfinite TRAIN canary')
        loss.backward();optimizer.step()
    need(not torch.equal(before,model.fc.weight),'Optimizer did not update classifier')
    model.eval()
    with torch.inference_mode():
        probe=model(torch.cat([x,x],0));need(probe.shape==(32,2) and torch.isfinite(probe).all(),'Batch32 inference canary failed')
    result=dict(three_real_TRAIN_optimizer_steps_discarded=True,training_batch=16,scoring_batch=32,
        parameters=sum(p.numel() for p in model.parameters()),peak_allocated_GiB=torch.cuda.max_memory_allocated(a.device)/1024**3 if a.device.type=='cuda' else None)
    del model,optimizer,loss;gc.collect()
    if a.device.type=='cuda':torch.cuda.empty_cache()
    print('PASS_B285_REAL_TRAIN_OPTIMIZER_AND_INFERENCE_CANARY',flush=True);return result

def train(a,context,data,frontend):
    folder=a.train_dir;cfg=config(a,context,data);fp=fingerprint(cfg);manifest=folder/'run_manifest.json'
    if manifest.exists():need(read_json(manifest)==dict(config=cfg,fingerprint=fp),'Training settings changed; preserve output and use a new --out-dir')
    else:write_json(manifest,dict(config=cfg,fingerprint=fp))
    best_path=folder/'best.pt';last=folder/'last_epoch.pt';contract=folder/'training_contract.json'
    if contract.exists():
        ct=read_json(contract);need(ct['status']==PASS and ct['run_fingerprint']==fp,'Completed settings differ')
        if not best_path.exists() and last.exists():atomic_save(best_path,load_checkpoint(last)['best_checkpoint'])
        need(digest_file(best_path)==ct['checkpoint_sha256'],'Selected checkpoint changed')
        print('Verified completed training; no retraining',flush=True);return ct
    setup(a.cpu_threads,a.seed);model=ImprovedMobileViT().to(a.device)
    optimizer=torch.optim.Adam(model.parameters(),lr=.003,weight_decay=0.)
    scheduler=torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(optimizer,T_0=10,T_mult=2,eta_min=1e-6)
    history=[];start=1
    def state(epoch,metrics):return dict(state_dict=snapshot(model),epoch=epoch,val_metrics=metrics,run_config=cfg,run_fingerprint=fp)
    def commit(epoch,best):
        value=state(epoch,history[-1]);value.update(best_checkpoint=best,history=history,optimizer=optimizer.state_dict(),scheduler=scheduler.state_dict(),
            torch_rng=torch.get_rng_state(),cuda_rng=torch.cuda.get_rng_state_all() if a.device.type=='cuda' else [])
        atomic_save(last,value);atomic_save(best_path,best);save_csv(folder/'train_val_history.csv',history)
    if last.exists():
        saved=load_checkpoint(last);need(saved['run_config']==cfg and saved['run_fingerprint']==fp,'Resume source differs')
        model.load_state_dict(saved['state_dict'],strict=True);optimizer.load_state_dict(saved['optimizer']);scheduler.load_state_dict(saved['scheduler'])
        best=saved['best_checkpoint'];history=saved['history'];start=saved['epoch']+1;torch.set_rng_state(saved['torch_rng'])
        if a.device.type=='cuda':torch.cuda.set_rng_state_all(saved['cuda_rng'])
        atomic_save(best_path,best);del saved
    else:
        v=evaluate(model,data,frontend,a.device,32);best=state(0,v)
        history=[dict(epoch=0,train_ce=None,lr=None,**v,best_epoch=0,elapsed_s=0.)];commit(0,best)
    for epoch in range(start,a.epochs+1):
        began=time.perf_counter();model.train();total=seen=0;order=list(indices(data.values['train'][1],epoch,16,a.seed))
        for step,ix in enumerate(order):
            scheduler.step(epoch-1+step/len(order));x,y=data.fetch('train',ix,frontend,a.device)
            optimizer.zero_grad(set_to_none=True);loss=F.cross_entropy(model(x),y);need(torch.isfinite(loss),'Nonfinite TRAIN CE')
            loss.backward();optimizer.step();total+=float(loss.detach())*len(y);seen+=len(y)
            if (step+1)%200==0:print(f'[MobileViT] epoch {epoch}/{a.epochs} TRAIN {seen:,}/{len(data.values["train"][1]):,}',flush=True)
        v=evaluate(model,data,frontend,a.device,32)
        if v['val_ce']<best['val_metrics']['val_ce']-1e-8:best=state(epoch,v)
        history.append(dict(epoch=epoch,train_ce=total/seen,lr=optimizer.param_groups[0]['lr'],**v,best_epoch=best['epoch'],elapsed_s=time.perf_counter()-began))
        commit(epoch,best)
        print(f'[MobileViT] {epoch}/{a.epochs} VAL_CE={v["val_ce"]:.6f} VAL_AUC={v["val_auc"]:.6f} best={best["epoch"]} time={history[-1]["elapsed_s"]:.1f}s',flush=True)
    model.load_state_dict(best['state_dict'],strict=True);replay=evaluate(model,data,frontend,a.device,32)
    need(abs(replay['val_ce']-best['val_metrics']['val_ce'])<1e-6,'Selected VAL replay differs')
    ct=dict(status=PASS,run_config=cfg,run_fingerprint=fp,checkpoint_sha256=digest_file(best_path),best_epoch=best['epoch'],selected_validation=replay,
        CAL_AUDIT_H1_used_for_training=False,official_author_checkpoint=False)
    write_json(contract,ct);del model,optimizer,best;gc.collect()
    if a.device.type=='cuda':torch.cuda.empty_cache()
    print(f'{PASS}; selected epoch={ct["best_epoch"]}',flush=True);return ct

def load_selected(a,context):
    ct=read_json(a.train_dir/'training_contract.json');cfg=ct['run_config'];path=a.train_dir/'best.pt'
    need(ct['status']==PASS and cfg['bank_sha256']==context['bc']['file_sha256'],'Incomplete/different training bank')
    need(cfg['model']==MODEL_CONFIG and cfg['frontend']==FRONTEND_CONFIG and cfg['code_sha256']==code_hashes(),'Implementation changed after training')
    need(digest_file(path)==ct['checkpoint_sha256'],'Selected checkpoint SHA differs');state=load_checkpoint(path)
    need(state['run_config']==cfg and state['run_fingerprint']==ct['run_fingerprint']==fingerprint(cfg) and state['epoch']==ct['best_epoch'],'Checkpoint internal identity differs')
    model=ImprovedMobileViT();model.load_state_dict(state['state_dict'],strict=True)
    return model.to(a.device).eval().requires_grad_(False),ct
