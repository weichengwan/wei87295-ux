"""Fill two ADN ablations; reuse completed full B276 and old ADN scores."""
import argparse,fcntl,gc,shutil,time
from pathlib import Path
from b271_data import device_for,need,write_json
from b271_score import original_protocol
from b273_shared import setup
from b274_data import resolve,Data
from b276_source import metadata as source_metadata
from b276_train import train_arm
from b277_model import ARMS,factory,initialize,initial_check,diagnostics
from b277_references import full_metadata,historical_metadata

PASS='PASS_B277_ADN_INCREMENTAL_ABLATION_TRAIN_VAL_ONLY'


def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    p.add_argument('--source-run',type=Path);p.add_argument('--full-run',type=Path);p.add_argument('--out-dir',type=Path)
    p.add_argument('--bank-dir',type=Path);p.add_argument('--b213-dir',type=Path)
    p.add_argument('--stage',choices=('all','preflight','train','score','report'),default='all')
    p.add_argument('--wait-for-gpu',action='store_true',help='Wait for the current radar job to release the shared lock')
    p.add_argument('--epochs',type=int,default=4);p.add_argument('--batch',type=int,default=32)
    p.add_argument('--train-limit',type=int,default=16000);p.add_argument('--val-limit',type=int,default=3000)
    p.add_argument('--lr',type=float,default=1e-5);p.add_argument('--new-lr',type=float,default=1e-4)
    p.add_argument('--seed',type=int,default=20261022);p.add_argument('--device',choices=('cpu','cuda'),default='cuda');p.add_argument('--cpu-threads',type=int,default=4)
    a=p.parse_args(argv);a.root=a.root.resolve()
    a.source_run=(a.source_run or a.root/'output_b274_single_spwvd_resnet18_v1').resolve()
    a.full_run=(a.full_run or a.root/'output_b276_spwvd_adn_phase_v1').resolve()
    a.out_dir=(a.out_dir or a.root/'output_b277_adn_incremental_ablation_v1').resolve()
    need(a.root.is_dir() and a.out_dir!=a.root and all(a.out_dir!=p and p not in a.out_dir.parents for p in (a.source_run,a.full_run)),'Use a separate output directory')
    need(a.batch==32 and a.epochs>0 and a.lr>0 and a.new_lr>0 and a.cpu_threads>0,'Invalid training budget')
    need(2<=a.train_limit<=30000 and 2<=a.val_limit<=5000 and a.train_limit%2==a.val_limit%2==0,'Invalid balanced subset')
    a.device=device_for(a.device);return a


def references(a,context,selection):
    _,original,generator=original_protocol(a.root,context,a.b213_dir)
    source=source_metadata(a.source_run,context,original,a.device,selection)
    full=full_metadata(a.full_run/'pd_scr_medium',context,original,a.device,selection,source,a)
    history=historical_metadata(a.root,original)
    return source,full,history,original,generator


def acquire_gpu(lock,wait=False):
    attempts=0
    while True:
        try:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            if attempts:print('GPU lock available; starting B277 now',flush=True)
            return
        except BlockingIOError:
            if not wait:raise SystemExit('Another radar experiment holds the GPU lock; wait for it to finish, then rerun this command')
            if attempts%4==0:print('Waiting for B275/other radar job to finish; B277 has not allocated GPU memory',flush=True)
            attempts+=1;time.sleep(15)


def main(argv=None):
    a=cli(argv);setup(a.cpu_threads)
    if a.stage=='report':
        from b277_report import generate
        return generate(a.out_dir/'pd_scr_medium')
    with (a.root/'codex_b271_night.lock').open('a') as lock:
        acquire_gpu(lock,a.wait_for_gpu)
        need(shutil.disk_usage(a.root).free>=2*1024**3,'Require2GiB free for separate ablation checkpoints')
        context=resolve(a.root,a.bank_dir);data=Data(context,a.train_limit,a.val_limit,a.seed)
        source,full,history,old,generator=references(a,context,data.selection)
        print(f'B277 preflight: B274 source + completed B276 full group verified; old ADN scores available={history["available"]}',flush=True)
        if not history['available']:print('Historical ADN row will remain missing: '+str(history.get('missing')),flush=True)
        if a.stage=='preflight':
            a.out_dir.mkdir(parents=True,exist_ok=True)
            write_json(a.out_dir/'preflight.json',dict(historical_original_adn=history,full_source=str(full['folder']),
                train_rows=data.selection,only_metadata_opened_for_reference_checks=True))
            return
        if a.stage in ('all','train'):
            hooks=dict(status=PASS,version='B277_ADN_INCREMENTAL_ABLATION_TRAIN_V1',factory=factory,migrate=initialize,
                verify_initial=initial_check,diagnostics=diagnostics)
            print('Only TRAIN/VAL for training; two new arms, native SimAM active; CE; no tail loss, no ARS',flush=True)
            for arm in ARMS:train_arm(a,context,data,source,arm,hooks)
        selection=data.selection;del data;gc.collect()
        if a.device.type=='cuda':
            import torch
            torch.cuda.empty_cache()
        if a.stage!='train':
            from b277_score import score
            return score(a,context,selection)


if __name__=='__main__':main()
