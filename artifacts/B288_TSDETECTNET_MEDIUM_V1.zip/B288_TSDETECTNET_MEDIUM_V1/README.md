# B288：仅复现 TS-DetectNet，中规模先行

原文：**CNN-Based Data Processing for Enhanced Detection of Small Targets in Sea Clutter**，
Shuangyu Xu、Zhihang Wang、Zishu He，IEEE Sensors Journal2025。
DOI：10.1109/JSEN.2025.3596263。

本包只训练、推理、绘制原文主模型 TS-DetectNet。不加载、训练或画 ADN，不加载或修改我们的方法。
唯一共用输入是现有冻结 SIM-R10 的 IQ TRAIN/VAL 数据。输出只允许写入新建的 `output_b288_*` 目录。
包内没有 ADN、TFSE、CGCR、WCSG、TFCG 或 Tail 网络代码，不读取任何旧模型分数。
共享 GPU 锁用于等待其他实验，不停止它们。

## 模型及原文核对

```text
512脉冲复数IQ [B,512]
  ├─实部 → Conv1d(1,128,k64,s2,p0) → [B,128,225]
  └─虚部 → Conv1d(1,128,k64,s2,p0) → [B,128,225]
      两个独立卷积，无额外一维激活
             ↓ stack
       [B,2,128,225]
             ↓ Conv2d(2,3,k3,s(1,2),p0) → BN → ReLU
       [B,3,126,112]
             ↓ 标准MobileNetV3-Small，二分类
       [B,2] logits → H1分数 → 独立H0阈值 → Pd
```

不进行 WVD/SPWVD/STFT、不 resize 到224、不转RGB、不引入新模块。
公式(5)–(12)规定 U=floor(N/4)、Q=floor(N/8)、stride2。按这些公式，
1024脉冲的前端参数数目为66,111，恰好对应原文表VI的66.11K。
原文仅写MobileNetV3，未明确Small/Large；二分类标准Small参数数目1,519,906，
与表VI的1.52M吻合，因此采用它。代码来自torchvision v0.10.1，只有两行导入路径修改，
网络结构未改。不是论文作者提供的完整源码，也不宣称恢复了原文未公开的全部实现细节。

默认从随机权重联合训练前端和检测器。BN参数、初始化、未记载的归一化等默认选择
列于 `paper_contract.json`，与明确写出的公式和设置区分记录。
当前输入为既有SIM512数据；论文也报告512脉冲实验。
本试验不等于已复现论文IPIX/SDRDSP的实测性能。

## 默认规模

- TRAIN16,000：从既有30,000中按标签和杂波类型确定性分层选取。
- VAL5,000：使用完整冻结VAL；仅按VAL CE选择已训练epoch。
- Adam lr0.001，betas(0.9,0.99)，CE，batch256；每5epoch学习率乘0.5。
- 默认20epoch，对应论文SDRDSP训练轮数；不使用增强和辅助损失。
- 独立H0 CAL300,000、H0 AUDIT200,000；每个SCR512个H1，SCR=-24…+12dB，共37点。
- 主图Pfa=1e-4；同时从完全相同的分数得到原文Pfa=1e-3诊断图，无额外推理。
- 只做本轮中规模，不自动升级全规模，不处理FINAL实测数据。
- 没有额外图像特征缓存；输出通常远少于256MiB。

## AutoDL启动

将本包解压到 `/root/autodl-tmp/MTDSP_NATIVE_LMDA_V1`，然后：

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
bash B288_TSDETECTNET_MEDIUM_V1/start_on_autodl.sh
tail -F codex_b288_tsdetectnet.log
```

不需要conda activate；启动器调用mpdnet-r10。断开SSH/手机热点不会终止nohup进程，
服务器自身关机或进程被杀会中断。恢复后重新运行同一启动命令，将校验本包自己的权重、
训练配置和分数后续跑；训练恢复到最近完整epoch，评分恢复到最近提交的块/SCR。
重复启动时已有进程会被识别；同一输出中的参数不能中途更改。

默认数据路径：
`SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1/sim_r10_iq512_v1.h5`
及同目录contract和audit JSON。

可选：前台仅做预检、训练或报告（均不涉及其他模型）：

```bash
/root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  bash B288_TSDETECTNET_MEDIUM_V1/run_b288.sh --stage preflight
```

如果默认batch256预检在你的GPU上报显存不足，在尚未开始训练时用新的输出目录：

```bash
bash B288_TSDETECTNET_MEDIUM_V1/start_on_autodl.sh \
  --train-batch 128 --batch 128 --out-dir /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1/output_b288_tsdetectnet_b128
```

这是训练批量的硬件适配，会明确记录在配置中，网络结构不变。默认先尝试原文batch256。

## 看哪些结果

目录：`output_b288_tsdetectnet_medium_v1/pd_scr_medium/`。

- `figures/b288_pd_scr_pfa_1e-04.pdf`：主Pd图，仅一条TS-DetectNet曲线。
- `figures/b288_pd_scr_pfa_1e-03.pdf`：论文操作点诊断图。
- `b288_curves.csv`：原始37点Pd、命中数、置信区间、每SCR的AUC诊断。
- `b288_metrics.csv`：D80、D90、实际虚警率及置信区间、各SCR的Pd。
- `b288_report.json`：单模型身份、检查点SHA、数据规模、质量提示。
- `b288_score_summary.csv`：H0/H1分数分布，便于分析异常曲线。
- `../train_medium/train_val_history.csv`：训练记录。
- `../train_medium/b288_val_scores.csv`：VAL标签和分数。

D90未达到时为空值，不外推。原始曲线不强制单调，不平滑，不平移。
中规模CAL在1e-4处只有约30个尾部样本，是筛查结果；最终对比还需要统一规模评估。
耗时由日志首个epoch及前一万条H0的实际速度估算，不保证未经GPU实跑的固定分钟数。

## 本地代码验证

```bash
python -m unittest discover -s tests -v
```

测试包括参数表核对、原生512输入的训练/推理、仅本模型的恢复训练、
评分断点恢复、校准阈值/审计分离以及单模型报告。测试用的微型合成数据不代表真实Pd效果。
