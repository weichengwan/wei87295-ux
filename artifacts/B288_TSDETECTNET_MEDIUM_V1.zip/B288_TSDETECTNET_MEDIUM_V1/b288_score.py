"""One TS-DetectNet only; independent H0 CAL/AUDIT and37-point paired DEV."""
import time
from pathlib import Path
import numpy as np
import torch
from b288_common import FILES,need,read_json,write_json,fingerprint,digest_file,code_hashes

def make_iq(generator,p,split,ix,j=None):
    scenes=[generator.make_one(p['master_seed'],p['h1_split'] if split=='h1' else p[split+'_split'],int(i),-30,10) for i in ix]
    if split!='h1':
        need(all(s['label']==0 and not np.any(s['target']) for s in scenes),'Target appeared in H0 split')
        return np.stack([s['base'] for s in scenes]).astype('complex64')
    need(all(s['label']==1 for s in scenes),'H1 label mismatch')
    base=np.stack([s['base'] for s in scenes]).astype('complex64').astype('complex128')
    unit=np.stack([s['unit'] for s in scenes]).astype('complex64').astype('complex128')
    cp=np.asarray([s['cp'] for s in scenes],dtype='float64');need((cp>0).all() and np.isfinite(cp).all(),'Invalid clutter power')
    amplitude=np.sqrt(cp*10**(p['scr_grid_db'][j]/10))
    return (base+unit*amplitude[:,None]).astype('complex64')

@torch.inference_mode()
def predict(model,iq,device,batch):
    output=[]
    for start in range(0,len(iq),batch):
        x=torch.from_numpy(np.ascontiguousarray(iq[start:start+batch])).to(device);z=model(x)
        need(z.shape==(len(x),2) and torch.isfinite(z).all(),'Invalid inference output')
        output.append((z[:,1]-z[:,0]).double().cpu().numpy())
    return np.concatenate(output)

def completed_arrays(folder,p):
    folder=Path(folder);progress=read_json(folder/'progress.json')
    need(progress['fingerprint']==p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'}),'Scoring identity differs')
    need(progress['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=37),'Scoring incomplete')
    arrays={}
    for split,file in FILES.items():
        shape=(37,p['h1_scenes_n']) if split=='h1' else (p[split+'_n'],)
        v=np.load(folder/file,mmap_mode='r',allow_pickle=False)
        need(v.shape==shape and v.dtype==np.float64 and np.isfinite(v).all(),'Malformed score array '+file);arrays[split]=v
    return arrays


def protocol(a,context,ct):
    # Same immutable generator splits as existing SIM-R10 DEV. No other
    # experiment directory, checkpoint or score array is read.
    p=dict(version='B288_TSDETECTNET_MEDIUM_SCORE_V1',
        master_seed=context['bc']['seed'],generator_sha=context['bc']['generator_sha256'],
        training_bank_sha256=context['bc']['file_sha256'],
        h0_cal_n=300000,h0_audit_n=200000,h1_scenes_n=512,
        scr_grid_db=list(range(-24,13)),h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',
        family_names=list(context['generator'].TRAIN_FAMILIES),
        scr_definition='pre-Doppler target/clutter mean IQ power; noise excluded from clutter denominator',
        training_contract=ct,nominal_pfas=[1e-4,1e-3],
        code_sha256=code_hashes(),batch=a.batch,chunk=a.chunk,device=a.device.type,
        torch_version=str(torch.__version__),amp=False,tf32=False,
        score_definition='float64(float32 logit1-logit0); monotonic to H1 softmax',
        strict_decision='score > own H0 CAL cutoff; rank-based with conservative handling of ties',
        methods=['TS-DetectNet (Sensors2025; SIM512)'],ADN_loaded=False,ours_loaded=False,
        independent_final=False,scope='exposed SIM-R10 DEV; medium screening only',automatic_full_scale=False)
    p['fingerprint']=fingerprint(p)
    return p


def verify_resume(a,p,model,generator):
    folder=a.score_dir
    if not (folder/'protocol_frozen.json').exists():return []
    need(read_json(folder/'protocol_frozen.json')==p,'Scoring settings changed; use a new independent output')
    if not (folder/'progress.json').exists():
        need(not any((folder/f).exists() for f in FILES.values()),'Raw scores exist without commit metadata; preserve output')
        return []
    pr=read_json(folder/'progress.json')
    need(pr['fingerprint']==p['fingerprint'],'Progress identity differs')
    checks=[]
    for split,file in FILES.items():
        done=pr['completed'][split]
        if done==0:continue
        path=folder/file;need(path.is_file(),'Committed scoring file missing')
        raw=np.load(path,mmap_mode='r',allow_pickle=False)
        n=p['h1_scenes_n'] if split=='h1' else p[split+'_n']
        shape=(37,n) if split=='h1' else (n,)
        need(raw.shape==shape and raw.dtype==np.float64,'Resume array shape/type changed')
        count=n if split=='h1' else done
        js=sorted({0,done-1}) if split=='h1' else [None]
        starts=sorted({0,max(0,((count-1)//a.batch)*a.batch)})
        error=0.
        for j in js:
            for start in starts:
                stop=min(start+a.batch,count)
                actual=predict(model,make_iq(generator,p,split,np.arange(start,stop),j),a.device,a.batch)
                expected=raw[j,start:stop] if split=='h1' else raw[start:stop]
                error=max(error,float(np.abs(actual-expected).max()))
                need(np.allclose(actual,expected,rtol=1e-5,atol=2e-5),'Resume score numerical replay differs; preserve result')
        checks.append(dict(split=split,committed=done,maxabs_difference=error))
        del raw
    return checks

def stream(a,p,model,generator):
    folder=a.score_dir;folder.mkdir(exist_ok=True);manifest=folder/'protocol_frozen.json';prpath=folder/'progress.json'
    if manifest.exists():need(read_json(manifest)==p,'Scoring settings changed; use another output')
    else:
        need(not any(folder.iterdir()),'Nonempty scoring output without protocol');write_json(manifest,p)
    if prpath.exists():pr=read_json(prpath);need(pr['fingerprint']==p['fingerprint'],'Score resume fingerprint differs')
    else:pr=dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=0,h0_audit=0,h1=0));write_json(prpath,pr)
    for split,file in FILES.items():
        n=p['h1_scenes_n'] if split=='h1' else p[split+'_n'];shape=(37,n) if split=='h1' else (n,);path=folder/file
        done=pr['completed'][split];need(isinstance(done,int) and 0<=done<=(37 if split=='h1' else n),'Invalid score progress')
        need(done==0 or path.is_file(),'Committed score array missing')
        array=np.lib.format.open_memmap(path,mode='r+' if path.exists() else 'w+',dtype='float64',shape=shape)
        need(array.shape==shape and array.dtype==np.float64,'Score array shape differs')
        began=time.perf_counter();inferred=0;first=done
        def block(start,stop,j=None):
            nonlocal inferred
            inferred+=stop-start
            return predict(model,make_iq(generator,p,split,np.arange(start,stop),j),a.device,a.batch)

        if split=='h1':
            for j in range(done,37):
                for start in range(0,n,a.chunk):array[j,start:min(start+a.chunk,n)]=block(start,min(start+a.chunk,n),j)
                array.flush();pr['completed'][split]=j+1;write_json(prpath,pr)
                print(f'[dev_h1] SCR={p["scr_grid_db"][j]:+d} dB {j+1}/37',flush=True)
        else:
            for start in range(done,n,a.chunk):
                stop=min(start+a.chunk,n);array[start:stop]=block(start,stop);array.flush();pr['completed'][split]=stop;write_json(prpath,pr)
                if stop==n or stop%10000<a.chunk:
                    rate=(stop-first)/max(time.perf_counter()-began,1e-6)
                    print(f'[{split}] {stop:,}/{n:,}; {rate:.1f}/s; remaining~{(n-stop)/max(rate,1e-6)/60:.1f}min; inferred={inferred:,}',flush=True)
        del array
