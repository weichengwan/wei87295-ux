#!/usr/bin/env bash
set -euo pipefail
package_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
project_root="$(cd -- "$package_dir/.." && pwd)"
conda_bin=/root/miniconda3/bin/conda
if [[ ! -x "$conda_bin" ]]; then conda_bin="$(command -v conda || true)"; fi
if [[ -z "$conda_bin" || ! -x "$conda_bin" ]]; then
    echo 'Conda executable missing; run run_b288.sh inside mpdnet-r10.' >&2
    exit 1
fi
log_path="$project_root/codex_b288_tsdetectnet.log"
pid_path="$project_root/codex_b288_tsdetectnet.pid"
# Guard concurrent invocations, including the gap before PID is written.
exec 9> "$project_root/codex_b288_start.lock"
flock -n 9 || { echo 'Another B288 starter is active.'; exit 1; }
if [[ -f "$pid_path" ]]; then
    read -r previous_pid < "$pid_path"
    if [[ "$previous_pid" =~ ^[0-9]+$ ]] && kill -0 "$previous_pid" 2>/dev/null; then
        echo "B288 process still active: PID=$previous_pid; log=$log_path"
        exit 0
    fi
fi
date -Is >> "$log_path"
nohup "$conda_bin" run --no-capture-output -n mpdnet-r10 \
    bash "$package_dir/run_b288.sh" --wait-for-gpu "$@" \
    >> "$log_path" 2>&1 < /dev/null 9>&- &
job_pid=$!
printf '%s\n' "$job_pid" > "$pid_path"
printf '后台 PID：%s\n日志：%s\n' "$job_pid" "$log_path"
