"""Independent TS-DetectNet run identity and atomic own-output operations."""
import csv
import hashlib
import importlib.util
import json
import random
import sys
from functools import lru_cache
from pathlib import Path
import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
NAME = 'TS-DetectNet (Sensors2025; SIM512)'
TRAIN_PASS = 'PASS_B288_TSDETECTNET_TRAIN_VAL_ONLY'
GENERATOR = 'r10_sim_iq512_builder_v1_EARLIEST_HDF5.py'
FILES = dict(h0_cal='h0_cal_scores.npy', h0_audit='h0_audit_scores.npy', h1='dev_h1_scores.npy')


def need(condition, message):
    if not bool(condition):
        raise RuntimeError(message)


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def digest_file(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(8 << 20), b''):
            h.update(b)
    return h.hexdigest()


def fingerprint(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, allow_nan=False).encode()).hexdigest()


def write_json(path, obj):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    tmp.replace(path)


def save_csv(path, rows):
    need(bool(rows), 'No CSV rows')
    with Path(path).open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def atomic_save(path, obj):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    torch.save(obj, tmp)
    tmp.replace(path)


def load_checkpoint(path):
    try:
        return torch.load(path, map_location='cpu', weights_only=False)
    except TypeError:
        return torch.load(path, map_location='cpu')


def snapshot(model):
    return {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}


def setup(threads, seed):
    torch.set_num_threads(threads)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False


def validate_sources():
    for name, sha in read_json(ROOT / 'reference_sources.json').items():
        need(digest_file(ROOT / name) == sha, 'Bundled source changed: ' + name)


def code_hashes():
    files = sorted(ROOT.glob('*.py')) + sorted((ROOT / 'vendor').glob('*.py'))
    files += [ROOT / 'reference_sources.json', ROOT / 'paper_contract.json']
    return {f.relative_to(ROOT).as_posix(): digest_file(f) for f in files}


@lru_cache(maxsize=1)
def generator():
    path = ROOT / 'frozen_source' / GENERATOR
    sha = read_json(ROOT / 'reference_sources.json')['frozen_source/' + GENERATOR]
    need(digest_file(path) == sha, 'Frozen IQ generator changed')
    spec = importlib.util.spec_from_file_location('b288_frozen_iq_generator', path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def balanced_subset(labels, families, count, seed):
    labels = np.asarray(labels)
    need(count > 0 and count % 2 == 0 and count <= len(labels), 'Invalid balanced subset size')
    if count == len(labels):
        return np.arange(count, dtype='int64')
    families = np.asarray(families)
    selected = []
    for label in (0, 1):
        available = np.flatnonzero(labels == label)
        need(len(available) >= count // 2, 'Insufficient class samples')
        groups = [available[families[available] == v] for v in np.unique(families[available])]
        desired = count / 2 * np.array([len(g) for g in groups]) / len(available)
        quota = np.floor(desired).astype(int)
        remainder = count // 2 - int(quota.sum())
        quota[np.argsort(-(desired - quota), kind='stable')[:remainder]] += 1
        for j, (group, take) in enumerate(zip(groups, quota)):
            selected.extend(np.random.default_rng(seed + 1000 * label + j).permutation(group)[:take])
    return np.sort(np.asarray(selected, dtype='int64'))


def roc_metrics(scores, labels):
    scores = np.asarray(scores)
    order = np.argsort(-scores, kind='stable')
    s, y = scores[order], np.asarray(labels)[order]
    n0, n1 = int((y == 0).sum()), int((y == 1).sum())
    need(n0 > 0 and n1 > 0, 'VAL needs both classes')
    ends = np.r_[np.flatnonzero(s[1:] != s[:-1]), len(s) - 1]
    x = np.r_[0., np.cumsum(y == 0)[ends] / n0]
    t = np.r_[0., np.cumsum(y == 1)[ends] / n1]
    integrate = np.trapezoid if hasattr(np, 'trapezoid') else np.trapz
    mask = x <= .01
    xp, tp = x[mask], t[mask]
    if xp[-1] < .01:
        r = int(np.searchsorted(x, .01, side='left'))
        l = r - 1
        xp = np.r_[xp, .01]
        tp = np.r_[tp, t[l] + (t[r] - t[l]) * (.01 - x[l]) / (x[r] - x[l])]
    return dict(val_auc=float(integrate(t, x)), val_pauc01=float(integrate(tp, xp) / .01))
