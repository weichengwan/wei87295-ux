"""Standalone TS-DetectNet curves only: no external references or relabeling."""
import math
import numpy as np
from b288_common import need, read_json, write_json, save_csv, digest_file, NAME, FILES
from b288_score import completed_arrays


def wilson(k, n):
    z = 1.959963984540054
    q = k / n
    den = 1 + z * z / n
    mid = (q + z * z / (2 * n)) / den
    rad = z * math.sqrt(q * (1 - q) / n + z * z / (4 * n * n)) / den
    return max(0., mid - rad), min(1., mid + rad)


def cutoff(scores, pfa):
    s = np.asarray(scores)
    need(s.ndim == 1 and np.isfinite(s).all(), 'Invalid H0 CAL scores')
    k = int(math.floor(len(s) * pfa))
    need(10 <= k < len(s), 'Insufficient calibration tail support')
    threshold = float(np.partition(s, len(s) - k - 1)[len(s) - k - 1])
    return threshold, k, int((s > threshold).sum())


def crossing(x, y, level):
    if y[0] >= level:
        return float(x[0])
    for i in range(1, len(x)):
        if y[i - 1] < level <= y[i]:
            return float(x[i - 1] + (level - y[i - 1]) * (x[i] - x[i - 1]) / (y[i] - y[i - 1]))
    return None


def generate(a):
    folder = a.score_dir
    p = read_json(folder / 'protocol_frozen.json')
    need(p['version'] == 'B288_TSDETECTNET_MEDIUM_SCORE_V1' and p['methods'] == [NAME], 'Wrong single-model scoring protocol')
    arrays = completed_arrays(folder, p)
    curves, metrics, summaries = [], [], []
    sorted_audit = np.sort(arrays['h0_audit'])
    for nominal in p['nominal_pfas']:
        th, k, calfp = cutoff(arrays['h0_cal'], nominal)
        n0 = len(arrays['h0_audit'])
        fp = int((arrays['h0_audit'] > th).sum())
        lo, hi = wilson(fp, n0)
        hits = (arrays['h1'] > th).sum(1)
        pd = hits / arrays['h1'].shape[1]
        mt = dict(method=NAME, nominal_pfa=nominal, actual_pfa=fp / n0,
            audit_false_alarms=fp, audit_n=n0, actual_pfa_ci95_low=lo, actual_pfa_ci95_high=hi,
            threshold=th, cal_n=len(arrays['h0_cal']), cal_tail_support=k, cal_exceedances=calfp,
            D50_db=crossing(p['scr_grid_db'], pd, .5), D80_db=crossing(p['scr_grid_db'], pd, .8),
            D90_db=crossing(p['scr_grid_db'], pd, .9), max_pd=float(pd.max()),
            max_pd_scr_db=p['scr_grid_db'][int(pd.argmax())],
            pd_downward_steps=int((np.diff(pd) < 0).sum()),
            pd_downward_steps_gt_5pp=int((np.diff(pd) < -.05).sum()))
        for scr in (-12, -6, 0, 6, 9, 12):
            mt['pd_at_' + str(scr)] = float(pd[p['scr_grid_db'].index(scr)])
        metrics.append(mt)
        for j, (scr, count) in enumerate(zip(p['scr_grid_db'], hits)):
            n1 = arrays['h1'].shape[1]
            low, high = wilson(int(count), n1)
            # Distribution diagnostic, independent of choice of threshold.
            left = np.searchsorted(sorted_audit, arrays['h1'][j], side='left')
            right = np.searchsorted(sorted_audit, arrays['h1'][j], side='right')
            auc = float(np.mean((left + right) / (2 * n0)))
            curves.append(dict(method=NAME, nominal_pfa=nominal, scr_db=scr, hits=int(count), n_h1=n1,
                pd=float(count / n1), pd_ci95_low=low, pd_ci95_high=high,
                diagnostic_auc_vs_H0_audit=auc))
    for split, values in [('h0_cal', arrays['h0_cal']), ('h0_audit', arrays['h0_audit'])] + [
            ('h1_scr_' + str(scr), arrays['h1'][j]) for j, scr in enumerate(p['scr_grid_db'])]:
        quantiles = np.quantile(values, [0, .01, .5, .99, .999, 1])
        summaries.append(dict(split=split, n=int(values.size), mean=float(np.mean(values)),
            std=float(np.std(values)), minimum=float(quantiles[0]), q01=float(quantiles[1]),
            median=float(quantiles[2]), q99=float(quantiles[3]), q999=float(quantiles[4]), maximum=float(quantiles[5])))
    save_csv(folder / 'b288_curves.csv', curves)
    save_csv(folder / 'b288_metrics.csv', metrics)
    save_csv(folder / 'b288_score_summary.csv', summaries)

    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    figdir = folder / 'figures'
    figdir.mkdir(exist_ok=True)
    for nominal in p['nominal_pfas']:
        rows = [r for r in curves if r['nominal_pfa'] == nominal]
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.plot([r['scr_db'] for r in rows], [r['pd'] for r in rows],
                color='tab:blue', marker='o', markerfacecolor='white', markersize=4,
                linewidth=1.7, linestyle='-', label=NAME, markevery=2)
        exponent = int(round(np.log10(nominal)))
        ax.set(xlabel='SCR (dB)', ylabel=r'$P_d$', xlim=(-24, 12), ylim=(0, 1.02),
               title=r'$P_{\mathrm{fa}}=10^{' + str(exponent) + '}$')
        ax.grid(alpha=.25)
        ax.legend(fontsize=9)
        fig.tight_layout()
        for ext in ('pdf', 'png', 'svg'):
            fig.savefig(figdir / f'b288_pd_scr_pfa_{nominal:.0e}.{ext}', dpi=250)
        plt.close(fig)
        save_csv(figdir / f'b288_pd_source_pfa_{nominal:.0e}.csv', rows)

    report = dict(status='PASS_B288_TSDETECTNET_MEDIUM_REPORT', method=NAME,
        protocol_fingerprint=p['fingerprint'], training_contract=p['training_contract'], metrics=metrics,
        raw_score_sha256={f: digest_file(folder / f) for f in FILES.values()},
        models_trained_and_plotted=['TS-DetectNet'], ADN_loaded=False, ADN_trained=False,
        ours_loaded=False, ours_trained=False, historical_scores_loaded=False,
        paper_equations_reimplemented=True, official_author_code=False,
        MobileNetV3_Small_inferred_from_Table_VI_parameter_count=True,
        real_IPIX_SDRDSP_performance_reproduced=False, independent_final=False,
        medium_screen_only=True, automatic_full_scale=False,
        source_Pd_unchanged=True, smoothing=False, curve_shifting=False,
        warning_flags=[dict(nominal_pfa=m['nominal_pfa'],
            max_Pd_below_0_5=m['max_pd'] < .5,
            high_SCR_Pd_drop_gt_10pp=m['max_pd'] - m['pd_at_12'] > .10,
            nominal_Pfa_outside_audit_95CI=not (m['actual_pfa_ci95_low'] <= m['nominal_pfa'] <= m['actual_pfa_ci95_high'])) for m in metrics])
    write_json(folder / 'b288_report.json', report)
    for m in metrics:
        print(f'{NAME} Pfa={m["nominal_pfa"]:.0e}: D80={m["D80_db"]}; D90={m["D90_db"]}; '
              f'Pd@0={m["pd_at_0"]:.4f}; Pd@12={m["pd_at_12"]:.4f}; '
              f'H0 FP={m["audit_false_alarms"]}/{m["audit_n"]}', flush=True)
    print(f'PASS_B288_TSDETECTNET_MEDIUM_COMPLETE: {folder}; only this model; stopped after medium', flush=True)
    return report
