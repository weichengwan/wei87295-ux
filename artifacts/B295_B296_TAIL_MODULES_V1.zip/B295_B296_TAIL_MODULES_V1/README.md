# B295/B296：冻结 ADN＋TFSE 的两个独立尾部候选

本包只训练两种新尾部：

1. `HGNL_tail`：借鉴 TAES2026 HGNLN 的图频带自适应融合，改为单样本深层特征构图。
2. `MDFG_tail`：借鉴 TAES2026 MDFG_SCL 的 Gini 加权、浅深对齐与监督对比学习，改为单 CUT 描述量和残差判别头。

详细原文解读、公式出处和改动见 `PAPER_ANALYSIS_ZH.md` 与 `paper_contract.json`。

两路都从**同一个 B280 A1 固定检查点**出发，TFSE、整个 ADN、BN、8个原生SimAM和原FC全部冻结。没有原ADN或TFSE对照的重新训练。本包的 `tail` 仅表示网络尾部位置，不是历史 L1-Tail 损失。

## 直接使用

将 ZIP 上传至 `/root/autodl-tmp/MTDSP_NATIVE_LMDA_V1`，在该目录运行：

```bash
unzip -n B295_B296_TAIL_MODULES_V1.zip
bash B295_B296_TAIL_MODULES_V1/start_on_autodl.sh
tail -n 80 -F codex_b295_b296_tails.log
```

启动器通过 `conda run -n mpdnet-r10` 后台运行，不要求 `conda activate`。网络断开或关闭日志查看，不会停止 nohup 任务。

启动后先做CPU只读检查，发现并等待已有 `b293_evaluate.py` / `run_b293.sh` 进程退出，再获取全系列共用的 `codex_b271_night.lock`。等待时不把模型移到GPU，不终止任何旧进程。B293已结束则继续等待其他持锁GPU实验；B293报错退出也会释放排队，本实验独立继续。

同一启动器重复调用会检查PID，避免重复排队。不要另开终端再直接运行同一个 `run_tails.py`。

## 默认做什么

- 完整既有 TRAIN30k/VAL5k，用于只训练新增尾部；冻结骨干特征缓存一次，float32，无WVD缓存依赖。
- 两个尾部各12个epoch，头部batch256；骨干特征提取与评分batch32，无AMP或TF32。
- 中规模配对DEV：CAL300,000、AUDIT200,000、H1512×37，SCR从-24至+12dB，标称Pfa1e-4。
- 训练→评分→三条原始Pd曲线、H0虚警区间图和CSV，自动串联完成后停止，不自动跑昂贵完整复评。
- 三条曲线为固定TFSE、图频带尾部、特征引导对比尾部。均为实线，新候选分别带上/下三角形；横轴`SCR (dB)`、纵轴`Pd`，上方标明Pfa。

输出目录：`output_b295_b296_tails_v1`。

```text
HGNL_tail/best.pt
MDFG_tail/best.pt
HGNL_tail/training_contract.json
MDFG_tail/training_contract.json
pd_scr_medium/b295_b296_metrics.csv
pd_scr_medium/b295_b296_comparisons.csv
pd_scr_medium/b295_b296_curves.csv
pd_scr_medium/b295_b296_pd_scr_pfa_1e-04.pdf
pd_scr_medium/b295_b296_report.json
```

新增头与分数数据占用较小，特征缓存约1.14GiB，建议至少留2GiB空闲。不会自动删除任何历史文件。3080Ti上的实际耗时未在本环境实测；中规模暂估20–50分钟，排队时间另计，主要耗时为H0推理。以日志吞吐为准。

## 中规模有收益后，完整复评，无需再训练

等中规模进程结束，运行：

```bash
bash B295_B296_TAIL_MODULES_V1/start_on_autodl.sh --stage score --full
tail -n 0 -F codex_b295_b296_tails.log
```

输出为同一目录下 `pd_scr_full`，CAL3,000,000、AUDIT1,000,000、H11024×37，Pfa1e-4和1e-5。只读取已训练的两个尾部，不重新训练，不覆盖中规模结果。

如果明确要直接完整评分而不先筛选，可首次启动时加 `--full`；默认仍是中规模。

## 必须保留的历史源

```text
SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1/
  sim_r10_iq512_v1.h5
  sim_r10_iq512_v1_contract.json
  sim_r10_iq512_audit_v1.json
output_b280_full_ablation_v1/A1/
  best.pt
  training_contract.json
output_b280_full_ablation_v1/pd_scr_full/
  protocol_frozen.json
  progress.json
  h0_cal_scores.npy
  h0_audit_scores.npy
  dev_h1_scores.npy
```

检查点、契约、生成器、原评分协议和前缀分数都校验。只接受准确的B280 A1，不把B282 control或其他continued模型当成frozen。原推理torch版本、batch、AMP和TF32设置必须匹配；不要为了安装本包升级torch。推荐直接复用已有`mpdnet-r10`依赖，本包不需要torch-geometric或pywavelets。

中规模会以原始分数的同规模前缀重新校准基线阈值，数字可能不同于原完整3M-CAL报告。完整复评保持相同CAL样本数时，基线应复现历史完整结果。原始文件始终只读。

## 恢复与复画

断线不等于任务中断。若进程确实退出，使用原启动命令再次启动：冻结特征按提交前缀恢复，训练按已完成epoch恢复，H0评分按chunk恢复，H1按完整SCR行恢复。参数或代码改变会拒绝混用旧输出。

只用CPU重新生成现有报告，无需训练或推理：

```bash
/root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  bash B295_B296_TAIL_MODULES_V1/run_b295_b296.sh --stage report
```

完整规模报告再加 `--full`。原始分数可用于CPU绘制ROC；包中也输出了声明正类先验0.5时的Precision/F1数据。新海况、新实测文件需要新推理，不因新增指标而要求重新训练。

`best.pt`只保存新增尾部；完整部署模型由 `reference.TailDetector`、准确的原A1权重和该尾部组成，不能单独把尾部文件当完整CNN。

## 检查范围

CPU功能检查记录见 `VALIDATION.json`。本包未在本地拥有AutoDL数据或CUDA，因此不声称已验证服务器Pd增益。两个候选即使未超过基线，也保留实际训练结果，不回退epoch0冒充成功。所有图均为原始统计点，不平移或修改Pd。
