"""B295/B296: two independent source-attributed tails on exactly fixed B280 A1."""
import argparse
import gc
from pathlib import Path
import torch
from common import ROOT,ARMS,need,readj,writej,fp,sha,setup,validate,code_hashes
from reference import check_bank,load_reference,verify_protected
from feature_cache import prepare
from train_tails import preflight,train_one
from queueing import wait_b293,acquire

def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=ROOT.parent)
    for option in ('bank-dir','b280-run','out-dir'):p.add_argument('--'+option,type=Path)
    p.add_argument('--device',choices=('cuda','cpu'),default='cuda')
    p.add_argument('--batch',type=int,default=32);p.add_argument('--head-batch',type=int,default=256)
    p.add_argument('--chunk',type=int,default=512);p.add_argument('--cpu-threads',type=int,default=2)
    p.add_argument('--epochs',type=int,default=12);p.add_argument('--seed',type=int,default=20261022)
    p.add_argument('--stage',choices=('all','train','score','report'),default='all')
    p.add_argument('--full',action='store_true');p.add_argument('--wait-for-gpu',action='store_true')
    p.add_argument('--check-only',action='store_true')
    a=p.parse_args(argv);a.root=a.root.resolve()
    defaults=dict(bank_dir='SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1',
                  b280_run='output_b280_full_ablation_v1',out_dir='output_b295_b296_tails_v1')
    for key,name in defaults.items():setattr(a,key,(getattr(a,key) or a.root/name).resolve())
    need(a.root.is_dir() and a.out_dir.parent==a.root and a.out_dir.name.startswith('output_b295_b296_'),'Use a fresh direct output_b295_b296_* directory')
    for old in (a.bank_dir,a.b280_run):
        need(old!=a.out_dir and old not in a.out_dir.parents and a.out_dir not in old.parents,'Output overlaps a protected historical source')
    need(1<=a.batch<=32 and a.chunk>=a.batch and a.chunk%a.batch==0,'Invalid scoring batch/chunk')
    need(16<=a.head_batch<=512 and 1<=a.epochs<=50 and 1<=a.cpu_threads<=4,'Invalid head training settings')
    if a.out_dir.exists() and any(a.out_dir.iterdir()):
        need((a.out_dir/'run_manifest.json').is_file(),'Existing output has no experiment identity')
        need(not any(f.is_symlink() for f in a.out_dir.rglob('*')),'Output contains symlinks; preserve it')
    return a

def main(argv=None):
    a=cli(argv);validate();setup(a.cpu_threads,a.seed)
    folder=a.out_dir/('pd_scr_full' if a.full else 'pd_scr_medium')
    if a.stage=='report':
        from report import generate
        generate(folder);return
    # CPU-only checks happen before queueing; neither model nor cache is moved to CUDA here.
    context=check_bank(a);info=load_reference(a,context)
    print('Found exact frozen B280 A1; two new tails only. Baseline will not be retrained.',flush=True)
    if a.check_only:
        for name in ('h0_cal_scores.npy','h0_audit_scores.npy','dev_h1_scores.npy'):
            need((a.b280_run/'pd_scr_full'/name).is_file(),'Historical A1 scores missing: '+name)
        print('PASS_B295_B296_CPU_PREFLIGHT_ONLY; no GPU acquired or training started',flush=True);return
    dependency=wait_b293(a.wait_for_gpu)
    lock_path=a.root/('codex_b271_night.lock' if a.device=='cuda' else 'codex_b295_b296_cpu.lock')
    with lock_path.open('a') as lock:
        acquire(lock,a.wait_for_gpu)
        if a.device=='cuda':need(torch.cuda.is_available(),'CUDA unavailable after queue completed')
        verify_protected(info);need(sha(context['path'])==context['bc']['file_sha256'],'TRAIN/VAL bank changed while waiting')
        info['model'].to(a.device).eval().requires_grad_(False)
        identity=dict(version='B295_B296_TAIL_MODULES_V1',arms=list(ARMS),epochs=a.epochs,seed=a.seed,
            batch=a.batch,head_batch=a.head_batch,chunk=a.chunk,cpu_threads=a.cpu_threads,device=a.device,
            torch_version=str(torch.__version__),bank_sha256=context['bc']['file_sha256'],
            source_checkpoint_sha256=info['contract']['checkpoint_sha256'],code_sha256=code_hashes(),
            frozen_TFSE_and_ADN=True,baseline_retrained=False,feature_cache_dtype='float32',
            training_count=30000,validation_count=5000)
        a.out_dir.mkdir(exist_ok=True);mp=a.out_dir/'run_manifest.json'
        if mp.exists():need(readj(mp)==identity,'Run settings/source changed; preserve output and choose a fresh output_b295_b296_* folder')
        else:
            need(not any(a.out_dir.iterdir()),'Unknown output contents');writej(mp,identity)
        writej(a.out_dir/'last_queue_entry.json',dependency)
        print('B295/B296: TFSE + ADN backbone frozen; only two tails train; output='+str(a.out_dir),flush=True)
        if a.stage in ('all','train'):
            cache=prepare(a,context,info)
            pp=a.out_dir/'preflight.json'
            if pp.exists():need(readj(pp)['run_fingerprint']==fp(identity),'Preflight source/settings changed')
            else:writej(pp,dict(run_fingerprint=fp(identity),checks=preflight(a,info,cache)))
            for arm in ARMS:train_one(a,info,cache,arm)
            del cache;gc.collect();verify_protected(info)
            if a.stage=='train':return
        from score_tails import score
        score(a,context,info)
        writej(a.out_dir/'protected_sources_after_run.json',verify_protected(info))
        print('PASS_B295_B296_'+('FULL' if a.full else 'MEDIUM')+'_COMPLETE: '+str(folder),flush=True)
        if not a.full:print('Medium DEV finished; stops here. No automatic expensive full scoring or additional model search.',flush=True)

if __name__=='__main__':main()
