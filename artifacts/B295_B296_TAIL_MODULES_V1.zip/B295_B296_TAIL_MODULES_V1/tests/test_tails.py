import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import types
import unittest
from unittest import mock
import numpy as np
import torch
import torch.nn.functional as F

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from common import ARMS,FILES,fp,sha,readj,writej,state_sha,roc_metrics,validate
from physical_features import descriptors,fit_gini,FEATURE_NAMES
from tail_models import graph_bands,make_tail,objective,supervised_contrastive,symmetric_alignment
from reference import Reference,TailDetector
from feature_cache import open_arrays
from train_tails import train_one,preflight,evaluate
from queueing import process_identity,b293_dependencies,same_process,acquire
from score_tails import make_iq,predictions,stream
from report import generate,paired_bootstrap
from tail_stats import cutoff,crossing

torch.set_num_threads(2)

def feature_stats():
    return dict(mean=[0.]*10,std=[1.]*10,weights=[.1]*10)

def synthetic_cache(n=64):
    rng=np.random.default_rng(771);fc=feature_stats()
    values={}
    for split,count in [('train',n),('val',32)]:
        y=np.arange(count,dtype='int64')%2
        z=rng.normal(size=(count,512)).astype('float32');z[:,0]+=y*.6
        physical=rng.normal(size=(count,10)).astype('float32');physical[:,0]+=y
        margin=(z[:,0]*.6).astype('float32')
        logits=np.stack((-.5*margin,.5*margin),1)
        values[split]=dict(pooled=rng.normal(size=(count,512,4,4)).astype('float32'),z=z,
            physical=physical,logits=logits,labels=y)
    v=values['val'];ce=float(F.cross_entropy(torch.from_numpy(v['logits']),torch.from_numpy(v['labels'])))
    ct=dict(feature_stats=fc,margin_scale=1.,reference_val_ce=ce,
            reference_val_metrics=roc_metrics(v['logits'][:,1]-v['logits'][:,0],v['labels']))
    return dict(values=values,contract=ct)

class ModuleTests(unittest.TestCase):
    def test_source_checksums(self):validate()

    def test_physical_gain_phase_invariance_and_zero_safety(self):
        torch.manual_seed(7);iq=torch.complex(torch.randn(6,512),torch.randn(6,512))
        a=descriptors(iq);b=descriptors(iq*torch.polar(torch.tensor(3.7),torch.tensor(1.23)))
        self.assertEqual(a.shape,(6,10));self.assertTrue(torch.allclose(a,b,rtol=2e-4,atol=2e-5))
        for value in (torch.zeros_like(iq),torch.ones_like(iq),iq*1e-5):
            self.assertTrue(torch.isfinite(descriptors(value)).all())

    def test_gini_uses_discriminative_gain_and_handles_constants(self):
        y=np.arange(128)%2;x=np.ones((128,10));x[:,0]=y
        out=fit_gini(x,y)
        self.assertAlmostEqual(out['weights'][0],1.)
        self.assertAlmostEqual(sum(out['weights'][1:]),0.)
        self.assertEqual(out['fit_split'],'TRAIN only')
        constant=fit_gini(np.ones((128,10)),y)
        self.assertTrue(constant['uniform_fallback']);self.assertAlmostEqual(sum(constant['weights']),1.)

    def test_graph_filters_are_complementary_and_symmetric(self):
        torch.manual_seed(8);x=torch.randn(3,16,64,requires_grad=True)
        low,high,s=graph_bands(x)
        self.assertTrue(torch.allclose(low+high,x,atol=2e-7))
        self.assertTrue(torch.allclose(s,s.transpose(1,2),atol=1e-7))
        eigen=torch.linalg.eigvalsh(s.detach())
        self.assertLessEqual(float(eigen.max()),1.00001);self.assertGreaterEqual(float(eigen.min()),-1.00001)
        (high.square().mean()+low.square().mean()).backward();self.assertTrue(torch.isfinite(x.grad).all())
        const=torch.ones(1,16,4);_,high,_=graph_bands(const,k=15)
        self.assertLess(float(high.abs().max()),1e-6)

    def test_losses_finite_and_label_dependent(self):
        torch.manual_seed(9);z=F.normalize(torch.randn(12,128),dim=1);q=F.normalize(torch.randn(12,128),dim=1)
        a=supervised_contrastive(z,torch.arange(12)%2);b=supervised_contrastive(z,torch.arange(12)%3)
        self.assertTrue(torch.isfinite(a));self.assertNotEqual(float(a),float(b))
        self.assertTrue(torch.isfinite(symmetric_alignment(z,q)))
        self.assertEqual(float(supervised_contrastive(z,torch.arange(12))),0.)

    def test_two_tails_identity_then_real_parameter_updates(self):
        cache=synthetic_cache();v=cache['values']['train'];args=types.SimpleNamespace(seed=20261022,device='cpu')
        before=[torch.from_numpy(v[k][:16].copy()) for k in ('pooled','z','physical','logits')];y=torch.from_numpy(v['labels'][:16])
        for arm in ARMS:
            m=make_tail(arm,1.,feature_stats());z,_=m(*before);self.assertTrue(torch.equal(z,before[-1]))
            opt=torch.optim.AdamW(m.parameters(),lr=.001)
            orig={k:x.detach().clone() for k,x in m.state_dict().items()}
            for _ in range(4):
                opt.zero_grad();z,aux=m(*before);loss,_=objective(arm,z,aux,y);loss.backward();opt.step()
            changed=[k for k,x in m.state_dict().items() if not torch.equal(x,orig[k])]
            self.assertTrue(any(not k.startswith('output.') for k in changed))
            delta=m(*before)[1]['delta'];self.assertGreater(float(delta.abs().max()),0.)
            self.assertLessEqual(float(delta.abs().max()),.5)

    def test_native_reference_path_and_frozen_tensors(self):
        torch.manual_seed(23);reference=Reference(1.).eval().requires_grad_(False)
        x=torch.complex(torch.randn(2,512),torch.randn(2,512))
        from tfse_frontend import smoothing_bank
        with torch.no_grad():
            direct=reference.prepared_forward(smoothing_bank(x,1.));features=reference.extract(x)
        self.assertTrue(torch.equal(direct,features[-1]))
        self.assertEqual(tuple(features[0].shape),(2,512,4,4))
        self.assertEqual(sum(type(m).__name__=='SimAM' for m in reference.detector.modules()),8)
        digest=state_sha(reference);tail=make_tail('MDFG_tail',1.,feature_stats());model=TailDetector(reference,tail).train()
        self.assertFalse(model.reference.training);self.assertFalse(any(p.requires_grad for p in reference.parameters()))
        for _ in range(3):
            optimizer=torch.optim.AdamW(tail.parameters(),lr=.001);optimizer.zero_grad()
            logits=model(x);F.cross_entropy(logits,torch.tensor([0,1])).backward();optimizer.step()
        self.assertEqual(state_sha(reference),digest)

    @unittest.skipUnless(torch.cuda.is_available(),'CUDA unavailable in local validation environment')
    def test_cuda_preflight_snapshots_are_device_safe(self):
        args=types.SimpleNamespace(seed=20261022,device='cuda')
        with mock.patch('train_tails.verify_protected',return_value={'unchanged':True}):
            value=preflight(args,{},synthetic_cache())
        self.assertEqual(set(value),set(ARMS))

class OperationalTests(unittest.TestCase):
    def test_feature_cache_missing_file_and_shape_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp);out=open_arrays(folder,'train',8,True)
            for value in out.values():value.flush()
            self.assertEqual(open_arrays(folder,'train',8)['z'].shape,(8,512))
            with self.assertRaisesRegex(RuntimeError,'shape/type'):open_arrays(folder,'train',10)
            (folder/'train_z.npy').unlink()
            with self.assertRaisesRegex(RuntimeError,'Missing'):open_arrays(folder,'train',8)

    def test_real_tail_training_checkpoint_resume_and_no_epoch_zero(self):
        cache=synthetic_cache();info=dict(contract=dict(checkpoint_sha256='test-fixed-reference'))
        with tempfile.TemporaryDirectory() as tmp, mock.patch('train_tails.verify_protected',return_value={'unchanged':True}):
            a=types.SimpleNamespace(out_dir=Path(tmp),seed=20261022,epochs=2,head_batch=32,device='cpu')
            for arm in ARMS:
                ct=train_one(a,info,cache,arm)
                self.assertGreater(ct['best_epoch'],0);self.assertFalse(ct['source_fallback'])
                self.assertEqual(ct['run_config']['train_n'],64)
                old=sha(a.out_dir/arm/'best.pt');again=train_one(a,info,cache,arm)
                self.assertEqual(again,ct);self.assertEqual(sha(a.out_dir/arm/'best.pt'),old)

    def test_training_interruption_after_last_commit_recovers_best(self):
        import train_tails
        cache=synthetic_cache();info=dict(contract=dict(checkpoint_sha256='test-fixed-reference'))
        with tempfile.TemporaryDirectory() as tmp, mock.patch('train_tails.verify_protected',return_value={'unchanged':True}):
            a=types.SimpleNamespace(out_dir=Path(tmp),seed=20261022,epochs=2,head_batch=32,device='cpu')
            real_save=train_tails.save
            def fail_best(path,obj):
                if Path(path).name=='best.pt':raise RuntimeError('simulated power loss after epoch commit')
                real_save(path,obj)
            with mock.patch('train_tails.save',side_effect=fail_best):
                with self.assertRaisesRegex(RuntimeError,'simulated power'):train_one(a,info,cache,'HGNL_tail')
            self.assertTrue((a.out_dir/'HGNL_tail/last_epoch.pt').is_file())
            ct=train_one(a,info,cache,'HGNL_tail');self.assertGreater(ct['best_epoch'],0)
            self.assertEqual(sha(a.out_dir/'HGNL_tail/best.pt'),ct['checkpoint_sha256'])

    def test_cli_readonly_preflight_with_complete_source_contract_schema(self):
        import h5py
        from common import ROOT as PACKAGE,load,save
        from reference import Reference
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);bank=root/'SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1';bank.mkdir()
            path=bank/'sim_r10_iq512_v1.h5'
            with h5py.File(path,'w') as h:
                # Sparse HDF5 geometry exercises exact production metadata without generating radar data.
                for split,n in [('train',30000),('val',5000)]:
                    group=h.create_group(split);group.create_dataset('iq',shape=(n,512),dtype='complex64',chunks=(32,512))
                    group.create_dataset('label',data=np.arange(n,dtype='int64')%2)
            gsha=sha(PACKAGE/'frozen_source/r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
            bc=dict(version='SIM_R10_IQ512_GENERATOR_V1',n_pulses=512,counts=dict(train=30000,val=5000),
                status='PASS_SIM_R10_IQ512_BUILDER_V1__SYNTHETIC_TEST',file_sha256=sha(path),generator_sha256=gsha,seed=20261009)
            writej(bank/'sim_r10_iq512_v1_contract.json',bc)
            writej(bank/'sim_r10_iq512_audit_v1.json',dict(status='PASS_SIM_R10_IQ512_AUDIT_V1__SYNTHETIC_TEST',bank_sha256=sha(path)))
            original=root/'output_b280_full_ablation_v1';model_dir=original/'A1';model_dir.mkdir(parents=True)
            cfg=dict(arm='A1',code_sha256=readj(PACKAGE/'expected_source_code.json')['B280'],factor_A_joint_SPWVD=True,
                factor_B_TFCG_Tail=False,bank_sha256=sha(path),selected_rows=dict(train=dict(count=30000),val=dict(count=5000)),scale=1.)
            model=Reference(1.);checkpoint=model_dir/'best.pt'
            save(checkpoint,dict(state_dict=model.state_dict(),run_config=cfg,run_fingerprint=fp(cfg),epoch=1))
            ct=dict(status='PASS_B280_FULL_TRAIN_VAL_ONLY',run_config=cfg,run_fingerprint=fp(cfg),best_epoch=1,
                checkpoint_sha256=sha(checkpoint),selected_validation=dict(val_ce=.69))
            writej(model_dir/'training_contract.json',ct)
            import common
            g=common.frozen('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
            scene=dict(master_seed=20261009,generator_sha=gsha,h0_cal_n=3000000,h0_audit_n=1000000,h1_scenes_n=1024,
                scr_grid_db=list(range(-24,13)),h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',
                family_names=list(g.TRAIN_FAMILIES),scr_definition='synthetic schema check only')
            p=dict(version='B280_FULL_FACTORIAL_SCORE_V1',labels=['A0','A1','A2','A3'],checkpoints=[{},ct,{},{}],
                scene_fingerprint=fp(scene),**scene,batch=32,torch_version=str(torch.__version__),device='cpu',amp=False,tf32=False)
            p['fingerprint']=fp(p);score_dir=original/'pd_scr_full';score_dir.mkdir()
            writej(score_dir/'protocol_frozen.json',p)
            writej(score_dir/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=3000000,h0_audit=1000000,h1=37)))
            for name in FILES.values():(score_dir/name).touch()
            protected={str(x):sha(x) for x in root.rglob('*') if x.is_file()}
            result=subprocess.run([sys.executable,str(PACKAGE/'run_tails.py'),'--root',str(root),'--device','cpu','--check-only'],
                capture_output=True,text=True,env=dict(os.environ),timeout=40)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('CPU_PREFLIGHT_ONLY',result.stdout)
            self.assertFalse((root/'output_b295_b296_tails_v1').exists())
            self.assertEqual(protected,{str(x):sha(x) for x in root.rglob('*') if x.is_file()})

    def test_process_identity_b293_filter_and_pid_reuse(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            def write(pid,start,name,state='S'):
                d=root/str(pid);d.mkdir(exist_ok=True)
                fields=[state]+['0']*19;fields[19]=str(start)
                (d/'stat').write_text(str(pid)+' (process with spaces) '+' '.join(fields))
                (d/'cmdline').write_bytes(b'python\0'+name.encode()+b'\0')
            write(22,100,'/root/B293_CVHST_VALBEST_MEDIUM_V1/b293_evaluate.py')
            write(23,101,'/root/B295_B296_TAIL_MODULES_V1/run_tails.py')
            write(24,102,'/root/run_b293.sh','Z')
            rows=b293_dependencies(root);self.assertEqual(rows,[dict(pid=22,start_ticks='100')])
            self.assertTrue(same_process(rows[0],root));write(22,999,'unrelated.py')
            self.assertFalse(same_process(rows[0],root));self.assertIsNone(process_identity(24,root))

    def test_shared_lock_honors_existing_owner(self):
        import fcntl
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'shared.lock'
            with path.open('a') as one,path.open('a') as two:
                fcntl.flock(one,fcntl.LOCK_EX|fcntl.LOCK_NB)
                with self.assertRaisesRegex(RuntimeError,'Another radar'):acquire(two,False)
                fcntl.flock(one,fcntl.LOCK_UN);acquire(two,False)

    def test_h1_generation_matches_old_quantization_order(self):
        class G:
            @staticmethod
            def make_one(seed,split,i,lo,hi):
                v=np.full(512,1.00000008+1j*1.00000008,dtype='complex128')
                return dict(label=1,base=v,unit=v*.31,cp=.73)
        p=dict(master_seed=1,h1_split='h1',scr_grid_db=[-3])
        actual=make_iq(G,p,'h1',np.arange(2),0)
        s=G.make_one(1,'h1',0,0,0)
        expected=(s['base'].astype('complex64').astype('complex128')+s['unit'].astype('complex64').astype('complex128')*np.sqrt(.73*10**(-.3))).astype('complex64')
        self.assertTrue(np.array_equal(actual[0],expected))

    def test_score_stream_interruption_resume_matches_uninterrupted(self):
        import score_tails
        class G:
            @staticmethod
            def make_one(seed,split,i,lo,hi):
                x=np.full(512,.01*i+.1j,dtype='complex64')
                return dict(label=int(split=='dev_h1'),base=x,unit=np.ones(512,dtype='complex64'),cp=.2,target=np.zeros(512))
        class R:
            def extract(self,x):
                z=x.real[:,:2];logits=torch.stack((-z[:,0],z[:,0]),1)
                return z,z,z,logits
        class T:
            def __init__(self,v):self.v=v
            def __call__(self,*xs):return xs[-1]+torch.tensor([[-self.v,self.v]]),{}
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);a=types.SimpleNamespace(batch=4,chunk=8,device='cpu')
            p=dict(master_seed=1,h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',
                h0_cal_n=16,h0_audit_n=16,h1_scenes_n=8,scr_grid_db=[-1,0,1],profile='unit')
            p['fingerprint']=fp(p);context=dict(generator=G);info=dict(model=R());models={ARMS[0]:T(.1),ARMS[1]:T(.2)}
            original=score_tails.predictions;counter=[0]
            def interrupted(*args,**kwargs):
                counter[0]+=1
                if counter[0]==2:raise RuntimeError('simulated disconnect')
                return original(*args,**kwargs)
            with mock.patch('score_tails.predictions',side_effect=interrupted):
                with self.assertRaisesRegex(RuntimeError,'simulated'):stream(a,p,context,info,models,root/'resumed')
            self.assertEqual(readj(root/'resumed/progress.json')['completed']['h0_cal'],8)
            stream(a,p,context,info,models,root/'resumed');stream(a,p,context,info,models,root/'clean')
            for name in FILES.values():self.assertEqual(sha(root/'resumed'/name),sha(root/'clean'/name))

    def test_paired_report_uses_raw_points_and_fixed_baseline(self):
        from common import LABELS,NAMES
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);old=root/'old';folder=root/'new';old.mkdir();folder.mkdir()
            rng=np.random.default_rng(992);grid=list(range(-24,13));cal=100000;audit=50000;nh=64
            old_p=old/'protocol_frozen.json';writej(old_p,dict(source='synthetic test only'))
            baseline=dict(h0_cal=rng.normal(size=cal),h0_audit=rng.normal(size=audit),
                h1=rng.normal(size=(37,nh))+np.linspace(0,8,37)[:,None])
            raw_hash={}
            for split,name in FILES.items():
                b=baseline[split];hist=np.zeros(b.shape+(4,),dtype='float64');hist[...,1]=b
                np.save(old/name,hist);raw_hash[name]=sha(old/name)
                shifts=np.zeros_like(b) if split!='h1' else .7
                np.save(folder/name,np.stack((b+shifts,b+shifts*1.2),-1))
            p=dict(version='test only',profile='medium',scr_grid_db=grid,h0_cal_n=cal,h0_audit_n=audit,h1_scenes_n=nh,
                nominal_pfas=[1e-4],reference=dict(source=str(old),raw_score_sha256=raw_hash),
                reference_source_protocol_sha256=sha(old_p),source_preservation=dict(sha256={str(old_p):sha(old_p)}),
                training_contracts={a:dict(best_epoch=1,selected_validation=dict(val_ce=.4,val_pauc01=.6)) for a in ARMS})
            p['fingerprint']=fp(p);writej(folder/'protocol_frozen.json',p)
            writej(folder/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=cal,h0_audit=audit,h1=37)))
            saved={name:sha(old/name) for name in FILES.values()}
            result=generate(folder)
            self.assertEqual(len(result['metrics']),3)
            self.assertLess(result['comparisons'][0]['delta_D90_db'],0.)
            self.assertTrue((folder/'b295_b296_pd_scr_pfa_1e-04.pdf').is_file())
            self.assertEqual(saved,{name:sha(old/name) for name in FILES.values()})
            import csv
            with (folder/'b295_b296_curves.csv').open() as handle:rows=list(csv.DictReader(handle))
            threshold=result['metrics'][0]['threshold']
            raw=(baseline['h1']>threshold).mean(1)
            np.testing.assert_array_equal([float(r['pd']) for r in rows[:37]],raw)

    def test_shell_syntax(self):
        for name in ('run_b295_b296.sh','start_on_autodl.sh'):
            subprocess.run(['bash','-n',str(ROOT/name)],check=True,capture_output=True)

if __name__=='__main__':unittest.main()
