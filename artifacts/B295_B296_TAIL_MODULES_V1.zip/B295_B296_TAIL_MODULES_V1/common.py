"""Read-only historical sources and atomic operations inside this experiment."""
import csv
import hashlib
import importlib.util
import json
import random
import sys
from functools import lru_cache
from pathlib import Path
import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
ARMS = ('HGNL_tail', 'MDFG_tail')
LABELS = ('A1_frozen',) + ARMS
NAMES = dict(A1_frozen='ADN + TFSE (frozen B280 A1)',
             HGNL_tail='ADN + TFSE + graph-frequency tail',
             MDFG_tail='ADN + TFSE + feature-guided contrastive tail')
FILES = dict(h0_cal='h0_cal_scores.npy', h0_audit='h0_audit_scores.npy', h1='dev_h1_scores.npy')
TRAIN_PASS = 'PASS_B295_B296_TAIL_TRAIN_VAL_ONLY'

def need(condition, message):
    if not bool(condition): raise RuntimeError(message)

def readj(path): return json.loads(Path(path).read_text(encoding='utf-8'))

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(8 << 20), b''): h.update(b)
    return h.hexdigest()

def fp(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, allow_nan=False).encode()).hexdigest()

def writej(path, obj):
    path = Path(path); tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    tmp.replace(path)

def writecsv(path, rows):
    need(bool(rows), 'No CSV rows')
    with Path(path).open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

def save(path, obj):
    path = Path(path); tmp = path.with_suffix(path.suffix + '.tmp')
    torch.save(obj, tmp); tmp.replace(path)

def load(path):
    try: return torch.load(path, map_location='cpu', weights_only=False)
    except TypeError: return torch.load(path, map_location='cpu')

def snapshot(model): return {k:v.detach().cpu().clone() for k,v in model.state_dict().items()}

def state_sha(model):
    h = hashlib.sha256()
    for name, t in sorted(model.state_dict().items()):
        t = t.detach().cpu().contiguous()
        h.update(name.encode()); h.update(str(t.dtype).encode()); h.update(str(tuple(t.shape)).encode()); h.update(t.numpy().tobytes())
    return h.hexdigest()

def setup(threads, seed):
    torch.set_num_threads(threads); random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False; torch.backends.cuda.matmul.allow_tf32 = False

def validate():
    for name, value in readj(ROOT/'frozen_sources.json').items():
        need(sha(ROOT/name) == value, 'Bundled original source changed: '+name)

@lru_cache(maxsize=None)
def frozen(name):
    path = ROOT/'frozen_source'/name
    need(sha(path) == readj(ROOT/'frozen_sources.json')['frozen_source/'+name], 'Frozen source checksum differs')
    spec = importlib.util.spec_from_file_location('b295_frozen_'+hashlib.sha256(name.encode()).hexdigest()[:12], path)
    module = importlib.util.module_from_spec(spec); sys.modules[spec.name] = module; spec.loader.exec_module(module)
    return module

def code_hashes():
    paths = list(ROOT.glob('*.py')) + list((ROOT/'frozen_source').glob('*.py'))
    paths += [ROOT/x for x in ('expected_source_code.json','frozen_sources.json','paper_contract.json')]
    return {p.relative_to(ROOT).as_posix():sha(p) for p in sorted(paths)}

def roc_metrics(scores, labels):
    s = np.asarray(scores); y = np.asarray(labels)
    need(s.ndim == y.ndim == 1 and np.isfinite(s).all(), 'Invalid VAL scores')
    order = np.argsort(-s, kind='stable'); s,y = s[order],y[order]
    n0,n1 = int((y==0).sum()),int((y==1).sum()); need(n0>0 and n1>0, 'Both VAL classes required')
    ends = np.r_[np.flatnonzero(s[1:] != s[:-1]),len(s)-1]
    x = np.r_[0.,np.cumsum(y==0)[ends]/n0]; t = np.r_[0.,np.cumsum(y==1)[ends]/n1]
    integrate = np.trapezoid if hasattr(np,'trapezoid') else np.trapz
    right = int(np.searchsorted(x,.01,side='right'))
    xp,tp = x[:right],t[:right]
    if xp[-1] < .01:
        r = right; l = r-1
        xp = np.r_[xp,.01]; tp = np.r_[tp,t[l]+(t[r]-t[l])*(.01-x[l])/(x[r]-x[l])]
    return dict(val_auc=float(integrate(t,x)),val_pauc01=float(integrate(tp,xp)/.01))
