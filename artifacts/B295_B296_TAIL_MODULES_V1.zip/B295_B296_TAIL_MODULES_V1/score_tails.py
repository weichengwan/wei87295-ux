"""Shared frozen feature pass, two new tails, exact old A1 scores read-only."""
import time
import numpy as np
import torch
from common import ARMS,FILES,LABELS,NAMES,TRAIN_PASS,need,readj,writej,fp,sha,load,code_hashes
from reference import SCENE_KEYS,original_score_arrays,verify_protected
from tail_models import make_tail

def load_tails(a,info):
    models={};contracts={}
    for arm in ARMS:
        folder=a.out_dir/arm;ct=readj(folder/'training_contract.json');path=folder/'best.pt'
        need(ct['status']==TRAIN_PASS and ct['best_epoch']>0 and not ct['source_fallback'],'Actual completed tail required')
        cfg=ct['run_config'];need(cfg['arm']==arm and cfg['source_checkpoint_sha256']==info['contract']['checkpoint_sha256'],'Wrong source/arm')
        need(cfg['code_sha256']==code_hashes() and sha(path)==ct['checkpoint_sha256'],'Tail source/checkpoint changed')
        state=load(path);need(state['run_config']==cfg and state['run_fingerprint']==ct['run_fingerprint']==fp(cfg) and state['epoch']==ct['best_epoch'],'Tail internal identity differs')
        fc=cfg['feature_cache_contract'];model=make_tail(arm,fc['margin_scale'],fc['feature_stats'])
        model.load_state_dict(state['state_dict'],strict=True);models[arm]=model.to(a.device).eval();contracts[arm]=ct
    return models,contracts

def make_iq(g,p,split,ids,j=None):
    scenes=[g.make_one(p['master_seed'],p['h1_split'] if split=='h1' else p[split+'_split'],int(i),-30,10) for i in ids]
    if split!='h1':
        need(all(s['label']==0 and not np.any(s['target']) for s in scenes),'Target leaked into H0')
        return np.stack([s['base'] for s in scenes]).astype('complex64')
    need(all(s['label']==1 for s in scenes),'Wrong H1 generator split')
    # Match B280: quantize base/unit to complex64 BEFORE the complex128 mixture.
    base=np.stack([s['base'] for s in scenes]).astype('complex64').astype('complex128')
    unit=np.stack([s['unit'] for s in scenes]).astype('complex64').astype('complex128')
    power=np.asarray([s['cp'] for s in scenes],dtype='float64')
    return (base+unit*np.sqrt(power*10**(p['scr_grid_db'][j]/10))[:,None]).astype('complex64')

@torch.inference_mode()
def predictions(a,reference,models,iq):
    rows=[];baseline=[]
    for start in range(0,len(iq),a.batch):
        x=torch.from_numpy(np.array(iq[start:start+a.batch],copy=True)).to(a.device)
        features=reference.extract(x)
        new=[model(*features)[0] for model in models.values()]
        rows.append(torch.stack([z[:,1]-z[:,0] for z in new],1).double().cpu().numpy())
        baseline.append((features[-1][:,1]-features[-1][:,0]).double().cpu().numpy())
    out=np.concatenate(rows);old=np.concatenate(baseline)
    need(np.isfinite(out).all() and np.isfinite(old).all(),'Nonfinite candidate score')
    return out,old

def replay_reference(a,context,info,models,arrays,p):
    reports=[]
    for split,j in [('h0_cal',None),('h0_audit',None),('h1',0),('h1',24),('h1',36)]:
        ids=np.arange(a.batch);iq=make_iq(context['generator'],p,split,ids,j)
        _,baseline=predictions(a,info['model'],models,iq)
        saved=arrays[split][j,ids] if split=='h1' else arrays[split][ids]
        error=float(np.max(np.abs(saved-baseline)))
        need(np.allclose(saved,baseline,rtol=2e-5,atol=5e-5),'Frozen A1 historical score prefix differs; preserve old arrays and investigate')
        reports.append(dict(split=split,scr_db=None if j is None else p['scr_grid_db'][j],n=len(ids),maxabs=error))
    print('Exact B280 A1 lineage and matched CAL/AUDIT/H1 prefix replay passed; no separate baseline inference pass',flush=True)
    return reports

def protocol(a,info,contracts,record):
    scene={k:info['scene'][k] for k in SCENE_KEYS}
    if not a.full:scene.update(h0_cal_n=300000,h0_audit_n=200000,h1_scenes_n=512)
    p=dict(version='B295_B296_TWO_TAIL_SCORE_V1',profile='full' if a.full else 'medium',**scene,
        labels=list(LABELS),candidate_columns=list(ARMS),names=NAMES,
        nominal_pfas=[1e-4,1e-5] if a.full else [1e-4],batch=a.batch,chunk=a.chunk,
        torch_version=str(torch.__version__),device=a.device,amp=False,tf32=False,
        reference=record,reference_source_protocol_sha256=sha(info['source_protocol_path']),
        training_contracts=contracts,source_preservation=verify_protected(info),
        code_sha256=code_hashes(),score_definition='float64(float32 logit1 - float32 logit0)',
        decision='score > own H0 CAL threshold',independent_final=False,
        scope='Paired exposed DEV for exploratory method selection; checkpoint choice uses TRAIN/VAL only',
        medium_baseline_note='Same fixed checkpoint; thresholds use matched300k CAL prefix, so medium metrics need not equal historical full3M metrics')
    p['fingerprint']=fp(p);return p

def stream(a,p,context,info,models,folder):
    folder.mkdir(exist_ok=True);pp=folder/'protocol_frozen.json'
    if pp.exists():need(readj(pp)==p,'Score profile/selected checkpoint changed; keep output and use a new directory')
    else:
        need(not any(folder.iterdir()),'Unknown score output contents');writej(pp,p)
    prpath=folder/'progress.json'
    if prpath.exists():pr=readj(prpath);need(pr['fingerprint']==p['fingerprint'],'Score resume fingerprint differs')
    else:pr=dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=0,h0_audit=0,h1=0));writej(prpath,pr)
    for split,name in FILES.items():
        n=p['h1_scenes_n'] if split=='h1' else p[split+'_n'];levels=len(p['scr_grid_db'])
        total=levels if split=='h1' else n;done=pr['completed'][split]
        need(isinstance(done,int) and 0<=done<=total,'Invalid committed score progress')
        path=folder/name;need(done==0 or path.is_file(),'Committed score array missing')
        shape=(levels,n,len(ARMS)) if split=='h1' else (n,len(ARMS))
        if path.exists():array=np.load(path,mmap_mode='r+',allow_pickle=False)
        else:array=np.lib.format.open_memmap(path,mode='w+',dtype='float64',shape=shape)
        need(array.shape==shape and array.dtype==np.float64,'Candidate score geometry/type changed')
        if done:
            j=done-1 if split=='h1' else None;ids=np.arange(a.batch)
            actual,_=predictions(a,info['model'],models,make_iq(context['generator'],p,split,ids,j))
            old=array[j,ids] if split=='h1' else array[ids]
            need(np.allclose(actual,old,rtol=2e-5,atol=5e-5),'Candidate score resume replay differs')
        began=time.perf_counter()
        if split=='h1':
            for j in range(done,levels):
                for start in range(0,n,a.chunk):
                    stop=min(start+a.chunk,n);iq=make_iq(context['generator'],p,split,np.arange(start,stop),j)
                    array[j,start:stop]=predictions(a,info['model'],models,iq)[0]
                need(np.isfinite(array[j]).all(),'Nonfinite H1 score row')
                array.flush();pr['completed'][split]=j+1;writej(prpath,pr)
                print(f'[{p["profile"]} dev_h1] SCR={p["scr_grid_db"][j]:+d} dB {j+1}/{levels}',flush=True)
        else:
            for start in range(done,n,a.chunk):
                stop=min(start+a.chunk,n);iq=make_iq(context['generator'],p,split,np.arange(start,stop))
                array[start:stop]=predictions(a,info['model'],models,iq)[0]
                array.flush();pr['completed'][split]=stop;writej(prpath,pr)
                if stop==n or stop%10000<a.chunk:
                    rate=(stop-done)/max(time.perf_counter()-began,1e-6)
                    print(f'[{p["profile"]} {split}] {stop:,}/{n:,}; shared backbone + two tails {rate:.1f}/s; remaining~{(n-stop)/max(rate,1e-6)/60:.1f}min',flush=True)
        del array

def score(a,context,info):
    models,contracts=load_tails(a,info)
    choices=[dict(label=arm,checkpoint_sha256=contracts[arm]['checkpoint_sha256'],
        val_ce=contracts[arm]['selected_validation']['val_ce'],
        val_pauc01=contracts[arm]['selected_validation']['val_pauc01']) for arm in ARMS]
    selection=dict(rule='max VAL pAUC01, then lower VAL CE; both candidates are fully scored',
        candidates=choices,preferred_label=sorted(choices,key=lambda r:(-r['val_pauc01'],r['val_ce'],r['label']))[0]['label'],
        committed_before_CAL_AUDIT_H1_scores_opened=True,H0_CAL_AUDIT_H1_used_for_choice=False)
    selection_path=a.out_dir/'val_model_selection.json'
    if selection_path.exists():need(readj(selection_path)==selection,'Previously committed VAL-only model choice changed')
    else:writej(selection_path,selection)
    reference_arrays,record=original_score_arrays(info,'full' if a.full else 'medium')
    p=protocol(a,info,contracts,record)
    replay=replay_reference(a,context,info,models,reference_arrays,p)
    folder=a.out_dir/('pd_scr_full' if a.full else 'pd_scr_medium')
    print(f'Two-tail {p["profile"]} score: CAL{p["h0_cal_n"]:,} AUDIT{p["h0_audit_n"]:,}; H1 {p["h1_scenes_n"]}x37; A1 old scores reused',flush=True)
    stream(a,p,context,info,models,folder)
    writej(folder/'historical_prefix_replay.json',replay)
    from report import generate
    result=generate(folder);verify_protected(info);return result
