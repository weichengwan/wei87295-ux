"""Load precisely B280 A1; never load/retrain A0, B289 or a continued baseline."""
import h5py
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from common import ROOT,need,readj,sha,fp,load,frozen,state_sha
from tfse_frontend import JointTFGate,smoothing_bank
from physical_features import descriptors

SCENE_KEYS=('master_seed','generator_sha','h0_cal_n','h0_audit_n','h1_scenes_n','scr_grid_db',
            'h0_cal_split','h0_audit_split','h1_split','family_names','scr_definition')

class Reference(nn.Module):
    def __init__(self,scale):
        super().__init__();self.scale=float(scale);self.gate=JointTFGate()
        self.detector=frozen('r10_2025_mtdsp_adn_source_protocol_freeze_canary_v1.py').ADN18(num_classes=2)

    def prepared_forward(self,bank):
        image,_=self.gate(bank);return self.detector(image)

    @torch.no_grad()
    def extract(self,iq):
        image,_=self.gate(smoothing_bank(iq,self.scale));d=self.detector
        value=d.maxpool(d.relu(d.bn1(d.conv1(image))))
        value=d.layer4(d.layer3(d.layer2(d.layer1(value))))
        z=torch.flatten(d.avgpool(value),1)
        # Branch-only pooled tokens. Original GAP/logits remain based on the full 7x7 map.
        return F.adaptive_avg_pool2d(value,(4,4)),z,descriptors(iq),d.fc(z)

class TailDetector(nn.Module):
    """Deployable complete model; reference tensors are always frozen/eval."""
    def __init__(self,reference,tail):
        super().__init__();self.reference=reference.requires_grad_(False).eval();self.tail=tail
    def train(self,mode=True):
        super().train(mode);self.reference.eval();return self
    def forward(self,iq):return self.tail(*self.reference.extract(iq))[0]

def check_bank(a):
    directory=a.bank_dir;path=directory/'sim_r10_iq512_v1.h5'
    bc=readj(directory/'sim_r10_iq512_v1_contract.json');audit=readj(directory/'sim_r10_iq512_audit_v1.json')
    need(bc.get('version')=='SIM_R10_IQ512_GENERATOR_V1' and bc.get('n_pulses')==512,'Wrong frozen IQ bank')
    need(bc['counts']['train']==30000 and bc['counts']['val']==5000,'Require existing full30k/5k TRAIN/VAL')
    need(str(bc.get('status','')).startswith('PASS_SIM_R10_IQ512_BUILDER_V1__') and
         str(audit.get('status','')).startswith('PASS_SIM_R10_IQ512_AUDIT_V1__'),'Bank audit has not passed')
    print('Verifying read-only original TRAIN/VAL IQ bank SHA256',flush=True)
    need(sha(path)==bc['file_sha256']==audit['bank_sha256'],'IQ bank checksum differs')
    g=frozen('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
    need(sha(g.__file__)==bc['generator_sha256'],'Generator differs from TRAIN/VAL contract')
    return dict(path=path,bc=bc,generator=g)

def load_reference(a,context):
    folder=a.b280_run/'A1';cp=folder/'training_contract.json';ck=folder/'best.pt'
    need(cp.is_file() and ck.is_file(),'Missing B280 A1 checkpoint/contract; baseline is never rebuilt automatically')
    ct=readj(cp);cfg=ct['run_config'];state=load(ck)
    need(ct['status']=='PASS_B280_FULL_TRAIN_VAL_ONLY' and cfg['arm']=='A1','Wrong original source arm')
    need(cfg['code_sha256']==readj(ROOT/'expected_source_code.json')['B280'],'Original B280 source release differs')
    need(cfg['factor_A_joint_SPWVD'] and not cfg['factor_B_TFCG_Tail'],'Require TFSE-only A1, no Tail/TFCG')
    need(cfg['bank_sha256']==context['bc']['file_sha256'],'A1 used another TRAIN/VAL bank')
    need((cfg['selected_rows']['train']['count'],cfg['selected_rows']['val']['count'])==(30000,5000),'Require full original source')
    need(sha(ck)==ct['checkpoint_sha256'] and state['run_config']==cfg and
         state['run_fingerprint']==ct['run_fingerprint']==fp(cfg) and state['epoch']==ct['best_epoch'],'A1 checkpoint identity differs')
    pp=a.b280_run/'pd_scr_full/protocol_frozen.json';prp=pp.with_name('progress.json')
    p=readj(pp);pr=readj(prp)
    need(p['version']=='B280_FULL_FACTORIAL_SCORE_V1' and p['labels']==['A0','A1','A2','A3'],'Wrong historical scene source')
    need(p['checkpoints'][1]==ct,'Existing A1 curves are from another checkpoint')
    need(p['fingerprint']==fp({k:v for k,v in p.items() if k!='fingerprint'})==pr['fingerprint'],'Historical protocol fingerprint differs')
    scene={k:p[k] for k in SCENE_KEYS}
    need(p['scene_fingerprint']==fp(scene) and p['scr_grid_db']==list(range(-24,13)),'Historical scene identity/grid differs')
    need(pr['completed']==dict(h0_cal=3000000,h0_audit=1000000,h1=37),'Historical source scores are incomplete')
    need((scene['h0_cal_n'],scene['h0_audit_n'],scene['h1_scenes_n'])==(3000000,1000000,1024),'Unexpected original scene size')
    need(scene['generator_sha']==context['bc']['generator_sha256'] and scene['master_seed']==context['bc']['seed'] and
         tuple(scene['family_names'])==context['generator'].TRAIN_FAMILIES,'Historical generator/seed differs')
    # Reusing old arrays requires the same inference arithmetic, not just the same ancestor.
    for key,expected in [('batch',a.batch),('torch_version',str(torch.__version__)),('device',a.device),('amp',False),('tf32',False)]:
        need(p.get(key)==expected,'Historical inference setting differs: '+key+'; do not silently replace baseline results')
    model=Reference(cfg['scale']);model.load_state_dict(state['state_dict'],strict=True);model.eval().requires_grad_(False)
    need(sum(type(m).__name__=='SimAM' for m in model.detector.modules())==8,'Every native ADN SimAM must remain')
    protected={str(x):sha(x) for x in (cp,ck,pp,prp)}
    return dict(model=model,contract=ct,scene=scene,source_protocol=p,source_protocol_path=pp,
                baseline_val_ce=float(ct['selected_validation']['val_ce']),
                protected=protected,initial_state_sha256=state_sha(model))

def verify_protected(info):
    need(all(sha(path)==value for path,value in info['protected'].items()),'A protected historical file changed')
    need(state_sha(info['model'])==info['initial_state_sha256'],'Frozen TFSE/ADN tensors changed')
    return dict(files_unchanged=True,tensors_unchanged=True,sha256=info['protected'])

def original_score_arrays(info,profile):
    """Only called after candidate training. Read-only exact B280 A1 column."""
    from common import FILES
    pp=info['source_protocol_path'];p=info['source_protocol'];n0,n1,nh=(300000,200000,512) if profile=='medium' else (3000000,1000000,1024)
    arrays={};records={}
    for split,name in FILES.items():
        path=pp.parent/name
        need(path.is_file(),'Original B280 raw A1 scores missing: '+str(path)+'; no baseline recomputation is performed')
        x=np.load(path,mmap_mode='r',allow_pickle=False)
        shape=(37,1024,4) if split=='h1' else ((p[split+'_n'],4))
        need(x.shape==shape and x.dtype==np.float64,'Wrong original raw-score shape/type')
        col=x[:,:nh,1] if split=='h1' else x[:n0 if split=='h0_cal' else n1,1]
        need(np.isfinite(col).all(),'Nonfinite fixed baseline scores')
        arrays[split]=col;records[name]=sha(path)
    return arrays,dict(checkpoint_sha256=info['contract']['checkpoint_sha256'],source=str(pp.parent),column='A1',
        raw_score_sha256=records,read_only=True,new_baseline_training=False,separate_baseline_inference=False,
        matched_medium_prefix=profile=='medium',full_curves_and_thresholds_unmodified=True)
