"""Single-CUT, gain/phase invariant descriptors. No reference cells or SCR input."""
import numpy as np
import torch
from common import need

FEATURE_NAMES = ['amplitude_cv','normalized_fourth_moment','lag1_correlation',
                 'doppler_entropy','doppler_peak_fraction','doppler_flatness',
                 'absolute_doppler_centroid','haar_WAER','haar_detail_WE','log1p_haar_WFR']

@torch.no_grad()
def descriptors(iq):
    need(iq.ndim==2 and iq.shape[1]==512 and iq.dtype==torch.complex64, 'Require complex64 IQ512')
    power = iq.abs().square().mean(1,keepdim=True).clamp_min(1e-20)
    x = iq / power.sqrt(); amp = x.abs(); eps = 1e-10
    cv = amp.std(1,unbiased=False)/amp.mean(1).clamp_min(eps)
    fourth = amp.pow(4).mean(1)
    corr = (x[:,1:]*x[:,:-1].conj()).mean(1).abs()
    spec = torch.fft.fftshift(torch.fft.fft(x,dim=1),dim=1).abs().square()
    prob = spec/(spec.sum(1,keepdim=True)+eps)
    ent = -(prob*prob.clamp_min(eps).log()).sum(1)/np.log(512)
    peak = prob.amax(1)
    flat = torch.exp(spec.clamp_min(eps).log().mean(1))/spec.mean(1).clamp_min(eps)
    frequency = torch.fft.fftshift(torch.fft.fftfreq(512,device=x.device))
    centroid = (prob*frequency.abs()).sum(1)
    # Three-level orthonormal Haar; both quadratures, no magnitude-only substitution.
    a = x; detail = []
    for _ in range(3):
        even,odd = a[:,::2],a[:,1::2]
        d = (even-odd)/np.sqrt(2.); a = (even+odd)/np.sqrt(2.)
        detail.append(d.abs().square().sum(1))
    energy = torch.stack(detail,1); ea = a.abs().square().sum(1)
    waer = ea/(ea+energy.sum(1)+eps)
    ratios = energy/(energy.sum(1,keepdim=True)+eps)
    we = -(ratios*ratios.clamp_min(eps).log()).sum(1)
    wfr = torch.log1p(waer/(we+1e-6))
    value = torch.stack((cv,fourth,corr,ent,peak,flat,centroid,waer,we/np.log(3),wfr),1)
    need(torch.isfinite(value).all(), 'Nonfinite physical descriptors')
    return value

def fit_gini(features, labels):
    """Best binary-split Gini decrease, estimated on TRAIN only (paper Eq.6)."""
    x=np.asarray(features,dtype=np.float64); y=np.asarray(labels,dtype=np.int64)
    need(x.ndim==2 and x.shape[1]==len(FEATURE_NAMES) and y.shape==(len(x),), 'Invalid TRAIN descriptor data')
    need(np.isfinite(x).all() and np.isin(y,[0,1]).all() and 0<y.sum()<len(y), 'Invalid TRAIN labels/features')
    n=len(y); p=y.mean(); parent=2*p*(1-p); gains=[]
    for col in x.T:
        order=np.argsort(col,kind='stable'); v=col[order]; yy=y[order]
        cuts=np.flatnonzero(v[1:]!=v[:-1])+1; cuts=cuts[(cuts>=8)&(cuts<=n-8)]
        if not len(cuts):gains.append(0.);continue
        left=np.cumsum(yy)[cuts-1]; right=y.sum()-left
        pl=left/cuts; pr=right/(n-cuts)
        impurity=cuts/n*(2*pl*(1-pl))+(n-cuts)/n*(2*pr*(1-pr))
        gains.append(max(0.,float(parent-impurity.min())))
    gains=np.asarray(gains); weights=gains/gains.sum() if gains.sum()>1e-12 else np.ones(len(gains))/len(gains)
    std=x.std(0); std=np.maximum(std,1e-5)
    return dict(feature_names=FEATURE_NAMES,mean=x.mean(0).tolist(),std=std.tolist(),
                gini_decrease=gains.tolist(),weights=weights.tolist(),uniform_fallback=bool(gains.sum()<=1e-12),
                fit_split='TRAIN only',count=n)
