"""CPU-only raw-point Pd plots and paired descriptive comparisons."""
import math
from pathlib import Path
import numpy as np
from common import LABELS,ARMS,FILES,NAMES,need,readj,writej,writecsv,fp,sha
from tail_stats import cutoff,wilson,crossing,classification_rates

def paired_bootstrap(grid,baseline,candidate,seed=295296,repeats=500):
    """Shared H1 scene resampling; fixed CAL thresholds, no calibration uncertainty."""
    rng=np.random.default_rng(seed);n=baseline.shape[1];delta=[];pd0=[];at0=list(grid).index(0)
    for _ in range(repeats):
        index=rng.integers(0,n,n);b=baseline[:,index].mean(1);c=candidate[:,index].mean(1)
        d0=crossing(grid,b,.9);d1=crossing(grid,c,.9)
        if d0 is not None and d1 is not None:delta.append(d1-d0)
        pd0.append((c[at0]-b[at0])*100)
    def ci(value):return [float(x) for x in np.percentile(value,[2.5,97.5])] if len(value)>=int(.8*repeats) else None
    return dict(H1_only_fixed_threshold_bootstrap=True,repeats=repeats,
                delta_D90_ci95=ci(delta),valid_D90_repeats=len(delta),pd_at0_gain_pp_ci95=ci(pd0),
                excludes_calibration_uncertainty=True,exploratory_DEV_not_independent_TEST=True)

def load_arrays(folder,p):
    reference=p['reference'];old=Path(reference['source']);arrays={}
    need(sha(old/'protocol_frozen.json')==p['reference_source_protocol_sha256'],'Historical source protocol changed')
    for path,value in p['source_preservation']['sha256'].items():need(sha(path)==value,'Protected source changed: '+path)
    for split,name in FILES.items():
        path=folder/name;new=np.load(path,mmap_mode='r',allow_pickle=False)
        n=p['h1_scenes_n'] if split=='h1' else p[split+'_n']
        shape=(len(p['scr_grid_db']),n,len(ARMS)) if split=='h1' else (n,len(ARMS))
        need(new.shape==shape and new.dtype==np.float64 and np.isfinite(new).all(),'Invalid candidate raw scores')
        oldpath=old/name;need(sha(oldpath)==reference['raw_score_sha256'][name],'Fixed historical raw A1 scores changed')
        hist=np.load(oldpath,mmap_mode='r',allow_pickle=False)
        baseline=hist[:,:n,1] if split=='h1' else hist[:n,1]
        arrays[split]={LABELS[0]:baseline,**{arm:new[...,j] for j,arm in enumerate(ARMS)}}
    return arrays

def generate(folder):
    folder=Path(folder);p=readj(folder/'protocol_frozen.json');pr=readj(folder/'progress.json')
    need(p['fingerprint']==fp({k:v for k,v in p.items() if k!='fingerprint'})==pr['fingerprint'],'Report fingerprint differs')
    need(pr['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=len(p['scr_grid_db'])),'Candidate scoring incomplete')
    arrays=load_arrays(folder,p);grid=p['scr_grid_db'];metrics=[];curves=[];comparisons=[];classification=[]
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    styles={'A1_frozen':dict(color='tab:orange',marker='s'),
            'HGNL_tail':dict(color='tab:green',marker='^'),
            'MDFG_tail':dict(color='black',marker='v')}
    for nominal in p['nominal_pfas']:
        decisions={};selected={}
        for arm in LABELS:
            threshold,k,chits=cutoff(arrays['h0_cal'][arm],nominal)
            hits=int((arrays['h0_audit'][arm]>threshold).sum());n0=p['h0_audit_n'];lo,hi=wilson(hits,n0)
            decision=arrays['h1'][arm]>threshold;pd=decision.mean(1);decisions[arm]=decision
            peak=float(pd.max());m=dict(label=arm,method=NAMES[arm],profile=p['profile'],nominal_pfa=nominal,
                threshold=threshold,cal_tail_support=k,cal_false_alarms=chits,
                audit_false_alarms=hits,audit_n=n0,actual_pfa=hits/n0,actual_pfa_ci95_low=lo,actual_pfa_ci95_high=hi,
                D80_db=crossing(grid,pd,.8),D90_db=crossing(grid,pd,.9),pd_at0=float(pd[grid.index(0)]),
                max_pd=peak,max_pd_scr_db=';'.join(str(s) for s,v in zip(grid,pd) if v==peak),
                selected_epoch=0 if arm=='A1_frozen' else p['training_contracts'][arm]['best_epoch'])
            metrics.append(m);selected[arm]=m
            for scr,count,prob in zip(grid,decision.sum(1),pd):
                l,h=wilson(int(count),p['h1_scenes_n'])
                curves.append(dict(label=arm,method=NAMES[arm],profile=p['profile'],nominal_pfa=nominal,scr_db=scr,
                                   hits=int(count),n_h1=p['h1_scenes_n'],pd=float(prob),pd_ci95_low=l,pd_ci95_high=h))
                classification.append(dict(label=arm,profile=p['profile'],nominal_pfa=nominal,scr_db=scr,
                    **classification_rates(float(prob),hits/n0,.5),
                    note='Declared positive prior .5; rate-derived sample classification, not image localization'))
        base=selected['A1_frozen']
        for arm in ARMS:
            current=selected[arm]
            delta=lambda key:None if current[key] is None or base[key] is None else current[key]-base[key]
            boot=paired_bootstrap(grid,decisions['A1_frozen'],decisions[arm])
            c=dict(label=arm,method=NAMES[arm],profile=p['profile'],nominal_pfa=nominal,
                delta_D80_db=delta('D80_db'),delta_D90_db=delta('D90_db'),
                pd_at0_gain_pp=(current['pd_at0']-base['pd_at0'])*100,
                candidate_actual_pfa=current['actual_pfa'],reference_actual_pfa=base['actual_pfa'],
                delta_D90_ci95_low=None if boot['delta_D90_ci95'] is None else boot['delta_D90_ci95'][0],
                delta_D90_ci95_high=None if boot['delta_D90_ci95'] is None else boot['delta_D90_ci95'][1],
                pd_at0_gain_pp_ci95_low=boot['pd_at0_gain_pp_ci95'][0],pd_at0_gain_pp_ci95_high=boot['pd_at0_gain_pp_ci95'][1],
                scope='Descriptive paired DEV; fixed-threshold H1-only bootstrap; no guaranteed superiority')
            comparisons.append(c)
            print(f'{NAMES[arm]} Pfa={nominal:.0e}: delta_D90={c["delta_D90_db"]}; Pd@0 gain={c["pd_at0_gain_pp"]:+.3f}pp; H0 FP={current["audit_false_alarms"]} vs {base["audit_false_alarms"]}',flush=True)
        fig,ax=plt.subplots(figsize=(8,5))
        for arm in LABELS:
            ax.plot(grid,decisions[arm].mean(1),linestyle='-',linewidth=1.9,markevery=3,
                    markersize=5,markerfacecolor='white',label=NAMES[arm],**styles[arm])
        exponent=int(round(math.log10(nominal)))
        ax.set(xlabel='SCR (dB)',ylabel=r'$P_d$',xlim=(grid[0],grid[-1]),ylim=(0,1.02),
               title=r'Nominal $P_{\mathrm{fa}}=10^{'+str(exponent)+'}$')
        ax.grid(alpha=.25);ax.legend(fontsize=8,loc='upper left');fig.tight_layout()
        for ext in ('pdf','png'):fig.savefig(folder/f'b295_b296_pd_scr_pfa_{nominal:.0e}.{ext}',dpi=250)
        plt.close(fig)
        fig,ax=plt.subplots(figsize=(7,4))
        for j,arm in enumerate(LABELS):
            m=selected[arm];v=m['actual_pfa'];lo=m['actual_pfa_ci95_low'];hi=m['actual_pfa_ci95_high']
            ax.errorbar(j,v,yerr=[[v-lo],[hi-v]],fmt=styles[arm]['marker'],color=styles[arm]['color'],capsize=5)
        ax.axhline(nominal,color='tab:red',linestyle='--',label='Nominal Pfa')
        ax.set_xticks(range(3),['TFSE frozen','Graph tail','Feature-guided tail'])
        ax.set(ylabel='Audit false-alarm rate',title='Independent H0 audit with 95% Wilson intervals')
        ax.grid(axis='y',alpha=.2);ax.legend();fig.tight_layout()
        fig.savefig(folder/f'b295_b296_empty_pfa_ci95_{nominal:.0e}.pdf');plt.close(fig)
    writecsv(folder/'b295_b296_metrics.csv',metrics);writecsv(folder/'b295_b296_curves.csv',curves)
    writecsv(folder/'b295_b296_comparisons.csv',comparisons)
    writecsv(folder/'b295_b296_classification_prior_0p5.csv',classification)
    # Both candidates fully shown. This descriptive choice is not independent final evidence.
    rows=[dict(label=arm,**{k:p['training_contracts'][arm]['selected_validation'][k] for k in ('val_ce','val_pauc01')}) for arm in ARMS]
    val_choice=sorted(rows,key=lambda r:(-r['val_pauc01'],r['val_ce'],r['label']))[0]['label']
    result=dict(status='PASS_B295_B296_TWO_TAIL_EVALUATION',profile=p['profile'],metrics=metrics,comparisons=comparisons,
        checkpoint_selection='TRAIN/VAL only; actual epochs>=1, no epoch0 fallback',val_preferred_arm=val_choice,
        independent_final=False,reference_scores_read_only=True,new_baseline_training=False,
        candidate_raw_score_sha256={k:sha(folder/name) for k,name in FILES.items()},protocol=p,
        future_metrics='Raw scores permit CPU ROC, Precision and F1 at declared class prior; new sea states need inference, not retraining',
        publication_note='Source modules must be cited; these are adaptations, not full-paper reproductions or proof of original invention')
    writej(folder/'b295_b296_report.json',result)
    print('Reports complete: '+str(folder),flush=True);return result
