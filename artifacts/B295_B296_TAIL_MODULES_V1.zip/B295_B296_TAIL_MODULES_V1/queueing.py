"""Wait for existing B293 processes, then acquire the shared radar GPU lock."""
import fcntl
import time
from pathlib import Path
from common import need

def process_identity(pid,proc_root=Path('/proc')):
    try:
        folder=proc_root/str(pid);raw=(folder/'stat').read_text()
        fields=raw.rsplit(')',1)[1].split()
        if fields[0]=='Z':return None
        command=(folder/'cmdline').read_bytes().split(b'\0')
        return dict(pid=int(pid),start_ticks=fields[19],
                    basenames=[Path(t.decode(errors='replace')).name for t in command if t])
    except (OSError,ValueError,IndexError):return None

def b293_dependencies(proc_root=Path('/proc')):
    rows=[]
    for entry in proc_root.iterdir():
        if not entry.name.isdigit():continue
        p=process_identity(int(entry.name),proc_root)
        if p and any(name in ('b293_evaluate.py','run_b293.sh') for name in p['basenames']):
            rows.append({k:p[k] for k in ('pid','start_ticks')})
    return rows

def same_process(item,proc_root=Path('/proc')):
    p=process_identity(item['pid'],proc_root)
    return bool(p and p['start_ticks']==item['start_ticks'])

def wait_b293(wait,interval=30):
    dependencies=b293_dependencies()
    while any(same_process(x) for x in dependencies):
        need(wait,'B293 is still active; use --wait-for-gpu to queue after it')
        active=[x['pid'] for x in dependencies if same_process(x)]
        print('Waiting for B293 to exit; no GPU allocation or process interruption. PIDs='+str(active),flush=True)
        time.sleep(interval)
    return dict(observed_B293_processes=dependencies,waited_for_exit=bool(dependencies),poll_seconds=interval)

def acquire(lock,wait,interval=30):
    while True:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);return
        except BlockingIOError:
            need(wait,'Another radar experiment holds the GPU lock; use --wait-for-gpu')
            print('Waiting for shared radar GPU lock; existing experiment continues.',flush=True)
            time.sleep(interval)
