"""Resumable float32 frozen-tail features; never open CAL/AUDIT/H1 for training."""
import shutil
import time
import h5py
import numpy as np
import torch
import torch.nn.functional as F
from common import need,readj,writej,fp,sha,roc_metrics
from physical_features import fit_gini

SPECS=dict(pooled=((512,4,4),'float32'),z=((512,),'float32'),physical=((10,),'float32'),logits=((2,),'float32'),labels=((),'int64'))

def open_arrays(folder,split,n,create=False):
    out={}
    for name,(tail,dtype) in SPECS.items():
        path=folder/(split+'_'+name+'.npy');shape=(n,)+tail
        if not path.exists():
            need(create,'Missing committed feature cache: '+str(path))
            value=np.lib.format.open_memmap(path,mode='w+',dtype=dtype,shape=shape)
        else:
            value=np.load(path,mmap_mode='r+' if create else 'r',allow_pickle=False)
        need(value.shape==shape and value.dtype==np.dtype(dtype),'Cache shape/type differs: '+name)
        out[name]=value
    return out

def check_arrays(values):
    n=len(values['labels']);need(np.isin(values['labels'],[0,1]).all() and int(values['labels'].sum())==n//2,'Malformed/unbalanced labels')
    for key,v in values.items():need(np.isfinite(v).all(),'Nonfinite cache: '+key)

@torch.inference_mode()
def prepare(a,context,info):
    folder=a.out_dir/'train_val_features';folder.mkdir(exist_ok=True)
    settings=dict(version='B295_B296_FROZEN_FEATURES_V1',source_checkpoint=info['contract']['checkpoint_sha256'],
        bank_sha256=context['bc']['file_sha256'],counts=dict(train=30000,val=5000),pooled_branch_shape=[512,4,4],
        original_gap='full7x7; original classifier unchanged',dtype='float32',batch=a.batch,
        feature_code_sha256=sha(__file__),torch_version=str(torch.__version__),device=a.device)
    identity=fp(settings);progress_path=folder/'progress.json'
    if progress_path.exists():
        progress=readj(progress_path);need(progress['fingerprint']==identity,'Feature cache settings changed')
    else:
        need(not any(folder.iterdir()),'Unknown contents in new feature cache')
        expected=sum(n*(512*16+512+10+2)*4 for n in settings['counts'].values())+35000*8
        need(shutil.disk_usage(folder).free>expected+(512<<20),'Need approximately1.7 GiB free for float32 TRAIN/VAL features; no automatic deletion')
        progress=dict(fingerprint=identity,settings=settings,completed=dict(train=0,val=0));writej(progress_path,progress)
    model=info['model'];model.to(a.device).eval()
    with h5py.File(context['path'],'r') as h:
        for split,n in settings['counts'].items():
            need(h[split+'/iq'].shape==(n,512) and h[split+'/iq'].dtype==np.complex64,'Unexpected frozen IQ geometry')
            done=progress['completed'][split];need(isinstance(done,int) and 0<=done<=n,'Invalid feature prefix')
            for name in SPECS:
                need(done==0 or (folder/(split+'_'+name+'.npy')).is_file(),'Committed feature array missing')
            values=open_arrays(folder,split,n,create=True)
            if done:
                iq=torch.from_numpy(h[split+'/iq'][:min(done,a.batch)]).to(a.device);current=model.extract(iq)
                for name,tensor in zip(('pooled','z','physical','logits'),current):
                    need(np.allclose(values[name][:len(iq)],tensor.cpu().numpy(),rtol=2e-5,atol=5e-5),'Committed feature prefix replay differs')
            began=time.perf_counter()
            for start in range(done,n,a.batch):
                stop=min(start+a.batch,n);iq=torch.from_numpy(h[split+'/iq'][start:stop]).to(a.device)
                result=model.extract(iq)
                for name,tensor in zip(('pooled','z','physical','logits'),result):values[name][start:stop]=tensor.cpu().numpy()
                values['labels'][start:stop]=h[split+'/label'][start:stop]
                for v in values.values():v.flush()
                progress['completed'][split]=stop;writej(progress_path,progress)
                if stop==n or stop%5000<a.batch:print(f'[frozen TRAIN/VAL features] {split} {stop:,}/{n:,}; {time.perf_counter()-began:.1f}s',flush=True)
            check_arrays(values)
    data={split:open_arrays(folder,split,n) for split,n in settings['counts'].items()}
    val=data['val'];ce=0.
    for start in range(0,5000,512):
        z=torch.from_numpy(np.array(val['logits'][start:start+512],copy=True));y=torch.from_numpy(np.array(val['labels'][start:start+512],copy=True))
        ce+=float(F.cross_entropy(z,y,reduction='sum'))
    ce/=5000;need(abs(ce-info['baseline_val_ce'])<=2e-4,'Fixed A1 full VAL replay differs from historical CE')
    # The classifier receives exactly its old 512-D GAP vector, never the pooled token average.
    summary=dict(feature_cache_fingerprint=identity,reference_val_ce=ce,historical_val_ce=info['baseline_val_ce'],
        reference_val_metrics=roc_metrics(val['logits'][:,1]-val['logits'][:,0],val['labels']),
        feature_stats=fit_gini(data['train']['physical'],data['train']['labels']),
        margin_scale=float(np.clip(np.std(data['train']['logits'][:,1]-data['train']['logits'][:,0]),.25,2.)),
        file_sha256={f.name:sha(f) for f in sorted(folder.glob('*.npy'))})
    path=folder/'cache_contract.json'
    if path.exists():need(readj(path)==summary,'Committed feature cache contents changed')
    else:writej(path,summary)
    print(f'A1 frozen full VAL replay passed: CE={ce:.8f}; no A1 training; cache~1.14 GiB',flush=True)
    return dict(values=data,contract=summary,path=folder)

def fetch(values,index,device):
    tensors=[torch.from_numpy(np.array(values[k][index],copy=True)).to(device) for k in ('pooled','z','physical','logits','labels')]
    return tensors[:4],tensors[4]
