"""Only the two new tails are optimized. The old detector never enters an optimizer."""
import time
import numpy as np
import torch
import torch.nn.functional as F
from common import ARMS,TRAIN_PASS,need,readj,writej,writecsv,fp,sha,save,load,snapshot,roc_metrics,code_hashes
from feature_cache import fetch
from tail_models import make_tail,objective
from reference import verify_protected

@torch.inference_mode()
def evaluate(tail,values,device,batch):
    tail.eval();all_scores=[];ce=0.;n=len(values['labels'])
    for start in range(0,n,batch):
        tensors,y=fetch(values,slice(start,min(start+batch,n)),device)
        logits,aux=tail(*tensors);need(torch.isfinite(logits).all(),'Nonfinite trained VAL logits')
        ce+=float(F.cross_entropy(logits,y,reduction='sum'))
        all_scores.append((logits[:,1]-logits[:,0]).cpu().numpy())
    scores=np.concatenate(all_scores)
    return dict(val_ce=ce/n,**roc_metrics(scores,values['labels']))

def configuration(a,info,cache,arm):
    return dict(version='B295_B296_FROZEN_BACKBONE_TRAIN_V1',arm=arm,seed=a.seed,epochs=a.epochs,
        head_batch=a.head_batch,learning_rate=5e-4,weight_decay=1e-4,
        source_checkpoint_sha256=info['contract']['checkpoint_sha256'],
        feature_cache_contract=cache['contract'],train_n=len(cache['values']['train']['labels']),
        val_n=len(cache['values']['val']['labels']),
        code_sha256=code_hashes(),device=a.device,torch_version=str(torch.__version__),
        all_TFSE_ADN_parameters_frozen=True,native_BN_eval=True,baseline_retrained=False,
        selection=f'max VAL pAUC(FPR<=.01), then lower VAL CE; trained epochs1..{a.epochs} only; epoch0 ineligible',
        objective='CE' if arm=='HGNL_tail' else 'CE + .02*(.1*symmetric alignment + .9*standard SupCon); temperature .07',
        graph_node_supervision=False,H0_CAL_AUDIT_H1_used_for_training=False)

def fresh_tail(a,cache,arm):
    torch.manual_seed(a.seed+(101 if arm=='HGNL_tail' else 202))
    return make_tail(arm,cache['contract']['margin_scale'],cache['contract']['feature_stats']).to(a.device)

def preflight(a,info,cache):
    values=cache['values']['train'];y=np.asarray(values['labels'])
    index=np.r_[np.flatnonzero(y==0)[:8],np.flatnonzero(y==1)[:8]]
    inputs,labels=fetch(values,index,a.device);result={}
    for arm in ARMS:
        model=fresh_tail(a,cache,arm);model.train();before=snapshot(model)
        actual,_=model(*inputs);error=float((actual-inputs[-1]).detach().abs().max())
        need(error==0.,'Tail initialization must exactly preserve reference logits')
        optimizer=torch.optim.AdamW(model.parameters(),lr=5e-4,weight_decay=1e-4)
        for _ in range(4):
            optimizer.zero_grad(set_to_none=True);logits,aux=model(*inputs)
            loss,_=objective(arm,logits,aux,labels);need(torch.isfinite(loss),'Nonfinite preflight objective')
            loss.backward();need(all(p.grad is None or torch.isfinite(p.grad).all() for p in model.parameters()),'Nonfinite tail gradients')
            optimizer.step()
        after=snapshot(model) # Both snapshots are CPU even when the model is CUDA.
        updated=[k for k in before if not torch.equal(before[k],after[k])]
        need(any(not k.startswith('output.') for k in updated),'Only output layer moved; borrowed tail representation never updated')
        trained,_=model(*inputs)
        need(float((trained-inputs[-1]).detach().abs().max())>0,'Tail never departed from identity')
        result[arm]=dict(initial_logit_difference=error,canary_steps=4,updated_parameter_names=updated,
                         extra_parameters=sum(p.numel() for p in model.parameters()),
                         frozen_backbone_in_optimizer=False)
        del optimizer,model
        print('Tail initialization/four-step optimizer canary passed: '+arm,flush=True)
    verify_protected(info);return result

def train_one(a,info,cache,arm):
    cfg=configuration(a,info,cache,arm);identity=fp(cfg)
    folder=a.out_dir/arm;folder.mkdir(exist_ok=True)
    contract_path=folder/'training_contract.json';best_path=folder/'best.pt';last_path=folder/'last_epoch.pt'
    if contract_path.exists():
        ct=readj(contract_path)
        need(ct['status']==TRAIN_PASS and ct['run_fingerprint']==identity and sha(best_path)==ct['checkpoint_sha256'],'Completed tail identity/checksum differs')
        need(ct['best_epoch']>0 and not ct['source_fallback'],'Epoch-zero fallback cannot be presented as a new model')
        print(f'{arm}: already trained, selected epoch={ct["best_epoch"]}; reuse unchanged',flush=True);return ct
    manifest=folder/'run_manifest.json'
    if manifest.exists():need(readj(manifest)==cfg,'Training settings changed; use a new output directory')
    else:
        need(not any(folder.iterdir()),'Unidentified candidate output contents');writej(manifest,cfg)
    model=fresh_tail(a,cache,arm);optimizer=torch.optim.AdamW(model.parameters(),lr=5e-4,weight_decay=1e-4)
    scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=a.epochs,eta_min=5e-5)
    history=[];best=None;first=1
    if last_path.exists():
        state=load(last_path);need(state['run_fingerprint']==identity,'Training resume identity differs')
        model.load_state_dict(state['state_dict']);optimizer.load_state_dict(state['optimizer']);scheduler.load_state_dict(state['scheduler'])
        first=state['epoch']+1;history=state['history'];best=state['best']
    else:
        initial=evaluate(model,cache['values']['val'],a.device,a.head_batch)
        need(abs(initial['val_ce']-cache['contract']['reference_val_ce'])<=1e-6,'Identity initial VAL replay differs')
        writej(folder/'initial_reference_metrics.json',dict(epoch=0,eligible_for_selection=False,metrics=initial))
    values=cache['values']['train'];n=len(values['labels'])
    for epoch in range(first,a.epochs+1):
        began=time.perf_counter();model.train();total=np.zeros(4);seen=0
        order=np.random.default_rng(a.seed+epoch*1009).permutation(n)
        for start in range(0,n,a.head_batch):
            index=order[start:start+a.head_batch];inputs,y=fetch(values,index,a.device)
            optimizer.zero_grad(set_to_none=True);logits,aux=model(*inputs);loss,parts=objective(arm,logits,aux,y)
            need(torch.isfinite(loss),'Nonfinite training objective')
            loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5.,error_if_nonfinite=True);optimizer.step()
            total+=len(y)*np.array([float(loss.detach()),parts['ce'],parts['align'],parts['supcon']]);seen+=len(y)
        scheduler.step();metrics=evaluate(model,cache['values']['val'],a.device,a.head_batch)
        candidate=dict(state_dict=snapshot(model),epoch=epoch,run_config=cfg,run_fingerprint=identity,val_metrics=metrics)
        if best is None or (metrics['val_pauc01'],-metrics['val_ce'])>(best['val_metrics']['val_pauc01'],-best['val_metrics']['val_ce']):best=candidate
        row=dict(epoch=epoch,train_objective=float(total[0]/seen),train_ce=float(total[1]/seen),
                 train_align=float(total[2]/seen),train_supcon=float(total[3]/seen),**metrics,
                 best_epoch=best['epoch'],elapsed_s=time.perf_counter()-began)
        history.append(row)
        save(last_path,dict(**candidate,optimizer=optimizer.state_dict(),scheduler=scheduler.state_dict(),history=history,best=best))
        save(best_path,best);writecsv(folder/'train_val_history.csv',history)
        print(f'[{arm}] {epoch}/{a.epochs} VAL_CE={metrics["val_ce"]:.6f} pAUC01={metrics["val_pauc01"]:.6f} best_epoch={best["epoch"]} time={row["elapsed_s"]:.1f}s',flush=True)
    need(best is not None and best['epoch']>0,'Actual trained tail required; no source fallback')
    save(best_path,best) # Repair an interruption after last_epoch commit but before best.pt commit.
    model.load_state_dict(best['state_dict']);replay=evaluate(model,cache['values']['val'],a.device,a.head_batch)
    need(abs(replay['val_ce']-best['val_metrics']['val_ce'])<1e-6,'Selected tail VAL replay differs')
    preserved=verify_protected(info)
    ct=dict(status=TRAIN_PASS,run_config=cfg,run_fingerprint=identity,checkpoint_sha256=sha(best_path),
            best_epoch=best['epoch'],selected_validation=replay,source_fallback=False,
            improves_reference_val_pauc01=replay['val_pauc01']>cache['contract']['reference_val_metrics']['val_pauc01'],
            improves_reference_val_ce=replay['val_ce']<cache['contract']['reference_val_ce'],
            original_TFSE_ADN_preservation=preserved,new_tail_trainable_parameters=sum(p.numel() for p in model.parameters()),
            checkpoint_contains='tail only; load exact read-only B280 A1 checkpoint to construct complete detector')
    writej(contract_path,ct);print(f'{TRAIN_PASS}; {arm}; actual trained epoch={best["epoch"]}; no fallback',flush=True)
    return ct
