"""Two source-attributed tail adaptations; both retain frozen native logits."""
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from common import need

def graph_bands(tokens, k=4):
    """Symmetric kNN graph; complementary first-order graph low/high filters."""
    need(tokens.ndim==3, 'Expected B,N,C graph features')
    b,n,_=tokens.shape
    unit=F.normalize(tokens,dim=-1,eps=1e-8); affinity=(unit@unit.transpose(1,2)).clamp_min(0)
    eye=torch.eye(n,device=tokens.device,dtype=tokens.dtype).unsqueeze(0)
    affinity=affinity*(1-eye)
    ids=affinity.topk(min(k,n-1),dim=-1).indices
    mask=torch.zeros_like(affinity).scatter_(-1,ids,1.)
    adjacency=.5*(affinity*mask+(affinity*mask).transpose(1,2))+eye
    inv=adjacency.sum(-1).clamp_min(1e-8).rsqrt()
    normalized=adjacency*inv[:,:,None]*inv[:,None,:]
    smooth=normalized@tokens
    # (I +/- S)/2 are actual different spectral responses and sum to I.
    return .5*(tokens+smooth),.5*(tokens-smooth),normalized

class BaseTail(nn.Module):
    def __init__(self, margin_scale):
        super().__init__(); self.register_buffer('margin_scale',torch.tensor(float(margin_scale)))

    def correct(self, logits, raw):
        delta=self.margin_scale*.5*torch.tanh(raw.squeeze(-1))
        return logits+torch.stack((-.5*delta,.5*delta),1),delta

class GraphTail(BaseTail):
    """HGNLN Eq.14/18–20 adapted to 16 within-sample deep-feature nodes."""
    def __init__(self, margin_scale):
        super().__init__(margin_scale)
        self.project=nn.Sequential(nn.LayerNorm(512),nn.Linear(512,64),nn.ReLU(),nn.Linear(64,64))
        self.low=nn.Linear(64,64,bias=False); self.high=nn.Linear(64,64,bias=False)
        self.attention=nn.Linear(64,64,bias=False); self.context_weights=nn.Parameter(torch.zeros(16))
        self.pool=nn.Linear(64,1)
        self.output=nn.Sequential(nn.LayerNorm(64),nn.Linear(64,32),nn.GELU(),nn.Linear(32,1))
        nn.init.zeros_(self.output[-1].weight);nn.init.zeros_(self.output[-1].bias)

    def forward(self, pooled,z,physical,logits):
        t=self.project(pooled.flatten(2).transpose(1,2));low,high,_=graph_bands(t)
        low,high=self.low(low),self.high(high)
        context=(t*self.context_weights.softmax(0)[None,:,None]).sum(1)
        score=torch.stack(((self.attention(low)*context[:,None]).sum(-1),
                           (self.attention(high)*context[:,None]).sum(-1)),-1).tanh()
        band=score.softmax(-1); mixed=band[:,:,:1]*low+band[:,:,1:]*high
        node=self.pool(mixed).softmax(1); summary=(mixed*node).sum(1)
        result,delta=self.correct(logits,self.output(summary))
        return result,dict(delta=delta,high_weight=band[:,:,1].mean())

class FeatureGuidedTail(BaseTail):
    """MDFG_SCL Eq.5–12: TRAIN Gini, two-layer projections, alignment, SupCon."""
    def __init__(self, margin_scale, feature_stats):
        super().__init__(margin_scale)
        for name in ('mean','std','weights'):
            self.register_buffer(name,torch.tensor(feature_stats[name],dtype=torch.float32))
        self.deep=nn.Sequential(nn.LayerNorm(512),nn.Linear(512,128),nn.ReLU(),nn.Linear(128,128))
        self.shallow=nn.Sequential(nn.Linear(10,64),nn.LayerNorm(64),nn.ReLU(),nn.Linear(64,128))
        self.output=nn.Sequential(nn.Linear(256,64),nn.GELU(),nn.Linear(64,1))
        nn.init.zeros_(self.output[-1].weight);nn.init.zeros_(self.output[-1].bias)

    def forward(self,pooled,z,physical,logits):
        weighted=((physical-self.mean)/self.std).clamp(-8,8)*self.weights*len(self.weights)
        deep=F.normalize(self.deep(z),dim=1,eps=1e-8)
        shallow=F.normalize(self.shallow(weighted),dim=1,eps=1e-8)
        result,delta=self.correct(logits,self.output(torch.cat((deep,shallow),1)))
        return result,dict(delta=delta,deep=deep,shallow=shallow)

def make_tail(arm, margin_scale, feature_stats):
    if arm=='HGNL_tail':return GraphTail(margin_scale)
    if arm=='MDFG_tail':return FeatureGuidedTail(margin_scale,feature_stats)
    raise ValueError('Unknown independent model: '+arm)

def symmetric_alignment(deep,shallow,temperature=.07):
    sim=shallow@deep.T/temperature
    labels=torch.arange(len(deep),device=deep.device)
    return .5*(F.cross_entropy(sim,labels)+F.cross_entropy(sim.T,labels))

def supervised_contrastive(z, labels, temperature=.07):
    """Stable standard SupCon: denominator all non-self examples; Eq.11 clarified."""
    n=len(z);identity=torch.eye(n,device=z.device,dtype=torch.bool)
    same=(labels[:,None]==labels[None,:])&~identity
    sim=z@z.T/temperature
    den=torch.logsumexp(sim.masked_fill(identity,-torch.inf),dim=1)
    positive_count=same.sum(1);valid=positive_count>0
    if not valid.any():return z.sum()*0
    logprob=sim-den[:,None]
    return -((logprob.masked_fill(~same,0)).sum(1)/positive_count.clamp_min(1))[valid].mean()

def objective(arm,logits,aux,labels):
    ce=F.cross_entropy(logits,labels)
    if arm=='HGNL_tail':return ce,dict(ce=float(ce.detach()),align=0.,supcon=0.)
    align=symmetric_alignment(aux['deep'],aux['shallow'])
    sup=supervised_contrastive(aux['deep'],labels)
    # Keep CE dominant; borrowed 0.1:0.9 matching/contrast ratio, total coefficient .02.
    total=ce+.02*(.1*align+.9*sup)
    return total,dict(ce=float(ce.detach()),align=float(align.detach()),supcon=float(sup.detach()))
