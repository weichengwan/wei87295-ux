"""B271 continued-training control and source-defined LMDA AHPM transplant.

AHPM: Yuan et al., Digital Signal Processing175(2026)105999, Eqs7/11,
DOI10.1016/j.dsp.2026.105999. Independently reconstructed from the paper.
AHPM3 adapts pooling geometry to ADN's original3x3,stride2,padding1.
"""
from __future__ import annotations
import math
import torch
from torch import nn
import torch.nn.functional as F
from b271_model import B271Net


class AHPM(nn.Module):
    def __init__(self, channels=64, kernel_size=3, stride=2, padding=1,
                 initial_average_weight=0.1):
        super().__init__()
        if kernel_size not in (2,3) or stride!=2 or padding!=(1 if kernel_size==3 else 0):
            raise ValueError("Only declared AHPM2/AHPM3 pooling geometries are supported")
        if not 0<initial_average_weight<1:
            raise ValueError("Invalid AHPM initialization")
        self.kernel_size,self.stride,self.padding=kernel_size,stride,padding
        self.gate=nn.Sequential(nn.Linear(channels,max(1,channels//4)),nn.ReLU(),
                                nn.Linear(max(1,channels//4),2))
        nn.init.zeros_(self.gate[-1].weight)
        logit=math.log(initial_average_weight/(1-initial_average_weight))
        with torch.no_grad():self.gate[-1].bias.copy_(torch.tensor([logit,-logit]))
        self.last_weights=None

    def forward(self,x):
        # Two INDEPENDENT Sigmoids, following the paper; no softmax or
        # constraint that their sum remains1 after training.
        weights=torch.sigmoid(self.gate(x.mean((2,3))))
        self.last_weights=weights.detach()
        average=F.avg_pool2d(x,self.kernel_size,self.stride,self.padding,count_include_pad=False)
        maximum=F.max_pool2d(x,self.kernel_size,self.stride,self.padding)
        return weights[:,0,None,None,None]*average+weights[:,1,None,None,None]*maximum


class B272Net(B271Net):
    def __init__(self, arm="control", b271_config=None, initial_average_weight=0.1):
        if arm not in ("control","ahpm3","ahpm2"):
            raise ValueError("Unknown B272 arm")
        config=dict(b271_config or dict(variant="guided",maximum_offset=.75,correction_bound=3.))
        if config.get("variant")!="guided":raise ValueError("Requires the measured guided B271 source")
        super().__init__(**config)
        self.arm=arm
        if arm!="control":
            k=3 if arm=="ahpm3" else 2
            self.detector.maxpool=AHPM(64,k,2,1 if k==3 else 0,initial_average_weight)
        self.model_config=dict(arm=arm,b271_config=config,initial_average_weight=initial_average_weight)
        self.train()

    def initialize_b271(self,state):
        original=state["state_dict"]
        missing=set(self.state_dict())-set(original)
        expected={k for k in self.state_dict() if k.startswith("detector.maxpool.")}
        if missing!=expected or set(original)-set(self.state_dict()):
            raise ValueError("B271 architecture/state keys differ")
        result=self.load_state_dict(original,strict=False)
        if set(result.missing_keys)!=expected or result.unexpected_keys:
            raise ValueError("Unexpected B271 checkpoint transplant result")

    def parameter_groups(self,base_lr,pool_lr,weight_decay=1e-3):
        pool=[p for n,p in self.named_parameters() if p.requires_grad and n.startswith("detector.maxpool.")]
        base=[p for n,p in self.named_parameters() if p.requires_grad and not n.startswith("detector.maxpool.")]
        groups=[dict(params=base,lr=base_lr,weight_decay=weight_decay)]
        if pool:groups.append(dict(params=pool,lr=pool_lr,weight_decay=weight_decay))
        return groups
