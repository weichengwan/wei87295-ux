#!/usr/bin/env python3
"""Medium DEV inference; reuse verified B271/L1 scores, recalibrate all thresholds."""
from __future__ import annotations
import argparse,time
from pathlib import Path
import numpy as np
import torch
from b271_data import device_for,digest_file,fingerprint,load_checkpoint,need,read_json,resolve_data,verify_l1_checkpoint,write_json
from b271_score import SCENE_KEYS,original_protocol
from b272_model import B272Net
from b272_source import verify_source
from b272_train import PASS as TRAIN_PASS,code_hashes
from b272_shared import setup
from source_loader import load_frozen_file,load_frozen_sources

VERSION='B272_B271_AHPM_SCORE_V1'


def cached_baselines(directory,source,context,original,original_path,batch,device):
    directory=Path(directory);p=read_json(directory/'protocol_frozen.json')
    need(p['version']=='B271_PHASE_ARS_SCORE_V1' and p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'}),
         'B271 cached score protocol invalid')
    need(all(p[k]==original[k] for k in SCENE_KEYS) and p['scene_fingerprint']==original['scene_fingerprint'],
         'B271 cache scenes differ from the original B213 scenes')
    need(p['labels']==['guided','L1_TAIL'] and len(p['checkpoints'])==1 and
         p['checkpoints'][0]['sha256']==source['sha256'] and p['original_checkpoint_sha256']==source['original_l1_sha256'],
         'Cached B271/L1 checkpoints differ')
    need(p['bank_sha256']==context['bc']['file_sha256'] and p['b213_protocol_sha256']==digest_file(original_path),
         'B271 score bank lineage differs')
    need(p['code_sha256']==read_json(Path(__file__).parent/'b271_original_sources.json'),
         'B271 score implementation differs from the verified original')
    need(p['batch']==batch and p['device']==device.type and p['tf32'] is False and
         p['score_definition']=='float64(float32 logit1 - float32 logit0)',
         'Cached numeric settings differ: use the original scoring batch (normally32), device and FP32/TF32-disabled mode')
    progress=read_json(directory/'progress.json')
    need(progress['fingerprint']==p['fingerprint'] and progress['completed']==dict(h0_cal=3000000,h0_audit=1000000,h1=37),
         'Original B271 score cache is incomplete; finish/restore it first')
    arrays={};hashes={}
    for split,name,shape in (('h0_cal','h0_cal_scores.npy',(3000000,2)),
                            ('h0_audit','h0_audit_scores.npy',(1000000,2)),
                            ('h1','dev_h1_scores.npy',(37,1024,2))):
        path=directory/name;need(path.is_file(),'Missing reusable score cache: '+str(path))
        x=np.load(path,mmap_mode='r',allow_pickle=False)
        need(x.shape==shape and x.dtype==np.dtype('float64') and np.isfinite(x).all(),'Malformed cached score array: '+name)
        arrays[split]=x;hashes[name]=digest_file(path)
    return arrays,dict(directory=str(directory.resolve()),protocol_sha256=digest_file(directory/'protocol_frozen.json'),
        array_sha256=hashes,labels=['B271_frozen','L1_TAIL'],prefix_reused=True,thresholds_recomputed=True)


@torch.inference_mode()
def predictions(models,source,iq,device,batch):
    need(iq.dtype==np.complex64 and iq.ndim==2 and iq.shape[1]==512,'Expected complex64 IQ512')
    scores=np.empty((len(iq),len(models)),dtype='float64')
    for start in range(0,len(iq),batch):
        stop=min(start+batch,len(iq));x=torch.from_numpy(np.ascontiguousarray(iq[start:stop])).to(device)
        images=source.map_to_adn_input(source.wvd_base_map(x))
        for j,model in enumerate(models):
            z=model(images,x);scores[start:stop,j]=(z[:,1]-z[:,0]).double().cpu().numpy()
    need(np.isfinite(scores).all(),'Nonfinite candidate score');return scores


def stream(a,p,generator,models,source,device,cached):
    original=load_frozen_file('r10_sim_stage_b216_pdscr_score_v1.py');progress=original.init(a,p)
    files={'h0_cal':'h0_cal_scores.npy','h0_audit':'h0_audit_scores.npy','h1':'dev_h1_scores.npy'}
    for split in files:
        total=len(p['scr_grid_db']) if split=='h1' else p[split+'_n'];done=progress['completed'][split]
        need(isinstance(done,int) and 0<=done<=total,'Invalid committed score prefix')
        need(done==0 or (a.out_dir/files[split]).is_file(),'Score array missing despite committed progress: '+files[split])
    columns=len(p['labels'])
    for split in ('h0_cal','h0_audit'):
        total=p[split+'_n'];path=a.out_dir/files[split]
        array=original.new_array(path,(total,columns),path.exists());first=progress['completed'][split]
        started=time.perf_counter()
        for start in range(first,total,a.chunk):
            stop=min(start+a.chunk,total)
            scenes=[generator.make_one(p['master_seed'],p[split+'_split'],i,-30,10) for i in range(start,stop)]
            need(all(s['label']==0 and not np.any(s['target']) for s in scenes),'Unexpected target in H0')
            iq=np.stack([s['base'] for s in scenes]).astype('complex64')
            array[start:stop,:len(models)]=predictions(models,source,iq,device,a.batch)
            array[start:stop,len(models):]=cached[split][start:stop]
            array.flush();progress['completed'][split]=stop;write_json(a.out_dir/'progress.json',progress)
            if stop==total or stop%10000<a.chunk:
                rate=(stop-first)/max(time.perf_counter()-started,1e-6)
                print(f'[{split}] {stop:,}/{total:,}; {rate:.1f}/s; remaining~{(total-stop)/max(rate,1e-6)/60:.1f}min',flush=True)
        del array
    ns=p['h1_scenes_n'];levels=p['scr_grid_db'];path=a.out_dir/files['h1']
    array=original.new_array(path,(len(levels),ns,columns),path.exists())
    scenes=[generator.make_one(p['master_seed'],p['h1_split'],i,-30,10) for i in range(ns)]
    need(all(s['label']==1 for s in scenes),'H1 split must generate targets')
    base=np.stack([s['base'] for s in scenes]).astype('complex64');unit=np.stack([s['unit'] for s in scenes]).astype('complex64')
    power=np.array([s['cp'] for s in scenes],dtype='float64');need(np.isfinite(power).all() and (power>0).all(),'Invalid clutter power')
    for level in range(progress['completed']['h1'],len(levels)):
        scr=levels[level]
        for start in range(0,ns,a.chunk):
            stop=min(start+a.chunk,ns);amplitude=np.sqrt(power[start:stop]*10**(scr/10))
            iq=(base[start:stop].astype('complex128')+unit[start:stop].astype('complex128')*amplitude[:,None]).astype('complex64')
            array[level,start:stop,:len(models)]=predictions(models,source,iq,device,a.batch)
            array[level,start:stop,len(models):]=cached['h1'][level,start:stop]
        array.flush();progress['completed']['h1']=level+1;write_json(a.out_dir/'progress.json',progress)
        print(f'[dev_h1] SCR={scr:+d} dB {level+1}/{len(levels)}',flush=True)
    del array


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    p.add_argument('--run-dir',type=Path);p.add_argument('--out-dir',type=Path);p.add_argument('--b213-dir',type=Path)
    p.add_argument('--batch',type=int,default=32);p.add_argument('--chunk',type=int,default=512)
    p.add_argument('--device',choices=('cuda','cpu'),default='cuda');p.add_argument('--cpu-threads',type=int,default=4)
    p.add_argument('--stage',choices=('all','score','report'),default='all');a=p.parse_args(argv)
    need(a.batch>0 and a.chunk>=a.batch and a.chunk%a.batch==0 and a.cpu_threads>0,'Invalid scoring batches')
    a.root=a.root.resolve();a.run_dir=(a.run_dir or a.root/'output_b272_b271_ahpm_v1').resolve()
    a.out_dir=(a.out_dir or a.run_dir/'pd_scr_medium').resolve();setup(a.cpu_threads)
    if a.stage=='report':
        from b272_report import generate
        generate(a.out_dir);return
    run=read_json(a.run_dir/'run_manifest.json')
    context=resolve_data(a.root,run['bank_dir'],run['cache_dir'])
    l1,l1_sha=verify_l1_checkpoint(run['l1_checkpoint'],context,20261022)
    source=verify_source(run['source_run'],context,l1,l1_sha)
    need(source['sha256']==run['source_b271_sha256'],'Source B271 checkpoint changed')
    path,old,generator=original_protocol(a.root,context,a.b213_dir);device=device_for(a.device)
    cached,cache_info=cached_baselines(source['run_dir']/'pd_scr',source,context,old,path,a.batch,device)
    models=[];identities=[]
    for arm in run['arms']:
        directory=a.run_dir/arm;c=read_json(directory/'training_contract.json');checkpoint=directory/'best.pt'
        need(c['status']==TRAIN_PASS and c['arm']==arm and c['source_b271_sha256']==source['sha256'] and
             digest_file(checkpoint)==c['checkpoint_sha256'],'Incomplete or changed B272 checkpoint')
        state=load_checkpoint(checkpoint)
        need(state['run_fingerprint']==c['run_fingerprint']==fingerprint(state['run_config']) and
             state['epoch']==c['best_epoch'] and state['model_config']==c['model_config'],'Checkpoint internal identity differs')
        need(state['run_config']['code_sha256']==code_hashes(),'B272 implementation changed after training')
        model=B272Net(**state['model_config']);model.load_state_dict(state['state_dict'],strict=True)
        for key,value in l1['state_dict'].items():
            need(torch.equal(model.state_dict()[key].cpu(),value.cpu()),'Frozen original ADN/L1 changed: '+key)
        model.to(device).eval()
        for parameter in model.parameters():parameter.requires_grad_(False)
        models.append(model);identities.append(dict(arm=arm,sha256=c['checkpoint_sha256'],selected_epoch=c['best_epoch'],
            selected_passes_ce_guard=c['selected_passes_ce_guard'],selected_pool_trained=c['selected_pool_trained'],
            validation=c['selected_validation'],trainable_parameters=c['trainable_parameters']))
    scene={k:old[k] for k in SCENE_KEYS};scene.update(h0_cal_n=500000,h0_audit_n=200000)
    protocol=dict(version=VERSION,**scene,scene_fingerprint=fingerprint(scene),budget_profile='medium',
        original_full_scene_fingerprint=old['scene_fingerprint'],nominal_pfas=[1e-4],labels=run['arms']+['B271_frozen','L1_TAIL'],
        checkpoints=identities,training_budget=run['budget'],source_b271_sha256=source['sha256'],
        original_checkpoint_sha256=l1_sha,reused_baselines=cache_info,batch=a.batch,device=device.type,tf32=False,
        score_definition='float64(float32 logit1 - float32 logit0)',code_sha256=code_hashes(),
        strict_decision='score > own H0 CAL threshold',exploratory=True,independent_final=False,
        scope='Prefix of previously exposed DEV scenes; medium screening only; not an independent final test')
    protocol['fingerprint']=fingerprint(protocol)
    print(f"B272 medium: CAL500000 CHECK200000 H1=1024x37; {protocol['labels']}; cached baseline forwards=0",flush=True)
    stream(a,protocol,generator,models,load_frozen_sources()[0],device,cached)
    if a.stage=='all':
        from b272_report import generate
        generate(a.out_dir)
    print('PASS_B272_MEDIUM_DEV_SCORING__STOP_NO_AUTO_FULL',flush=True)


if __name__=='__main__':main()
