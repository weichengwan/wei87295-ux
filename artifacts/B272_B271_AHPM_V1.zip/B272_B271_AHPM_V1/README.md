# B272：B271＋AHPM 中等规模实验

这是实际训练、推理、评分和绘图代码。**没有预置新模型权重，也没有尚未运行就声称的检测增益。**

## 做了什么

- 读取你已经完成的 `output_b271_phase_ars_v1/guided/best.pt`，默认保留该次选中的第8轮实际权重；不从随机模型或旧L1重新开始。
- 两组相同继续训练预算：`control` 保留原最大池化；`ahpm3` 用改成3×3、stride2、padding1的AHPM替换ADN stem的最大池化，仍得到64×56×56特征。
- B271相位引导、两处有界重采样、修正头均保留。只训练原B271新增的13,869参数和AHPM的1,074参数；原ADN/L1权重及BN统计始终冻结。
- AHPM用两路独立Sigmoid，样本级全局描述经64→16→2 MLP产生平均池化与最大池化权重。初始为0.1/0.9；**因此AHPM组初始输出不是严格等于B271**。训练后权重之和不强制为1。未选择训练后权重时，报告会明确标记 `selected_pool_trained=false`。
- 默认两个分支各4轮，TRAIN16,000/VAL3,000，原数据行按标签、背景类型确定性抽样。复用原B271的1280条TRAIN-only负样本池，不再筛20万条，也不创建大型WVD缓存。
- 继续沿用B271的L1-Tail损失、跨批次难负样本排序、同背景目标增强一致性及位移正则。两个分支使用相同数据、顺序及原损失权重；继续训练学习率3e-5，AHPM学习率3e-4。
- 只用VAL pAUC[0,.01]选模型，同时要求CE不超过同一VAL子集上冻结B271的CE+0.03。该代理指标不等于Pfa=1e-4实测Pd。若没有满足CE条件的AHPM检查点，保留最佳CE诊断模型并明确标记，不隐瞒失败。

## 在AutoDL运行

将ZIP上传到 `/root/autodl-tmp/MTDSP_NATIVE_LMDA_V1`，文件名保持 `B272_B271_AHPM_V1.zip`。解压一次即可；没有外层GitHub仓库ZIP嵌套。

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
unzip -n B272_B271_AHPM_V1.zip
nohup /root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  bash B272_B271_AHPM_V1/run_b272_night.sh \
  >> codex_b272_ahpm_medium.log 2>&1 < /dev/null &
tail -f codex_b272_ahpm_medium.log
```

无需conda activate。只启动一次；共享 `codex_b271_night.lock`，避免与已有B271任务同时占GPU。日志窗口Ctrl+C只退出查看。重跑同一命令会校验并续跑已提交的训练epoch和推理前缀，不覆盖原B271结果。

如只运行某一环节：

```bash
/root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 bash B272_B271_AHPM_V1/run_b272_train.sh
/root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 bash B272_B271_AHPM_V1/run_b272_score.sh
```

支持训练参数 `--epochs 4 --batch 32 --train-limit 16000 --val-limit 3000 --source-run /绝对路径 --out-dir /绝对路径`。修改参数应使用新的 `--out-dir`。默认推理batch32与原B271缓存保持一致；更改batch会触发缓存数值口径检查。`ahpm2` 为原文2×2池化的可选几何对照，不会默认启动：另设输出并传 `--arms control,ahpm2`。

## 评分规模与复用

只做 nominal Pfa=**1e-4**，CAL500,000、H0 check200,000、每个SCR1024条H1、-24至12dB共37点；完成后停止，不自动启动全量评分。两个新分支重新推理，冻结B271和L1复用**原完整评分数组的对应前缀**，但四个方法均用本轮500k CAL重新求各自阈值。不是直接搬用原3M阈值。约50个CAL尾部支持样本、20个期望H0 check误警，报告提供Wilson区间。

必须保留：

- 原B271输出目录的 `run_manifest.json`、`guided/{best.pt,training_contract.json}`；
- 原B271的 `train_h0_pool/{pool.h5,contract.json}`；
- 原B271 `pd_scr/{protocol_frozen.json,progress.json,h0_cal_scores.npy,h0_audit_scores.npy,dev_h1_scores.npy}`；
- 原L1权重与训练契约、30k/5k冻结IQ数据、已重建WVD缓存及恢复证据、原B213评分协议和完成状态。

代码从B271记录中定位数据，不扫描一个无关环境来假定是你的服务器。缓存使用前校验场景、模型、原代码SHA、精度、batch、数组形状及文件SHA。**这些DEV场景已用于先前开发，本轮结果仍是开发筛选，不是独立最终测试。**

## 输出

`output_b272_b271_ahpm_v1/` 下：

- `control/`、`ahpm3/`：best.pt、last_epoch.pt、训练历史和所选模型契约。
- `pd_scr_medium/b272_metrics.csv`、`b272_comparisons.csv`、`b272_curves.csv`、`b272_report.json`。
- `pd_scr_medium/figures/b272_pd_scr_pfa_1e-04.{pdf,png}`：四条原始Pd曲线与各自实际误警率。

看 `ahpm3 vs control` 判断AHPM的净收益；看 `ahpm3 vs B271_frozen` 判断完整下一轮收益；负的delta_D90表示左移。模型在VAL选定，DEV不参与训练，也不自动按DEV结果换检查点或增加实验。

## 来源与验证

见 `METHOD_AND_SOURCES.md` 和 `VALIDATION.json`。B271原始六个PY文件逐字保留以核验来源；新的B272入口与其分开。保留旧代码不表示本轮会执行旧的全量流水线。压缩包无数据、权重、密钥或PDF全文。

在有PyTorch环境中可运行CPU功能验证：

```bash
python -m unittest discover -s B272_B271_AHPM_V1/tests -v
```

这些测试验证公式、真实前向/反向、冻结权重、断点恢复、评分和报告正确性，不能证明雷达检测性能提升。实际3080Ti耗时取决于前几个epoch和评分吞吐；本轮规模小于之前全量，但不承诺固定完成时间。
