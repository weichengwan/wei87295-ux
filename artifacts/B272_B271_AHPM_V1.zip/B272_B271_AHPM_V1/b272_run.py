#!/usr/bin/env python3
"""Run medium matched training then scoring, with the shared B271/B272 GPU lock."""
from __future__ import annotations
import fcntl,sys
from datetime import datetime
import b272_train


def main():
    arguments=sys.argv[1:]
    a=b272_train.cli(arguments)
    with (a.root/'codex_b271_night.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise SystemExit('Another B271/B272 task holds codex_b271_night.lock; no job launched')
        print(datetime.now().astimezone().isoformat(),flush=True)
        b272_train.main(arguments)
        from b272_score import main as score
        score(['--root',str(a.root),'--run-dir',str(a.out_dir),'--batch',str(a.batch),
               '--device',a.device,'--cpu-threads',str(a.cpu_threads)])
        print(datetime.now().astimezone().isoformat(),flush=True)


if __name__=='__main__':main()
