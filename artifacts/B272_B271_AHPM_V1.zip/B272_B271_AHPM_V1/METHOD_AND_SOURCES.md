# 研究依据与可检验的改动

## SFM与B271的关系

Chen et al., *Spatial Frequency Modulation for Semantic Segmentation*, IEEE TPAMI47(11),9767–9784,2025. DOI: https://doi.org/10.1109/TPAMI.2025.3592621 。作者仓库 https://github.com/Linwei-Chen/SFM ，检查版本 b08e63ee49a5e5d4e304ada368142a9f5972113a。

核对作者代码 `SFM_mask2former/mmseg_custom/models/backbones/interp2d.py` 的 `SaliencySampler` 可见：官方采样器由高通/PSP显著性、空间softmax、Gaussian加权坐标质心构造采样网格。**B271不是这段官方ARS的移植**：它独立预测受限位移，结合IQ相位证据，使用零初始化的残差重采样和小型分类修正头。应描述为“受到自适应重采样思想启发的领域适配”。未获得可独立读取的出版社SFM全文，不声称完整复现该论文。

## AHPM实际出处

Shanliang Yuan, Hongyuan Gao, Zhiwei Zhang, Yapeng Liu, *Small target detection in sea clutter based on lightweight multi-dimensional adaptive network*, Digital Signal Processing175(2026)105999. DOI: https://doi.org/10.1016/j.dsp.2026.105999 。依据用户上传原文第4.2节、式(11)及式(7)实现，未复制作者代码。

Fp = w_avg(F) * AvgPool(F) + w_max(F) * MaxPool(F)

原文权重经MLP和各自Sigmoid产生；不能随意宣称是softmax归一化权重。B272的具体工程选择是：全局空间均值得到64维描述，64→16→2 MLP输出两个样本级标量权重；原文没有充分指定的隐藏维数、边界平均策略和初始化均明确记录。默认3×3、stride2、padding1保留ADN原池化几何；平均池化不把padding计入均值；初始偏向最大池化(0.1/0.9)，避免突然采用均匀混合。可选2×2、stride2、不padding为接近原文的几何对照。

这些是适配选择，不应把原始AHPM公式或MLP/Sigmoid宣称为新发明。本轮也不是完整LMDA复现，不引入其ADSCM或Ghost骨干。

## 接入理由与适用边界

ADN/L1经过WCSG抑制并得到浅层特征后，B271先做相位引导的有界重采样，随后原最大池化再降采样。重采样调整“在哪取样”，池化决定“怎样汇总局部信息”，因此在相邻位置验证二者互补有明确切入点。海尖峰和目标都可能出现强响应，单纯保留最大值不保证区分二者；平均池化能保留局部响应分布，但也可能稀释弱目标。自适应混合能否改善这一权衡，需要控制实验支持，不能仅凭叙述认定。

B272当前做最小因果实验：B271继续训练对照 vs B271替换一处AHPM，在相同额外训练预算、样本与损失下比较。若只相对原L1改善、却不超过B271继续训练，不能把改善归于AHPM。如果门控在所选检查点仍恒定，不能据此声称学到了样本自适应。

论文可如实表述“借鉴自适应混合池化思想，针对ADN前端和相位引导重采样的几何约束进行结构适配”，再用与ADN、L1、B271及匹配对照的实验支撑完整方法贡献。只换3×3窗口本身通常不足以独立支撑强创新主张；不能保证投稿档次或曲线左移1dB。

## Wang2024与后续优先级

Kaiqi Wang, Zeyu Wang, *A Triple-Channel Network for Maritime Radar Target Detection*, Remote Sensing16(2024),4662, DOI https://doi.org/10.3390/rs16244662 。原文单个时频分支主要为SPWVD+ResNet18；三通道方案还加入相位/相关性分支及借自SENet的SE融合。本轮不引入这些改动，以便先隔离AHPM的贡献。SPWVD应在复数时滞乘积形成过程中平滑，不能把已取绝对值/对数的WVD简单模糊后宣称等价。

引用模块来源并不自动要求完整复现来源论文的全部网络。比较方法应与研究任务、数据协议和论文主张相匹配；若声称优于某个模型，则需要对应公平比较，不能因结果更差而作超出证据的主张。
