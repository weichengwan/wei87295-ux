"""CPU functional verification with synthetic fixtures; these are not detection results."""
from __future__ import annotations
import copy,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import h5py
import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from b271_model import B271Net
from b271_data import digest_file,fingerprint,load_checkpoint,read_json,write_json
from b271_score import SCENE_KEYS,predictions as old_predictions
from b272_model import AHPM,B272Net
from b272_source import verify_source,verify_pool
from b272_shared import Data,setup,tensors,validation
from source_loader import load_frozen_sources,load_frozen_file
import b272_train as train
import b272_score as score
import b272_report as report


def fixture(root):
    source,trainer,reference=load_frozen_sources();b210=load_frozen_file('r10_sim_stage_b210_a3_adn_earlystop_v1.py')
    generator=load_frozen_file('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
    bank=root/'bank';bank.mkdir();cache_dir=root/'cache';cache_dir.mkdir();cache=cache_dir/'maps.h5'
    with h5py.File(bank/b210.H5_NAME,'w') as raw,h5py.File(cache,'w') as maps:
        for split in ('train','val'):
            scenes=[generator.make_one(20261009,split,i,-30,10) for i in range(4)]
            iq=np.stack([s['iq'] for s in scenes]).astype('complex64');labels=np.array([s['label'] for s in scenes],dtype='uint8')
            g=raw.create_group(split);g['iq']=iq;g['target_iq']=np.stack([s['target'] for s in scenes]).astype('complex64');g['label']=labels
            h=maps.create_group(split);h['label']=labels;h['wvd']=source.wvd_base_map(torch.from_numpy(iq)).numpy()
    context=dict(root=root,bank_dir=bank,cache_dir=cache_dir,cache=cache,b210=b210,source=source,device=torch.device('cpu'),
        bc=dict(file_sha256=digest_file(bank/b210.H5_NAME),generator_sha256=digest_file(generator.__file__),seed=20261009),
        cc=dict(wvd_cache_sha256=digest_file(cache)))
    torch.manual_seed(3);original=trainer.ProposedWrapper(source,dict(reference.CFG))
    l1=dict(method='L1_TAIL',seed=20261022,epoch=1,cfg=reference.CFG,state_dict=original.state_dict(),
        source_sha256=b210.SOURCE_SHA,trainer_sha256=b210.TRAINER_SHA)
    l1_path=root/'l1.pt';torch.save(l1,l1_path);l1_sha=digest_file(l1_path)
    m=B271Net();m.load_l1_checkpoint(l1)
    with torch.no_grad():m.correction[-1].bias.fill_(.05)
    data=Data(context,4,4);val=validation(m,data,context,2)
    run_dir=root/'old';run_dir.mkdir();(run_dir/'guided').mkdir();(run_dir/'train_h0_pool').mkdir()
    pool=run_dir/'train_h0_pool/pool.h5'
    with h5py.File(pool,'w') as h:
        with h5py.File(cache,'r') as maps,h5py.File(bank/b210.H5_NAME,'r') as raw:
            h['iq']=raw['train/iq'][::2];h['wvd']=maps['train/wvd'][::2]
    pool_config=dict(split='b271_training_h0_v1',bank_sha=context['bc']['file_sha256'],generator_sha=context['bc']['generator_sha256'],
        baseline_checkpoint_sha=l1_sha,n_proposals=4)
    write_json(pool.with_name('contract.json'),dict(config=pool_config,fingerprint=fingerprint(pool_config),pool_sha256=digest_file(pool),
        original_cal_audit_dev_opened=False,retained=2))
    config=dict(bank_sha=context['bc']['file_sha256'],cache_sha=context['cc']['wvd_cache_sha256'],initialization_sha=l1_sha,
        code_sha=read_json(Path(train.__file__).parent/'b271_original_sources.json'),pool_sha=digest_file(pool),
        hard_weight=.05,consistency_weight=.05,warp_weight=.001)
    state=dict(state_dict=m.state_dict(),model_config=m.model_config,run_config=config,run_fingerprint=fingerprint(config),epoch=8,val_metrics=val)
    ck=run_dir/'guided/best.pt';torch.save(state,ck)
    write_json(ck.with_name('training_contract.json'),dict(status='PASS_B271_FROZEN_L1__TRAIN_VAL_ONLY',variant='guided',
        checkpoint_sha256=digest_file(ck),run_fingerprint=state['run_fingerprint'],best_epoch=8,model_config=m.model_config,initialization_sha256=l1_sha))
    write_json(run_dir/'run_manifest.json',dict(variants=['guided'],initialization_sha256=l1_sha,bank_dir=str(bank),cache_dir=str(cache_dir),proposal_count=4))
    verified=verify_source(run_dir,context,l1,l1_sha);verify_pool(verified,context)
    return context,data,l1,verified,pool,val,generator


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):setup(2)

    def test_ahpm_formula_geometry_and_independent_gates(self):
        torch.manual_seed(8);x=torch.randn(2,64,112,112)
        for k,p in ((2,0),(3,1)):
            pool=AHPM(64,k,2,p)
            actual=pool(x);expected=.1*F.avg_pool2d(x,k,2,p,count_include_pad=False)+.9*F.max_pool2d(x,k,2,p)
            torch.testing.assert_close(actual,expected,atol=1e-6,rtol=1e-6);self.assertEqual(actual.shape,(2,64,56,56))
            with torch.no_grad():pool.gate[-1].bias.fill_(2.)
            pool(x);self.assertGreater(float(pool.last_weights[0].sum()),1.7)
            optimizer=torch.optim.SGD(pool.parameters(),lr=.01)
            for step in range(2):
                optimizer.zero_grad();pool(x).square().mean().backward()
                self.assertGreater(float(pool.gate[-1].weight.grad.abs().sum()),0)
                if step:self.assertGreater(float(pool.gate[0].weight.grad.abs().sum()),0)
                optimizer.step()

    def test_source_transplant_and_frozen_weights(self):
        with tempfile.TemporaryDirectory() as t:
            context,data,l1,source,pool,ref,gen=fixture(Path(t));maps,iq,_=data.fetch('val',[0,1]);images,x=tensors(context,maps,iq)
            old=B271Net(**source['state']['model_config']);old.load_state_dict(source['state']['state_dict']);old.eval()
            with torch.no_grad():expected=old(images,x)
            for arm,count in (('control',13869),('ahpm3',14943)):
                m=B272Net(arm);m.initialize_b271(source['state']);m.eval()
                self.assertEqual(sum(p.numel() for p in m.parameters() if p.requires_grad),count)
                with torch.no_grad():out=m(images,x)
                if arm=='control':torch.testing.assert_close(out,expected,rtol=0,atol=0)
                self.assertTrue(torch.isfinite(out).all())
                m.train();self.assertFalse(m.detector.bn1.training)
                for key,value in l1['state_dict'].items():self.assertTrue(torch.equal(m.state_dict()[key],value))
            data.close()

    def test_source_and_pool_reject_changed_identity(self):
        with tempfile.TemporaryDirectory() as t:
            context,data,l1,source,pool,ref,gen=fixture(Path(t))
            contract=pool.with_name('contract.json');value=read_json(contract);value['config']['split']='dev_h1';write_json(contract,value)
            with self.assertRaises(RuntimeError):verify_pool(source,context)
            wrong=copy.deepcopy(l1);wrong['state_dict']['detector.conv1.weight']=wrong['state_dict']['detector.conv1.weight']+1
            with self.assertRaises(RuntimeError):verify_source(source['run_dir'],context,wrong,source['original_l1_sha256'])
            data.close()

    def test_actual_training_resume_and_unchanged_original_bn(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);context,data,l1,source,pool,ref,gen=fixture(root)
            a=train.cli(['--root',t,'--out-dir',str(root/'new'),'--epochs','2','--batch','2','--train-limit','4','--val-limit','4','--device','cpu','--resume'])
            a.out_dir.mkdir()
            original_save=train.atomic_save;interrupted=[False]
            def stop_after_commit(path,value):
                original_save(path,value)
                if path.name=='last_epoch.pt' and value['epoch']==1 and not interrupted[0]:
                    interrupted[0]=True;raise InterruptedError('simulated process interruption after committed epoch')
            with patch.object(train,'atomic_save',side_effect=stop_after_commit):
                with self.assertRaises(InterruptedError):train.train_one(a,context,data,source,l1,pool,'ahpm3',ref)
            c=train.train_one(a,context,data,source,l1,pool,'ahpm3',ref)
            self.assertEqual(c['epochs_executed'],2);self.assertEqual(c['trainable_parameters'],14943)
            last=load_checkpoint(a.out_dir/'ahpm3/last_epoch.pt');self.assertEqual(len(last['history']),2)
            self.assertGreater(float(last['state_dict']['detector.maxpool.gate.2.weight'].abs().sum()),0)
            for key,value in l1['state_dict'].items():self.assertTrue(torch.equal(last['state_dict'][key],value))
            a.out_dir=root/'uninterrupted';a.out_dir.mkdir()
            train.train_one(a,context,data,source,l1,pool,'ahpm3',ref)
            oracle=load_checkpoint(a.out_dir/'ahpm3/last_epoch.pt')
            for key,value in last['state_dict'].items():self.assertTrue(torch.equal(value,oracle['state_dict'][key]),key)
            train.train_one(a,context,data,source,l1,pool,'control',ref)
            data.close()

    def test_selection_guard_and_medium_defaults(self):
        a=train.cli([]);self.assertEqual((a.train_limit,a.val_limit,a.epochs,a.batch),(16000,3000,4,32))
        self.assertEqual(a.arms,['control','ahpm3'])
        self.assertTrue(train.better(dict(val_ce=.52,pauc01=.3),dict(val_ce=.6,pauc01=.8),.5))
        self.assertFalse(train.better(dict(val_ce=.6,pauc01=.99),dict(val_ce=.52,pauc01=.3),.5))
        self.assertFalse(train.better(dict(val_ce=.52,pauc01=.29),dict(val_ce=.52,pauc01=.3),.5))

    def test_real_stream_cached_baselines_resume_and_missing_array_guard(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);context,data,l1,source,pool,ref,gen=fixture(root)
            models=[]
            for arm in ('control','ahpm3'):
                m=B272Net(arm);m.initialize_b271(source['state']);m.eval();models.append(m)
            old=B271Net();old.load_state_dict(source['state']['state_dict']);old.eval()
            p=dict(version=score.VERSION,master_seed=20261009,h0_cal_n=4,h0_audit_n=4,h1_scenes_n=2,scr_grid_db=[0,3],
                h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',labels=['control','ahpm3','B271_frozen','L1_TAIL'])
            cache={}
            for split in ('h0_cal','h0_audit'):
                iq=np.stack([gen.make_one(p['master_seed'],split,i,-30,10)['base'] for i in range(4)]).astype('complex64')
                cache[split]=old_predictions([old],context['source'],iq,context['device'],2)
            scenes=[gen.make_one(p['master_seed'],'dev_h1',i,-30,10) for i in range(2)]
            base=np.stack([s['base'] for s in scenes]);unit=np.stack([s['unit'] for s in scenes]);power=np.array([s['cp'] for s in scenes])
            cache['h1']=np.stack([old_predictions([old],context['source'],
                (base.astype('complex128')+unit.astype('complex128')*np.sqrt(power*10**(scr/10))[:,None]).astype('complex64'),context['device'],2) for scr in p['scr_grid_db']])
            p['fingerprint']=fingerprint(p);a=SimpleNamespace(out_dir=root/'score',batch=2,chunk=2)
            score.stream(a,p,gen,models,context['source'],context['device'],cache)
            actual=np.load(a.out_dir/'h0_cal_scores.npy');np.testing.assert_array_equal(actual[:,0],cache['h0_cal'][:,0])
            np.testing.assert_array_equal(actual[:,2:],cache['h0_cal'])
            h=np.load(a.out_dir/'dev_h1_scores.npy');np.testing.assert_array_equal(h[:,:,0],cache['h1'][:,:,0])
            progress=read_json(a.out_dir/'progress.json');progress['completed']['h0_cal']=2;write_json(a.out_dir/'progress.json',progress)
            damaged=np.load(a.out_dir/'h0_cal_scores.npy',mmap_mode='r+');damaged[2:]=np.nan;damaged.flush();del damaged
            score.stream(a,p,gen,models,context['source'],context['device'],cache)
            np.testing.assert_array_equal(actual,np.load(a.out_dir/'h0_cal_scores.npy'))
            (a.out_dir/'h0_cal_scores.npy').unlink()
            with self.assertRaisesRegex(RuntimeError,'missing despite committed'):score.stream(a,p,gen,models,context['source'],context['device'],cache)
            data.close()

    def test_cache_identity_numeric_mode_and_file_checks(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);context,data,l1,source,pool,ref,gen=fixture(root)
            folder=source['run_dir']/'pd_scr';folder.mkdir();original_path=root/'original_protocol.json'
            original=dict(master_seed=20261009,generator_sha=context['bc']['generator_sha256'],
                h0_cal_n=3000000,h0_audit_n=1000000,h1_scenes_n=1024,scr_grid_db=list(range(-24,13)),
                h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',family_names=list(gen.TRAIN_FAMILIES),
                scr_definition='fixture')
            original['scene_fingerprint']=fingerprint(original);write_json(original_path,original)
            p=dict(version='B271_PHASE_ARS_SCORE_V1',**original,labels=['guided','L1_TAIL'],
                checkpoints=[dict(sha256=source['sha256'])],original_checkpoint_sha256=source['original_l1_sha256'],
                bank_sha256=context['bc']['file_sha256'],b213_protocol_sha256=digest_file(original_path),
                code_sha256=read_json(Path(train.__file__).parent/'b271_original_sources.json'),
                batch=2,device='cpu',tf32=False,score_definition='float64(float32 logit1 - float32 logit0)')
            p['fingerprint']=fingerprint(p);write_json(folder/'protocol_frozen.json',p)
            write_json(folder/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=3000000,h0_audit=1000000,h1=37)))
            for name,shape in [('h0_cal_scores.npy',(3000000,2)),('h0_audit_scores.npy',(1000000,2)),('dev_h1_scores.npy',(37,1024,2))]:
                x=np.lib.format.open_memmap(folder/name,mode='w+',dtype='float64',shape=shape);x.flush();del x
            train.score_prerequisites(source,2,torch.device('cpu'))
            arrays,info=score.cached_baselines(folder,source,context,original,original_path,2,torch.device('cpu'))
            self.assertTrue(info['thresholds_recomputed']);self.assertEqual(arrays['h1'].shape,(37,1024,2))
            with self.assertRaisesRegex(RuntimeError,'numeric settings differ'):
                score.cached_baselines(folder,source,context,original,original_path,4,torch.device('cpu'))
            (folder/'h0_audit_scores.npy').unlink()
            with self.assertRaisesRegex(RuntimeError,'Required completed B271 score cache missing'):
                train.score_prerequisites(source,2,torch.device('cpu'))
            with self.assertRaisesRegex(RuntimeError,'Missing reusable score cache'):
                score.cached_baselines(folder,source,context,original,original_path,2,torch.device('cpu'))
            data.close()

    def test_night_sequencing_failure_stop_and_shared_lock(self):
        import fcntl
        import b272_run as runner
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);a=train.cli(['--root',t,'--device','cpu']);calls=[]
            with patch.object(sys,'argv',['b272_run.py','--root',t,'--device','cpu']), \
                 patch.object(train,'main',side_effect=lambda args:calls.append('train')), \
                 patch.object(score,'main',side_effect=lambda args:calls.append('score')):
                runner.main();self.assertEqual(calls,['train','score']);calls.clear()
                with patch.object(train,'main',side_effect=RuntimeError('failed training')):
                    with self.assertRaises(RuntimeError):runner.main()
                self.assertEqual(calls,[])
                with (root/'codex_b271_night.lock').open('a') as lock:
                    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
                    with self.assertRaisesRegex(SystemExit,'Another B271/B272'):runner.main()
                self.assertEqual(calls,[])

    def test_medium_report_recalibrates_all_four_columns_and_known_shift(self):
        with tempfile.TemporaryDirectory() as t:
            out=Path(t);n=500000;m=200000;ns=1024;levels=list(range(-24,13));labels=['control','ahpm3','B271_frozen','L1_TAIL']
            # Analytic rank fixture only: AHPM-labeled column has a known2dB shift.
            cal=np.linspace(-6,6,n);audit=np.linspace(-6,6,m);q=(np.arange(ns)+.5)/ns
            distribution=np.log(q/(1-q))
            h=np.stack([6+(scr-distribution)/3 for scr in levels])
            np.save(out/'h0_cal_scores.npy',np.stack([cal]*4,1));np.save(out/'h0_audit_scores.npy',np.stack([audit]*4,1))
            np.save(out/'dev_h1_scores.npy',np.stack([h,h+2/3,h,h],2))
            p=dict(version=score.VERSION,nominal_pfas=[1e-4],h0_cal_n=n,h0_audit_n=m,h1_scenes_n=ns,scr_grid_db=levels,
                labels=labels,checkpoints=[],reused_baselines={},training_budget={},scope='Synthetic functional test; no detection result')
            p['fingerprint']=fingerprint(p);write_json(out/'protocol_frozen.json',p)
            write_json(out/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=n,h0_audit=m,h1=37)))
            r=report.generate(out);self.assertFalse(r['automatic_promotion']);self.assertFalse(r['independent_final'])
            pair=next(x for x in r['comparisons'] if x['candidate']=='ahpm3' and x['reference']=='control')
            self.assertAlmostEqual(pair['delta_D90_db'],-2.,places=10)
            self.assertEqual(len(r['metrics']),4);self.assertTrue((out/'figures/b272_pd_scr_pfa_1e-04.pdf').is_file())
            for row in r['metrics']:self.assertEqual(row['cal_tail_support'],50)


if __name__=='__main__':unittest.main(verbosity=2)
