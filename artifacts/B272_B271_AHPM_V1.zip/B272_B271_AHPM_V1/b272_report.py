"""Raw medium DEV curves; own CAL threshold and independent H0 check per method."""
from __future__ import annotations
import os
from pathlib import Path
import numpy as np
import csv
from b271_data import digest_file,fingerprint,need,read_json,write_json
from source_loader import load_frozen_file

NAMES={'control':'B271 continued (control)','ahpm3':'B271 + AHPM3','ahpm2':'B271 + AHPM2','B271_frozen':'B271 frozen','L1_TAIL':'L1-Tail'}

def save_csv(path,rows):
    if not rows:return
    with Path(path).open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def crossing(x,y,level):
    if y[0]>=level:return float(x[0])
    for i in range(1,len(x)):
        if y[i-1]<level<=y[i]:
            return float(x[i-1]+(level-y[i-1])*(x[i]-x[i-1])/(y[i]-y[i-1]))
    return None

def metrics_for(name,cal,audit,h1,protocol):
    statistics=load_frozen_file("r10_sim_stage_b216_pdscr_report_v1.py")
    need(np.isfinite(cal).all() and np.isfinite(audit).all() and np.isfinite(h1).all(),"Nonfinite scores")
    curves,metrics=[],[]
    for nominal in protocol.get("nominal_pfas",(1e-4,1e-5)):
        threshold,k,cal_fp=statistics.cutoff(cal,nominal)
        false=int((audit>threshold).sum())
        low,high=statistics.wilson(false,len(audit))
        hits=(h1>threshold).sum(1)
        pd=hits/h1.shape[1]
        metric=dict(method=name,nominal_pfa=nominal,actual_pfa=false/len(audit),
                    audit_false_alarms=false,audit_n=len(audit),actual_pfa_ci95_low=low,
                    actual_pfa_ci95_high=high,threshold=threshold,cal_n=len(cal),
                    cal_tail_support=k,cal_exceedances=cal_fp,
                    D50_db=crossing(protocol["scr_grid_db"],pd,.5),
                    D80_db=crossing(protocol["scr_grid_db"],pd,.8),
                    D90_db=crossing(protocol["scr_grid_db"],pd,.9))
        for level in (0,6,9,12):
            metric["pd_at_"+str(level)]=float(pd[protocol["scr_grid_db"].index(level)]) if level in protocol["scr_grid_db"] else None
        metrics.append(metric)
        for scr,n in zip(protocol["scr_grid_db"],hits):
            lo,hi=statistics.wilson(int(n),h1.shape[1])
            curves.append(dict(method=name,nominal_pfa=nominal,scr_db=scr,hits=int(n),
                               n_h1=h1.shape[1],pd=float(n/h1.shape[1]),pd_ci95_low=lo,pd_ci95_high=hi))
    return curves,metrics


def generate(out):
    out=Path(out);p=read_json(out/'protocol_frozen.json');progress=read_json(out/'progress.json')
    need(p['version']=='B272_B271_AHPM_SCORE_V1' and p['nominal_pfas']==[1e-4] and
         fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==p['fingerprint']==progress['fingerprint'],'Protocol changed')
    need(progress['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=len(p['scr_grid_db'])),'Scoring incomplete')
    cols=len(p['labels']);arrays=[]
    for name,shape in (('h0_cal_scores.npy',(p['h0_cal_n'],cols)),('h0_audit_scores.npy',(p['h0_audit_n'],cols)),
                       ('dev_h1_scores.npy',(len(p['scr_grid_db']),p['h1_scenes_n'],cols))):
        x=np.load(out/name,mmap_mode='r',allow_pickle=False)
        need(x.shape==shape and x.dtype==np.dtype('float64'),'Malformed score array');arrays.append(x)
    cal,audit,h1=arrays;curves=[];metrics=[];lookup={}
    for i,label in enumerate(p['labels']):
        c,m=metrics_for(NAMES[label],cal[:,i],audit[:,i],h1[:,:,i],p)
        curves.extend(c);metrics.extend(m);lookup[label]=m[0]
    comparisons=[]
    for candidate in p['labels']:
        if candidate not in ('ahpm3','ahpm2','control'):continue
        for reference in ('control','B271_frozen','L1_TAIL'):
            if reference not in lookup or candidate==reference:continue
            a,b=lookup[candidate],lookup[reference]
            delta=lambda field:a[field]-b[field] if a[field] is not None and b[field] is not None else None
            comparisons.append(dict(candidate=candidate,reference=reference,nominal_pfa=1e-4,
                delta_D50_db=delta('D50_db'),delta_D80_db=delta('D80_db'),delta_D90_db=delta('D90_db'),
                pd_at_0_gain_pp=100*delta('pd_at_0'),candidate_false_alarms=a['audit_false_alarms'],
                reference_false_alarms=b['audit_false_alarms'],audit_n=p['h0_audit_n'],
                candidate_actual_pfa=a['actual_pfa'],reference_actual_pfa=b['actual_pfa'],
                negative_delta_means_left=True,scope='DEV descriptive; statistical significance not established'))
    save_csv(out/'b272_curves.csv',curves);save_csv(out/'b272_metrics.csv',metrics)
    save_csv(out/'b272_comparisons.csv',comparisons)
    report=dict(status='PASS_B272_MEDIUM_DEV_REPORT',metrics=metrics,comparisons=comparisons,checkpoints=p['checkpoints'],
        evaluation=dict(cal=p['h0_cal_n'],audit=p['h0_audit_n'],h1_per_scr=p['h1_scenes_n'],scr=p['scr_grid_db'],nominal_pfas=[1e-4]),
        thresholds_recomputed_from_medium_cal=True,baseline_cache=p['reused_baselines'],training_budget=p['training_budget'],
        scope=p['scope'],independent_final=False,automatic_promotion=False,one_db_gain_established=False,
        uncertainty='50 CAL tail samples and about20 expected H0-check false alarms; show Wilson intervals. Previously exposed DEV scenes are not new independent evidence.',
        attribution='AHPM adapted from Yuan et al., DSP175(2026)105999, Eqs7/11; pool3 geometry preserves ADN stride/padding. B271 resampling is an independent SFM-inspired adaptation, not official ARS.',
        smoothing=False)
    write_json(out/'b272_report.json',report)
    os.environ.setdefault('MPLCONFIGDIR',str(out/'.matplotlib_cache'))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    figures=out/'figures';figures.mkdir(exist_ok=True);fig,ax=plt.subplots(figsize=(9,5.5))
    styles={'control':dict(color='#777777',linestyle='--'),'ahpm3':dict(color='#d62728'),'ahpm2':dict(color='#9467bd'),
            'B271_frozen':dict(color='#1f77b4'),'L1_TAIL':dict(color='#2ca02c',linestyle=':')}
    for label in p['labels']:
        q=[r for r in curves if r['method']==NAMES[label]]
        m=lookup[label]
        ax.plot([r['scr_db'] for r in q],[r['pd'] for r in q],marker='o',markersize=3,markevery=3,
            label=f"{NAMES[label]} (check Pfa={m['actual_pfa']:.2g})",**styles[label])
    ax.set(xlabel='Input SCR (dB)',ylabel='Empirical Pd',xlim=(-24,12),ylim=(0,1.02),
        title='B272 | medium DEV screen | nominal Pfa=1e-4\n500k CAL /200k H0 check /1024 H1 per SCR')
    ax.grid(alpha=.25);ax.legend(fontsize=8);fig.tight_layout()
    for ext in ('pdf','png'):fig.savefig(figures/f'b272_pd_scr_pfa_1e-04.{ext}',dpi=180)
    plt.close(fig)
    for row in comparisons:
        print(f"{row['candidate']} vs {row['reference']}: delta_D90={row['delta_D90_db']}; "
              f"Pd@0 gain={row['pd_at_0_gain_pp']:+.3f}pp; H0 check FP={row['candidate_false_alarms']} vs {row['reference_false_alarms']}",flush=True)
    print('Medium screening complete; stopped. No full-size job has been launched.',flush=True)
    print(f"Report: {out/'b272_report.json'}",flush=True)
    return report
