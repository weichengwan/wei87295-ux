"""Synthetic checkpoints and generated IQ; no claim of real AutoDL performance."""
import copy
import gc
import hashlib
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import h5py
import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from b284_common import ROOT,REFERENCE,LABELS,NAMES,FACTORS,need,read_json,write_json,digest_file,fingerprint,validate_reference,PASS
from b284_model import WVDArm,initial_check
from b284_source import load_references,load_new_models,collect_cache,ScoreCache
from b284_train import evaluate,train_arm,preflight
from b284_score import fill_predictions,compute_chunk,verify_cache,stream
from b284_data import PreparedData
from b283_source import PlainADN
from b282_model import A1Core,Candidate,tensor_hash,optimizer_for
from b282_train import code_hashes as old_hashes,PASS as OLD_PASS
from b282_source import SCENE_KEYS
from b280_frontend import smoothing_bank
from b273_shared import setup
from b274_data import Data
from source_loader import load_frozen_sources,load_frozen_file
import b284_run as runner
import b284_report as reporter
import b284_plots as plots


class TinyData:
    def __init__(self,n=32,nval=16):
        rng=np.random.default_rng(73)
        self.values={};self.selection={};self.tensors={}
        for split,count in [('train',n),('val',nval)]:
            y=np.arange(count)%2
            images=rng.standard_normal((count,3,64,64)).astype('float32')*.1
            images+=y[:,None,None,None].astype('float32')*.6
            guide=rng.uniform(0,1,(count,1,128,128)).astype('float32')
            self.values[split]=(np.zeros((count,512),'complex64'),y)
            self.selection[split]=dict(count=count,original_count=count,fixture=True)
            self.tensors[split]=(torch.from_numpy(images),torch.from_numpy(guide),torch.from_numpy(y))
    def fetch(self,split,index,device,with_guide=False):
        x,c,y=self.tensors[split]
        return x[index].to(device),c[index].to(device) if with_guide else None,y[index].to(device)
    def close(self):pass


def fixture(root,data=None,epochs=1):
    """Real full network tensors; only historical metadata is synthetic."""
    data=data or TinyData()
    generator=load_frozen_file('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
    context=dict(bc=dict(file_sha256='synthetic-bank',generator_sha256=digest_file(generator.__file__),seed=20261009),
        b210=load_frozen_file('r10_sim_stage_b210_a3_adn_earlystop_v1.py'))
    old,new=root/'b280',root/'b282';old.mkdir();new.mkdir()
    torch.manual_seed(12)
    ref=A1Core(2.).eval();a0=PlainADN().eval()
    with torch.no_grad():
        for model in (ref,a0):
            for m in model.modules():
                if isinstance(m,torch.nn.BatchNorm2d):m.running_mean.uniform_(-.1,.1);m.running_var.uniform_(.8,1.2)
    basecode=read_json(REFERENCE/'b282_reference/b280_release_sources.json')
    def save(folder,cfg,model,status,**extra):
        folder.mkdir(parents=True);fp=fingerprint(cfg)
        torch.save(dict(state_dict=copy.deepcopy(model.state_dict()),run_config=cfg,run_fingerprint=fp,epoch=1),folder/'best.pt')
        ct=dict(status=status,run_config=cfg,run_fingerprint=fp,best_epoch=1,checkpoint_sha256=digest_file(folder/'best.pt'),**extra)
        write_json(folder/'training_contract.json',ct);return ct
    common=dict(scale=2.,bank_sha256='synthetic-bank',selected_rows=dict(train=dict(count=30000),val=dict(count=5000)),
        epochs=12,seed=42,batch=32,lr=.001,weight_decay=1e-4,optimizer='Adam',code_sha256=basecode,factor_B_TFCG_Tail=False)
    anchor=evaluate(WVDArm(a0,'ADN'),data,torch.device('cpu'),32)
    c0=save(old/'A0',dict(common,arm='A0',factor_A_joint_SPWVD=False),a0,'PASS_B280_FULL_TRAIN_VAL_ONLY',selected_validation=anchor)
    c1=save(old/'A1',dict(common,arm='A1',factor_A_joint_SPWVD=True),ref,'PASS_B280_FULL_TRAIN_VAL_ONLY',selected_validation=dict(val_ce=.5))
    p=dict(version='B280_FULL_FACTORIAL_SCORE_V1',labels=['A0','A1','A2','A3'],checkpoints=[c0,c1,{},{}],
        master_seed=20261009,generator_sha=context['bc']['generator_sha256'],h0_cal_n=3000000,h0_audit_n=1000000,h1_scenes_n=1024,
        scr_grid_db=list(range(-24,13)),h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',family_names=list(generator.TRAIN_FAMILIES),
        scr_definition='synthetic fixture',device='cpu',batch=32,torch_version=str(torch.__version__),amp=False,tf32=False)
    p['scene_fingerprint']=fingerprint({k:p[k] for k in SCENE_KEYS});p['fingerprint']=fingerprint(p)
    folder=old/'pd_scr_full';folder.mkdir();write_json(folder/'protocol_frozen.json',p)
    write_json(folder/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=3000000,h0_audit=1000000,h1=37)))
    identity=dict(A1_checkpoint_sha256=c1['checkpoint_sha256'],A1_run_fingerprint=c1['run_fingerprint'],source_protocol_sha256=digest_file(folder/'protocol_frozen.json'),source_selected_epoch=1,source_device='cpu',source_torch_version=str(torch.__version__),reused_A1_arrays_sha256={})
    for arm in ('control','guided'):
        torch.manual_seed(42);m=Candidate(ref,arm).eval()
        initial=dict(shared_A1_sha256=tensor_hash(ref.state_dict()),refiner_sha256=tensor_hash(m.refiner.state_dict()) if m.refiner else None)
        if m.refiner:
            with torch.no_grad():m.refiner.project.weight.normal_(0,.001)
        cfg=dict(arm=arm,seed=42,epochs=epochs,batch=32,selected_rows=data.selection,bank_sha256='synthetic-bank',scale=2.,source_identity=identity,
            backbone_lr=1e-5,new_module_lr=3e-4,loss='CE only',weight_decay=1e-4,optimizer='Adam',
            frontend_frozen=True,native_BN_affine_and_running_frozen=True,code_sha256=old_hashes(),device='cpu',torch_version=str(torch.__version__))
        save(new/arm,cfg,m,OLD_PASS,initialization=initial)
    a=SimpleNamespace(root=root,b280_run=old,b282_run=new,b283_run=root/'b283',out_dir=root/'output',device=torch.device('cpu'),batch=32,chunk=32,recompute_scores=False,cache_dir=None)
    a.out_dir.mkdir()
    info=load_references(a,context)
    return a,context,info,data


def all_models(info):
    return dict(ADN=WVDArm(info['base'],'ADN').eval(),CGCR=WVDArm(info['base'],'CGCR').eval(),
        TFSE=info['models']['control'],FULL=info['models']['guided'])


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):setup(2)
    def tearDown(self):gc.collect()

    def test_reference_integrity_and_cli(self):
        validate_reference()
        with tempfile.TemporaryDirectory() as d:
            a=runner.cli(['--root',d,'--device','cpu'])
            self.assertEqual((a.stage,a.eval_size,a.batch),('all','full',32))
            with self.assertRaises(RuntimeError):runner.cli(['--root',d,'--device','cpu','--out-dir',str(Path(d)/'output_b280_full_ablation_v1')])

    def test_strict_source_loading_without_any_score_array_access(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,info,data=fixture(Path(d))
            before={str(p):digest_file(p) for p in Path(d).rglob('*.pt')}
            with patch('numpy.load',side_effect=AssertionError('Evaluation arrays must not be read before training')):
                actual=load_references(a,c)
            self.assertEqual(set(actual['models']),{'ADN','A1_frozen','control','guided'})
            self.assertEqual(before,{str(p):digest_file(p) for p in Path(d).rglob('*.pt')})
            path=a.b282_run/'guided/training_contract.json';ct=read_json(path);ct['checkpoint_sha256']='wrong';write_json(path,ct)
            with self.assertRaisesRegex(RuntimeError,'checksum'):load_references(a,c)

    def test_real_B283_cache_files_and_training_preflight_metadata_only(self):
        from b283_common import own_code_hashes
        from b284_common import FILES
        with tempfile.TemporaryDirectory() as d:
            a,c,info,data=fixture(Path(d));folder=a.b283_run/'pd_scr_full';folder.mkdir(parents=True)
            p=dict(version='B283_FULL_INCREMENTAL_SCORE_V1',labels=['A1_frozen','control','unguided','guided','ADN'],
                **{k:info['p'][k] for k in SCENE_KEYS},source_lineage=info['lineage'],training_contracts=info['contracts'],
                code_sha256=own_code_hashes(),device='cpu',torch_version=str(torch.__version__),batch=32,amp=False,tf32=False)
            p['fingerprint']=fingerprint(p);write_json(folder/'protocol_frozen.json',p)
            write_json(folder/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=3000000,h0_audit=1000000,h1=37)))
            for split,name in FILES.items():
                n=1024 if split=='h1' else p[split+'_n'];shape=(37,n,5) if split=='h1' else (n,5)
                values=np.lib.format.open_memmap(folder/name,mode='w+',dtype='float64',shape=shape)
                values[...,1]=1.25;values[...,3]=3.5;values.flush();del values
            with patch('numpy.load',side_effect=AssertionError('No evaluation arrays before training')):
                self.assertFalse(collect_cache(a,info,metadata_only=True).values)
            cache=collect_cache(a,info);self.assertEqual(len(cache.records),6)
            for split in FILES:
                value,missing=cache.fill(split,0,4,0 if split=='h1' else None)
                np.testing.assert_array_equal(value[:,1],np.full(4,1.25));np.testing.assert_array_equal(value[:,3],np.full(4,3.5))
                self.assertTrue(missing[:,[0,2]].all());self.assertFalse(missing[:,[1,3]].any())
            p['source_lineage']=copy.deepcopy(p['source_lineage']);p['source_lineage']['checkpoints']['guided']='changed'
            p['fingerprint']=fingerprint({k:v for k,v in p.items() if k!='fingerprint'});write_json(folder/'protocol_frozen.json',p)
            write_json(folder/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=3000000,h0_audit=1000000,h1=37)))
            with self.assertRaisesRegex(RuntimeError,'different checkpoints'):collect_cache(a,info)

    def test_initial_identity_real_learning_and_frozen_BN(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,info,data=fixture(Path(d));images,guide,y=data.fetch('train',slice(0,4),a.device,True)
            originals={k:v.clone() for k,v in info['base'].state_dict().items()}
            for arm in ('ADN','CGCR'):
                torch.manual_seed(info['budget']['seed']);m=WVDArm(info['base'],arm)
                check=initial_check(m,info['base'],images,guide)
                self.assertLessEqual(check['maxabs_logit_difference'],1e-6);self.assertEqual(check['original_SimAM_count'],8)
                self.assertFalse(any(type(x).__name__=='JointTFGate' for x in m.modules()))
                if arm=='CGCR':self.assertEqual(check['refiner_sha256'],info['contracts']['guided']['initialization']['refiner_sha256'])
                old_bn={k:v.clone() for k,v in m.state_dict().items() if 'bn' in k}
                optimizer=optimizer_for(m,1e-5,3e-4);m.train()
                before=m.net.detector.fc.weight.detach().clone()
                for _ in range(3):
                    optimizer.zero_grad(set_to_none=True);loss=F.cross_entropy(m.prepared_forward(images,guide),y);loss.backward();optimizer.step()
                self.assertFalse(torch.equal(before,m.net.detector.fc.weight))
                for key,v in old_bn.items():torch.testing.assert_close(v,m.state_dict()[key],atol=0,rtol=0)
                if arm=='CGCR':self.assertGreater(float(m.refiner.project.weight.abs().sum()),0)
            for k,v in originals.items():torch.testing.assert_close(v,info['base'].state_dict()[k],atol=0,rtol=0)

    def test_WVD_images_and_fixed_guide_are_independent_of_learned_TFSE(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);g=load_frozen_file('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py');bank=root/'bank.h5';cache=root/'cache.h5'
            with h5py.File(bank,'w') as h,h5py.File(cache,'w') as w:
                for split,n in [('train',32),('val',16)]:
                    scenes=[g.make_one(20261009,split,i,-30,10) for i in range(n)]
                    iq=np.stack([s['iq'] for s in scenes]);labels=np.array([s['label'] for s in scenes]);families=np.array([s['family'] for s in scenes])
                    h.create_dataset(split+'/iq',data=iq);h.create_dataset(split+'/label',data=labels);h.create_dataset(split+'/family_index',data=families)
                    source,_,_=load_frozen_sources()
                    w.create_dataset(split+'/wvd',data=source.wvd_base_map(torch.from_numpy(iq)).numpy());w.create_dataset(split+'/label',data=labels)
            context=dict(bank_path=bank);raw=Data(context,16,16,42);prepared=PreparedData(raw,context,cache,42,2.)
            try:
                index=np.array([7,1,7,3])
                with patch('b284_data.smoothing_bank',side_effect=AssertionError('ADN control does not need a guide')):
                    image,guide,y=prepared.fetch('train',index,torch.device('cpu'),False)
                self.assertIsNone(guide)
                from b280_frontend import JointTFGate
                with patch.object(JointTFGate,'forward',side_effect=AssertionError('No learned frontend for WVD arms')):
                    actual,c,y2=prepared.fetch('train',index,torch.device('cpu'),True)
                torch.testing.assert_close(image,actual,atol=0,rtol=0)
                iq,expected_y=raw.fetch('train',index,torch.device('cpu'))
                torch.testing.assert_close(c,smoothing_bank(iq,2.)[:,3:4],atol=0,rtol=0)
                torch.testing.assert_close(y,y2);torch.testing.assert_close(y,expected_y)
            finally:prepared.close()

    def test_real_training_commit_skip_and_atomic_resume(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,info,data=fixture(Path(d),TinyData(8,8),epochs=2);a.batch=4
            anchor=evaluate(WVDArm(info['base'],'ADN'),data,a.device,a.batch)
            first=train_arm(a,c,info,data,anchor,'ADN')
            from b271_data import load_checkpoint
            completed=load_checkpoint(a.out_dir/'ADN/last_epoch.pt')
            before=digest_file(a.out_dir/'ADN/best.pt')
            with patch('torch.optim.Adam',side_effect=AssertionError('Completed arm must not retrain')):train_arm(a,c,info,data,anchor,'ADN')
            self.assertEqual(before,digest_file(a.out_dir/'ADN/best.pt'))
            target=a.out_dir;a.out_dir=Path(d)/'interrupted';a.out_dir.mkdir()
            real_evaluate=evaluate;calls=[0]
            def fail_after_one_commit(*args,**kwargs):
                calls[0]+=1
                if calls[0]==3:raise RuntimeError('simulated interruption')
                return real_evaluate(*args,**kwargs)
            with patch('b284_train.evaluate',side_effect=fail_after_one_commit):
                with self.assertRaisesRegex(RuntimeError,'simulated interruption'):train_arm(a,c,info,data,anchor,'ADN')
            self.assertEqual(load_checkpoint(a.out_dir/'ADN/last_epoch.pt')['epoch'],1)
            train_arm(a,c,info,data,anchor,'ADN')
            resumed=load_checkpoint(a.out_dir/'ADN/last_epoch.pt')
            for k,v in completed['state_dict'].items():torch.testing.assert_close(v,resumed['state_dict'][k],atol=0,rtol=0)
            # Actually train the missing CGCR cell; check gradients and metadata.
            a.out_dir=target
            ct=train_arm(a,c,info,data,anchor,'CGCR')
            self.assertEqual(ct['status'],PASS);self.assertFalse(ct['run_config']['TFSE']);self.assertTrue(ct['run_config']['CGCR'])
            self.assertFalse(ct['CAL_AUDIT_DEV_used_for_training'])
            models,contracts=load_new_models(a,info)
            self.assertEqual(set(models),set(LABELS));self.assertEqual(len(contracts),4)

    def test_actual_four_column_predictions_and_selective_reuse(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,info,data=fixture(Path(d));models=all_models(info);score_info=dict(info,models=models)
            iq=__import__('b283_score').make_iq(info['generator'],info['p'],'h0_cal',np.arange(4))
            actual=fill_predictions(models,iq,np.ones((4,4),bool),np.empty((4,4)),a.device,2)
            source,_,_=load_frozen_sources();x=torch.from_numpy(iq)
            with torch.inference_mode():
                wvd=source.map_to_adn_input(source.wvd_base_map(x));bank=smoothing_bank(x,2.)
                for col,label in enumerate(LABELS):
                    z=models[label].prepared_forward(wvd,bank[:,3:4] if label=='CGCR' else None) if label in ('ADN','CGCR') else models[label].prepared_forward(bank)
                    np.testing.assert_allclose(actual[:,col],(z[:,1]-z[:,0]).double().numpy(),atol=2e-6,rtol=1e-5)
            cache=ScoreCache()
            for col,label in enumerate(LABELS):cache.put(label,'h0_cal',actual[:,col],dict(path='fixture'))
            with patch('b284_score.make_iq',side_effect=AssertionError('Fully cached scenes must not regenerate')):
                value,reused,computed=compute_chunk(score_info,info['p'],cache,'h0_cal',0,4,a.device,2)
            np.testing.assert_array_equal(value,actual);self.assertEqual((reused,computed),(16,0))
            cache=ScoreCache()
            for label,col in [('TFSE',1),('FULL',3)]:cache.put(label,'h0_cal',actual[:,col],dict(path='fixture'))
            value,reused,computed=compute_chunk(score_info,info['p'],cache,'h0_cal',0,4,a.device,2)
            np.testing.assert_array_equal(value,actual);self.assertEqual((reused,computed),(8,8))
            verify_cache(score_info,cache,a.device,2)
            cache.values['FULL','h0_cal'][0]+=1
            with self.assertRaisesRegex(RuntimeError,'replay differs'):verify_cache(score_info,cache,a.device,2)

    def test_stream_all_37_levels_and_resume(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,info,data=fixture(Path(d));info=dict(info,models=all_models(info))
            a.out_dir=Path(d)/'scores';a.batch=2;a.chunk=2
            p={k:info['p'][k] for k in SCENE_KEYS};p.update(h0_cal_n=4,h0_audit_n=4,h1_scenes_n=2);p['fingerprint']=fingerprint(p)
            cache=ScoreCache();stream(a,p,info,cache)
            before={p.name:digest_file(p) for p in a.out_dir.glob('*.npy')}
            progress=read_json(a.out_dir/'progress.json');progress['completed'].update(h0_cal=2,h1=35);write_json(a.out_dir/'progress.json',progress)
            stream(a,p,info,cache)
            self.assertEqual(before,{p.name:digest_file(p) for p in a.out_dir.glob('*.npy')})
            (a.out_dir/'h0_audit_scores.npy').unlink()
            with self.assertRaisesRegex(RuntimeError,'missing'):stream(a,p,info,cache)

    def test_main_training_scoring_chain_with_small_generated_IQ(self):
        with tempfile.TemporaryDirectory() as d:
            a,context,info,data=fixture(Path(d),TinyData(32,16),epochs=1)
            old_files={str(p):digest_file(p) for p in Path(d).rglob('*.pt')}
            def tiny_stream(args,protocol,score_info,cache):
                self.assertEqual((protocol['h0_cal_n'],protocol['h0_audit_n'],protocol['h1_scenes_n']),(3000000,1000000,1024))
                self.assertEqual(protocol['nominal_pfas'],[1e-4,1e-5]);self.assertEqual(protocol['labels'],list(LABELS))
                p=dict(protocol,h0_cal_n=2,h0_audit_n=2,h1_scenes_n=2)
                p['fingerprint']=fingerprint({k:v for k,v in p.items() if k!='fingerprint'})
                stream(SimpleNamespace(out_dir=args.out_dir,batch=2,chunk=2,device=args.device),p,score_info,cache)
            with patch('b284_run.resolve',return_value=context),patch('b284_run.prepare',return_value=data),patch('b284_run.stream',side_effect=tiny_stream),patch('b284_report.generate',return_value={'generated':True}) as generate:
                result=runner.main(['--root',d,'--device','cpu','--cpu-threads','2','--b280-run',str(a.b280_run),'--b282-run',str(a.b282_run),'--b283-run',str(a.b283_run),'--out-dir',str(a.out_dir)])
            self.assertTrue(result['generated']);generate.assert_called_once_with(a.out_dir/'pd_scr_full')
            self.assertTrue((a.out_dir/'ADN/best.pt').is_file());self.assertTrue((a.out_dir/'CGCR/best.pt').is_file())
            self.assertFalse((a.out_dir/'TFSE/best.pt').exists());self.assertFalse((a.out_dir/'FULL/best.pt').exists())
            progress=read_json(a.out_dir/'pd_scr_full/progress.json');self.assertEqual(progress['completed'],dict(h0_cal=2,h0_audit=2,h1=37))
            for path,sha in old_files.items():self.assertEqual(digest_file(Path(path)),sha)

    def test_dual_pfa_exact_four_curves_and_styles(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);cal=np.linspace(-6,6,1000000);audit=np.linspace(-6,6,20000);q=(np.arange(512)+.5)/512
            h1=np.stack([6+(scr-np.log(q/(1-q)))/3 for scr in range(-24,13)])
            contracts={label:dict(run_config=dict(selected_rows=dict(train=dict(count=16000)),epochs=6),best_epoch=6,checkpoint_sha256='fixture') for label in LABELS}
            bases={label:dict(run_config=dict(selected_rows=dict(train=dict(count=30000)),epochs=12),best_epoch=3 if label=='ADN' else 9) for label in ('ADN','A1_frozen')}
            p=dict(version='B284_TFSE_CGCR_FACTORIAL_SCORE_V1',labels=list(LABELS),nominal_pfas=[1e-4,1e-5],scr_grid_db=list(range(-24,13)),h0_cal_n=len(cal),h0_audit_n=len(audit),h1_scenes_n=512,training_contracts=contracts,base_contracts=bases)
            p['fingerprint']=fingerprint(p);write_json(root/'protocol_frozen.json',p);write_json(root/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=len(cal),h0_audit=len(audit),h1=37)))
            np.save(root/'h0_cal_scores.npy',np.stack([cal]*4,1));np.save(root/'h0_audit_scores.npy',np.stack([audit]*4,1));np.save(root/'dev_h1_scores.npy',np.stack([h1+j/3 for j in range(4)],2))
            report=reporter.generate(root)
            self.assertTrue(report['strict_2x2_factorial']);self.assertEqual(len(report['metrics']),8);self.assertEqual(len(report['table']),8)
            self.assertEqual({(r['TFSE'],r['CGCR']) for r in report['table']},set(FACTORS.values()))
            for pfa,exponent in [(1e-4,-4),(1e-5,-5)]:
                manifest=read_json(root/f'figures/pfa_{pfa:.0e}/b284_curves_paper_manifest.json')
                self.assertEqual(list(manifest['styles']),list(NAMES.values()));style=manifest['styles'][NAMES['FULL']]
                self.assertEqual((style['color'],style['linestyle'],style['marker'],style['markerfacecolor']),('black','-','v','white'))
                self.assertIn('10^{'+str(exponent)+'}',manifest['pd_title']);self.assertFalse(manifest['smoothing'])
                self.assertTrue((root/f'figures/b284_pd_scr_pfa_{pfa:.0e}.pdf').is_file())
                plotted=plots.read_csv(root/f'figures/pfa_{pfa:.0e}/b284_curves_paper_pd_source.csv')
                self.assertEqual(len(plotted),148)
                self.assertTrue(all(abs(float(r['pd'])-int(r['hits'])/int(r['n_h1']))<1e-12 for r in plotted))

    @unittest.skipUnless(torch.cuda.is_available(),'Local CUDA unavailable; startup executes real AutoDL optimizer canaries')
    def test_CUDA_batch32_four_networks(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,info,data=fixture(Path(d));models=all_models(info)
            for model in models.values():model.to('cuda').eval()
            iq=__import__('b283_score').make_iq(info['generator'],info['p'],'h0_cal',np.arange(32))
            out=fill_predictions(models,iq,np.ones((32,4),bool),np.empty((32,4)),torch.device('cuda'),32)
            self.assertTrue(np.isfinite(out).all())


if __name__=='__main__':unittest.main(verbosity=2)
