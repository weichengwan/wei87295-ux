"""Paper audit / read-only historical replay / optional fresh reconstruction.

Default replay costs only full5000 VAL plus256 H0 from each old split.
It never launches fresh training automatically and never trains the prototype.
"""
import argparse,fcntl,gc
from pathlib import Path
from b271_data import device_for,need,write_json
from b273_shared import setup
from b275_core import architecture_audit


def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--stage',choices=('audit','replay','train','score','fresh-night','core-night'),default='replay')
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    p.add_argument('--out-dir',type=Path);p.add_argument('--bank-dir',type=Path)
    p.add_argument('--reuse-core-control',type=Path,help='Read-only reuse of a completed original B275 continued arm')
    p.add_argument('--device',choices=('cuda','cpu'),default='cuda');p.add_argument('--cpu-threads',type=int,default=4)
    p.add_argument('--batch',type=int,default=32);p.add_argument('--seed',type=int,default=20261022)
    p.add_argument('--steps',type=int,default=5610);p.add_argument('--train-limit',type=int,default=16000);p.add_argument('--val-limit',type=int,default=3000)
    p.add_argument('--epochs',type=int,default=4);p.add_argument('--core-lr',type=float,default=3e-5);p.add_argument('--core-new-lr',type=float,default=3e-4)
    a=p.parse_args(argv);a.root=a.root.resolve();a.out_dir=(a.out_dir or a.root/'output_b275_lmda_replay_core_fix1').resolve()
    need(a.batch==32 and a.steps>0 and a.cpu_threads>0,'Use declared batch32 and positive steps/threads')
    need(2<=a.train_limit<=30000 and 2<=a.val_limit<=5000 and a.train_limit%2==a.val_limit%2==0,'Invalid balanced subset')
    a.device=device_for('cpu' if a.stage=='audit' else a.device)
    return a


def main(argv=None):
    a=cli(argv);setup(a.cpu_threads)
    if a.stage=='audit':
        a.out_dir.mkdir(parents=True,exist_ok=True)
        report=architecture_audit();write_json(a.out_dir/'b275_architecture_audit.json',report)
        print(f'Architecture checked; PF parameters={report["variants"]["lmda_pf"]["parameters"]}; no training/inference on real data',flush=True)
        return report
    with (a.root/'codex_b271_night.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise SystemExit('B271/B272/B273/B274/B275 GPU task already holds the shared lock; no job started')
        if a.stage=='replay':
            from b275_replay import replay
            return replay(a)
        if a.stage=='core-night':
            need(a.epochs>0 and a.core_lr>0 and a.core_new_lr>0,'Invalid ADSCM fine-tuning budget')
            import shutil
            need(shutil.disk_usage(a.root).free>=2*1024**3,'Require2GiB free for independent model/optimizer checkpoints')
            from b275_adscm_experiment import experiment
            return experiment(a)
        if a.stage in ('train','fresh-night'):
            from b274_data import resolve,Data
            from b275_train import train
            context=resolve(a.root,a.bank_dir);data=Data(context,a.train_limit,a.val_limit,a.seed)
            if a.stage=='fresh-night':
                from b271_score import original_protocol
                from b274_baselines import metadata
                from b275_rank_reference import metadata as rank_metadata
                _,original,_=original_protocol(a.root,context)
                metadata(a.root/'output_b273_residual_spwvd_v1/pd_scr_medium',context,original,a.device,data.selection)
                rank_metadata(a.root,original)
                print('Preflight: completed B273 and fixed-rank sources checked; no CAL/AUDIT/H1 arrays opened for training',flush=True)
            result=train(a,context,data);del data;gc.collect()
            if a.device.type=='cuda':
                import torch
                torch.cuda.empty_cache()
            if a.stage=='train':return result
        from b275_score import score
        return score(a)


if __name__=='__main__':main()
