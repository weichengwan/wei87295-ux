"""Verified historical LMDA-PF reconstruction and a channel-matched ADSCM prototype.

This preserves the user's original source, not an author-released implementation.
The prototype is untrained and does not establish detector novelty or Pd gain.
"""
from __future__ import annotations
import importlib.util,sys
from functools import lru_cache
from pathlib import Path
import torch
from torch import nn
from b271_data import digest_file,need

SOURCE_NAME='r10_2025_mtdsp_lmda2026_two_variant_loao_train_v1.py'
SOURCE_SHA='87a11242a7a6befa56f7db3cd12b57829706b13d10288037b1792e9487273c06'
OLD_WEIGHT_SHA='94b0687d8675feec1101cf1158fb926049fc838b0e6d112d456264f9e5de4460'
OLD_WEIGHT='output_sim_r10_b225_real_four_dl_train_v1/LMDA_PF/seed_20261022/sim_r10_final.pt'
METHOD='LMDA-PF reconstruction (fixed5610 SIM)'


@lru_cache(maxsize=1)
def paper_source():
    path=Path(__file__).parent/'paper_source'/SOURCE_NAME
    need(digest_file(path)==SOURCE_SHA,'Historical LMDA source checksum differs')
    spec=importlib.util.spec_from_file_location('b275_verified_lmda_source',path)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    return module


class STFTFrontend:
    def __init__(self):self.adapters={}
    @torch.no_grad()
    def images(self,iq):
        key=str(iq.device)
        if key not in self.adapters:self.adapters[key]=paper_source().TFMAdapter(torch,iq.device)
        return self.adapters[key](iq)
    def components(self,iq):return iq
    def maps(self,iq):return self.images(iq)


class PaperNet(nn.Module):
    def __init__(self):
        super().__init__();source=paper_source()
        self.cfg=dict(source.VARIANTS['lmda_pf'])
        self.frontend=STFTFrontend();self.net=source.build_lmda(torch,self.cfg)
    def forward(self,iq):return self.net(self.frontend.images(iq))
    def prepared_forward(self,images,iq):return self.net(images)


def architecture_audit():
    source=paper_source();result={}
    for name,cfg in source.VARIANTS.items():
        model=source.build_lmda(torch,dict(cfg)).eval();shapes={};handles=[]
        for layer in ('stem1','stem2','pool1','lres1','pool2','lres2','pool3','lres3','avg','fc'):
            handles.append(getattr(model,layer).register_forward_hook(lambda m,x,y,k=layer:shapes.__setitem__(k,list(y.shape[1:]))))
        with torch.inference_mode():output=model(torch.zeros(1,3,128,128))
        for h in handles:h.remove()
        count=sum(p.numel() for p in model.parameters())
        result[name]=dict(config=dict(cfg),parameters=count,fp32_parameter_bytes=4*count,
            fp32_parameter_MiB=4*count/1024**2,shapes=shapes,output_shape=list(output.shape),
            original_author_implementation=False)
    return dict(source_sha256=SOURCE_SHA,variants=result,paper_doi='10.1016/j.dsp.2026.105999',
        scope='Architecture reconstruction audit only; not an IPIX accuracy reproduction',
        unresolved=['Discrete STFT/window/colormap not fully specified in paper','Reduction ratio and normalization conventions are engineering choices',
                    'Historical PF uses r=1 with no reduction and depthwise-separable branches; figure4 labels DWConv and c*(r-1)/r',
                    'Published0.65MB is not asserted equal to raw float32 parameter bytes; parameter/FLOP conventions not identical'])


@lru_cache(maxsize=1)
def adscm_class():return type(PaperNet().net.lres1.adscm)


class ChannelMatchedADSCM(nn.Module):
    """1x1 geometry bridge -> original PF ADSCM, adjusted to preserve ADN width.

Original ADSCM maps c->2c. Set c=cout/2, so the external output is cout.
At downsampling blocks the bridge has the original stride. This is an
explicit new geometry, not a claim of a weight-compatible transplant.
"""
    def __init__(self,cin,cout,stride=1,kaxis=9,adaptive=True,cbam=True):
        super().__init__();need(cout%2==0,'Even ADN output width required')
        c=cout//2
        self.bridge=nn.Sequential(nn.Conv2d(cin,c,1,stride,bias=False),nn.BatchNorm2d(c),nn.ReLU())
        self.core=adscm_class()(c,kaxis)
        if not cbam:self.core.cbam=nn.Identity()
        if not adaptive:
            for m in (self.core.w1,self.core.w2):
                nn.init.zeros_(m.weight);nn.init.zeros_(m.bias)
                for p in m.parameters():p.requires_grad_(False)
        self.spec=dict(cin=cin,cout=cout,stride=stride,kaxis=kaxis,adaptive=adaptive,cbam=cbam,
            source='original PF ADSCM; width/stride adapted; new weights')
    def forward(self,x):return self.core(self.bridge(x))


class ReplaceACBBlock(nn.Module):
    """Replace first ACB only; reuse old second conv, TFCG, BN and shortcut."""
    def __init__(self,old,adaptive=True,cbam=True):
        super().__init__()
        self.adscm=ChannelMatchedADSCM(old.conv3.in_channels,old.conv3.out_channels,
            old.conv3.stride[0],9,adaptive,cbam)
        self.conv2=old.conv2;self.simam=old.simam;self.bn2=old.bn2
        self.downsample=old.downsample;self.relu=old.relu
    def forward(self,x):
        identity=x if self.downsample is None else self.downsample(x)
        z=self.bn2(self.simam(self.conv2(self.adscm(x))))
        return self.relu(z+identity)


def replace_stage2(l1_wrapper,adaptive=True,cbam=True):
    detector=l1_wrapper.detector
    need(len(detector.layer2)==2 and hasattr(l1_wrapper,'suppressor'),'Expected full original L1-Tail')
    for i in range(2):
        old=detector.layer2[i];reference=old.conv3.weight
        # Replacement happens after the wrapper may already be on CUDA.
        # New modules otherwise default to CPU/float32, unlike reused layers.
        block=ReplaceACBBlock(old,adaptive,cbam).to(device=reference.device,dtype=reference.dtype)
        block.train(old.training)
        detector.layer2[i]=block
    return l1_wrapper
