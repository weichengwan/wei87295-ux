"""L1-Tail continued vs Stage2 first-ACB replaced by verified PF ADSCM.

Full CNN/BN fine tuning, identical original L1-Tail objective and data/budget.
The replacement is randomly initialized and is not identity preserving.
"""
import gc
from pathlib import Path
from types import SimpleNamespace
import torch
from b271_data import digest_file,fingerprint,load_checkpoint,need,read_json,write_json
from b271_score import original_protocol,SCENE_KEYS
from b274_data import resolve,Data
from b275_core import replace_stage2,SOURCE_SHA
from b275_rank_reference import metadata as rank_metadata,arrays as rank_arrays
from b276_source import metadata as b274_metadata,arrays as b274_arrays
from b276_train import train_arm,code_hashes,configuration
from b276_score import stream
from b276_report import generate
from source_loader import load_frozen_sources

L1_WEIGHT='output_sim_r10_b215_tpht_train_v1/trainseed_20261022/L1_TAIL/best_val_ce.pt'
L1_SHA='bd0cd4ff06534d723d2329918e5931ccffa9000b691e115b88048ad16394911e'
PASS='PASS_B275_L1_ADSCM_STAGE2_TRAIN_VAL_ONLY'
NAMES={'continued':'L1-Tail continued (ADSCM control)','adscm':'L1-Tail + Stage2 ADSCM replacement'}


class WVDFrontend:
    def __init__(self):
        self.source=load_frozen_sources()[0]
        self.backend={'sha256':digest_file(self.source.__file__)};self.scale=1.
    def components(self,iq):return iq
    @torch.no_grad()
    def maps(self,iq):
        return torch.cat([self.source.map_to_adn_input(self.source.wvd_base_map(iq[start:start+8])) for start in range(0,len(iq),8)])
    images=maps


class CoreNet(torch.nn.Module):
    def __init__(self,arm='continued'):
        super().__init__();s,t,r=load_frozen_sources();self.architecture=t.ProposedWrapper(s,dict(r.CFG));self.frontend=WVDFrontend()
        self.arm=arm
    def prepared_forward(self,images,iq,return_aux=False):return self.architecture(images,return_aux=return_aux)
    def forward(self,iq,return_aux=False):return self.prepared_forward(self.frontend.images(iq),iq,return_aux)


def source_info(a,context):
    path=a.root/L1_WEIGHT;need(digest_file(path)==L1_SHA,'Original L1 checkpoint missing/changed')
    c=read_json(path.with_name('training_contract.json'));s,t,r=load_frozen_sources()
    need(c['best_checkpoint_sha256']==L1_SHA and c['method']=='L1_TAIL' and c['params_loss']==r.PARAMS and
         c['bank_sha256']==context['bc']['file_sha256'] and c['source_sha256']==context['b210'].SOURCE_SHA and
         c['trainer_sha256']==context['b210'].TRAINER_SHA and c['status']==r.PASS,'Original L1 lineage differs')
    return dict(checkpoint=path,contract={'checkpoint_sha256':L1_SHA},run_dir=path.parent,
                config={'backend':{'sha256':digest_file(s.__file__)},'scale':1.})


def teacher(info,device):
    model=CoreNet();state=load_checkpoint(info['checkpoint']);_,t,r=load_frozen_sources()
    need(state['method']=='L1_TAIL' and state['cfg']==r.CFG and state['source_sha256']==t.EXPECTED_SOURCE_SHA,'L1 checkpoint metadata differs')
    model.architecture.load_state_dict(state['state_dict'],strict=True)
    return model.to(device).eval()


def initialize(model,source,arm):
    model.architecture.load_state_dict(source.architecture.state_dict(),strict=True)
    if arm=='adscm':replace_stage2(model.architecture)
    # Unchanged named tensors get the low fine-tuning LR; replacement weights
    # get the declared new-parameter LR. No unrelated frozen layers remain.
    old=dict(source.named_parameters())
    return {n for n,p in model.named_parameters() if n in old and p.shape==old[n].shape}


@torch.inference_mode()
def initial_check(model,source,iq):
    model.eval();source.eval();images=source.frontend.images(iq)
    delta=float((model.prepared_forward(images,iq)-source.prepared_forward(images,iq)).abs().max())
    if model.arm=='continued':need(delta<1e-6,'Unchanged L1 control does not replay')
    return dict(maxabs_logit_difference=delta,train_probe_n=len(iq),
        initial_function_preserved_within_tolerance=model.arm=='continued',
        ADSCM_randomly_initialized=model.arm=='adscm',pretrained_remaining_layers_loaded=True)


def objective(model,x,y):
    z,aux=model(x,return_aux=True)
    loss,ce,_,_=load_frozen_sources()[2].compute_loss('L1_TAIL',z,y,aux)
    return z,ce,loss


def diagnostics(model,probe):
    if model.arm=='continued':return {'replacement_present':False}
    blocks=model.architecture.detector.layer2
    return dict(replacement_present=True,replaced_first_ACB_count=2,stage=2,
        adaptive_MLP_weight_norm=[float(b.adscm.core.w2.weight.detach().norm()) for b in blocks],
        lmda_source_sha256=SOURCE_SHA)


def reuse_control(directory,a,context,data,info,hooks):
    """Verify immutable V1 control; never relabel its old hashes as new code."""
    directory=Path(directory).resolve()
    need(directory!=a.out_dir.resolve() and directory not in a.out_dir.resolve().parents,
         'Use a separate FIX1 output directory, outside the old control')
    contract_path=directory/'training_contract.json';path=directory/'best.pt'
    c=read_json(contract_path);manifest=read_json(directory/'run_manifest.json');cfg=c['run_config']
    old_hashes=read_json(Path(__file__).parent/'b275_release_sources_v1.json')
    need(cfg['code_sha256']==old_hashes,'Only the exact original B275 V1 control may be reused')
    expected=configuration(a,context,data,info,'continued',hooks);expected['code_sha256']=old_hashes
    need(cfg==expected and c['status']==PASS and c['arm']=='continued' and c['epochs_executed']==a.epochs,
         'Old control settings/data/budget differ from this repair run')
    fp=fingerprint(cfg)
    need(c['run_fingerprint']==fp and manifest==dict(run_config=cfg,run_fingerprint=fp,bank_dir=str(context['bank_dir'])),
         'Old control manifest/contract differ')
    need(path.is_file() and digest_file(path)==c['checkpoint_sha256'],'Old completed control checkpoint changed')
    state=load_checkpoint(path)
    need(state['run_config']==cfg and state['run_fingerprint']==fp and state['epoch']==c['best_epoch'],
         'Old selected control checkpoint internal identity differs')
    need(set(state['val_metrics'])==set(c['selected_validation']) and
         all(abs(float(state['val_metrics'][k])-float(c['selected_validation'][k]))<=1e-6 for k in state['val_metrics']),
         'Old selected control validation differs')
    result=dict(directory=str(directory),checkpoint_sha256=c['checkpoint_sha256'],
        contract_sha256=digest_file(contract_path),selected_epoch=c['best_epoch'],
        old_run_fingerprint=fp,old_code_sha256=old_hashes,
        new_code_sha256=code_hashes(),old_files_modified=False,control_retraining_performed=False,
        reason='FIX1 changes replacement device/dtype inheritance; continued has no replacement')
    a.out_dir.mkdir(parents=True,exist_ok=True);record=a.out_dir/'reused_control.json'
    if record.exists():need(read_json(record)==result,'Reused control identity changed')
    else:write_json(record,result)
    print(f'Reusing completed B275 continued control; selected epoch={c["best_epoch"]}; no control training',flush=True)
    return result


def experiment(a):
    context=resolve(a.root,a.bank_dir);data=Data(context,a.train_limit,a.val_limit,a.seed)
    _,old,generator=original_protocol(a.root,context)
    cache_info=b274_metadata(a.root/'output_b274_single_spwvd_resnet18_v1',context,a.device,data.selection,old)
    rank_info=rank_metadata(a.root,old);info=source_info(a,context)
    a.lr=a.core_lr;a.new_lr=a.core_new_lr
    hooks=dict(status=PASS,version='B275_ADSCM_STAGE2_TRAIN_V1',loss_name='original B215 L1_TAIL CE+0.05 tail ranking',
        old_l1_weights=True,teacher=teacher,factory=lambda arm,backend,scale:CoreNet(arm),migrate=initialize,
        verify_initial=initial_check,objective=objective,diagnostics=diagnostics)
    print('B275 Stage2 ACB replacement; full CNN/BN trainable; WCSG/TFCG and original L1-Tail objective retained',flush=True)
    print('TRAIN/VAL only; baseline metadata checked, no CAL/AUDIT/H1 score arrays used for training',flush=True)
    reused=None
    if getattr(a,'reuse_core_control',None):
        reused=reuse_control(a.reuse_core_control,a,context,data,info,hooks)
    else:train_arm(a,context,data,info,'continued',hooks)
    train_arm(a,context,data,info,'adscm',hooks)
    selection=data.selection;del data;gc.collect()
    if a.device.type=='cuda':torch.cuda.empty_cache()
    cached,reuse=b274_arrays(cache_info);cached,rank=rank_arrays(rank_info,cached)
    models=[];identities=[]
    for arm in ('continued','adscm'):
        folder=Path(reused['directory']) if arm=='continued' and reused else a.out_dir/arm
        c=read_json(folder/'training_contract.json');cfg=c['run_config'];path=folder/'best.pt'
        expected_hashes=reused['old_code_sha256'] if arm=='continued' and reused else code_hashes()
        need(c['status']==PASS and cfg['code_sha256']==expected_hashes and c['run_fingerprint']==fingerprint(cfg) and
             digest_file(path)==c['checkpoint_sha256'] and cfg['initialization_sha256']==L1_SHA and cfg['selected_rows']==selection,'ADSCM checkpoint identity differs')
        state=load_checkpoint(path);need(state['run_config']==cfg and state['run_fingerprint']==c['run_fingerprint'] and state['epoch']==c['best_epoch'],'ADSCM checkpoint internal identity differs')
        m=CoreNet(arm)
        if arm=='adscm':replace_stage2(m.architecture)
        m.load_state_dict(state['state_dict'],strict=True);m.to(a.device).eval();models.append(m)
        identities.append(dict(arm=arm,sha256=c['checkpoint_sha256'],selected_epoch=c['best_epoch'],validation=c['selected_validation'],initialization=c['initialization'],module_diagnostics=c['module_diagnostics'],trainable_parameters=c['trainable_parameters'],
            read_only_reused_from=str(folder) if arm=='continued' and reused else None))
    scene={k:old[k] for k in SCENE_KEYS};scene.update(h0_cal_n=500000,h0_audit_n=200000)
    labels=['BASE_'+v for v in cache_info['p']['labels']]+['BASE_OLD_LMDA','BASE_RANKMIX75']
    names={'BASE_'+v:n for v,n in cache_info['p']['names'].items()}
    names.update(BASE_OLD_LMDA='Frozen LMDA-PF',BASE_RANKMIX75='Fixed rank mix LMDA75/L125 (medium CAL)')
    p=dict(version='B275_ADSCM_STAGE2_SCORE_V1',**scene,scene_fingerprint=fingerprint(scene),nominal_pfas=[1e-4],
        labels=['continued','adscm']+labels,names={**NAMES,**names},candidate_labels=['continued','adscm'],ours_label='adscm',checkpoints=identities,
        reused_baselines={'B274':reuse,'fixed_rankmix':rank},batch=32,device=a.device.type,tf32=False,code_sha256=code_hashes(),
        recovery_control=reused,
        score_definition='float64(float32 logit1 - float32 logit0)',strict_decision='score > own H0 CAL threshold',
        scope='Paired exposed medium DEV; Stage2 random replacement, full fine tuning; no claim of independent FINAL or established novelty')
    p['fingerprint']=fingerprint(p);args=SimpleNamespace(out_dir=a.out_dir/'core_pd_scr_medium',batch=32,chunk=512)
    stream(args,p,generator,models,None,a.device,cached);return generate(args.out_dir)
