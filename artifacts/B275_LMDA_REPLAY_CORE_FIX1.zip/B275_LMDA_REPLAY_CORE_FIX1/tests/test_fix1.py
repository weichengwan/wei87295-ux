"""Regressions for post-.to() replacement and immutable V1-control recovery."""
import gc,json,os,subprocess,sys,tempfile,unittest,zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from b271_data import digest_file,read_json
from b273_shared import setup
from b274_data import Data
from b275_core import replace_stage2
from source_loader import load_frozen_sources,load_frozen_file
import b275_adscm_experiment as core
import b276_train as trainer


def hooks():
    return dict(status=core.PASS,version='B275_ADSCM_STAGE2_TRAIN_V1',loss_name='original B215 L1_TAIL CE+0.05 tail ranking',
        old_l1_weights=True,teacher=core.teacher,factory=lambda arm,b,s:core.CoreNet(arm),migrate=core.initialize,
        verify_initial=core.initial_check,objective=core.objective,diagnostics=core.diagnostics)


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):setup(2)

    def test_replacement_after_double_preserves_dtype_mode_and_gradients(self):
        model=core.CoreNet('adscm').double().eval()
        original_second=model.architecture.detector.layer2[0].conv2
        replace_stage2(model.architecture)
        self.assertIs(model.architecture.detector.layer2[0].conv2,original_second)
        self.assertTrue(all(p.dtype==torch.float64 for p in model.parameters()))
        self.assertFalse(model.architecture.detector.layer2[0].training)
        y=model.architecture(torch.randn(2,3,224,224,dtype=torch.float64));y.square().mean().backward()
        self.assertGreater(float(model.architecture.detector.layer2[0].adscm.bridge[0].weight.grad.abs().sum()),0)

    def test_replacement_after_meta_move_inherits_non_cpu_device(self):
        model=core.CoreNet('adscm').to('meta').eval();replace_stage2(model.architecture)
        self.assertTrue(all(p.device.type=='meta' for p in model.parameters()))
        self.assertTrue(all(b.device.type=='meta' for b in model.buffers()))
        self.assertEqual(tuple(model.architecture(torch.empty(2,3,224,224,device='meta')).shape),(2,2))

    @unittest.skipUnless(torch.cuda.is_available(),'CUDA unavailable in this execution workspace')
    def test_actual_cuda_replacement_forward_backward(self):
        model=core.CoreNet('adscm').cuda();replace_stage2(model.architecture)
        self.assertTrue(all(p.is_cuda for p in model.parameters()))
        iq=torch.randn(2,512,dtype=torch.complex64,device='cuda');z,ce,loss=core.objective(model,iq,torch.tensor([0,1],device='cuda'))
        loss.backward();self.assertTrue(torch.isfinite(loss))

    def test_original_v1_control_readonly_reuse_and_changed_budget_rejected(self):
        # Train with the ACTUAL original package in a separate process; its
        # code hashes are not forged or changed to match this repair package.
        archive=Path(__file__).parents[2]/'B275_LMDA_REPLAY_CORE_V1.zip'
        if not archive.exists():self.skipTest('Place original V1 ZIP next to extracted package for this cross-version test')
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);v1=root/'v1'
            with zipfile.ZipFile(archive) as z:z.extractall(v1)
            old=v1/'B275_LMDA_REPLAY_CORE_V1'
            program='''
import sys,json
from pathlib import Path
from types import SimpleNamespace
import torch
sys.path.insert(0,sys.argv[1]);sys.path.insert(1,str(Path(sys.argv[1])/'tests'))
from test_b276 import fixture
from b273_shared import setup
from b271_data import digest_file,write_json
from source_loader import load_frozen_sources
import b275_adscm_experiment as c
from b276_train import train_arm
setup(2);root=Path(sys.argv[2]);context,data,g=fixture(root)
torch.manual_seed(123);source=c.CoreNet();s,tr,r=load_frozen_sources();path=root/'source.pt'
torch.save(dict(method='L1_TAIL',cfg=r.CFG,source_sha256=tr.EXPECTED_SOURCE_SHA,state_dict=source.architecture.state_dict()),path)
info=dict(checkpoint=path,contract={'checkpoint_sha256':digest_file(path)},run_dir=root,config={'backend':source.frontend.backend,'scale':1.})
a=SimpleNamespace(out_dir=root/'old_results',seed=20261022,epochs=1,batch=2,lr=3e-5,new_lr=3e-4,device=torch.device('cpu'))
h=dict(status=c.PASS,version='B275_ADSCM_STAGE2_TRAIN_V1',loss_name='original B215 L1_TAIL CE+0.05 tail ranking',old_l1_weights=True,teacher=c.teacher,factory=lambda arm,b,s:c.CoreNet(arm),migrate=c.initialize,verify_initial=c.initial_check,objective=c.objective,diagnostics=c.diagnostics)
train_arm(a,context,data,info,'continued',h)
write_json(root/'info.json',{'checkpoint':str(path),'sha':info['contract']['checkpoint_sha256']})
'''
            subprocess.run([sys.executable,'-c',program,str(old),str(root)],check=True,stdout=subprocess.DEVNULL)
            bank=root/'bank';hp=bank/'iq.h5';g=load_frozen_file('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
            context=dict(root=root,bank_dir=bank,bank_path=hp,b210=load_frozen_file('r10_sim_stage_b210_a3_adn_earlystop_v1.py'),bc=dict(file_sha256=digest_file(hp),generator_sha256=digest_file(g.__file__)))
            data=Data(context,4,4,20261022);i=read_json(root/'info.json');s=load_frozen_sources()[0]
            info=dict(checkpoint=Path(i['checkpoint']),contract={'checkpoint_sha256':i['sha']},run_dir=root,config={'backend':{'sha256':digest_file(s.__file__)},'scale':1.})
            directory=root/'old_results/continued';before={str(p):digest_file(p) for p in directory.iterdir() if p.is_file()}
            a=SimpleNamespace(out_dir=root/'fix_results',seed=20261022,epochs=1,batch=2,lr=3e-5,new_lr=3e-4,device=torch.device('cpu'))
            record=core.reuse_control(directory,a,context,data,info,hooks());self.assertFalse(record['control_retraining_performed'])
            self.assertNotEqual(record['old_code_sha256'],record['new_code_sha256'])
            contract=trainer.train_arm(a,context,data,info,'adscm',hooks());self.assertEqual(contract['status'],core.PASS)
            self.assertEqual(before,{str(p):digest_file(p) for p in directory.iterdir() if p.is_file()})
            core.reuse_control(directory,a,context,data,info,hooks())
            a.epochs=2
            with self.assertRaisesRegex(RuntimeError,'settings/data/budget'):core.reuse_control(directory,a,context,data,info,hooks())


if __name__=='__main__':unittest.main(verbosity=2)
