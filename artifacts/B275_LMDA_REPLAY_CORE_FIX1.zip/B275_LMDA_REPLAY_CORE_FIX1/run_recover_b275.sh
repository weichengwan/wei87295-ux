#!/usr/bin/env bash
# Independent recovery: completed V1 continued is reused read-only.
set -euo pipefail
package_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
project_root=$(dirname -- "$package_dir")
exec bash "$package_dir/run_b275.sh" --stage core-night \
  --root "$project_root" \
  --out-dir "$project_root/output_b275_lmda_replay_core_fix1" \
  --reuse-core-control "$project_root/output_b275_lmda_replay_core_v1/continued" "$@"
