# B275 FIX1：设备修复与已完成对照组恢复

修复V1在CUDA上替换Stage2 ACB时，新建ADSCM仍留在CPU的问题。新块继承原层device、dtype和train/eval状态；训练器在前向前检查参数设备。

## 恢复运行

把本ZIP上传到原项目目录，解压为独立文件夹。原V1程序、B276结果、B275已完成对照均不改写。

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
unzip -n B275_LMDA_REPLAY_CORE_FIX1.zip
nohup /root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  bash B275_LMDA_REPLAY_CORE_FIX1/run_recover_b275.sh \
  > codex_b275_fix1.log 2>&1 < /dev/null &
tail -F codex_b275_fix1.log
```

脚本校验原`output_b275_lmda_replay_core_v1/continued`的完整契约、原版代码SHA、已选权重SHA与内部信息、冻结数据、训练行、seed、4epoch预算、学习率和目标。全部相符才只读复用，不重新训练对照，不修改其code_sha或契约。

然后在`output_b275_lmda_replay_core_fix1/adscm`训练ADSCM替换组，自动执行相同medium评分和绘图。结果为`core_pd_scr_medium/b275_report.json`、`b275_metrics.csv`、`b275_comparisons.csv`、图及原始分数。`reused_control.json`记录原代码与修复代码的不同SHA、复用权重来源和未重训事实。

原日志`continued; selected epoch=0`表示4轮完成后，最小VAL CE仍是初始权重；不表示只训练了0轮。本次修复不改变这种选择。

若配置或原文件不符，程序会停止并指出原因；不通过删除旧输出、重写旧指纹来绕过检查。修复中断后可重跑同一命令恢复最后完整epoch。B276不会重新训练或评分。

## 范围

修复不改变ADSCM结构、CE+0.05尾部排序目标、训练数据、预算、参数学习率或评分协议。依然Pfa1e-4，TRAIN16000/VAL3000，每组4epoch、batch32，500k CAL/200k CHECK/1024×37 H1，不自动全量。与其他雷达任务共用GPU锁。

默认普通`run_b275.sh`输出也改为FIX1新目录。若不复用旧对照而要独立训练两组，可直接使用`run_b275.sh --stage core-night --out-dir <另一个新目录>`；当前恢复场景推荐上面的`run_recover_b275.sh`。

## 本地验证与限制

15项功能测试通过，1项实际CUDA前向/反向测试因本机无CUDA而跳过。新增检查包括float64原模型上替换的前向/梯度、meta设备继承、以原V1代码真实短训对照后跨版本只读复用、修复版短训ADSCM、预算变化拒绝及原文件SHA不变。原有训练恢复、配对评分和绘图回归保持通过。

这些是CPU/模拟设备功能验证，没有把它们当作实际CUDA运行或检测增益证据。完整验证见VALIDATION.json。旧方法、数据/论文边界与来源说明见README_V1.md（其中原包名和默认输出属于V1历史说明，当前恢复以本页为准）。
