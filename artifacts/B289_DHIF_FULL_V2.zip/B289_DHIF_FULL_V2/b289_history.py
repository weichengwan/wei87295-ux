"""Read existing complete TFSE score arrays only. Never load or execute its model."""
import numpy as np
from b289_common import FILES,need,read_json,fingerprint,digest_file
from b289_source import SCENE_KEYS


def find_reference(root,protocol):
    candidates=[
        ('output_b287_tfse_lcbr_factorial_v1','B287_TFSE_LCBR_SCORE_V1','TFSE'),
        ('output_b284_tfse_cgcr_factorial_v1','B284_TFSE_CGCR_FACTORIAL_SCORE_V1','TFSE'),
        ('output_b282_a1_cfexpert_v1','B282_CFEXPERT_SCORE_V1','control'),
        ('output_b280_full_ablation_v1','B280_FULL_FACTORIAL_SCORE_V1','A1'),
    ]
    skipped=[]
    for directory,version,label in candidates:
        folder=root/directory/'pd_scr_full'
        try:
            pp,prp=folder/'protocol_frozen.json',folder/'progress.json'
            if not pp.is_file() or not prp.is_file():
                skipped.append(dict(path=str(folder),reason='No complete full-score metadata'));continue
            p,pr=read_json(pp),read_json(prp)
            need(p['version']==version and label in p['labels'],'Unexpected old release/column')
            need(p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==pr['fingerprint'],
                 'Old protocol/progress identity differs')
            need(all(p[k]==protocol[k] for k in SCENE_KEYS),'Historical full scene protocol differs')
            need(pr['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=37),
                 'Historical scoring incomplete')
            for key in ('device','batch','torch_version','amp','tf32'):
                need(p.get(key)==protocol.get(key),'Historical inference setting differs: '+key)
            col=p['labels'].index(label)
            if label=='TFSE':ct=p['training_contracts']['TFSE']
            elif label=='control':ct=p['checkpoints'][0]
            else:ct=p['checkpoints'][1]
            cfg=ct['run_config']
            if label=='A1':ancestor=ct['checkpoint_sha256']
            else:ancestor=cfg['source_identity']['A1_checkpoint_sha256']
            need(ancestor==protocol['source_lineage']['B280_A1'],'Historical TFSE has another A1 ancestor')
            arrays={};records={}
            for split,file in FILES.items():
                path=folder/file;n=p['h1_scenes_n'] if split=='h1' else p[split+'_n']
                expected=(37,n,len(p['labels'])) if split=='h1' else (n,len(p['labels']))
                value=np.load(path,mmap_mode='r',allow_pickle=False)
                need(value.shape==expected and value.dtype==np.float64,'Historical score shape/type differs')
                column=value[...,col]
                need(np.isfinite(column).all(),'Nonfinite historical TFSE scores')
                arrays[split]=column
                records[file]=digest_file(path)
            record=dict(path=str(folder),release=version,column_label=label,column_index=col,
                checkpoint_sha256=ct['checkpoint_sha256'],training_contract=ct,
                source_protocol_sha256=digest_file(pp),raw_score_sha256=records,
                model_loaded=False,model_executed=False,recomputed_scores=False,
                exact_scene_protocol=True,earlier_sources_skipped=skipped)
            return dict(arrays=arrays,record=record),skipped
        except (RuntimeError,KeyError,ValueError,OSError,TypeError) as error:
            skipped.append(dict(path=str(folder),reason=str(error)))
    return None,skipped
