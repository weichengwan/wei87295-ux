"""Only two DHiF candidate experiments run. Existing TFSE scores are read-only optional references."""
import argparse
import fcntl
import gc
import shutil
import time
from pathlib import Path
import torch
from b289_common import ROOT,need,read_json,write_json,fingerprint,code_hashes,validate_sources,setup
from b289_data import resolve,Data
from b289_source import load_sources,verify_protected
from b289_train import preflight,train_arm,load_selected
from b289_score import make_protocol,stream


def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=ROOT.parent)
    for name in ('bank-dir','b280-run','out-dir'):p.add_argument('--'+name,type=Path)
    p.add_argument('--stage',choices=('all','preflight','train','score','report'),default='all')
    p.add_argument('--epochs',type=int,default=15);p.add_argument('--warmup-epochs',type=int,default=3)
    p.add_argument('--backbone-lr',type=float,default=1e-5);p.add_argument('--new-lr',type=float,default=3e-4)
    p.add_argument('--batch',type=int,default=32);p.add_argument('--chunk',type=int,default=512)
    p.add_argument('--cpu-threads',type=int,default=4);p.add_argument('--seed',type=int,default=20261022)
    p.add_argument('--device',choices=('cuda','cpu'),default='cuda')
    p.add_argument('--wait-for-gpu',action='store_true')
    a=p.parse_args(argv);a.root=a.root.resolve()
    for name,default in [('b280_run','output_b280_full_ablation_v1'),
        ('out_dir','output_b289_dhif_two_full_v2')]:setattr(a,name,(getattr(a,name) or a.root/default).resolve())
    need(a.root.is_dir() and a.out_dir.parent==a.root and a.out_dir.name.startswith('output_b289_'),'Use a new direct output_b289_* directory only')
    for original in (a.b280_run,):
        need(a.out_dir!=original and original not in a.out_dir.parents and a.out_dir not in original.parents,'Do not overlap original model runs')
    need(a.epochs>0 and 0<=a.warmup_epochs<=a.epochs and a.cpu_threads>0 and a.batch==32 and a.chunk>=32 and a.chunk%32==0,'Use positive epochs, batch32 and chunk multiple32')
    need(a.backbone_lr>0 and a.new_lr>0,'Learning rates must be positive')
    if a.out_dir.exists() and any(a.out_dir.iterdir()):
        need((a.out_dir/'run_manifest.json').is_file(),'Nonempty output has no B289 identity; preserve it')
        need(not any(f.is_symlink() for f in a.out_dir.rglob('*')),'B289 output contains symbolic links; preserve it and choose a fresh output')
    if a.device=='cuda':need(torch.cuda.is_available(),'CUDA unavailable; use AutoDL mpdnet-r10')
    a.device=torch.device(a.device);a.score_dir=a.out_dir/'pd_scr_full'
    return a


def acquire(lock,wait):
    while True:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);return
        except BlockingIOError:
            need(wait,'Another radar job holds the shared GPU lock')
            print('Waiting for another radar job; it will not be interrupted.',flush=True);time.sleep(30)


def main(argv=None):
    a=cli(argv);setup(a.cpu_threads,a.seed);validate_sources()
    if a.stage=='report':
        from b289_report import generate
        return generate(a.score_dir)
    print('B289 V2: ADN + DHiF; ADN + TFSE + DHiF. Only these TWO models train/score; historical TFSE never rerun.',flush=True)
    with (a.root/'codex_b271_night.lock').open('a') as lock:
        acquire(lock,a.wait_for_gpu);context=resolve(a);info=load_sources(a,context)
        a.out_dir.mkdir(exist_ok=True)
        identity=dict(version='B289_DHIF_TWO_MODEL_FULL_V2',source_lineage=info['lineage'],code_sha256=code_hashes(),
            train_count=30000,val_count=5000,epochs=a.epochs,warmup_epochs=a.warmup_epochs,
            batch=a.batch,backbone_lr=a.backbone_lr,new_module_lr=a.new_lr,seed=a.seed,
            device=a.device.type,torch_version=str(torch.__version__),cpu_threads=a.cpu_threads,
            pure_ADN_trained=False,fixed_TFSE_trained=False,fixed_TFSE_full_scoring_executed=False)
        manifest=a.out_dir/'run_manifest.json'
        if manifest.exists():need(read_json(manifest)==identity,'B289 run settings changed; use another output')
        else:
            need(not any(a.out_dir.iterdir()),'Nonempty output without manifest');write_json(manifest,identity)
        if a.stage in ('all','preflight','train'):
            missing=sum(not (a.out_dir/arm/'training_contract.json').is_file() for arm in ('DHIF','FULL'))
            needed=max(256*1024**2,missing*1024**3)
            need(shutil.disk_usage(a.out_dir).free>=needed,'Insufficient space for missing own checkpoints; no cleanup or old output modification performed')
            raw=Data(context,30000,a.seed)
            path=a.out_dir/'preflight.json';fp=fingerprint(identity)
            if path.exists():
                pf=read_json(path);need(pf['run_fingerprint']==fp,'Preflight identity differs');anchors=pf['anchors']
            else:
                anchors,result=preflight(a,info,raw)
                write_json(path,dict(run_fingerprint=fp,anchors=anchors,result=result))
            if a.stage=='preflight':return
            for arm in ('DHIF','FULL'):train_arm(a,context,info,raw,anchors[arm],arm)
            del raw;gc.collect();verify_protected(info)
            if a.device.type=='cuda':torch.cuda.empty_cache()
            if a.stage=='train':return
        models={};contracts={}
        for arm in ('DHIF','FULL'):models[arm],contracts[arm]=load_selected(a,info,arm)
        p=make_protocol(a,info,contracts)
        need(shutil.disk_usage(a.out_dir).free>=256*1024**2,'Need256MiB for two-column full scores and figures')
        print('Only TWO models: CAL3,000,000; AUDIT1,000,000; H1=1024x37; Pfa1e-4 and1e-5',flush=True)
        stream(a,info,models,p)
        write_json(a.out_dir/'protected_sources_after_run.json',verify_protected(info))
        del models,info;gc.collect()
        if a.device.type=='cuda':torch.cuda.empty_cache()
        from b289_report import generate
        return generate(a.score_dir)


if __name__=='__main__':main()
