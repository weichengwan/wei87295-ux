import contextlib
import copy
import io
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from b289_common import (ROOT,LABELS,NAMES,FILES,setup,source,generator,read_json,write_json,
    digest_file,fingerprint,atomic_save,load_checkpoint,snapshot)
from dhif_module import DHiF
from b289_model import PlainADN,TFSECore,Model,initial_check,tensor_hash
from b289_source import load_sources,verify_protected,SCENE_KEYS
from b289_train import Prepared,evaluate,optimizer_for,set_phase,preflight,train_arm,load_selected
from b289_score import fill_predictions,stream
from b289_history import find_reference
from b289_report import generate
from b289_run import cli


def fixture(root,epochs=2):
    setup(2,42)
    a=SimpleNamespace(root=root,b280_run=root/'original_B280',
        out_dir=root/'output_b289_fixture',device=torch.device('cpu'),batch=2,chunk=4,
        seed=42,cpu_threads=2,epochs=epochs,warmup_epochs=1,backbone_lr=1e-5,new_lr=3e-4)
    a.out_dir.mkdir(parents=True);a.score_dir=a.out_dir/'pd_scr_full'
    context=dict(bc=dict(seed=20261009,file_sha256='synthetic-test-bank-not-measured',generator_sha256=digest_file(generator().__file__)))
    raw=SimpleNamespace(values={},selection={})
    for split,n in [('train',8),('val',4)]:
        scenes=[generator().make_one(20261009,split,i,-15,10) for i in range(n)]
        raw.values[split]=(np.stack([s['iq'] for s in scenes]),np.array([s['label'] for s in scenes],dtype='int64'))
        raw.selection[split]=dict(count=n,fixture_only=True)
    def fetch(split,index,device):
        iq,y=raw.values[split]
        return torch.from_numpy(np.ascontiguousarray(iq[index])).to(device),torch.from_numpy(np.ascontiguousarray(y[index])).to(device)
    raw.fetch=fetch
    a0=PlainADN().eval();a1=TFSECore(1.).eval()
    with torch.no_grad():a1.gate.head.weight.normal_(0,.02);a1.gate.head.bias.normal_(0,.02)
    expected=read_json(ROOT/'expected_source_code.json');contracts={};models={}
    for key,m,tfse in [('A0',a0,False),('A1',a1,True)]:
        folder=a.b280_run/key;folder.mkdir(parents=True)
        cfg=dict(arm=key,code_sha256=expected['B280'],bank_sha256=context['bc']['file_sha256'],
            factor_A_joint_SPWVD=tfse,factor_B_TFCG_Tail=False,scale=1.,epochs=15,
            selected_rows=dict(train=dict(count=30000),val=dict(count=5000)))
        state=dict(state_dict=snapshot(m),run_config=cfg,run_fingerprint=fingerprint(cfg),epoch=3)
        atomic_save(folder/'best.pt',state)
        val=evaluate(m,Prepared(raw,tfse,1.),a.device,a.batch)
        ct=dict(status='PASS_B280_FULL_TRAIN_VAL_ONLY',run_config=cfg,run_fingerprint=fingerprint(cfg),
            best_epoch=3,checkpoint_sha256=digest_file(folder/'best.pt'),selected_validation=val)
        write_json(folder/'training_contract.json',ct);contracts[key]=ct;models[key]=m
    scene=dict(master_seed=20261009,generator_sha=context['bc']['generator_sha256'],h0_cal_n=3000000,h0_audit_n=1000000,
        h1_scenes_n=1024,scr_grid_db=list(range(-24,13)),h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',
        family_names=list(generator().TRAIN_FAMILIES),scr_definition='synthetic unit test fixture')
    p=dict(version='B280_FULL_FACTORIAL_SCORE_V1',**scene,scene_fingerprint=fingerprint(scene),
        labels=['A0','A1','A2','A3'],checkpoints=[contracts['A0'],contracts['A1'],None,None])
    p['fingerprint']=fingerprint(p);folder=a.b280_run/'pd_scr_full';folder.mkdir()
    write_json(folder/'protocol_frozen.json',p);write_json(folder/'progress.json',
        dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=3000000,h0_audit=1000000,h1=37)))
    info=load_sources(a,context)
    return a,context,info,raw


class DHiFTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):torch.set_num_threads(2)

    def test_equation_orientation_against_explicit_local_matrix_oracle(self):
        torch.manual_seed(11);m=DHiF(3);x=torch.randn(1,3,4,5)
        actual=m(x);expected=torch.zeros_like(actual);padded=F.pad(x,(1,1,1,1))
        kernel=m.weight.reshape(3,3,9).permute(1,0,2)
        for h in range(4):
            for w in range(5):
                patch=padded[0,:,h:h+3,w:w+3].reshape(3,9)
                op=m.operator_conv(torch.norm(patch,p=2,dim=0)).reshape(9,9)
                filtered=patch@op
                expected[0,:,h,w]=torch.sum((patch+filtered)[None,:,:]*kernel,dim=(1,2))+m.bias
        self.assertTrue(torch.allclose(actual,expected,atol=1e-6,rtol=1e-5))

    def test_dirac_identity_and_both_paths_receive_gradient(self):
        m=DHiF(128).initialize_identity();x=torch.randn(2,128,28,28)
        self.assertTrue(torch.equal(m(x),x))
        m(x).square().mean().backward()
        self.assertGreater(float(m.weight.grad.abs().sum()),0)
        self.assertGreater(float(m.operator_conv[0].weight.grad.abs().sum()),0)
        self.assertEqual(sum(p.numel() for p in m.parameters()),148394)

    def test_native_interfaces_identity_and_frontend_bn_source_immutability(self):
        iq=torch.randn(2,512,dtype=torch.complex64)
        for tfse in (False,True):
            core=TFSECore(1.) if tfse else PlainADN()
            if tfse:
                with torch.no_grad():core.gate.head.weight.normal_(0,.02);core.gate.head.bias.normal_(0,.02)
            raw=SimpleNamespace(values={'train':(iq.numpy(),np.array([0,1])),'val':(iq.numpy(),np.array([0,1]))},selection={})
            raw.fetch=lambda split,index,device:(iq[index].to(device),torch.tensor([0,1])[index].to(device))
            x,y=Prepared(raw,tfse,1.).fetch('train',slice(0,2),torch.device('cpu'))
            before=tensor_hash(core.state_dict());m=Model(core,tfse)
            self.assertEqual(initial_check(m,core,x)['initial_maxabs_logit_difference'],0.)
            bn={k:v.clone() for k,v in m.net.detector.named_buffers()}
            gate=snapshot(m.net.gate) if tfse else None
            args=SimpleNamespace(backbone_lr=1e-5,new_lr=3e-4);op=optimizer_for(m,args)
            for warmup in (True,False):
                set_phase(m,warmup);m.train();op.zero_grad(set_to_none=True)
                loss=F.cross_entropy(m.prepared_forward(x),y);loss.backward()
                if warmup:self.assertIsNone(m.net.detector.conv1.weight.grad)
                else:self.assertGreater(float(m.net.detector.conv1.weight.grad.abs().sum()),0)
                self.assertGreater(float(m.refiner.operator_conv[0].weight.grad.abs().sum()),0);op.step()
            self.assertEqual(before,tensor_hash(core.state_dict()))
            self.assertTrue(all(torch.equal(v,dict(m.net.detector.named_buffers())[k]) for k,v in bn.items()))
            if tfse:self.assertEqual(tensor_hash(gate),tensor_hash(m.net.gate.state_dict()))

    def test_new_namespace_and_missing_sources_never_start_baseline_training(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);old=root/'output_b280_full_ablation_v1';old.mkdir();sentinel=old/'best.pt';sentinel.write_bytes(b'old')
            with self.assertRaisesRegex(RuntimeError,'output_b289_'):cli(['--root',tmp,'--out-dir',str(old),'--device','cpu'])
            self.assertEqual(sentinel.read_bytes(),b'old')
            a=cli(['--root',tmp,'--device','cpu'])
            self.assertEqual((a.epochs,a.warmup_epochs,a.batch),(15,3,32))
            with self.assertRaisesRegex(RuntimeError,'no automatic baseline retraining'):load_sources(a,dict(bc={}))

    def test_sources_only_A0_A1_without_any_B282_checkpoint_dependency(self):
        with tempfile.TemporaryDirectory() as tmp:
            a,c,info,raw=fixture(Path(tmp))
            self.assertTrue(verify_protected(info)['unchanged'])
            self.assertEqual(set(info['models']),{'A0','A1'})
            self.assertFalse((a.root/'output_b282_a1_cfexpert_v1').exists())
            self.assertEqual(len(info['protected_sources']),4)
            with (a.b280_run/'A0/best.pt').open('ab') as f:f.write(b'changed')
            with self.assertRaisesRegex(RuntimeError,'changed'):verify_protected(info)

    def test_preflight_and_resume_train_only_requested_new_candidates(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            a,ctx,info,raw=fixture(Path(tmp)/'interrupted')
            anchors,pf=preflight(a,info,raw)
            self.assertEqual(set(pf['candidate_checks']),{'DHIF','FULL'})
            hit=[]
            def interrupt(path,obj):
                atomic_save(path,obj)
                if Path(path).name=='last_epoch.pt' and obj['epoch']==1 and not hit:
                    hit.append(True);raise RuntimeError('simulated training interruption')
            with patch('b289_train.atomic_save',side_effect=interrupt):
                with self.assertRaisesRegex(RuntimeError,'simulated'):train_arm(a,ctx,info,raw,anchors['DHIF'],'DHIF')
            ct=train_arm(a,ctx,info,raw,anchors['DHIF'],'DHIF')
            sha=digest_file(a.out_dir/'DHIF/best.pt');train_arm(a,ctx,info,raw,anchors['DHIF'],'DHIF')
            self.assertEqual(sha,digest_file(a.out_dir/'DHIF/best.pt'))
            m,_=load_selected(a,info,'DHIF');self.assertIsInstance(m.refiner,DHiF)
            b,ctx2,info2,raw2=fixture(Path(tmp)/'continuous')
            anchor=evaluate(info2['models']['A0'],Prepared(raw2,False),b.device,b.batch)
            ct2=train_arm(b,ctx2,info2,raw2,anchor,'DHIF')
            self.assertEqual(ct['best_epoch'],ct2['best_epoch'])
            s1=load_checkpoint(a.out_dir/'DHIF/best.pt')['state_dict'];s2=load_checkpoint(b.out_dir/'DHIF/best.pt')['state_dict']
            self.assertTrue(all(torch.equal(v,s2[k]) for k,v in s1.items()))
            self.assertTrue(verify_protected(info)['unchanged'])
            self.assertFalse((a.out_dir/'TFSE').exists());self.assertFalse(ct['pure_ADN_trained'])

    def test_two_column_dispatch_and_stream_resume(self):
        class Predictor:
            scale=1.
            def __init__(self,v):self.v=v
            def prepared_forward(self,x):
                value=x.flatten(1).mean(1)+self.v;return torch.stack((-value,value),1)
        models={label:Predictor(i) for i,label in enumerate(LABELS)}
        iq=np.ones((7,512),dtype=np.complex64);out=np.zeros((7,2));mask=np.ones((7,2),bool)
        mocksource=SimpleNamespace(wvd_base_map=lambda x:x.real[:,None,:],map_to_adn_input=lambda x:x)
        with patch('b289_score.source',return_value=mocksource),patch('b289_score.smoothing_bank',side_effect=lambda x,s:x.real[:,None,:]+10):
            result=fill_predictions(models,iq,out,mask,torch.device('cpu'),3)
        self.assertTrue(np.all(result[:,0]==2.));self.assertTrue(np.all(result[:,1]==24.))
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            a=SimpleNamespace(score_dir=Path(tmp)/'scores',batch=2,chunk=4,device=torch.device('cpu'))
            p=dict(h0_cal_n=9,h0_audit_n=7,h1_scenes_n=4,scr_grid_db=list(range(-24,13)),fingerprint='software-test-only')
            calls=[]
            def values(a,info,models,p,split,start,stop,j=None):
                return np.arange(start,stop)[:,None]+np.arange(2)[None,:]+100*(j or 0)
            def interrupted(*args,**kwargs):
                calls.append(1)
                if len(calls)==2:raise RuntimeError('simulated scoring interruption')
                return values(*args,**kwargs)
            with patch('b289_score.compute',side_effect=interrupted):
                with self.assertRaisesRegex(RuntimeError,'simulated'):stream(a,None,None,p)
            prefix=np.load(a.score_dir/FILES['h0_cal'])[:4].copy()
            with patch('b289_score.compute',side_effect=values):stream(a,None,None,p)
            self.assertTrue(np.array_equal(prefix,np.load(a.score_dir/FILES['h0_cal'])[:4]))
            self.assertEqual(np.load(a.score_dir/FILES['h1']).shape,(37,4,2))

    def test_history_is_scores_only_and_rejects_different_scenes_or_ancestor(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);folder=root/'output_b282_a1_cfexpert_v1/pd_scr_full';folder.mkdir(parents=True)
            scene=dict(master_seed=20261009,generator_sha='fixture',h0_cal_n=32,h0_audit_n=32,h1_scenes_n=4,
                scr_grid_db=list(range(-24,13)),h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',
                family_names=['fixture'],scr_definition='software test')
            ct=dict(checkpoint_sha256='fixed-control',run_config=dict(source_identity=dict(A1_checkpoint_sha256='ancestor')))
            p=dict(version='B282_CFEXPERT_SCORE_V1',**scene,labels=['A1_frozen','control','unguided','guided'],
                checkpoints=[ct,{},{}],batch=32,device='cpu',torch_version=str(torch.__version__),amp=False,tf32=False)
            p['fingerprint']=fingerprint(p)
            write_json(folder/'protocol_frozen.json',p)
            write_json(folder/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=32,h0_audit=32,h1=37)))
            for split,file in FILES.items():
                shape=(37,4,4) if split=='h1' else (32,4)
                value=np.zeros(shape,dtype='float64');value[...,0]=11;value[...,1]=22;value[...,2]=33;value[...,3]=44
                np.save(folder/file,value)
            current=dict(p,source_lineage=dict(B280_A1='ancestor'))
            before={f.name:digest_file(f) for f in folder.iterdir()}
            with patch('torch.load',side_effect=AssertionError('Historical model must never load')):
                reference,skipped=find_reference(root,current)
            self.assertIsNotNone(reference)
            for value in reference['arrays'].values():self.assertTrue(np.all(value==22))
            self.assertFalse(reference['record']['model_loaded']);self.assertFalse(reference['record']['model_executed'])
            current['source_lineage']['B280_A1']='different'
            self.assertIsNone(find_reference(root,current)[0])
            current['source_lineage']['B280_A1']='ancestor';current['master_seed']+=1
            self.assertIsNone(find_reference(root,current)[0])
            self.assertEqual(before,{f.name:digest_file(f) for f in folder.iterdir()})

    def test_two_pfa_two_model_report_tie_is_not_gain(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            folder=Path(tmp);n0=1000000;nh=64
            ctf=dict(best_epoch=2,run_config=dict(epochs=6,selected_rows=dict(train=dict(count=16000))))
            cnew=dict(best_epoch=4,run_config=dict(epochs=15,selected_rows=dict(train=dict(count=30000))))
            p=dict(version='B289_DHIF_TWO_MODEL_FULL_SCORE_V2',labels=list(LABELS),h0_cal_n=n0,h0_audit_n=100000,
                h1_scenes_n=nh,scr_grid_db=list(range(-24,13)),nominal_pfas=[1e-4,1e-5],source_lineage={},
                training_contracts=dict(DHIF=cnew,FULL=cnew));p['fingerprint']=fingerprint(p)
            write_json(folder/'protocol_frozen.json',p);write_json(folder/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=n0,h0_audit=100000,h1=37)))
            cal=np.tile(np.linspace(-3,3,n0)[:,None],(1,2));audit=np.tile(np.linspace(-3,2.99,100000)[:,None],(1,2))
            values=np.stack([np.linspace(-2,2,nh)+(scr+24)/4 for scr in range(-24,13)])
            h1=np.repeat(values[:,:,None],2,axis=2)
            np.save(folder/FILES['h0_cal'],cal);np.save(folder/FILES['h0_audit'],audit);np.save(folder/FILES['h1'],h1)
            result=generate(folder)
            self.assertEqual(len(result['metrics']),4)
            self.assertTrue(all(not v['descriptive_D90_left'] for v in result['ours_D90_comparison']))
            self.assertTrue((folder/'figures/b289_pd_scr_pfa_1e-05.pdf').exists())
            self.assertFalse(result['pure_ADN_trained']);self.assertFalse(result['fixed_TFSE_trained'])
            self.assertFalse(result['equal_budget_ablation'])
            self.assertEqual(result['executed_labels'],['DHIF','FULL'])
            self.assertFalse(result['fixed_TFSE_full_scoring_executed']);self.assertFalse(result['fixed_TFSE_reused'])
            historical=dict(arrays=dict(h0_cal=cal[:,0],h0_audit=audit[:,0],h1=h1[:,:,0]),
                record=dict(path='existing-historical-scores',training_contract=ctf,
                    model_loaded=False,model_executed=False,recomputed_scores=False))
            with patch('b289_report.find_reference',return_value=(historical,[])), \
                 patch('torch.load',side_effect=AssertionError('Never load historical weights for plotting')):
                overlaid=generate(folder)
            self.assertEqual(overlaid['executed_labels'],['DHIF','FULL'])
            self.assertEqual(overlaid['plotted_labels'],['TFSE','DHIF','FULL'])
            self.assertEqual(len(overlaid['metrics']),6)
            self.assertTrue(overlaid['fixed_TFSE_reused'])
            self.assertFalse(overlaid['historical_reference']['model_executed'])
            self.assertTrue(all(not row['descriptive_D90_left'] for row in overlaid['ours_D90_comparison']))


if __name__=='__main__':unittest.main()
