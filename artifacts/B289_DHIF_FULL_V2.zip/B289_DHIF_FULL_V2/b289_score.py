"""Only two new models execute: DHIF and FULL. No historical-model inference."""
import time
from pathlib import Path
import numpy as np
import torch
from b289_common import LABELS,NAMES,FILES,need,read_json,write_json,fingerprint,digest_file,code_hashes,source
from b289_source import SCENE_KEYS
from tfse_frontend import smoothing_bank

def make_iq(generator,p,split,ix,j=None):
    scenes=[generator.make_one(p['master_seed'],p['h1_split'] if split=='h1' else p[split+'_split'],int(i),-30,10) for i in ix]
    if split!='h1':
        need(all(s['label']==0 and not np.any(s['target']) for s in scenes),'Target appeared in H0 split')
        return np.stack([s['base'] for s in scenes]).astype('complex64')
    need(all(s['label']==1 for s in scenes),'H1 label mismatch')
    base=np.stack([s['base'] for s in scenes]).astype('complex64').astype('complex128')
    unit=np.stack([s['unit'] for s in scenes]).astype('complex64').astype('complex128')
    cp=np.asarray([s['cp'] for s in scenes],dtype='float64');need((cp>0).all() and np.isfinite(cp).all(),'Invalid clutter power')
    amplitude=np.sqrt(cp*10**(p['scr_grid_db'][j]/10))
    return (base+unit*amplitude[:,None]).astype('complex64')


@torch.inference_mode()
def fill_predictions(models,iq,out,missing,device,batch):
    need(iq.dtype==np.complex64 and iq.shape[1:]==(512,),'Require original complex64 IQ512')
    need(out.shape==missing.shape==(len(iq),len(LABELS)),'Invalid two-column mask')
    for start in range(0,len(iq),batch):
        stop=min(start+batch,len(iq));mask=missing[start:stop]
        if not mask.any():continue
        x=torch.from_numpy(np.ascontiguousarray(iq[start:stop])).to(device)
        image=source().map_to_adn_input(source().wvd_base_map(x)) if mask[:,0].any() else None
        bank=smoothing_bank(x,models['FULL'].scale) if mask[:,1].any() else None
        for col,label in enumerate(LABELS):
            rows=np.flatnonzero(mask[:,col])
            if not len(rows):continue
            ix=torch.as_tensor(rows,device=device,dtype=torch.long)
            prepared=image if label=='DHIF' else bank
            z=models[label].prepared_forward(prepared.index_select(0,ix))
            need(z.shape==(len(rows),2) and torch.isfinite(z).all(),'Invalid new-model logits')
            out[start+rows,col]=(z[:,1]-z[:,0]).double().cpu().numpy()
    need(np.isfinite(out).all(),'Nonfinite or unfilled score cells')
    return out


def compute(a,info,models,p,split,start,stop,j=None):
    iq=make_iq(info['generator'],p,split,np.arange(start,stop),j)
    out=np.zeros((stop-start,len(LABELS)),dtype=np.float64)
    return fill_predictions(models,iq,out,np.ones(out.shape,bool),a.device,a.batch)


def make_protocol(a,info,contracts):
    p=dict(version='B289_DHIF_TWO_MODEL_FULL_SCORE_V2',**info['scene'],
        scene_fingerprint=fingerprint(info['scene']),labels=list(LABELS),names=NAMES,
        nominal_pfas=[1e-4,1e-5],training_contracts=contracts,source_lineage=info['lineage'],
        source_files_sha256=info['protected_sources'],
        code_sha256=code_hashes(),batch=a.batch,chunk=a.chunk,device=a.device.type,
        torch_version=str(torch.__version__),amp=False,tf32=False,
        score_definition='float64(float32 logit1-logit0)',strict_decision='score > own H0 CAL cutoff',
        training_rows=30000,validation_rows=5000,pure_ADN_trained=False,fixed_TFSE_trained=False,fixed_TFSE_full_scoring_executed=False,
        same_new_arm_training_budget=True,historical_control_budget_matched=False,
        independent_final=False,scope='Paired exposed SIM-R10 DEV; two new candidates only. Historical TFSE results may be overlaid read-only after scoring.')
    p['fingerprint']=fingerprint(p)
    return p


def stream(a,info,models,p):
    folder=a.score_dir;folder.mkdir(exist_ok=True)
    pp,prp=folder/'protocol_frozen.json',folder/'progress.json'
    if pp.exists():need(read_json(pp)==p,'Scoring identity changed; preserve output')
    else:
        need(not any(folder.iterdir()),'Nonempty scoring output without manifest');write_json(pp,p)
    if prp.exists():
        pr=read_json(prp);need(pr['fingerprint']==p['fingerprint'],'Scoring resume fingerprint differs')
    else:
        need(not any((folder/f).exists() for f in FILES.values()),'Scores exist without commit metadata')
        pr=dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=0,h0_audit=0,h1=0));write_json(prp,pr)
    for split,file in FILES.items():
        n=p['h1_scenes_n'] if split=='h1' else p[split+'_n']
        maximum=37 if split=='h1' else n;done=pr['completed'][split]
        need(isinstance(done,int) and 0<=done<=maximum,'Invalid scoring progress')
        path=folder/file;need(done==0 or path.is_file(),'Committed score file missing')
        shape=(37,n,len(LABELS)) if split=='h1' else (n,len(LABELS))
        array=np.lib.format.open_memmap(path,mode='r+' if path.exists() else 'w+',dtype='float64',shape=shape)
        need(array.shape==shape and array.dtype==np.float64,'Two-column array shape differs')
        # Numerically replay committed boundary blocks before continuing.
        if done:
            count=n if split=='h1' else done
            starts=sorted({0,max(0,((count-1)//a.batch)*a.batch)})
            levels=sorted({0,done-1}) if split=='h1' else [None]
            for j in levels:
                for start in starts:
                    stop=min(start+a.batch,count)
                    actual=compute(a,info,models,p,split,start,stop,j)
                    expected=array[j,start:stop] if split=='h1' else array[start:stop]
                    need(np.allclose(actual,expected,atol=5e-5,rtol=2e-5),'Own committed score replay differs; preserve result')
        began=time.perf_counter()
        if split=='h1':
            for j in range(done,37):
                for start in range(0,n,a.chunk):
                    stop=min(start+a.chunk,n);array[j,start:stop]=compute(a,info,models,p,split,start,stop,j)
                array.flush();pr['completed'][split]=j+1;write_json(prp,pr)
                print(f'[dev_h1] SCR={p["scr_grid_db"][j]:+d} dB {j+1}/37',flush=True)
        else:
            for start in range(done,n,a.chunk):
                stop=min(start+a.chunk,n);array[start:stop]=compute(a,info,models,p,split,start,stop)
                array.flush();pr['completed'][split]=stop;write_json(prp,pr)
                if stop==n or stop%10000<a.chunk:
                    rate=(stop-done)/max(time.perf_counter()-began,1e-6)
                    print(f'[{split}] {stop:,}/{n:,}; two-model rate={rate:.1f}/s; remaining~{(n-stop)/max(rate,1e-6)/60:.1f}min',flush=True)
        del array

