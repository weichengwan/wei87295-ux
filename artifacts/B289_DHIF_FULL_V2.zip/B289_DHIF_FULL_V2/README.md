# B289 V2：只运行两个DHiF候选模型

按2026-10-17用户最新要求，只训练、完整推理以下两组：

1. **ADN＋DHiF**：从B280 A0检查点的独立副本启动。
2. **ADN＋TFSE＋DHiF**：从B280 A1检查点的独立副本启动，冻结既有TFSE前端。

**ADN＋TFSE不重训、不续训、不重新完整评分。**
图中若出现第三条ADN＋TFSE曲线，它来自已完成的历史完整分数，绝不是第三个运行任务。
找不到兼容历史分数时只画两个新模型；不会自动补跑旧对照。
所有新权重、分数及图表写入独立 `output_b289_dhif_two_full_v2/`。

## 结构与来源

模块原文：**Dynamic High-Frequency Convolution for Infrared Small Target Detection**，
Li et al.，IEEE Transactions on Circuits and Systems for Video Technology，2026，
DOI：10.1109/TCSVT.2026.3661285。
作者仓库：https://github.com/TinaLRJ/DHiF ，核对commit
`06862c844bc16a3b5ee0d0019e5ae24f0f1bb4e7` 的 `model/basic.py`。

本包按式(5)–(8)独立实现DHiF核心计算；输出、输入梯度和参数梯度均与作者实现核对。

```text
ADN＋DHiF：
IQ512 → 原WVD输入处理 → 原ADN Stem、Layer1、Layer2
      → DHiF(128→128, k3,s1,p1) → 原Layer3、Layer4、GAP、FC

ADN＋TFSE＋DHiF：
IQ512 → 已学且冻结的TFSE前端 → 原ADN Stem、Layer1、Layer2
      → 同一个DHiF → 原Layer3、Layer4、GAP、FC
```

DHiF插在原LCBR所在位置，接收128×28×28中层特征。保留全部8个原生SimAM。
没有LCBR、CGCR、TFCG或Tail，也没有额外注意力或外层残差乘子。
DHiF读取局部3×3特征的通道L2范数，经Linear9→81与Tanh生成局部9×9动态算子；
将变换后的局部特征与原局部特征相加，再通过基础卷积核聚合。
Tanh本身不保证零直流响应，本包不添加原实现没有的零均值约束。

基础核使用Dirac初始化，动态Linear权重和偏置为零，保证初始函数与源模型相同。
两条计算路径都能获得梯度。**这是明确披露的初始化适配，不是作者默认随机初始化协议。**
中层特征的高频变化不能直接等同于物理多普勒频率；收益需由实验验证，不保证Pd提升。

## 默认全量流程

- 使用既有冻结IQ：30,000 TRAIN＋5,000 VAL。
- 每个新模型15epoch：前3epoch仅优化DHiF，再12epoch优化CNN＋DHiF。
- Adam，CNN学习率1e-5，DHiF学习率3e-4，weight_decay1e-4，CE损失。
- 原生BN仿射参数、运行统计和既有TFSE前端冻结。
- 以完整VAL的pAUC@FPR≤0.01选择已训练epoch，CE作平分判据；epoch0仅为诊断。
- 锁定两个候选权重后，推理H0 CAL 3,000,000、H0 AUDIT 1,000,000，
  H1每个SCR 1,024个，-24到+12dB共37点。
- 输出Pfa=1e-4和1e-5两套Pd及空场虚警率图。
- WVD和TFSE表征在线计算，不新增数GB的时频图缓存，不依赖已删除的旧WVD缓存。

源模型仅用于构造候选、初始化小批量函数一致性核对，不单独运行完整VAL或H0/H1。
候选自身的epoch0完整VAL与源模型历史VAL核对；失败时明确报错，不改旧检查点。
低虚警率性能不由5000VAL直接保证；pAUC01是预先指定的选择代理。

## 历史参考曲线如何复用

训练和评分阶段均不依赖B282或其他历史TFSE对照权重。
两个新模型评分完成后，绘图器依次检查B287、B284、B282、B280的 `pd_scr_full/`。
只接受已完整完成、场景协议与运行设置一致、源A1血缘匹配的分数列。
它仅用只读模式打开旧数组，记录原路径和SHA256，不加载或执行旧TFSE模型。

优先沿用B287/B284里的固定TFSE列，其次B282 control；仅在前者不可用时考虑B280 A1。
不同检查点不会被冒充成同一个模型，报告保留精确来源与训练预算。
缺少完整分数时仍生成两个新模型的全部指标和两条曲线，并记录未采用旧结果的原因。

新候选30k/15epoch与历史对照可能训练预算不同；这些是筛选结果，不能直接作为严格同预算消融。
所有推理仍属于已暴露的SIM-R10 DEV，不能称为独立最终测试。

## 启动与恢复

解压到 `/root/autodl-tmp/MTDSP_NATIVE_LMDA_V1`，执行：

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
bash B289_DHIF_FULL_V2/start_on_autodl.sh
tail -F codex_b289_dhif_two_full_v2.log
```

使用conda run，无需conda activate。nohup后台执行，SSH或手机热点断线不终止任务。
若其他实验持有共享GPU锁，本包等待，不终止它们。
服务器关机、进程被杀或磁盘满仍会中断；相同启动命令可恢复完整epoch和已提交评分块。

必需旧文件（只读）：

```text
SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1/
output_b280_full_ablation_v1/A0/{best.pt,training_contract.json}
output_b280_full_ablation_v1/A1/{best.pt,training_contract.json}
output_b280_full_ablation_v1/pd_scr_full/{protocol_frozen.json,progress.json}
```

源文件缺失时输出精确路径，不自动重训原始ADN或TFSE对照。
默认不覆盖V1输出；V1与V2运行身份不同，不能互相续接。

结果目录：`output_b289_dhif_two_full_v2/pd_scr_full/`。

- `figures/b289_pd_scr_pfa_1e-04.pdf`
- `figures/b289_pd_scr_pfa_1e-05.pdf`
- `figures/b289_empty_pfa_ci95_pfa_1e-04.pdf`
- `figures/b289_empty_pfa_ci95_pfa_1e-05.pdf`
- `b289_metrics.csv`、`b289_curves.csv`、`b289_training_table.csv`、`b289_comparisons.csv`、`b289_report.json`

完整方法用黑色实线、空心倒三角；ADN＋DHiF用绿色菱形；历史TFSE如可复用则用橙色方形。
横轴SCR(dB)，纵轴Pd，图上方标虚警率。不平移、不平滑、不强制单调，D90未达到则留空。

本地测试是CPU合成数据代码验证，不是AutoDL的真实Pd结果；启动预检会在实际TRAIN上
检查batch32的三步优化和显存占用，再丢弃预检副本。

```bash
python -m unittest discover -s tests -v
```
