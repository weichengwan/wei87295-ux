# 独立论文重绘工具（B271/B272）

仅读取已有CSV，不导入训练模型，不使用GPU，不更改分数、阈值或检查点。放在项目根目录，与训练包并列；**不要把它放进已有B271/B272训练包内部**，原训练程序对自身PY文件做校验。

## 默认样式

- 本文方法：黑色虚线、空心倒三角 `v`；三角形是数据点标记。
- 横轴 `SCR (dB)`，纵轴 `P_d`；去掉Input、Empirical。
- B272其他方法保留原有颜色、线型、圆点、标记间距；B271保留原Matplotlib色序及圆点样式。
- 按原CSV的SCR排序并逐点连线，保存绘图数值和SHA；不平滑、不移动曲线。
- 输出PDF/SVG矢量图与300dpi PNG。默认仅Pfa=1e-4。

## B272评分完成后运行

将本ZIP解压到 `/root/autodl-tmp/MTDSP_NATIVE_LMDA_V1`，然后：

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
/root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  python B272_PAPER_PLOTS_V1/paper_plots.py \
  --curves output_b272_b271_ahpm_v1/pd_scr_medium/b272_curves.csv \
  --metrics output_b272_b271_ahpm_v1/pd_scr_medium/b272_metrics.csv
```

输出在对应评分目录的 `paper_figures/`。默认把 `B271 + AHPM3` 作为本文方法；不会按结果好坏自动挑曲线。若实验命名改变，用 `--ours 'CSV中准确的方法名'` 指定。

B271旧结果也可直接重画：

```bash
/root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  python B272_PAPER_PLOTS_V1/paper_plots.py \
  --curves output_b271_phase_ars_v1/pd_scr/b271_curves.csv \
  --metrics output_b271_phase_ars_v1/pd_scr/b271_metrics.csv
```

传入metrics后额外输出H0空场CUT级实际虚警率及95% Wilson区间，使用原始 `false_alarms/audit_n`。**同一批H0没有目标SCR**，所以用方法间误警率对比图，不画一个随目标SCR下降的假空场虚警曲线。

## Precision/F1的补充情景分析（可选）

模型最终确定后，最好在有固定样本组成和真值匹配规则的实测检测集上统计TP/FP/FN，报告实际Precision、F1、FP/frame。

若现在仅有SIM-R10汇总Pd/Pfa，可在上述命令末尾显式添加 `--prevalence 0.01`。它表示**假设目标先验占比1%**，由原Pd和实际H0 Pfa推算标准化情景Precision/F1；输出图上注明假设，CSV逐行保存先验。这不是实测部署精确率。不要因为不同方法或SCR不同就换先验，更不能以1%为“实际目标发生率”而不说明来源。

Precision = pi*Pd / [pi*Pd + (1-pi)*Pfa]

F1 = 2*pi*Pd / [pi*(1+Pd) + (1-pi)*Pfa]

当TP+FP=0时Precision无定义，CSV留空、曲线断点，不能随意填成100%。工具不会自动选择最有利的先验。

## 后续评价优先级

1. 主指标：相同标称Pfa下的Pd–SCR、D50/D80/D90及差值，同时列独立H0实测Pfa、误警次数、置信区间。阈值由独立CAL确定。
2. 补充：低SCR固定区间的表现、低FPR段ROC/pAUC；区间和统计方法在看最终测试结果前固定。
3. 不同背景：SIM-R10五类仿真杂波分别报告Pd、D90、FAR和样本数。保持全局CAL确定的各模型阈值，不能用各组AUDIT重新调阈值。
4. 真实海况：只有存在浪高、风速、有效海况等级等记录时，按预先定义的组别报告；五类仿真背景不等于低/中/高真实海况。
5. 实测：按目标距离支撑和预测匹配规则统计Pd/Recall、Precision、F1、FP/frame；空场另报每帧是否误警和平均误警数。固定候选生成、NMS/聚类、匹配容差和阈值。
6. 模块消融：原ADN、L1、B271、匹配继续训练对照、B271+AHPM；使用一致数据和预算，区分继续训练收益与AHPM收益。
7. 计算代价：总/可训练参数、预处理与网络端到端时延、吞吐和显存，说明batch、预热、GPU型号与计时范围。
8. 最终验证：冻结方法后用未用于开发选择的测试集；需要多seed或配对重采样时保留场景级数据。整条37点曲线来自相同场景，不把它们当作37组独立重复试验。

评价组合按雷达检测任务确定。可以突出得到证据支持的优势，并展示所有方法的同口径核心指标；完整结果保留为CSV或补充材料，不能只挑有利SCR/海况或改变baseline阈值。

数据说明特别约束：SIM-R10是纯仿真，横轴SCR；用户2025实测残差扫描横轴为 `Delta=20log10(alpha)`，不能直接改成SCR。原始实测、残差敏感性、203份实测模板注入是不同协议，分开标注。

这个包只有重绘代码和说明，无用户数据或权重。当前正在运行的B272无需重启或替换文件。
