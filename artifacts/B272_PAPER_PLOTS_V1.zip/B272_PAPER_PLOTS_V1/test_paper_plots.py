"""Scientific metric/count consistency tests; synthetic data, not detection results."""
import csv,json,math,tempfile,unittest
from pathlib import Path
from paper_plots import precision_f1,load_curves,save_csv,generate

class MetricTests(unittest.TestCase):
    def test_rates_reproduce_independent_confusion_matrix(self):
        # Positives100, negatives900, TP80, FP10, FN20.
        p,f=precision_f1(.8,10/900,.1)
        self.assertAlmostEqual(p,80/(80+10))
        self.assertAlmostEqual(f,2*80/(2*80+10+20))
        p,f=precision_f1(0,0,.1);self.assertIsNone(p);self.assertEqual(f,0)
        with self.assertRaises(ValueError):precision_f1(.8,.01,0)

    def test_report_keeps_scores_and_marks_assumed_prevalence(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);curves=root/'b272_curves.csv';metrics=root/'b272_metrics.csv';rows=[]
            for name in ('B271 continued (control)','B271 + AHPM3'):
                for scr,hits in ((-1,0),(0,5),(1,10)):
                    rows.append(dict(method=name,nominal_pfa=1e-4,scr_db=scr,hits=hits,n_h1=10,pd=hits/10))
            save_csv(curves,rows)
            save_csv(metrics,[dict(method=m,nominal_pfa=1e-4,audit_false_alarms=2,audit_n=1000,actual_pfa=.002) for m in ('B271 continued (control)','B271 + AHPM3')])
            original=curves.read_bytes();manifest=generate(curves,root/'plots',metrics=metrics,prevalence=1/11)
            self.assertEqual(curves.read_bytes(),original);self.assertTrue(manifest['source_values_unchanged'])
            self.assertTrue(manifest['precision_f1_is_scenario_analysis']);self.assertEqual(manifest['styles']['B271 + AHPM3']['marker'],'v')
            f=next((root/'plots').glob('*precision_f1.csv'))
            with f.open() as h:q=list(csv.DictReader(h))
            row=next(r for r in q if float(r['scr_db'])==0)
            # Equivalent standardized population:100 positives,1000 negatives, TP50,FP2,FN50.
            self.assertAlmostEqual(float(row['precision']),50/52)
            self.assertAlmostEqual(float(row['f1']),100/152)
            self.assertTrue(any(name.endswith('.svg') for name in manifest['products']))

    def test_inconsistent_hits_and_different_grids_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'x.csv'
            save_csv(p,[dict(method='x',nominal_pfa=1e-4,scr_db=0,hits=1,n_h1=10,pd=.5)])
            with self.assertRaisesRegex(ValueError,'differs from recorded'):load_curves(p,1e-4)
            save_csv(p,[dict(method=m,nominal_pfa=1e-4,scr_db=x,pd=.5) for m,x in [('a',0),('a',1),('b',0),('b',2)]])
            with self.assertRaisesRegex(ValueError,'different SCR grids'):load_curves(p,1e-4)

if __name__=='__main__':unittest.main(verbosity=2)
