"""CPU functionality on generated/synthetic data; these are not Pd benchmarks."""
import ast,csv,json,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import h5py
import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from b271_data import digest_file,fingerprint,read_json,write_json,load_checkpoint
from b271_score import SCENE_KEYS
from b273_shared import setup
from b273_statistics import metrics_for,save_csv
from b273_score import stream,predictions
from b273_report import NAMES
from source_loader import load_frozen_file
from b274_model import ResNet18,SingleBranch,Frontend,select_backend,LEGACY_SHA
from b274_data import Data,fit_scale
from b274_score import AlreadyMapped
import b274_train as trainer
import b274_baselines as baselines
import b274_report as report
import b274_model as model_source
import b274_run as runner
import legacy_tf_recovered as recovered


def fixture(root):
    root.mkdir(exist_ok=True);bank=root/'bank';bank.mkdir(exist_ok=True)
    generator=load_frozen_file('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
    hp=bank/'iq.h5'
    with h5py.File(hp,'w') as h:
        for split in ('train','val'):
            samples=[generator.make_one(20261009,split,i,-30,10) for i in range(4)]
            group=h.create_group(split)
            group['iq']=np.stack([s['iq'] for s in samples]).astype('complex64')
            group['label']=np.array([s['label'] for s in samples],dtype='uint8')
            group['family_index']=np.arange(4,dtype='int64')%2
    context=dict(root=root,bank_dir=bank,bank_path=hp,b210=load_frozen_file('r10_sim_stage_b210_a3_adn_earlystop_v1.py'),
        bc=dict(file_sha256=digest_file(hp),generator_sha256=digest_file(generator.__file__),seed=20261009))
    return context,Data(context,4,4,20261022),generator


def original_protocol(context,generator):
    return dict(master_seed=20261009,generator_sha=context['bc']['generator_sha256'],h0_cal_n=3000000,
        h0_audit_n=1000000,h1_scenes_n=1024,scr_grid_db=list(range(-24,13)),h0_cal_split='h0_cal',
        h0_audit_split='h0_audit',h1_split='dev_h1',family_names=list(generator.TRAIN_FAMILIES),scr_definition='synthetic_fixture')


def cache_fixture(root,context,data,generator):
    directory=root/'old';directory.mkdir();folder=directory/'pd_scr_medium';folder.mkdir()
    old=original_protocol(context,generator)
    scene=dict(old);scene.update(h0_cal_n=500000,h0_audit_n=200000)
    identities=[]
    for arm in ('plain','residual'):
        d=directory/arm;d.mkdir();(d/'best.pt').write_bytes(b'synthetic baseline checkpoint identity only')
        sha=digest_file(d/'best.pt');write_json(d/'training_contract.json',dict(arm=arm,checkpoint_sha256=sha))
        identities.append(dict(arm=arm,sha256=sha))
    p=dict(version='B273_RESIDUAL_SPWVD_SCORE_V1',**scene,scene_fingerprint=fingerprint(scene),nominal_pfas=[1e-4],
        batch=32,device='cpu',tf32=False,score_definition='float64(float32 logit1 - float32 logit0)',
        code_sha256=read_json(Path(trainer.__file__).parent/'b273_release_sources.json'),
        checkpoints=identities,labels=['plain','residual','B271_CONTROL','AHPM_REFERENCE','L1_TAIL'])
    p['fingerprint']=fingerprint(p);write_json(folder/'protocol_frozen.json',p)
    write_json(folder/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=500000,h0_audit=200000,h1=37)))
    write_json(directory/'run_manifest.json',dict(bank_dir=str(context['bank_dir']),selected_rows=data.selection))
    cal=np.tile(np.linspace(-6,6,500000)[:,None],(1,5));audit=np.tile(np.linspace(-6,6,200000)[:,None],(1,5))
    q=(np.arange(1024)+.5)/1024;z=np.log(q/(1-q))
    h1=np.stack([6+(scr-z)/3 for scr in range(-24,13)])
    h1=np.stack([h1-.2,h1,h1,h1+.1,h1-.3],2)
    for name,x in [('h0_cal_scores.npy',cal),('h0_audit_scores.npy',audit),('dev_h1_scores.npy',h1)]:np.save(folder/name,x)
    curves=[];metrics=[]
    for j,label in enumerate(p['labels']):
        c,m=metrics_for(NAMES[label],cal[:,j],audit[:,j],h1[:,:,j],p);curves+=c;metrics+=m
    save_csv(folder/'b273_curves.csv',curves);save_csv(folder/'b273_metrics.csv',metrics)
    return folder,old


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):setup(2)

    def test_unmodified_recovered_functions_and_independent_numpy_spwvd(self):
        source=Path(recovered.__file__).read_text();tree=ast.parse(source)
        expected=read_json(Path(recovered.__file__).with_name('RECOVERED_FRONTEND_SOURCE.json'))
        import hashlib
        for node in tree.body:
            if isinstance(node,ast.FunctionDef):self.assertEqual(hashlib.sha256(ast.get_source_segment(source,node).encode()).hexdigest(),expected['functions'][node.name])
        rng=np.random.default_rng(4);x=(rng.normal(size=512)+1j*rng.normal(size=512)).astype('complex64')
        tau=np.arange(-24,25);tc=np.arange(128)*4+2;window=np.hanning(51)[1:-1]
        corr=np.zeros((128,128),dtype='complex128')
        for j,t in enumerate(tc):
            for k,w in zip(tau,window):
                if 0<=t+k<512 and 0<=t-k<512:corr[k%128,j]=x[t+k]*x[t-k].conjugate()*w
        raw=np.fft.fftshift(np.fft.fft(corr,axis=0),axes=0).real
        expected=np.stack([np.pad(row,(2,2)).reshape(-1) for row in raw])
        expected=np.stack([np.convolve(row,np.ones(5)/5,mode='valid') for row in expected])
        actual=recovered.spwvd_torch(torch.from_numpy(x[None])).numpy()[0]
        np.testing.assert_allclose(actual,expected,rtol=2e-5,atol=6e-6)
        t=torch.arange(512);tone=torch.exp(2j*torch.pi*(10/128)*t)[None].to(torch.complex64)
        self.assertEqual(int(recovered.spwvd_torch(tone)[0,:,60].abs().argmax()),84)

    def test_full_resnet_training_and_exact_scoring_image_path(self):
        backend=select_backend(Path('/workspace'),'recovered');torch.manual_seed(7)
        model=SingleBranch(backend,1.7);x=torch.randn(2,512,dtype=torch.complex64)
        self.assertEqual(sum(p.numel() for p in model.parameters()),11177538)
        self.assertTrue(all(p.requires_grad for p in model.parameters()))
        self.assertEqual([len(getattr(model.net,f'layer{i}')) for i in range(1,5)],[2,2,2,2])
        before=model.net.bn1.running_mean.clone();loss=F.cross_entropy(model(x),torch.tensor([0,1]));loss.backward()
        self.assertGreater(float(model.net.conv1.weight.grad.abs().sum()),0)
        self.assertGreater(float(model.net.fc.weight.grad.abs().sum()),0)
        self.assertFalse(torch.equal(before,model.net.bn1.running_mean))
        self.assertFalse(any(any(t in name.lower() for t in ('wcsg','tfcg','resample','phase')) for name,_ in model.named_modules()))
        model.eval()
        with torch.inference_mode():expected=(model(x)[:,1]-model(x)[:,0]).double().numpy()
        actual=predictions([model],AlreadyMapped(),x.numpy(),torch.device('cpu'),2)[:,0]
        np.testing.assert_array_equal(actual,expected)
        # No WVD/ADN rendering is inserted by the reused streaming helper.
        torch.testing.assert_close(model.frontend.images(x),recovered.tf_image(x,1.7),rtol=0,atol=0)

    def test_verified_legacy_source_selection_interface_and_missing_source(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);path=root/'b236_fixture.py'
            path.write_text('from b274_model import ResNet18\nimport legacy_tf_recovered as f\ndef network(): return ResNet18()\ndef spwvd_torch(x): return f.spwvd_torch(x)\ndef tf_image(x,scale): return f.tf_image(x,scale)\n')
            with patch.object(model_source,'LEGACY_SHA',digest_file(path)):
                selected=select_backend(root,'auto')
                self.assertEqual(selected['kind'],'verified_b236_source')
                model=SingleBranch(selected,2.).eval();x=torch.randn(2,512,dtype=torch.complex64)
                self.assertEqual(tuple(model(x).shape),(2,2))
                torch.testing.assert_close(model.frontend.images(x),recovered.tf_image(x,2.),rtol=0,atol=0)
            self.assertEqual(select_backend(root,'auto')['kind'],'recovered_descendant_frontend')
            with self.assertRaisesRegex(RuntimeError,'not found'):select_backend(root,'legacy')

    def test_runner_sequence_failure_stop_and_shared_lock(self):
        import fcntl
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);a=SimpleNamespace(root=root,out_dir=root/'new',bank_dir=None,b213_dir=None,baseline_dir=None,
                cpu_threads=2,device=torch.device('cpu'),train_limit=4,val_limit=4,epochs=2,seed=20261022,backend='recovered',legacy_script=None)
            data=SimpleNamespace(selection={});events=[]
            with patch.object(runner,'cli',return_value=a),patch.object(runner,'resolve',return_value={}),patch.object(runner,'Data',return_value=data),\
                 patch.object(runner,'original_protocol',return_value=(None,{},None)),patch.object(runner,'metadata'),\
                 patch.object(runner,'select_backend',return_value={'kind':'test'}),\
                 patch.object(runner,'train',side_effect=lambda *args:events.append('train')),\
                 patch('b274_score.main',side_effect=lambda args:events.append('score')):
                runner.main([]);self.assertEqual(events,['train','score'])
            with (root/'codex_b271_night.lock').open('a') as lock:
                fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
                with patch.object(runner,'cli',return_value=a),patch.object(runner,'train') as tr:
                    with self.assertRaisesRegex(SystemExit,'GPU lock'):runner.main([])
                    tr.assert_not_called()
            with patch.object(runner,'cli',return_value=a),patch.object(runner,'resolve',side_effect=RuntimeError('preflight failed')),patch('b274_score.main') as score:
                with self.assertRaisesRegex(RuntimeError,'preflight failed'):runner.main([])
                score.assert_not_called()

    def test_from_scratch_training_interrupt_resume_is_identical(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);context,data,_=fixture(root);backend=select_backend(root,'recovered')
            a=trainer.cli(['--root',t,'--out-dir',str(root/'resume'),'--epochs','2','--batch','2','--train-limit','4','--val-limit','4','--device','cpu','--backend','recovered','--resume'])
            save=trainer.atomic_save;stopped=[False]
            def interrupt(path,state):
                save(path,state)
                if path.name=='last_epoch.pt' and state['epoch']==1 and not stopped[0]:stopped[0]=True;raise InterruptedError('test after committed epoch')
            with patch.object(trainer,'atomic_save',side_effect=interrupt):
                with self.assertRaises(InterruptedError):trainer.train(a,context,data,backend)
            c=trainer.train(a,context,data,backend);first=load_checkpoint(a.out_dir/'last_epoch.pt')
            self.assertEqual(c['epochs_executed'],2);self.assertTrue(c['all_cnn_layers_trained'])
            self.assertFalse(c['original_cal_audit_dev_used'])
            a.out_dir=root/'continuous';trainer.train(a,context,data,backend);second=load_checkpoint(a.out_dir/'last_epoch.pt')
            for key,value in first['state_dict'].items():self.assertTrue(torch.equal(value,second['state_dict'][key]),key)
            self.assertEqual(first['best_epoch'],second['best_epoch'])
            a.lr*=2
            with self.assertRaisesRegex(RuntimeError,'settings changed'):trainer.train(a,context,data,backend)

    def test_cached_baselines_threshold_hits_replay_and_damage_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);context,data,generator=fixture(root);folder,old=cache_fixture(root,context,data,generator)
            info=baselines.metadata(folder,context,old,torch.device('cpu'),data.selection)
            cached,details=baselines.arrays(info)
            self.assertTrue(details['baseline_thresholds_false_alarms_all37_hits_replayed'])
            self.assertEqual(details['additional_baseline_GPU_forwards'],0)
            del cached
            bad=np.load(folder/'h0_audit_scores.npy',mmap_mode='r+');bad[0,0]=1000;bad.flush();del bad
            with self.assertRaisesRegex(RuntimeError,'threshold/H0 replay'):baselines.arrays(info)

    def test_actual_generated_iq_stream_resume_and_missing_prefix_guard(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);context,data,generator=fixture(root);backend=select_backend(root,'recovered')
            model=SingleBranch(backend,1.).eval()
            p=original_protocol(context,generator);p.update(h0_cal_n=4,h0_audit_n=4,h1_scenes_n=2,scr_grid_db=[-1,0,1],labels=['SINGLE','fixture'])
            p['fingerprint']=fingerprint(p)
            cached=dict(h0_cal=np.zeros((4,1)),h0_audit=np.zeros((4,1)),h1=np.zeros((3,2,1)))
            a=SimpleNamespace(out_dir=root/'score',batch=2,chunk=2)
            stream(a,p,generator,[model],AlreadyMapped(),torch.device('cpu'),cached)
            paths=['h0_cal_scores.npy','h0_audit_scores.npy','dev_h1_scores.npy'];checks=[digest_file(a.out_dir/f) for f in paths]
            stream(a,p,generator,[model],AlreadyMapped(),torch.device('cpu'),cached)
            self.assertEqual(checks,[digest_file(a.out_dir/f) for f in paths])
            self.assertEqual(read_json(a.out_dir/'progress.json')['completed'],dict(h0_cal=4,h0_audit=4,h1=3))
            (a.out_dir/'h0_cal_scores.npy').unlink()
            with self.assertRaisesRegex(RuntimeError,'missing despite'):stream(a,p,generator,[model],AlreadyMapped(),torch.device('cpu'),cached)

    def test_analytic_report_metrics_plots_and_no_auto_promotion(self):
        with tempfile.TemporaryDirectory() as t:
            out=Path(t);cal=np.linspace(-6,6,100000);audit=np.linspace(-6,6,20000);q=(np.arange(1024)+.5)/1024
            h1=np.stack([6+(scr-np.log(q/(1-q)))/3 for scr in range(-24,13)])
            p=dict(version='B274_SINGLE_SPWVD_RESNET18_SCORE_V1',h0_cal_n=100000,h0_audit_n=20000,h1_scenes_n=1024,scr_grid_db=list(range(-24,13)),
                nominal_pfas=[1e-4],labels=['SINGLE','L1_TAIL'],names={'SINGLE':'Single SPWVD fixture','L1_TAIL':'L1-Tail'},
                backend={'kind':'synthetic_fixture'},checkpoint={'sha256':'fixture'},reused_baselines={},scope='Synthetic functional test only')
            p['fingerprint']=fingerprint(p);write_json(out/'protocol_frozen.json',p)
            write_json(out/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=100000,h0_audit=20000,h1=37)))
            for name,x in [('h0_cal_scores.npy',np.stack([cal,cal],1)),('h0_audit_scores.npy',np.stack([audit,audit],1)),('dev_h1_scores.npy',np.stack([h1,h1-1/3],2))]:np.save(out/name,x)
            result=report.generate(out)
            self.assertAlmostEqual(result['comparisons'][0]['delta_D90_db'],-1.,places=8)
            self.assertFalse(result['automatic_promotion']);self.assertFalse(result['matched_training_procedure'])
            plot=read_json(out/'figures/b274_curves_paper_manifest.json')
            self.assertEqual(plot['styles']['Single SPWVD fixture']['marker'],'v')
            self.assertTrue(plot['source_values_unchanged']);self.assertFalse(plot['smoothing'])
            self.assertTrue((out/'figures/b274_pd_scr_pfa_1e-04.pdf').is_file())


if __name__=='__main__':unittest.main(verbosity=2)
