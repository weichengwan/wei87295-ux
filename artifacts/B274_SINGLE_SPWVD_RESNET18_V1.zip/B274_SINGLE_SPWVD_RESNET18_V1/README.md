# B274：SPWVD＋ResNet18 单分支独立训练

当前包只训练一套 `复数IQ512 → SPWVD → log1p(abs)/TRAIN尺度 → 224×224×3灰度复制 → 标准ResNet18 → 二分类 → 独立CAL阈值`。它不包含WCSG、TFCG、ACB、相位旁路、重采样或残差混合。原骨干没有冻结；所有CNN权重与BN均从随机初始化训练。不下载ImageNet权重，不依赖torchvision。

这是用户现有SIM-R10数据上的单分支重建复现，不是Wang完整三通道方法的复现，也不能保证恢复截图中的历史曲线。

## 为何与B273 plain不同

1. B273 plain换了SPWVD图，但仍使用WVD训练的ADN/WCSG/TFCG冻结权重，只训练少量B271新增参数；本包训练整套纯ResNet18。
2. 上传B266派生脚本中可恢复的前端为49个时滞权重（Hann51去掉首尾）、128个时间中心、128点FFT、5个时间格平均平滑；`log1p(abs)`后除以TRAIN前256条图的99%分位数。B273使用Hann9时间/Hann129时滞窗以及逐图峰值相对dB显示。两个实现的频率/时间朝向也不同；旧图本身是否采用该派生实现的全部参数尚未证实。
3. 截图写有 regenerated DEV (preview)，未证明与当前冻结B213/B273场景完全一致。旧图典型preview为300k CAL、200k CHECK、每SCR256个H1；本包用当前已核验的500k CAL、200k CHECK、每SCR1024个H1。旧原始契约未取得，不能把这些截图设置当成已确认事实。

因此，不能仅凭B273 plain较差就断言SPWVD单分支不好；这次也不能预先承诺复现旧图的左移幅度。

## 来源恢复

Wang & Wang, *A Triple-Channel Network for Maritime Radar Targets Detection Based on Multi-Modal Features*, Remote Sensing2024,16,4662，式(4)、3.2节与Table2单TF分支，DOI https://doi.org/10.3390/rs16244662 。SPWVD是已有时频分析方法。

目前上传源码没有生成旧图的原始B233/B236脚本；存在B266派生文件。本包`legacy_tf_recovered.py`的`spwvd_torch`及`tf_image`两个函数直接从该上传文件提取，函数文本未改，来源SHA见`RECOVERED_FRONTEND_SOURCE.json`；不会调用其中的MSDA/TFAM改造网络。

默认`--backend auto`只在项目内查找深度不超过3层的相关小型py文件。找到SHA严格等于历史契约记录值`5177f9475fb38bf685714438842abb29ae65bd719d64d38caa8da5bde9841cfb`且提供`network/spwvd_torch/tf_image`接口的B236脚本时，调用其原网络/前端函数，并记录路径/SHA。否则，明确用恢复的前端函数和本包实现的标准ResNet18。若旧脚本接口不同，会报错提示保留旧文件并改用`--backend recovered`。即使找到了旧源码，本轮仍采用新声明的中等训练预算和固定数据，不声称旧训练过程完全重放。

## 默认规模与空间

- 冻结30k/5k IQ银行中选取16000 TRAIN、3000 VAL；选择算法、seed、分层和行索引与B273相同。
- 最多/固定12轮，batch32，Adam lr1e-3、weight_decay1e-4、CE；仅用最小VAL CE选模型。当前无按DEV选超参数、无自动加轮数。
- 只评估 nominal Pfa1e-4。CAL500000、H0 CHECK200000、H1每SCR1024条，SCR=-24～12共37点。每种方法各自CAL定阈值，H0 CHECK不用于调阈值。
- 复用B273全部基线分数，重放每种基线的原阈值、虚警数和37个命中计数；旧模型GPU推理次数0。
- 不新建时频图大缓存。best/last（包含Adam状态）和评分约需0.4～0.6GiB，启动要求至少1GiB余量；临时保存期间也会使用空间。恢复训练后保留检查点。
- 3080Ti12GB准确耗时/显存未实测，可先预留约45～90分钟；以首个epoch和评分吞吐更新。CPU功能检查不构成GPU测试或Pd结果。

## 启动

将`B274_SINGLE_SPWVD_RESNET18_V1.zip`上传至`/root/autodl-tmp/MTDSP_NATIVE_LMDA_V1`。首次只运行一次：

```bash
(
set -e
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
unzip -t B274_SINGLE_SPWVD_RESNET18_V1.zip >/dev/null
unzip -n B274_SINGLE_SPWVD_RESNET18_V1.zip
nohup /root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  bash B274_SINGLE_SPWVD_RESNET18_V1/run_b274_night.sh \
  >> codex_b274_single_spwvd.log 2>&1 < /dev/null &
echo "后台PID：$!"
)
tail -F /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1/codex_b274_single_spwvd.log
```

使用现有mpdnet-r10，不需要conda activate或安装torchvision。与B271/B272/B273共用GPU锁；已有实验运行时立即退出。相同命令可在已提交epoch/评分前缀处恢复，不重复已完成训练。

如旧B236脚本加载失败，可用`--backend recovered`，但已初始化的输出不能更改backend；请同时指定新的`--out-dir /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1/output_b274_single_spwvd_recovered_v1`。只有后台日志提示这类问题时才需要改动。

独立环节：

```bash
/root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 bash B274_SINGLE_SPWVD_RESNET18_V1/run_b274_train.sh
/root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 bash B274_SINGLE_SPWVD_RESNET18_V1/run_b274_score.sh
```

独立训练脚本不加GPU锁，应在没有其他GPU任务时运行；推荐使用night脚本。修改训练预算会要求新输出目录。默认night先验证B273完成状态，训练阶段只读TRAIN/VAL；评分时才读取H0/H1分数。原始数据、原WVD缓存、B271/B272/B273目录均不改写。

## 必需文件与输出

只需要原冻结IQ银行（HDF5/contract/audit）、原B213完整协议及progress、已完成B273的run manifest/候选best.pt与training contract，以及`pd_scr_medium`中protocol/progress、3个原始npy评分数组和b273_curves/metrics.csv。包内提供冻结生成器及共享助手。训练不需要旧WVD缓存或旧权重；night为复用比较结果检查B273文件身份。

`output_b274_single_spwvd_resnet18_v1/`：

- `run_manifest.json`、`training_contract.json`、`train_val_history.csv`。
- `best.pt`、`last_epoch.pt`，可恢复中断训练。
- `pd_scr_medium/b274_curves.csv`、`b274_metrics.csv`、`b274_comparisons.csv`、`b274_report.json`。
- `pd_scr_medium/figures/b274_pd_scr_pfa_1e-04.{png,pdf,svg}`；新单分支画黑色虚线空心倒三角，轴为SCR(dB)、Pd。只画真实37点，不平滑或移动。

新方法与旧B273是同一批数据/场景，但训练过程（全CNN从零训练 vs 冻结适配）不同，报告明确`matched_training_procedure=false`。本轮目的为定位差异、验证单分支，不是隔离某个模块的贡献。正式归因还需要同预算全训练的WVD+ResNet18对照，最终还需独立测试；程序PASS仅代表完成运行和一致性校验。
