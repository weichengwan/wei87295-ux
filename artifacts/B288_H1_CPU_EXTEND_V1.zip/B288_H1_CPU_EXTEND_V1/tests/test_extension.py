"""Synthetic CPU fixtures only; no measured AutoDL Pd claims."""
import contextlib
import io
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import numpy as np
import torch

HERE=Path(__file__).resolve().parents[1]
SOURCE=Path(os.environ.get('B288_PACKAGE_PATH',str(HERE.parent/'B288_TSDETECTNET_MEDIUM_V1')))
sys.path.insert(0,str(SOURCE));sys.path.insert(0,str(HERE))
from b288_common import (write_json,read_json,save_csv,digest_file,fingerprint,code_hashes,
    generator,atomic_save,snapshot,TRAIN_PASS,FILES,NAME)
from b288_model import TSDetectNet
from b288_score import protocol,make_iq,predict
from b288_report import cutoff
import b288_extend_cpu as ext


def fixture(root):
    torch.manual_seed(17);model=TSDetectNet().eval().requires_grad_(False)
    run=root/'output_b288_tsdetectnet_medium_v1';train=run/'train_medium';score=run/'pd_scr_medium'
    train.mkdir(parents=True);score.mkdir()
    cfg=dict(code_sha256=code_hashes(),synthetic_fixture_only=True)
    state=dict(run_config=cfg,run_fingerprint=fingerprint(cfg),epoch=1,state_dict=snapshot(model))
    atomic_save(train/'best.pt',state)
    ct=dict(status=TRAIN_PASS,run_config=cfg,run_fingerprint=fingerprint(cfg),best_epoch=1,
        checkpoint_sha256=digest_file(train/'best.pt'))
    write_json(train/'training_contract.json',ct)
    a=SimpleNamespace(root=root,run_dir=run,out_dir=root/'output_b288_h1_cpu_test',batch=32,cpu_threads=2,
        device=torch.device('cpu'),chunk=512)
    a.out_dir.mkdir()
    p=protocol(a,dict(bc=dict(seed=20261009,generator_sha256=digest_file(generator().__file__),file_sha256='fixture'),
        generator=generator()),ct)
    p.update(h0_cal_n=100000,h0_audit_n=100000)
    p['fingerprint']=fingerprint({k:v for k,v in p.items() if k!='fingerprint'})
    write_json(score/'protocol_frozen.json',p)
    write_json(score/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=100000,h0_audit=100000,h1=37)))
    cal=np.linspace(-2,2,100000);audit=np.linspace(-2,1.99,100000)
    h1=np.repeat(np.linspace(-1,3,512)[None,:],37,axis=0)
    for scr in (0,12):
        j=p['scr_grid_db'].index(scr)
        h1[j]=predict(model,make_iq(generator(),p,'h1',np.arange(512),j),a.device,a.batch)
    for split,v in dict(h0_cal=cal,h0_audit=audit,h1=h1).items():np.save(score/FILES[split],v)
    metrics=[];curves=[]
    for nominal in p['nominal_pfas']:
        th,_,_=cutoff(cal,nominal);fp=int((audit>th).sum())
        metrics.append(dict(nominal_pfa=nominal,threshold=th,audit_false_alarms=fp,audit_n=len(audit),actual_pfa=fp/len(audit)))
        for scr,v in zip(p['scr_grid_db'],h1):
            hits=int((v>th).sum())
            curves.append(dict(method=NAME,nominal_pfa=nominal,scr_db=scr,hits=hits,n_h1=512,pd=hits/512,
                pd_ci95_low=0,pd_ci95_high=1,diagnostic_auc_vs_H0_audit=''))
    save_csv(score/'b288_metrics.csv',metrics);save_csv(score/'b288_curves.csv',curves)
    return a,model


class ExtensionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):torch.set_num_threads(2)

    def test_native_cpu_checkpoint_overlap_and_old_files_immutable(self):
        with tempfile.TemporaryDirectory() as tmp:
            a,model=fixture(Path(tmp));info=ext.old_inputs(a)
            loaded=ext.load_model(a,info);checks=ext.cpu_overlap(a,info,loaded)
            self.assertEqual([r['scr_db'] for r in checks],[0,12])
            self.assertTrue(all(r['maxabs_score_difference']<2e-4 for r in checks))
            self.assertTrue(ext.unchanged(info));self.assertFalse(torch.cuda.is_initialized())
            self.assertEqual(os.environ['CUDA_VISIBLE_DEVICES'],'')
            p=a.run_dir/'pd_scr_medium/b288_metrics.csv'
            rows=ext.read_csv(p);rows[0]['threshold']='999';save_csv(p,rows)
            with self.assertRaisesRegex(RuntimeError,'threshold differs'):ext.old_inputs(a)

    def test_resume_and_45_point_report_preserve_all_old_pd(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            a,model=fixture(Path(tmp));info=ext.old_inputs(a)
            p=dict(info['protocol'],scr_grid_db=list(range(13,21)),overlap_checks=[],fingerprint='synthetic-extension')
            calls=[]
            def write(path,obj):
                write_json(path,obj)
                if Path(path).name=='progress.json' and obj.get('completed_scr')==1 and not calls:
                    calls.append(True);raise RuntimeError('simulated interruption after commit')
            # Isolate commit/recovery with deterministic synthetic CPU scores.
            def score(model,iq,device,batch):
                self.assertEqual(device.type,'cpu');return iq.real.mean(1).astype('float64')
            with patch('b288_score.predict',side_effect=score),patch('b288_common.write_json',side_effect=write):
                with self.assertRaisesRegex(RuntimeError,'simulated'):ext.extend(a,info,model,p)
            self.assertEqual(read_json(a.out_dir/'progress.json')['completed_scr'],1)
            first=np.load(a.out_dir/'h1_scores_13_20.npy')[0].copy()
            with patch('b288_score.predict',side_effect=score):values=ext.extend(a,info,model,p)
            self.assertTrue(np.array_equal(first,values[0]))
            ext.report(a,info,values,p)
            curves=ext.read_csv(a.out_dir/'b288_curves_extended.csv')
            self.assertEqual(len(curves),90)
            for old in info['curves']:
                now=next(r for r in curves if r['nominal_pfa']==old['nominal_pfa'] and r['scr_db']==old['scr_db'])
                self.assertEqual(now['pd'],old['pd']);self.assertEqual(now['hits'],old['hits'])
            self.assertTrue(ext.unchanged(info))
            report=read_json(a.out_dir/'b288_extension_report.json')
            self.assertFalse(report['GPU_used']);self.assertFalse(report['training_executed'])
            self.assertFalse(report['H0_inference_executed']);self.assertTrue(report['thresholds_reused'])
            self.assertTrue((a.out_dir/'b288_pd_scr_extended_pfa_1e-04.pdf').is_file())

    def test_output_cannot_target_old_run(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);package=root/'B288_TSDETECTNET_MEDIUM_V1';package.mkdir()
            run=root/'output_b288_tsdetectnet_medium_v1';run.mkdir()
            with self.assertRaisesRegex(RuntimeError,'output_b288_h1_cpu_'):
                ext.cli(['--root',tmp,'--out-dir',str(run)])


if __name__=='__main__':unittest.main()
