"""CPU-only H1 extension, +13..+20 dB. Existing TS-DetectNet and H0 cutoffs only."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
import argparse
import csv
import fcntl
import sys
import time
from pathlib import Path
import numpy as np
import torch


def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    p.add_argument('--package-dir',type=Path)
    p.add_argument('--run-dir',type=Path)
    p.add_argument('--out-dir',type=Path)
    p.add_argument('--batch',type=int,default=32)
    p.add_argument('--cpu-threads',type=int,default=2)
    a=p.parse_args(argv);a.root=a.root.resolve()
    a.package_dir=(a.package_dir or a.root/'B288_TSDETECTNET_MEDIUM_V1').resolve()
    a.run_dir=(a.run_dir or a.root/'output_b288_tsdetectnet_medium_v1').resolve()
    a.out_dir=(a.out_dir or a.root/'output_b288_h1_cpu_13_20_v1').resolve()
    if not (a.root.is_dir() and a.package_dir.is_dir() and a.run_dir.is_dir()):
        raise RuntimeError('Missing root/B288 package/original B288 output; pass --package-dir or --run-dir if renamed')
    if not (a.out_dir.parent==a.root and a.out_dir.name.startswith('output_b288_h1_cpu_')):
        raise RuntimeError('Use a fresh direct output_b288_h1_cpu_* directory only')
    for old in (a.package_dir,a.run_dir):
        if a.out_dir==old or old in a.out_dir.parents or a.out_dir in old.parents:
            raise RuntimeError('New output must not overlap old package/results')
    if not (1<=a.cpu_threads<=4 and 1<=a.batch<=64):
        raise RuntimeError('Use1..4 CPU threads and batch1..64')
    if a.out_dir.exists() and any(a.out_dir.iterdir()):
        if not (a.out_dir/'protocol_frozen.json').is_file() or any(f.is_symlink() for f in a.out_dir.rglob('*')):
            raise RuntimeError('Existing output has no safe extension identity; preserve it')
    return a


def read_csv(path):
    with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))


def old_inputs(a):
    from b288_common import need,read_json,digest_file,code_hashes,fingerprint,validate_sources,generator,TRAIN_PASS
    from b288_score import completed_arrays
    from b288_report import cutoff
    validate_sources()
    score=a.run_dir/'pd_scr_medium';train=a.run_dir/'train_medium'
    p=read_json(score/'protocol_frozen.json');ct=read_json(train/'training_contract.json')
    need(p['version']=='B288_TSDETECTNET_MEDIUM_SCORE_V1' and p['scr_grid_db']==list(range(-24,13)),
         'Require the completed original B28837-point medium run')
    need(p['h1_scenes_n']==512 and p['nominal_pfas']==[1e-4,1e-3],'Unexpected H1 count or Pfa settings')
    need(ct==p['training_contract'] and ct['status']==TRAIN_PASS,'Training and score checkpoints differ')
    need(ct['run_config']['code_sha256']==code_hashes(),'Original B288 implementation changed; preserve source')
    need(ct['run_fingerprint']==fingerprint(ct['run_config']),'Training metadata fingerprint differs')
    need(digest_file(train/'best.pt')==ct['checkpoint_sha256'],'Selected B288 checkpoint changed')
    need(digest_file(generator().__file__)==p['generator_sha'],'Scene generator changed')
    arrays=completed_arrays(score,p)
    metrics=read_csv(score/'b288_metrics.csv');curves=read_csv(score/'b288_curves.csv')
    need(len(metrics)==2 and len(curves)==74,'Original complete metrics/curves are missing')
    thresholds={}
    for nominal in p['nominal_pfas']:
        matches=[r for r in metrics if float(r['nominal_pfa'])==nominal]
        need(len(matches)==1,'Ambiguous original Pfa metric row');m=matches[0]
        threshold=float(m['threshold']);derived,_,_=cutoff(arrays['h0_cal'],nominal)
        need(threshold==derived,'Old saved threshold differs from original CAL cutoff')
        fp=int((arrays['h0_audit']>threshold).sum())
        need(fp==int(m['audit_false_alarms']) and fp/len(arrays['h0_audit'])==float(m['actual_pfa']),
             'Old audit counts differ; no threshold adjustment performed')
        thresholds[nominal]=threshold
        rows=sorted([r for r in curves if float(r['nominal_pfa'])==nominal],key=lambda r:int(r['scr_db']))
        need([int(r['scr_db']) for r in rows]==p['scr_grid_db'],'Original curve grid differs')
        for j,r in enumerate(rows):
            hits=int((arrays['h1'][j]>threshold).sum())
            need(hits==int(r['hits']) and int(r['n_h1'])==512 and float(r['pd'])==hits/512,
                 'Old Pd CSV disagrees with saved H1 scores')
    paths=[train/'best.pt',train/'training_contract.json',score/'protocol_frozen.json',score/'progress.json',
           score/'b288_metrics.csv',score/'b288_curves.csv']
    from b288_common import FILES
    paths.extend(score/name for name in FILES.values())
    return dict(protocol=p,contract=ct,arrays=arrays,metrics=metrics,curves=curves,thresholds=thresholds,
                protected={str(f):digest_file(f) for f in paths})


def unchanged(info):
    from b288_common import need,digest_file
    need(all(digest_file(Path(path))==sha for path,sha in info['protected'].items()),'An old B288 input changed')
    return True


def load_model(a,info):
    from b288_common import load_checkpoint,need
    from b288_model import TSDetectNet
    ct=info['contract'];state=load_checkpoint(a.run_dir/'train_medium/best.pt')
    need(state['run_config']==ct['run_config'] and state['run_fingerprint']==ct['run_fingerprint'] and
         state['epoch']==ct['best_epoch'],'Checkpoint internal identity differs')
    model=TSDetectNet();model.load_state_dict(state['state_dict'],strict=True)
    return model.cpu().eval().requires_grad_(False)


def cpu_overlap(a,info,model):
    from b288_common import generator,need
    from b288_score import make_iq,predict
    p=info['protocol'];checks=[]
    # Reuse exactly the original scene IDs. No H0 inference is performed.
    for scr,n in [(0,min(64,p['h1_scenes_n'])),(12,p['h1_scenes_n'])]:
        j=p['scr_grid_db'].index(scr)
        iq=make_iq(generator(),p,'h1',np.arange(n),j)
        values=predict(model,iq,torch.device('cpu'),a.batch)
        old=info['arrays']['h1'][j,:n]
        maxabs=float(np.abs(values-old).max())
        need(np.allclose(values,old,rtol=1e-4,atol=2e-4),
             f'CPU/CUDA overlap scores differ excessively at SCR{scr}; preserve old outputs and inspect')
        disagreements={str(k):int(np.count_nonzero((values>t)!=(old>t))) for k,t in info['thresholds'].items()}
        need(not any(disagreements.values()),'CPU/CUDA overlap has threshold decision differences; no merged curve produced')
        checks.append(dict(scr_db=scr,n=n,maxabs_score_difference=maxabs,decision_disagreements=disagreements))
    return checks


def extend(a,info,model,p):
    from b288_common import need,read_json,write_json,generator
    from b288_score import make_iq,predict
    prpath=a.out_dir/'progress.json';path=a.out_dir/'h1_scores_13_20.npy'
    if prpath.exists():
        pr=read_json(prpath);need(pr['fingerprint']==p['fingerprint'],'Extension resume identity differs')
    else:
        need(not path.exists(),'Extension scores exist without commit metadata')
        pr=dict(fingerprint=p['fingerprint'],completed_scr=0);write_json(prpath,pr)
    n=p['h1_scenes_n'];done=pr['completed_scr']
    need(isinstance(done,int) and 0<=done<=8 and (done==0 or path.is_file()),'Invalid extension progress')
    values=np.lib.format.open_memmap(path,mode='r+' if path.exists() else 'w+',dtype='float64',shape=(8,n))
    need(values.shape==(8,n) and values.dtype==np.float64,'Wrong extension score shape/type')
    def infer(j,indices):
        iq=make_iq(generator(),p,'h1',indices,j)
        return predict(model,iq,torch.device('cpu'),a.batch)
    if done:
        for j in sorted({0,done-1}):
            indices=np.r_[np.arange(min(a.batch,n)),np.arange(max(a.batch,n-a.batch),n)]
            actual=infer(j,indices)
            need(np.allclose(actual,values[j,indices],rtol=1e-5,atol=2e-5),'Committed CPU scores changed on resume')
    for j in range(done,8):
        began=time.perf_counter();values[j]=infer(j,np.arange(n));values.flush()
        need(np.isfinite(values[j]).all(),'Nonfinite extension scores')
        pr['completed_scr']=j+1;write_json(prpath,pr)
        details='; '.join(f'Pfa={f:.0e}: Pd={float((values[j]>t).mean()):.4f}' for f,t in info['thresholds'].items())
        print(f'[CPU H1] SCR=+{p["scr_grid_db"][j]} dB {j+1}/8; {details}; {time.perf_counter()-began:.1f}s',flush=True)
    return values


def report(a,info,values,p):
    from b288_common import NAME,save_csv,write_json,digest_file
    from b288_report import wilson,crossing
    curves=[];metrics=[]
    for nominal in info['protocol']['nominal_pfas']:
        old=sorted([r for r in info['curves'] if float(r['nominal_pfa'])==nominal],key=lambda r:int(r['scr_db']))
        # Preserve old values verbatim. New scores have their CPU provenance recorded separately.
        rows=[dict(r) for r in old];threshold=info['thresholds'][nominal]
        for scr,v in zip(p['scr_grid_db'],values):
            count=int((v>threshold).sum());lo,hi=wilson(count,len(v))
            rows.append(dict(method=NAME,nominal_pfa=nominal,scr_db=scr,hits=count,n_h1=len(v),
                pd=count/len(v),pd_ci95_low=lo,pd_ci95_high=hi,diagnostic_auc_vs_H0_audit=''))
        curves.extend(rows);x=[int(r['scr_db']) for r in rows];y=np.array([float(r['pd']) for r in rows])
        oldmetric=next(r for r in info['metrics'] if float(r['nominal_pfa'])==nominal)
        top=float(y.max());peak=[scr for scr,pd in zip(x,y) if pd==top]
        m=dict(method=NAME,nominal_pfa=nominal,threshold=threshold,actual_pfa=float(oldmetric['actual_pfa']),
            audit_false_alarms=int(oldmetric['audit_false_alarms']),audit_n=int(oldmetric['audit_n']),
            max_pd=top,max_pd_scr_db=';'.join(map(str,peak)),pd_at_20=float(y[-1]),
            D50_db=crossing(x,y,.5),D80_db=crossing(x,y,.8),D90_db=crossing(x,y,.9),
            reached_0_8=bool(top>=.8),reached_0_9=bool(top>=.9),scr_points=45)
        metrics.append(m)
        print(f'Pfa={nominal:.0e}: MAX Pd={top:.4%} at SCR={peak}; Pd@20={y[-1]:.4%}; D80={m["D80_db"]}; D90={m["D90_db"]}',flush=True)
        save_csv(a.out_dir/f'b288_pd_source_extended_pfa_{nominal:.0e}.csv',rows)
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig,ax=plt.subplots(figsize=(8,5))
        ax.plot(x,y,color='tab:blue',marker='o',markerfacecolor='white',markersize=4,linewidth=1.7,
            linestyle='-',markevery=2,label=NAME)
        ax.axvline(12.5,color='gray',linestyle=':',linewidth=1)
        ax.text(13,.03,'CPU extension',fontsize=8,color='gray')
        ax.set(xlabel='SCR (dB)',ylabel=r'$P_d$',xlim=(-24,20),ylim=(0,1.02),
               title=r'$P_{\mathrm{fa}}=10^{'+str(int(round(np.log10(nominal))))+'}$')
        ax.grid(alpha=.25);ax.legend(fontsize=8);fig.tight_layout()
        for ext in ('pdf','png','svg'):fig.savefig(a.out_dir/f'b288_pd_scr_extended_pfa_{nominal:.0e}.{ext}',dpi=250)
        plt.close(fig)
    save_csv(a.out_dir/'b288_curves_extended.csv',curves)
    save_csv(a.out_dir/'b288_metrics_extended.csv',metrics)
    write_json(a.out_dir/'b288_extension_report.json',dict(status='PASS_B288_CPU_H1_13_20_COMPLETE',
        protocol_fingerprint=p['fingerprint'],metrics=metrics,only_existing_B288_loaded=True,
        training_executed=False,H0_inference_executed=False,thresholds_reused=True,
        GPU_used=False,CUDA_VISIBLE_DEVICES=os.environ['CUDA_VISIBLE_DEVICES'],
        original_score_device=info['protocol']['device'],extension_device='cpu',
        original_37_Pd_points_unchanged=True,CPU_vs_original_overlap_checks=p['overlap_checks'],
        raw_extension_sha256=digest_file(a.out_dir/'h1_scores_13_20.npy'),
        protected_old_inputs_unchanged=unchanged(info),independent_final=False,scope='Extended SCR diagnostic only'))


def main(argv=None):
    a=cli(argv);sys.path.insert(0,str(a.package_dir))
    from b288_common import need,read_json,write_json,fingerprint,digest_file
    torch.set_num_threads(a.cpu_threads);torch.set_num_interop_threads(1)
    need(not torch.cuda.is_initialized(),'CUDA was initialized before CPU-only runner')
    torch.manual_seed(20261022)
    info=old_inputs(a);model=load_model(a,info)
    a.out_dir.mkdir(exist_ok=True)
    with (a.root/'codex_b288_h1_cpu.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise RuntimeError('Another B288 CPU extension is active; do not start a duplicate')
        print('CPU ONLY; GPU hidden; no shared GPU lock; no training, no H0 inference.',flush=True)
        overlap=cpu_overlap(a,info,model)
        p=dict(version='B288_CPU_H1_13_20_V1',master_seed=info['protocol']['master_seed'],
            generator_sha=info['protocol']['generator_sha'],h1_split=info['protocol']['h1_split'],
            scr_grid_db=list(range(13,21)),h1_scenes_n=512,batch=a.batch,cpu_threads=a.cpu_threads,
            torch_version=str(torch.__version__),device='cpu',extension_code_sha256=digest_file(Path(__file__)),
            source_protocol_fingerprint=info['protocol']['fingerprint'],protected_old_inputs=info['protected'],
            frozen_thresholds={str(k):v for k,v in info['thresholds'].items()},overlap_checks=overlap)
        p['fingerprint']=fingerprint(p);pp=a.out_dir/'protocol_frozen.json'
        if pp.exists():need(read_json(pp)==p,'Extension settings/CPU overlap changed; preserve output')
        else:
            need(not any(a.out_dir.iterdir()),'Nonempty output without extension identity');write_json(pp,p)
        values=extend(a,info,model,p);report(a,info,values,p)
        need(not torch.cuda.is_initialized(),'CPU runner unexpectedly initialized CUDA')
        print('PASS_B288_CPU_EXTENSION_COMPLETE: '+str(a.out_dir),flush=True)


if __name__=='__main__':main()
