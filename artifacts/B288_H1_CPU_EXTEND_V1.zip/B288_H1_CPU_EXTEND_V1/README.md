# B288 CPU补充推理：+13至+20 dB

只加载已有TS-DetectNet检查点，新增8个SCR、每点512条H1，共4096条。
不训练、不重新推理H0、不重新选择阈值，不加载ADN或我们的方法。

本包是独立补充工具，必须放在原B288代码目录旁边，不能把本脚本复制进原B288代码目录，
否则会改变原包按Python源码文件计算的身份。

## 启动

解压到 `/root/autodl-tmp/MTDSP_NATIVE_LMDA_V1`，执行：

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
bash B288_H1_CPU_EXTEND_V1/start_on_autodl.sh
tail -F codex_b288_h1_cpu_13_20.log
```

强制CUDA_VISIBLE_DEVICES为空，模型和回波只放在CPU，默认2线程、batch32。
进程优先级降低，不占用共享GPU锁；GPU实验可以继续。
CPU任务仍会使用少量CPU和内存，具体耗时看逐点日志。
后台nohup运行，SSH断线不影响；进程或服务器中断后可用相同命令恢复已提交SCR。

默认读取：

```text
B288_TSDETECTNET_MEDIUM_V1/
output_b288_tsdetectnet_medium_v1/train_medium/best.pt
output_b288_tsdetectnet_medium_v1/train_medium/training_contract.json
output_b288_tsdetectnet_medium_v1/pd_scr_medium/
```

若此前重命名过目录，可添加 `--run-dir /实际B288输出目录` 或 `--package-dir /实际B288代码目录`。
缺文件会停止并报路径，不触发训练或H0补算。

## 冻结旧结果与CPU一致性

读取原Pfa=1e-4、1e-3阈值，核对它们与保存的H0 CAL和AUDIT分数一致。
原权重、CSV和原始分数均只读，开始与结束核对SHA256。
先在SCR=0的64条和SCR=+12的512条原H1上核对CPU分数，
要求分数数值近似且两种阈值下判决一致；失败时保留原结果并停止。
这不是重新运行完整旧范围，亦不用于重新选阈值或选择模型。

## 输出

新目录：`output_b288_h1_cpu_13_20_v1/`。

- `b288_curves_extended.csv`：原37点逐项保留，加8个CPU点，共45点、两种虚警率。
- `b288_metrics_extended.csv`：当前完整范围的最高Pd、所有峰值SCR、Pd@20和D50/D80/D90。
- `b288_pd_scr_extended_pfa_1e-04.pdf`、`b288_pd_scr_extended_pfa_1e-03.pdf`：扩展图。
- `b288_extension_report.json`：权重、阈值、CPU重放核对与原文件保护记录。
- `h1_scores_13_20.npy`：8×512个原始分数；`progress.json`支持恢复。

图保持蓝色实线、圆形标记，横轴延长到+20dB，在+12.5dB处标记CPU扩展起点。
不平移、不平滑、不强制单调。未达到0.8或0.9时如实留空，不外推。
新点采用CPU推理，旧点保持原设备结果；报告明确记录设备切换与重放核对。
本补充仍是既有SIM-R10 DEV诊断，不能据此宣称独立测试性能。
