# B273：B271＋残差SPWVD前端，中等规模实验

完整训练、推理、评分、绘图代码。以你已训练好的B271为起点，不包含数据或新权重，不声称已取得检测增益。

## 本轮实际改动

SPWVD借鉴Wang2024的式(4)，在复数IQ的时滞乘积阶段做时间和时滞平滑。**不是把已显示的WVD图片模糊**。原文未充分指定本项目所需的离散窗，本实现明确使用长度9的归一化Hann时间窗、半宽64的Hann时滞窗（共129点），保留原整数时滞FFT坐标q=2f(mod1)。

两组采用相同B271源权重、TRAIN/VAL行、既有TRAIN-only负样本池和损失：

- `plain`：普通SPWVD直接替换WVD前端，训练原B271的13,869个新增参数；原ADN/L1权重和BN冻结。
- `residual`：在取绝对值/对数之前，以有符号时频谱做残差混合：`R = W + alpha*(S-W)`。W为原WVD谱，S为SPWVD谱。混合系数有界于0～0.75，由**一个全局可学习标量**控制；不是逐样本或逐像素自适应门控。总可训练参数13,870。

残差组第0轮progress=0，直接使用冻结WVD缓存，精确复现B271；第1轮progress=0.5，第2轮起progress=1。完整进度下初始alpha=0.25（第1轮约0.125），随后可学习。所选检查点保存自己的progress和alpha，推理时不会强行改成全进度。

WCSG/TFCG、原最大池化、相位证据、两处有界重采样、IQ修正头和原B271损失均保留。本轮不加入AHPM。对照图中的AHPM是读取上轮结果。

## 运行规模与时间

默认两个新分支各4个epoch，训练16,000条、验证3,000条；行选择与B272相同。复用原B271的1280条TRAIN-only负样本池，不重新生成20万提案，不创建大型时频缓存。原始/平滑谱按8条IQ分块构造，减少前端瞬时内存。

只评估 nominal Pfa=1e-4：CAL500,000、H0 check200,000、每个SCR1024条H1，-24～12dB共37点。共737,888个评分场景。两个新分支共享谱计算，旧基线GPU推理次数为0。绘图后停止，不自动跑全量。

RTX3080Ti12GB上的准确耗时和显存仍需实测；相比B272，残差组还需要沿输入路径反传混合系数，预留约1～2小时更合适。首轮epoch和推理吞吐会给出更准确估计。CPU功能验证不代表GPU性能已测。

## AutoDL启动

下载 `B273_RESIDUAL_SPWVD_V1.zip` 并上传到：

`/root/autodl-tmp/MTDSP_NATIVE_LMDA_V1`

```bash
(
set -e
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
unzip -t B273_RESIDUAL_SPWVD_V1.zip >/dev/null
unzip -n B273_RESIDUAL_SPWVD_V1.zip
nohup /root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  bash B273_RESIDUAL_SPWVD_V1/run_b273_night.sh \
  >> codex_b273_spwvd_medium.log 2>&1 < /dev/null &
echo "后台PID：$!"
)
tail -F /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1/codex_b273_spwvd_medium.log
```

无需conda activate。使用B271/B272同一个 `codex_b271_night.lock`；请只启动一次。日志窗口Ctrl+C只退出查看。相同命令可恢复已提交epoch和推理前缀；原B271/B272文件不改动。

如只需单独运行一个环节：

```bash
/root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 bash B273_RESIDUAL_SPWVD_V1/run_b273_train.sh
/root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 bash B273_RESIDUAL_SPWVD_V1/run_b273_score.sh
```

如只想先跑残差候选，可在night/train命令末尾加 `--arms residual`；将少一个新候选，仍保留旧对照。但缺少普通SPWVD这一改造对照，默认建议保留两组。

## 复用哪些现有文件

代码从现有manifest中读取真实路径。默认需要保留：

1. `output_b271_phase_ars_v1/{run_manifest.json,guided/best.pt,guided/training_contract.json,train_h0_pool/pool.h5,train_h0_pool/contract.json}`。
2. `output_b272_b271_ahpm_v1/run_manifest.json`、`control/`和`ahpm3/`中的best.pt及training_contract.json。
3. B272的 `pd_scr_medium/` 中protocol、progress、三个npy评分数组、b272_curves.csv、b272_metrics.csv。
4. 原L1权重及训练契约、冻结30k/5k IQ数据、已重建WVD缓存与恢复证据、B213原评分协议和完成状态。

不需要找回旧Wang实验目录或Wang权重，不下载新依赖。使用现有mpdnet-r10环境。

启动前检查B272对照确实选中epoch0，且全部张量与B271相同；其4轮训练预算、seed、batch32、16k/3k行选择、base_lr3e-5、负样本池和损失与本轮匹配。修改这些预算项会要求新的匹配对照，不会默默复用不同预算。

训练只读取TRAIN/VAL与负样本池；评分时才打开CAL/AUDIT/H1数组，并重放旧基线各自阈值、误警次数及全部37个命中计数。每种方法用本轮500k CAL求自己的阈值。开发场景已被观察过，本轮仍是开发筛选，不是独立最终测试。

## 输出与判断

`output_b273_residual_spwvd_v1/`：

- `plain/`、`residual/`：best.pt、last_epoch.pt、训练历史、所选模型及前端alpha/progress。
- `pd_scr_medium/b273_curves.csv`、`b273_metrics.csv`、`b273_comparisons.csv`、`b273_report.json`。
- `pd_scr_medium/figures/b273_pd_scr_pfa_1e-04.{pdf,png,svg}`。

本文候选画为黑色虚线＋空心倒三角，横轴SCR(dB)，纵轴Pd；旧对照维持原样式，数据不平滑、不横移。

重点比较：

- residual vs B271_CONTROL：改造相对既有B271的净收益。
- residual vs plain：残差适配是否优于普通SPWVD替换。
- 两个分支的实际误警次数、区间和CE guard，而不只看D90。

负delta_D90表示左移。模型由VAL pAUC[0,.01]与相对源B271 CE+0.03条件选择，epoch0可以被选回。没有合格检查点时保留最佳CE诊断模型，`selected_passes_ce_guard=false`明确标记；程序PASS仅代表运行/校验完成。若residual选择epoch0且alpha=0，就是没有选出有效改进，不能宣称新模块有效。

## 研究归属

见 `METHOD_AND_SOURCES.md`、`provenance.json`、`VALIDATION.json`。SPWVD、残差混合或有界参数本身不是新发明；本轮验证的是这些适配与现有相位引导检测器能否形成有根据的互补。仅通过改名或增加模块不能保证创新性、1dB增益或期刊录用。
