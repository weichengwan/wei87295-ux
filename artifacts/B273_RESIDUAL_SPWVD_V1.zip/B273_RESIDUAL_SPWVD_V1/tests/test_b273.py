"""CPU functional checks; synthetic scenes/analytic curves are not detection results."""
from __future__ import annotations
import copy,csv,json,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import h5py
import numpy as np
import torch
import torch.nn.functional as F
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from b271_model import B271Net
from b271_data import digest_file,fingerprint,load_checkpoint,read_json,write_json
from b271_score import SCENE_KEYS,predictions as old_predictions
from b273_frontend import ResidualSPWVD
from b273_model import B273Net
from b273_source import verify_source,verify_pool
from b273_shared import Data,setup,tensors,validation
from source_loader import load_frozen_sources,load_frozen_file
import b273_train as train
import b273_score as score
import b273_cache as cache
import b273_report as report

def fixture(root):
    source,trainer,reference=load_frozen_sources();b210=load_frozen_file('r10_sim_stage_b210_a3_adn_earlystop_v1.py')
    generator=load_frozen_file('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
    bank=root/'bank';bank.mkdir();cache_dir=root/'cache';cache_dir.mkdir();cache=cache_dir/'maps.h5'
    with h5py.File(bank/b210.H5_NAME,'w') as raw,h5py.File(cache,'w') as maps:
        for split in ('train','val'):
            scenes=[generator.make_one(20261009,split,i,-30,10) for i in range(4)]
            iq=np.stack([s['iq'] for s in scenes]).astype('complex64');labels=np.array([s['label'] for s in scenes],dtype='uint8')
            g=raw.create_group(split);g['iq']=iq;g['target_iq']=np.stack([s['target'] for s in scenes]).astype('complex64');g['label']=labels
            h=maps.create_group(split);h['label']=labels;h['wvd']=source.wvd_base_map(torch.from_numpy(iq)).numpy()
    context=dict(root=root,bank_dir=bank,cache_dir=cache_dir,cache=cache,b210=b210,source=source,device=torch.device('cpu'),
        bc=dict(file_sha256=digest_file(bank/b210.H5_NAME),generator_sha256=digest_file(generator.__file__),seed=20261009),
        cc=dict(wvd_cache_sha256=digest_file(cache)))
    torch.manual_seed(3);original=trainer.ProposedWrapper(source,dict(reference.CFG))
    l1=dict(method='L1_TAIL',seed=20261022,epoch=1,cfg=reference.CFG,state_dict=original.state_dict(),
        source_sha256=b210.SOURCE_SHA,trainer_sha256=b210.TRAINER_SHA)
    l1_path=root/'l1.pt';torch.save(l1,l1_path);l1_sha=digest_file(l1_path)
    m=B271Net();m.load_l1_checkpoint(l1)
    with torch.no_grad():m.correction[-1].bias.fill_(.05)
    data=Data(context,4,4);val=validation(m,data,context,2)
    run_dir=root/'old';run_dir.mkdir();(run_dir/'guided').mkdir();(run_dir/'train_h0_pool').mkdir()
    pool=run_dir/'train_h0_pool/pool.h5'
    with h5py.File(pool,'w') as h:
        with h5py.File(cache,'r') as maps,h5py.File(bank/b210.H5_NAME,'r') as raw:
            h['iq']=raw['train/iq'][::2];h['wvd']=maps['train/wvd'][::2]
    pool_config=dict(split='b271_training_h0_v1',bank_sha=context['bc']['file_sha256'],generator_sha=context['bc']['generator_sha256'],
        baseline_checkpoint_sha=l1_sha,n_proposals=4)
    write_json(pool.with_name('contract.json'),dict(config=pool_config,fingerprint=fingerprint(pool_config),pool_sha256=digest_file(pool),
        original_cal_audit_dev_opened=False,retained=2))
    config=dict(bank_sha=context['bc']['file_sha256'],cache_sha=context['cc']['wvd_cache_sha256'],initialization_sha=l1_sha,
        code_sha=read_json(Path(train.__file__).parent/'b271_original_sources.json'),pool_sha=digest_file(pool),
        hard_weight=.05,consistency_weight=.05,warp_weight=.001)
    state=dict(state_dict=m.state_dict(),model_config=m.model_config,run_config=config,run_fingerprint=fingerprint(config),epoch=8,val_metrics=val)
    ck=run_dir/'guided/best.pt';torch.save(state,ck)
    write_json(ck.with_name('training_contract.json'),dict(status='PASS_B271_FROZEN_L1__TRAIN_VAL_ONLY',variant='guided',
        checkpoint_sha256=digest_file(ck),run_fingerprint=state['run_fingerprint'],best_epoch=8,model_config=m.model_config,initialization_sha256=l1_sha))
    write_json(run_dir/'run_manifest.json',dict(variants=['guided'],initialization_sha256=l1_sha,bank_dir=str(bank),cache_dir=str(cache_dir),proposal_count=4))
    verified=verify_source(run_dir,context,l1,l1_sha);verify_pool(verified,context)
    return context,data,l1,verified,pool,val,generator


def baseline_fixture(root,context,data,source,pool,args):
    directory=root/'b272';directory.mkdir();folder=directory/'pd_scr_medium';folder.mkdir()
    original=dict(master_seed=20261009,generator_sha=context['bc']['generator_sha256'],
        h0_cal_n=3000000,h0_audit_n=1000000,h1_scenes_n=1024,scr_grid_db=list(range(-24,13)),
        h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',family_names=list(load_frozen_file('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py').TRAIN_FAMILIES),scr_definition='fixture')
    original['scene_fingerprint']=fingerprint({k:original[k] for k in SCENE_KEYS})
    expected=read_json(Path(train.__file__).parent/'b272_original_sources.json');identities=[]
    for arm in ('control','ahpm3'):
        d=directory/arm;d.mkdir()
        config=dict(epochs=args.epochs,batch=args.batch,seed=args.seed,base_lr=args.base_lr,weight_decay=.001,
            selected_rows=data.selection,pool_sha256=digest_file(pool),
            losses={k:source['state']['run_config'][k] for k in ('hard_weight','consistency_weight','warp_weight')},code_sha256=expected)
        state=dict(state_dict=source['state']['state_dict'],epoch=0,run_fingerprint=fingerprint(config))
        torch.save(state,d/'best.pt');sha=digest_file(d/'best.pt')
        c=dict(status='PASS_B272_FROZEN_ADN_L1__TRAIN_VAL_ONLY',source_b271_sha256=source['sha256'],
            checkpoint_sha256=sha,best_epoch=0,epochs_executed=args.epochs,run_config=config,run_fingerprint=fingerprint(config))
        write_json(d/'training_contract.json',c);identities.append(dict(arm=arm,sha256=sha,selected_epoch=0))
    scene={k:original[k] for k in SCENE_KEYS};scene.update(h0_cal_n=500000,h0_audit_n=200000)
    p=dict(version='B272_B271_AHPM_SCORE_V1',**scene,scene_fingerprint=fingerprint(scene),
        source_b271_sha256=source['sha256'],original_checkpoint_sha256=source['original_l1_sha256'],
        original_full_scene_fingerprint=original['scene_fingerprint'],labels=['control','ahpm3','B271_frozen','L1_TAIL'],
        batch=args.batch,device='cpu',tf32=False,score_definition='float64(float32 logit1 - float32 logit0)',
        code_sha256=expected,checkpoints=identities)
    p['fingerprint']=fingerprint(p);write_json(folder/'protocol_frozen.json',p)
    write_json(directory/'run_manifest.json',dict(source_b271_sha256=source['sha256']))
    write_json(folder/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=500000,h0_audit=200000,h1=37)))
    n=500000;m=200000;ns=1024;cal=np.linspace(-6,6,n);audit=np.linspace(-6,6,m)
    q=(np.arange(ns)+.5)/ns;z=np.log(q/(1-q));h=np.stack([6+(scr-z)/3 for scr in range(-24,13)])
    c=np.stack([cal]*4,1);a=np.stack([audit]*4,1);hh=np.stack([h,h+.1,h,h-.2],2)
    for filename,x in [('h0_cal_scores.npy',c),('h0_audit_scores.npy',a),('dev_h1_scores.npy',hh)]:np.save(folder/filename,x)
    from b273_statistics import metrics_for,save_csv
    all_c=[];all_m=[]
    for col,name in zip(cache.BASELINE_COLUMNS,cache.BASELINE_NAMES):
        cc,mm=metrics_for(name,c[:,col],a[:,col],hh[:,:,col],dict(scr_grid_db=list(range(-24,13)),nominal_pfas=[1e-4]))
        all_c+=cc;all_m+=mm
    save_csv(folder/'b272_curves.csv',all_c);save_csv(folder/'b272_metrics.csv',all_m)
    return directory,original


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):setup(2)

    def test_original_identity_manual_complex_smoothing_and_q_grid(self):
        torch.manual_seed(9);f=ResidualSPWVD(time_length=5,lag_half=3,component_batch=1)
        x=torch.randn(2,512,dtype=torch.complex64);raw,smooth=f.components(x)
        source=load_frozen_sources()[0]
        torch.testing.assert_close(f.display(raw),source.wvd_base_map(x),rtol=0,atol=0)
        g=[0,.25,.5,.25,0];h=[0,.25,.75,1,.75,.25,0]
        for t in (0,128,256,511):
            products=np.zeros(512,dtype='complex128');a=x[0].numpy().astype('complex128')
            for ik,k in enumerate(range(-3,4)):
                for im,m in enumerate(range(-2,3)):
                    u=t+m
                    if 0<=u<512 and 0<=u+k<512 and 0<=u-k<512:
                        products[256+k]+=g[im]*h[ik]*a[u+k]*a[u-k].conjugate()
            expected=np.fft.fftshift(np.fft.fft(np.fft.ifftshift(products))).real
            np.testing.assert_allclose(smooth[0,t].numpy(),expected,atol=2e-6,rtol=2e-5)
        t=torch.arange(512);tone=torch.exp(2j*torch.pi*(30/512)*t)[None]
        f=ResidualSPWVD();_,s=f.components(tone);self.assertEqual(int(s[0,256].abs().argmax()),256+60)

    def test_residual_schedule_gradient_and_checkpoint_config(self):
        f=ResidualSPWVD();self.assertEqual(float(f.alpha()),0.)
        f.set_epoch(1,2);self.assertAlmostEqual(float(f.alpha()),.125,places=6)
        f.set_epoch(2,2);self.assertAlmostEqual(float(f.alpha()),.25,places=6)
        # Positive spectra with a fixed unique maximum avoid abs/max switching
        # during the finite-difference step; real-IQ network gradients are
        # independently exercised in the next test.
        torch.manual_seed(11)
        a=1+torch.rand(1,512,512);b=1+torch.rand(1,512,512)
        a[0,0,0]=10;b[0,0,0]=10;components=(a,b)
        loss=f.maps(components).square().mean();loss.backward()
        self.assertTrue(torch.isfinite(f.mix_logit.grad));self.assertGreater(float(f.mix_logit.grad.abs()),0.)
        original=float(f.mix_logit.detach());epsilon=.002
        with torch.no_grad():
            f.mix_logit.fill_(original+epsilon);plus=float(f.maps(components).square().mean())
            f.mix_logit.fill_(original-epsilon);minus=float(f.maps(components).square().mean())
        self.assertAlmostEqual(float(f.mix_logit.grad),(plus-minus)/(2*epsilon),delta=5e-5)
        with torch.no_grad():f.mix_logit.fill_(100.)
        self.assertLessEqual(float(f.alpha()),.75)

    def test_b271_exact_initialization_and_real_scalar_backprop(self):
        with tempfile.TemporaryDirectory() as t:
            context,data,l1,source,pool,ref,gen=fixture(Path(t));maps,iq,_=data.fetch('val',[0,1]);images,x=tensors(context,maps,iq)
            baseline=B271Net();baseline.load_state_dict(source['state']['state_dict']);baseline.eval()
            m=B273Net();m.initialize_b271(source['state']);m.eval()
            with torch.no_grad():torch.testing.assert_close(m(images,x),baseline(images,x),rtol=0,atol=0)
            self.assertEqual(sum(p.numel() for p in m.parameters() if p.requires_grad),13870)
            m.frontend.set_epoch(1);m.train();m(images,x).square().mean().backward()
            self.assertGreater(float(m.frontend.mix_logit.grad.abs()),0.)
            self.assertFalse(m.detector.bn1.training)
            for key,v in l1['state_dict'].items():self.assertTrue(torch.equal(v,m.state_dict()[key]))
            data.close()

    def test_actual_training_resume_matches_uninterrupted_and_original_frozen(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);context,data,l1,source,pool,ref,gen=fixture(root)
            a=train.cli(['--root',t,'--out-dir',str(root/'new'),'--epochs','2','--batch','2','--train-limit','4','--val-limit','4','--device','cpu','--resume'])
            a.out_dir.mkdir();save=train.atomic_save;interrupted=[False]
            def stop(path,value):
                save(path,value)
                if path.name=='last_epoch.pt' and value['epoch']==1 and not interrupted[0]:
                    interrupted[0]=True;raise InterruptedError('simulated process interruption after committed epoch')
            with patch.object(train,'atomic_save',side_effect=stop):
                with self.assertRaises(InterruptedError):train.train_one(a,context,data,source,l1,pool,'residual',ref)
            c=train.train_one(a,context,data,source,l1,pool,'residual',ref)
            first=load_checkpoint(a.out_dir/'residual/last_epoch.pt')
            self.assertEqual(len(first['history']),2)
            self.assertNotEqual(float(first['state_dict']['frontend.mix_logit']),float(torch.tensor(np.log(.25/(.75-.25)),dtype=torch.float32)))
            a.out_dir=root/'uninterrupted';a.out_dir.mkdir();train.train_one(a,context,data,source,l1,pool,'residual',ref)
            second=load_checkpoint(a.out_dir/'residual/last_epoch.pt')
            for key,v in first['state_dict'].items():self.assertTrue(torch.equal(v,second['state_dict'][key]),key)
            for key,v in l1['state_dict'].items():self.assertTrue(torch.equal(v,second['state_dict'][key]))
            train.train_one(a,context,data,source,l1,pool,'plain',ref)
            data.close()

    def test_cached_control_metadata_budget_and_all_hits_replay(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);context,data,l1,source,pool,ref,gen=fixture(root)
            args=train.cli(['--root',t,'--epochs','2','--batch','2','--train-limit','4','--val-limit','4','--device','cpu'])
            directory,original=baseline_fixture(root,context,data,source,pool,args)
            info=cache.metadata(directory,source,context,original,2,torch.device('cpu'),args,data.selection)
            arrays,details=cache.arrays(info);self.assertEqual(arrays['h0_cal'].shape,(500000,3))
            self.assertTrue(details['all_baseline_thresholds_false_alarms_hits_replayed'])
            args.epochs=3
            with self.assertRaisesRegex(RuntimeError,'budget differs'):cache.metadata(directory,source,context,original,2,torch.device('cpu'),args,data.selection)
            bad=directory/'pd_scr_medium/h0_audit_scores.npy'
            x=np.load(bad,mmap_mode='r+');x[0,0]+=1;x.flush();del x
            with self.assertRaisesRegex(RuntimeError,'does not replay'):cache.arrays(info)
            data.close()

    def test_real_stream_shared_components_cached_columns_and_resume(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);context,data,l1,source,pool,ref,gen=fixture(root);models=[]
            for arm in ('plain','residual'):
                m=B273Net(arm);m.initialize_b271(source['state']);m.frontend.set_epoch(2);m.eval();models.append(m)
            cached=dict(h0_cal=np.zeros((4,3)),h0_audit=np.zeros((4,3)),h1=np.zeros((2,2,3)))
            p=dict(version=score.VERSION,master_seed=20261009,h0_cal_n=4,h0_audit_n=4,h1_scenes_n=2,scr_grid_db=[0,3],
                h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',labels=['plain','residual','B271_CONTROL','AHPM_REFERENCE','L1_TAIL'])
            p['fingerprint']=fingerprint(p);a=SimpleNamespace(out_dir=root/'score',batch=2,chunk=2)
            score.stream(a,p,gen,models,context['source'],context['device'],cached)
            result=np.load(a.out_dir/'h0_cal_scores.npy');self.assertEqual(result.shape,(4,5))
            np.testing.assert_array_equal(result[:,2:],cached['h0_cal'])
            iq=np.stack([gen.make_one(20261009,'h0_cal',i,-30,10)['base'] for i in range(2)]).astype('complex64')
            with torch.no_grad():
                direct=models[1](None,torch.from_numpy(iq));direct=(direct[:,1]-direct[:,0]).double().numpy()
            np.testing.assert_array_equal(result[:2,1],direct)
            progress=read_json(a.out_dir/'progress.json');progress['completed']['h0_cal']=2;write_json(a.out_dir/'progress.json',progress)
            x=np.load(a.out_dir/'h0_cal_scores.npy',mmap_mode='r+');x[2:]=np.nan;x.flush();del x
            score.stream(a,p,gen,models,context['source'],context['device'],cached)
            np.testing.assert_array_equal(np.load(a.out_dir/'h0_cal_scores.npy'),result)
            (a.out_dir/'dev_h1_scores.npy').unlink()
            with self.assertRaisesRegex(RuntimeError,'missing despite committed'):score.stream(a,p,gen,models,context['source'],context['device'],cached)
            data.close()

    def test_medium_report_known_shift_and_triangle_axes(self):
        with tempfile.TemporaryDirectory() as t:
            out=Path(t);n=500000;m=200000;ns=1024;levels=list(range(-24,13));labels=['plain','residual','B271_CONTROL','AHPM_REFERENCE','L1_TAIL']
            cal=np.linspace(-6,6,n);audit=np.linspace(-6,6,m);q=(np.arange(ns)+.5)/ns;z=np.log(q/(1-q))
            h=np.stack([6+(scr-z)/3 for scr in levels])
            np.save(out/'h0_cal_scores.npy',np.stack([cal]*5,1));np.save(out/'h0_audit_scores.npy',np.stack([audit]*5,1))
            np.save(out/'dev_h1_scores.npy',np.stack([h,h+2/3,h,h,h],2))
            p=dict(version=score.VERSION,nominal_pfas=[1e-4],h0_cal_n=n,h0_audit_n=m,h1_scenes_n=ns,scr_grid_db=levels,
                labels=labels,checkpoints=[],training_budget={},reused_baselines={},scope='Analytic functional fixture; not detection performance')
            p['fingerprint']=fingerprint(p);write_json(out/'protocol_frozen.json',p)
            write_json(out/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=n,h0_audit=m,h1=37)))
            r=report.generate(out);self.assertFalse(r['automatic_promotion'])
            row=next(x for x in r['comparisons'] if x['candidate']=='residual' and x['reference']=='plain')
            self.assertAlmostEqual(row['delta_D90_db'],-2.,places=10)
            self.assertTrue((out/'figures/b273_pd_scr_pfa_1e-04.pdf').is_file())
            manifest=read_json(out/'figures/b273_curves_paper_manifest.json')
            self.assertEqual(manifest['styles']['B271 + residual SPWVD']['marker'],'v')
            self.assertTrue(manifest['source_values_unchanged'])

    def test_medium_defaults_and_night_lock_sequencing(self):
        import fcntl,b273_run as runner
        a=train.cli([]);self.assertEqual((a.epochs,a.train_limit,a.val_limit,a.batch),(4,16000,3000,32))
        self.assertEqual(a.arms,['plain','residual'])
        with tempfile.TemporaryDirectory() as t:
            calls=[]
            with patch.object(sys,'argv',['b273_run.py','--root',t,'--device','cpu']),patch.object(train,'main',side_effect=lambda _:calls.append('train')),patch.object(score,'main',side_effect=lambda _:calls.append('score')):
                runner.main();self.assertEqual(calls,['train','score']);calls.clear()
                with patch.object(train,'main',side_effect=RuntimeError('training failed')):
                    with self.assertRaises(RuntimeError):runner.main()
                self.assertEqual(calls,[])
                with (Path(t)/'codex_b271_night.lock').open('a') as lock:
                    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
                    with self.assertRaisesRegex(SystemExit,'Another B271/B272/B273'):runner.main()


if __name__=='__main__':unittest.main(verbosity=2)
