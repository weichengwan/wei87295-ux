# B273来源、实际适配和论文可检验主张

Wang,K.; Wang,Z. *A Triple-Channel Network for Maritime Radar Targets Detection Based on Multi-Modal Features*. Remote Sensing2024,16,4662. DOI https://doi.org/10.3390/rs16244662 。用户上传原文2.3节式(4)定义SPWVD；3.2节时频分支是SPWVD+ResNet18，3.3节SE用于多分支融合且引用SENet。SPWVD属于更早的时频分析方法，不能将其基础公式认作本项目发明。

式(4)的关键是在复数时滞乘积C(t,k)=x(t+k)conj(x(t-k))上先计算C_s(t,k)=h(k)sum_m g(m)C(t+m,k)，再沿k做FFT。B273在取绝对值和log之前使用有符号实谱W和S；R=W+alpha(S-W)与FFT的线性关系相容。它与模糊已归一化WVD图不同。

声明的工程重构：512点原整数时滞FFT、Hann9归一化时间窗、中心Hann129时滞窗、零边界、原q=2f(mod1)混叠坐标、原60dB峰值相对显示和128→224双线性resize。原论文没有给出足以恢复用户旧Wang运行的全部离散参数；本轮不是旧Wang结果复现，也不是作者代码移植。

针对已有ADN/L1/B271检查点做的适配：

1. 保留原坐标、显示归一化与输入尺寸，使相位证据引导仍在对应位置。
2. 原WVD保真残差与平滑谱在有符号域混合，系数上限0.75，至少保留一定原谱贡献。
3. 混合仅新增一个全局可学习参数，不声称逐样本自适应。学习率1e-3、无weight decay；B271新增模块继续用3e-5。
4. 第0轮严格复现原检查点，第1/2轮progress0.5/1，所选状态完整保存。原骨干及BN不变。
5. 同预算普通SPWVD对照、旧B271匹配继续训练对照、上轮AHPM与L1曲线一并保留。

可检验研究假设：前端抑制交叉项，可能降低伪时频响应对后续相位引导取样的干扰；保留原谱可能缓解纯平滑输入对冻结骨干的分布偏移。SPWVD也会展宽自项、损失分辨率，因此改进不是必然。若普通SPWVD同样好或更好，不能声称残差改造有独立价值；若residual选回epoch0，不能写成训练出新检测增益。

B271本体参考SFM自适应采样思想：Chen et al., *Spatial Frequency Modulation for Semantic Segmentation*, IEEE TPAMI2025, DOI https://doi.org/10.1109/TPAMI.2025.3592621 。B271是独立实现的相位条件有界残差采样与IQ修正头，不是官方SaliencySampler的移植。原始ADN/L1的WCSG/TFCG与tail损失沿用已有代码，其收益不能算作B273新增贡献。

本轮不从LMDA取新模块；AHPM只作为缓存参考曲线存在。借鉴的来源保留，论文贡献应落在真实适配和经消融支持的收益上。SPWVD借鉴不自动要求复现整个Wang三通道网络，但若论文声称优于某方法，则需要同协议公平比较。

统计口径：nominalPfa1e-4，每种模型独立CAL阈值，独立H0 check及Wilson区间；所有37点保留，不改变SCR轴。当前场景已用于开发，最终结论还需要冻结方案后的独立实测/测试及贡献归因消融。
