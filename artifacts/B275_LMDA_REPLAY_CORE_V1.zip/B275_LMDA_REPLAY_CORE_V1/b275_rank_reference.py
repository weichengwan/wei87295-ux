"""Read frozen B227 expert scores and form the predeclared75/25 rank reference.

No learning or new baseline inference. The old3M ECDF is retained; this run
uses its own500k final threshold, so it is not the old3M-threshold curve.
"""
from pathlib import Path
import numpy as np
from b271_data import digest_file,need,read_json
from b275_core import OLD_WEIGHT_SHA

P222_SHA='f89991214c8fc9c5c8e1871d4ea43123dc86d1d5f5917c584d43b8a9354368af'
P223_SHA='2f8ed8335e5ad8570aef99a7d1831f217dd63e012fcef6e38b4aa8a16183b631'


def metadata(root,original):
    root=Path(root)
    l1=root/'output_sim_r10_b222_gpu_dualpfa_v1/seed_20261022'
    lmda=root/'output_sim_r10_b223_external_baselines_v1/dl/LMDA_PF/seed_20261022'
    for directory,expected in [(l1,P222_SHA),(lmda,P223_SHA)]:
        need(digest_file(directory/'protocol_frozen.json')==expected,'Frozen B227 source protocol changed')
        for f in ('h0_cal_scores.npy','h0_audit_scores.npy','dev_h1_scores_37.npy'):need((directory/f).is_file(),'Missing frozen rankmix source: '+str(directory/f))
    p1,p2=read_json(l1/'protocol_frozen.json'),read_json(lmda/'protocol_frozen.json')
    need(p1['scene_fingerprint']==p2['b213_scene_fingerprint']==original['scene_fingerprint'] and
         p2['checkpoint_sha256']==OLD_WEIGHT_SHA and p1['methods'][1]=='L1-Tail','Frozen rankmix source identity differs')
    return dict(l1=l1,lmda=lmda,source_protocol_sha256=[P222_SHA,P223_SHA])


def arrays(info,cached):
    raw={};hashes={}
    for key,name,shape in [('h0_cal','h0_cal_scores.npy',(3000000,)),('h0_audit','h0_audit_scores.npy',(1000000,)),('h1','dev_h1_scores_37.npy',(37,1024))]:
        left=np.load(info['l1']/name,mmap_mode='r',allow_pickle=False)
        right=np.load(info['lmda']/name,mmap_mode='r',allow_pickle=False)
        need(left.shape==shape+(4,) and right.shape==shape+(1,) and left.dtype==right.dtype==np.dtype('float64'),'Frozen expert score shape differs')
        raw[key]=(left[...,1],right[...,0])
        for folder,label in [(info['l1'],'L1'),(info['lmda'],'LMDA')]:hashes[label+'/'+name]=digest_file(folder/name)
    need(all(np.isfinite(v).all() for v in raw['h0_cal']),'Nonfinite full historical ECDF support')
    l1_sort=np.sort(raw['h0_cal'][0]);lmda_sort=np.sort(raw['h0_cal'][1]);out={}
    for key,(left,right) in raw.items():
        n=500000 if key=='h0_cal' else 200000 if key=='h0_audit' else None
        if n is not None:left,right=left[:n],right[:n]
        need(np.isfinite(left).all() and np.isfinite(right).all(),'Nonfinite expert scores')
        ranks_l1=np.searchsorted(l1_sort,left,side='left')/len(l1_sort)
        ranks_lmda=np.searchsorted(lmda_sort,right,side='left')/len(lmda_sort)
        fused=.75*ranks_lmda+.25*ranks_l1
        out[key]=np.concatenate([cached[key],right[...,None],fused[...,None]],axis=-1)
    return out,dict(source_protocol_sha256=info['source_protocol_sha256'],source_array_sha256=hashes,
        fixed_lmda_weight=.75,expert_ECDF_support=3000000,final_own_CAL_support=500000,
        same_as_historical_B227_threshold=False,additional_expert_GPU_forwards=0)
