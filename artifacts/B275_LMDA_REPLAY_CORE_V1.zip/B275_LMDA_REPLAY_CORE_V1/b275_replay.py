"""Read-only existing LMDA-PF checkpoint, full VAL and H0-prefix replay."""
from __future__ import annotations
import pickle
from pathlib import Path
import h5py
import numpy as np
import torch
import torch.nn.functional as F
from b271_data import digest_file,need,read_json,write_json
from b271_score import original_protocol
from b274_data import resolve
from b275_core import PaperNet,architecture_audit,SOURCE_SHA,OLD_WEIGHT,OLD_WEIGHT_SHA


def compatible_state(payload,expected):
    """Accept an entire exact state dictionary; never discard unmatched tensors."""
    candidates=[('root',payload)]
    if isinstance(payload,dict):
        for key,value in payload.items():
            if isinstance(value,dict):candidates.append((str(key),value))
    for label,state in candidates:
        if not isinstance(state,dict):continue
        for prefix in ('','net.','model.','module.'):
            if prefix and not all(isinstance(k,str) and k.startswith(prefix) for k in state):continue
            mapped={k[len(prefix):]:v for k,v in state.items()} if prefix else state
            if set(mapped)==set(expected) and all(torch.is_tensor(v) and v.shape==expected[k].shape for k,v in mapped.items()):
                return mapped,dict(field=label,common_prefix_removed=prefix)
    raise RuntimeError('Existing checkpoint does not contain the exact PF state keys/shapes; inspect its metadata, do not approximate-load')


@torch.inference_mode()
def val_replay(model,context,batch,device):
    model.eval();loss=0.;correct=0;n=0
    with h5py.File(context['bank_path'],'r') as bank:
        group=bank['val']
        for start in range(0,len(group['label']),batch):
            stop=min(start+batch,len(group['label']))
            x=torch.from_numpy(np.asarray(group['iq'][start:stop],dtype='complex64')).to(device)
            y=torch.from_numpy(np.asarray(group['label'][start:stop],dtype='int64')).to(device)
            z=model(x);loss+=float(F.cross_entropy(z,y,reduction='sum'));correct+=int((z.argmax(1)==y).sum());n+=len(y)
    return dict(n_val=n,val_ce=loss/n,val_acc=correct/n)


@torch.inference_mode()
def prefix_replay(root,model,context,batch,device,count=256):
    folder=Path(root)/'output_sim_r10_b223_external_baselines_v1/dl/LMDA_PF/seed_20261022'
    if not (folder/'protocol_frozen.json').is_file():return dict(available=False,reason='Old B223 protocol absent')
    _,original,generator=original_protocol(root,context)
    p=read_json(folder/'protocol_frozen.json')
    need(p['checkpoint_sha256']==OLD_WEIGHT_SHA and p['b213_scene_fingerprint']==original['scene_fingerprint'],'Old LMDA reference source/scenes differ')
    result={}
    for split in ('h0_cal','h0_audit'):
        path=folder/(split+'_scores.npy')
        if not path.is_file():result[split]=dict(available=False);continue
        ref=np.load(path,mmap_mode='r',allow_pickle=False)
        need(ref.dtype==np.dtype('float64') and ref.shape==(p[split+'_n'],1),'Old LMDA reference score shape differs')
        x=np.stack([generator.make_one(original['master_seed'],original[split+'_split'],i,-30,10)['base'] for i in range(count)]).astype('complex64')
        f32=[];f64=[]
        for start in range(0,count,batch):
            z=model(torch.from_numpy(x[start:start+batch]).to(device))
            f32.extend((z[:,1]-z[:,0]).double().cpu().tolist())
            f64.extend((z[:,1].double()-z[:,0].double()).cpu().tolist())
        reference=np.asarray(ref[:count,0])
        stats={}
        for label,values in [('float32_margin',f32),('float64_subtract',f64)]:
            delta=np.asarray(values)-reference
            stats[label]=dict(maxabs=float(np.abs(delta).max()),rmse=float(np.sqrt((delta**2).mean())),n=count)
        result[split]=dict(available=True,stats=stats,within_1e4=any(v['maxabs']<=1e-4 for v in stats.values()),
            reference_file_sha256=digest_file(path))
    return result


def replay(a):
    report=architecture_audit();path=a.root/OLD_WEIGHT
    report.update(mode='readonly_replay',checkpoint_path=str(path),historical_curve_reproduction_established=False,
        official_IPIX_paper_results_reproduced=False,learning_performed=False)
    out=a.out_dir/'b275_replay_report.json'
    out.parent.mkdir(parents=True,exist_ok=True)
    try:
        need(path.is_file(),'Existing LMDA-PF checkpoint missing: '+str(path))
        need(digest_file(path)==OLD_WEIGHT_SHA,'Existing LMDA-PF checkpoint SHA differs')
        contract=read_json(path.with_name('training_contract.json'))
        need(contract['checkpoint_sha256']==OLD_WEIGHT_SHA and contract['original_source_sha256']==SOURCE_SHA and
             contract['train_steps']==5610,'Historical LMDA contract/source differs')
        # Only this known-SHA, user-owned historical checkpoint may need old
        # numpy metadata unpickling. Arbitrary checkpoints are never loaded here.
        try:payload=torch.load(path,map_location='cpu',weights_only=True)
        except (TypeError,pickle.UnpicklingError):payload=torch.load(path,map_location='cpu',weights_only=False)
        model=PaperNet();state,location=compatible_state(payload,model.net.state_dict())
        model.net.load_state_dict(state,strict=True);model.to(a.device).eval()
        report.update(checkpoint_sha256=OLD_WEIGHT_SHA,state_location=location,strict_state_loaded=True,
            historical_train_steps=contract['train_steps'])
        context=resolve(a.root,a.bank_dir)
        need(contract['training_bank_sha256']==context['bc']['file_sha256'],'Historical training bank differs')
        result=val_replay(model,context,a.batch,a.device);old=contract['val_metrics']
        difference=abs(result['val_ce']-float(old['val_ce']))
        report.update(validation=result,historical_validation=old,val_ce_difference=difference,val_replay_pass=difference<=1e-4)
        prefix=prefix_replay(a.root,model,context,a.batch,a.device)
        report['h0_prefix']=prefix
        available=[prefix.get(split,{}) for split in ('h0_cal','h0_audit')]
        report['h0_prefix_replay_pass']=all(x.get('available') and x.get('within_1e4') for x in available)
        report['status']='PASS_EXISTING_LMDA_PF_REPLAY' if report['val_replay_pass'] and report['h0_prefix_replay_pass'] else 'REPLAY_NOT_EXACT__PRESERVE_EXISTING_RESULTS'
        report['reuse_old_thresholds_authorized']=False
    except Exception as error:
        report.update(status='REPLAY_BLOCKED',error=f'{type(error).__name__}: {error}')
        write_json(out,report)
        raise
    write_json(out,report)
    print(f"{report['status']}; VAL CE difference={report['val_ce_difference']:.3g}; report={out}",flush=True)
    print('No model trained or old result overwritten. Prefix agreement does not replace full CAL/AUDIT.',flush=True)
    return report
