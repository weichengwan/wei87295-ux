"""Medium paired scoring of a freshly trained PF reconstruction plus fixed rankmix."""
from pathlib import Path
import torch
from b271_data import device_for,digest_file,fingerprint,load_checkpoint,need,read_json
from b271_score import original_protocol,SCENE_KEYS
from b274_data import resolve
from b274_baselines import metadata,arrays
from b273_score import stream
from b275_core import PaperNet,METHOD
from b275_train import PASS,code_hashes
from b275_rank_reference import metadata as rank_metadata,arrays as rank_arrays


class AlreadyMapped:
    @staticmethod
    def map_to_adn_input(images):
        need(images.shape[1:]==(3,128,128),'Expected complete historical STFT image')
        return images


def score(a):
    run_dir=a.out_dir/'fresh';contract=read_json(run_dir/'training_contract.json');config=contract['run_config']
    need(contract['status']==PASS and config['code_sha256']==code_hashes(),'Fresh PF source changed or training unfinished')
    context=resolve(a.root,config['bank_dir']);_,original,generator=original_protocol(a.root,context)
    need(config['bank_sha256']==context['bc']['file_sha256'],'Fresh PF IQ bank changed')
    info=metadata(a.root/'output_b273_residual_spwvd_v1/pd_scr_medium',context,original,a.device,config['selected_rows'])
    cached,reuse=arrays(info);cached,rank=rank_arrays(rank_metadata(a.root,original),cached)
    checkpoint=run_dir/'final.pt';need(digest_file(checkpoint)==contract['checkpoint_sha256'],'Fresh PF checkpoint changed')
    state=load_checkpoint(checkpoint)
    need(state['run_config']==config and state['run_fingerprint']==contract['run_fingerprint'] and state['step']==contract['selected_step'],'Fresh checkpoint identity differs')
    model=PaperNet();model.load_state_dict(state['state_dict'],strict=True);model.to(a.device).eval()
    labels=info['p']['labels']+['OLD_LMDA','RANKMIX75'];names={**info['names'],'OLD_LMDA':'Frozen LMDA-PF','RANKMIX75':'Fixed rank mix LMDA75/L125 (medium CAL)'}
    scene={k:original[k] for k in SCENE_KEYS};scene.update(h0_cal_n=500000,h0_audit_n=200000)
    protocol=dict(version='B275_LMDA_PF_MEDIUM_SCORE_V1',**scene,scene_fingerprint=fingerprint(scene),nominal_pfas=[1e-4],
        labels=['SINGLE']+labels,names={'SINGLE':METHOD,**names},backend={'kind':'verified historical PF source; freshly trained'},
        checkpoint=dict(sha256=contract['checkpoint_sha256'],selected_step=contract['selected_step'],validation=contract['selected_validation']),
        reused_baselines={'B273':reuse,'B227_fixed_experts':rank},batch=32,device=a.device.type,tf32=False,
        code_sha256=code_hashes(),scope='Previously exposed SIM DEV; fixed5610 fresh reconstruction; not original IPIX or independent FINAL')
    protocol['fingerprint']=fingerprint(protocol)
    from types import SimpleNamespace
    args=SimpleNamespace(out_dir=a.out_dir/'pd_scr_medium',batch=32,chunk=512)
    print('B275 medium scoring:500k CAL,200k CHECK,1024H1x37SCR; only new PF model uses GPU',flush=True)
    stream(args,protocol,generator,[model],AlreadyMapped(),a.device,cached)
    from b275_report import generate
    return generate(args.out_dir)
