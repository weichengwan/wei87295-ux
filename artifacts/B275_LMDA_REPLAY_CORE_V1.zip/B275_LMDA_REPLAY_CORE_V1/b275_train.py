"""LMDA-PF fresh SIM reconstruction: Adam1e-3,batch32,5610 fixed updates.

This is the paper's training budget on the user's frozen SIM bank, not an
IPIX experimental reproduction. Final update selects weights, never DEV Pd.
"""
from __future__ import annotations
import time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from b271_data import digest_file,fingerprint,load_checkpoint,need,read_json,write_json
from b273_shared import atomic_save
from b273_statistics import save_csv
from b274_data import Data,resolve
from b274_train import evaluate
from b275_core import PaperNet,SOURCE_SHA

PASS='PASS_B275_LMDA_PF_FIXED_BUDGET_TRAIN_VAL_ONLY'


def code_hashes():
    return {p.name:digest_file(p) for p in sorted(Path(__file__).parent.glob('*.py'))}


def train(a,context=None,data=None):
    context=context or resolve(a.root,a.bank_dir)
    data=data or Data(context,a.train_limit,a.val_limit,a.seed)
    directory=a.out_dir/'fresh';directory.mkdir(parents=True,exist_ok=True)
    config=dict(version='B275_LMDA_PF_TRAIN_V1',seed=a.seed,steps=a.steps,batch=32,lr=.001,weight_decay=0.,
        source_sha256=SOURCE_SHA,bank_sha256=context['bc']['file_sha256'],bank_dir=str(context['bank_dir']),
        selected_rows=data.selection,code_sha256=code_hashes(),sampling='balanced TRAIN-only replacement; independent step seed',
        input='historical PF STFT adapter unchanged',selection='FINAL update only; no VAL/DEV checkpoint selection')
    fp=fingerprint(config);manifest=directory/'run_manifest.json';latest=directory/'last_step.pt';final=directory/'final.pt';cp=directory/'training_contract.json'
    if manifest.exists():need(read_json(manifest)==dict(run_config=config,run_fingerprint=fp),'Fresh LMDA config changed; use a new output directory')
    else:
        need(not any(directory.iterdir()),'Nonempty fresh output without manifest')
        write_json(manifest,dict(run_config=config,run_fingerprint=fp))
    if cp.exists():
        c=read_json(cp);need(c['status']==PASS and c['run_fingerprint']==fp and digest_file(final)==c['checkpoint_sha256'],'Fresh LMDA checkpoint changed')
        print('Fresh LMDA already complete and verified',flush=True);return c
    torch.manual_seed(a.seed);model=PaperNet().to(a.device)
    optimizer=torch.optim.Adam(model.parameters(),lr=.001)
    start=1;history=[]
    if latest.exists():
        state=load_checkpoint(latest);need(state['run_fingerprint']==fp,'Resume config differs')
        model.load_state_dict(state['state_dict'],strict=True);optimizer.load_state_dict(state['optimizer'])
        start=state['step']+1;history=state['history'];torch.set_rng_state(state['torch_rng'])
        if a.device.type=='cuda':torch.cuda.set_rng_state_all(state['cuda_rng'])
    else:need(not final.exists(),'Final weights without completed state; preserve and use a new output')
    labels=data.values['train'][1];h0=np.flatnonzero(labels==0);h1=np.flatnonzero(labels==1)
    need(len(h0) and len(h1),'Both TRAIN classes required')
    began=time.perf_counter()
    print(f'LMDA-PF | all {sum(p.numel() for p in model.parameters()):,} parameters train | updates {start}..{a.steps}',flush=True)
    for step in range(start,a.steps+1):
        rng=np.random.default_rng(a.seed+997*step)
        index=rng.permutation(np.r_[rng.choice(h0,16,replace=True),rng.choice(h1,16,replace=True)])
        x,y=data.fetch('train',index,a.device);model.train();optimizer.zero_grad(set_to_none=True)
        logits=model(x);loss=F.cross_entropy(logits,y);need(torch.isfinite(loss).item(),'Nonfinite LMDA objective')
        loss.backward();optimizer.step()
        if step%500==0 or step==a.steps:
            metrics=evaluate(model,data,a.device,32)
            history.append(dict(step=step,train_batch_ce=float(loss.detach()),**metrics))
            save_csv(directory/'train_val_history.csv',history)
            rate=(step-start+1)/max(time.perf_counter()-began,1e-6)
            print(f'[LMDA-PF] {step}/{a.steps} VAL_CE={metrics["val_ce"]:.6f} pAUC01={metrics["val_pauc01"]:.6f} remaining~{(a.steps-step)/max(rate,1e-9)/60:.1f}min',flush=True)
        if step%250==0 or step==a.steps:
            state=dict(state_dict=model.state_dict(),step=step,run_config=config,run_fingerprint=fp,history=history,
                optimizer=optimizer.state_dict(),torch_rng=torch.get_rng_state(),cuda_rng=torch.cuda.get_rng_state_all() if a.device.type=='cuda' else [])
            atomic_save(latest,state)
    if latest.exists() and start>a.steps:
        state=load_checkpoint(latest);model.load_state_dict(state['state_dict'],strict=True)
    validation=evaluate(model,data,a.device,32)
    atomic_save(final,dict(state_dict=model.state_dict(),step=a.steps,run_config=config,run_fingerprint=fp,val_metrics=validation))
    contract=dict(status=PASS,run_config=config,run_fingerprint=fp,checkpoint_sha256=digest_file(final),
        selected_step=a.steps,selected_validation=validation,official_IPIX_results_reproduced=False,
        original_cal_audit_dev_used=False,previous_LMDA_training_bit_exact_replayed=False)
    write_json(cp,contract);print(PASS,flush=True)
    return contract
