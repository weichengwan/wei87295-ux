#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
R10 2025 — LMDA-Net 2026 TWO-VARIANT LOAO TRAINING V1
======================================================

ROLE
----
Train two transparently frozen LMDA-Net 2026 reconstructions under the SAME
MTDSP R10 2025 LOAO protocol.

The two variants were frozen BEFORE any MTDSP LMDA performance was observed:

  LMDA-PF  : paper-text-faithful reconstruction
  LMDA-CM  : paper-complexity-matched diagnostic reconstruction

Why two variants?
-----------------
The paper text/Fig.4 describe depthwise/asymmetric depthwise operators, while
the published A/B/C/D parameter/FLOP table cannot be reconciled closely with
that textual interpretation.  Rather than weakening the baseline or silently
inventing an implementation, BOTH are trained and retained.

IMPORTANT
---------
Neither variant is selected using MTDSP Pd/Pfa/AUC/final203 before training.
Both use exactly the same IQ512 cache, STFT adapter, LOAO split, optimizer,
batch size, number of iterations, and checkpoint rule.

SOURCE PAPER
------------
Shanliang Yuan, Hongyuan Gao, Zhiwei Zhang, Yapeng Liu,
"Small target detection in sea clutter based on lightweight multi-dimensional
adaptive network", Digital Signal Processing 175 (2026) 105999.

PAPER-FIXED TRAINING
--------------------
observation vector length = 512
network input             = 128x128x3
optimizer                 = Adam
initial LR                = 0.001
batch size                = 32
training iterations       = 5610
loss                      = cross entropy
classes                   = clutter / target

MTDSP-COMMON-PROTOCOL STFT ADAPTER
----------------------------------
The paper specifies STFT and a 128x128x3 input but does NOT fully specify the
discrete STFT/window/colormap pipeline.  This script freezes a deterministic
adapter BEFORE training:

  complex IQ512
  -> Hann-window STFT
       n_fft=128
       win_length=128
       hop_length=4
       center=True
       onesided=False
  -> fftshift frequency axis
  -> power dB
  -> per-sample peak reference
  -> fixed [-50,0] dB clip
  -> bilinear resize to 128x128
  -> repeat the scalar TFM into 3 identical channels

This is explicitly an MTDSP adapter, NOT a claim that the original authors used
the same unreported STFT discretization or RGB colormap.

FROZEN VARIANTS
---------------
LMDA-PF (paper-text-faithful):
  reduction_rule      = NONE
  r                   = 1
  local_operator      = DWSEP
  axis_operator       = DWSEP
  branch_weight_mode  = CHANNEL
  AHPM weight mode    = SCALAR
  normalization       = BN

LMDA-CM (complexity-matched diagnostic):
  reduction_rule      = KEEP
  r                   = 6
  local_operator      = DW
  axis_operator       = FULL
  branch_weight_mode  = CHANNEL
  AHPM weight mode    = SCALAR
  normalization       = NONE

Macro architecture for both:
  128x128x3
  -> Conv7x7 16
  -> Conv3x3 s2 16
  -> AHPM
  -> L-Res 16->32
  -> AHPM
  -> L-Res 32->64
  -> AHPM
  -> L-Res 64->128
  -> AvgPool8x8
  -> FC2

LOAO
----
Uses the existing frozen frame-level split manifest.

For fold LOAO__A:
  acquisition A      -> OUTER_HELDOUT
  every 8th frame in each other acquisition -> INNER_VAL
  remaining frames  -> INNER_TRAIN

This script DOES NOT use OUTER_HELDOUT for checkpoint selection.
It trains for the paper-fixed 5610 iterations and saves the FINAL iteration.
INNER_VAL is descriptive/audit only.

FIREWALL
--------
* no exposed H0
* no H0 threshold fitting
* no final203-specific score extraction
* no synthetic target generation
* no baseline weakening
* no early stopping based on OUTER_HELDOUT
* no architecture selection by MTDSP performance

INPUT
-----
r10_lmda2026_train_iq512.h5
r10_lmda2026_train_rows.csv.gz
r10_deep_baseline_loao_frame_split_manifest.csv.gz

GPU RUNTIME EXPECTATION
-----------------------
Depends strongly on GPU and HDF5/RAM speed.

One fold, BOTH variants, full 5610 steps each:
  roughly 20–60 min on a modern GPU is a reasonable planning range.

All 7 folds, BOTH variants:
  roughly 2.5–7 h.

Run one-fold canary first.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import random
import sys
import time
import traceback
from pathlib import Path
from typing import Dict, Tuple, List

import h5py
import numpy as np
import pandas as pd

VERSION = "R10_2025_MTDSP_LMDA2026_TWO_VARIANT_LOAO_TRAIN_V1"

ACQS = (
    "20250106102221_2002_AT_412450000_1",
    "20250106103943_2002_AT_413212990_1",
    "20250107155816_2002_AT_412331720_1",
    "20250117093108_2002_AT_413324410_1",
    "20250117103141_2002_AT_413020540_1",
    "20250117110751_2002_AT_414211000_1",
    "20250312101233_2002_AT_413203610_1",
)

OBS_LEN = 512
TF_H = 128
TF_W = 128
NFFT = 128
WIN_LEN = 128
HOP = 4
DYNAMIC_RANGE_DB = 50.0

PAPER_LR = 1e-3
PAPER_BATCH = 32
PAPER_STEPS = 5610

SEED_BASE = 20261004

VARIANTS = {
    "lmda_pf": {
        "display": "LMDA-PF",
        "scientific_class": "PAPER_TEXT_FAITHFUL",
        "reduction_rule": "NONE",
        "r": 1,
        "local_operator": "DWSEP",
        "axis_operator": "DWSEP",
        "branch_weight_mode": "CHANNEL",
        "ahpm_weight_mode": "SCALAR",
        "norm": "BN",
    },
    "lmda_cm": {
        "display": "LMDA-CM",
        "scientific_class": "COMPLEXITY_MATCHED_DIAGNOSTIC",
        "reduction_rule": "KEEP",
        "r": 6,
        "local_operator": "DW",
        "axis_operator": "FULL",
        "branch_weight_mode": "CHANNEL",
        "ahpm_weight_mode": "SCALAR",
        "norm": "NONE",
    },
}


def req(x, msg):
    if not bool(x):
        raise RuntimeError(msg)


def sha256_file(p: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def dump_json(obj, p: Path):
    p.write_text(
        json.dumps(obj, ensure_ascii=False, indent=2, default=str) + "\n",
        encoding="utf-8",
    )


def set_seed(seed, torch):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def setup_torch(torch):
    if torch.cuda.is_available():
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = True


def resolve_device(torch, s: str):
    if s == "cuda":
        req(torch.cuda.is_available(), "CUDA requested but unavailable")
        return torch.device("cuda")
    if s == "cpu":
        return torch.device("cpu")
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def red_channels(c: int, r: int, rule: str) -> int:
    if rule == "NONE":
        return c
    if rule == "KEEP":
        return max(1, int(round(c * (r - 1.0) / float(r))))
    if rule == "DIV":
        return max(1, int(round(c / float(r))))
    raise ValueError(rule)


def build_lmda(torch, cfg: Dict):
    nn = torch.nn

    def norm_layer(c):
        if cfg["norm"] == "BN":
            return nn.BatchNorm2d(c)
        return nn.Identity()

    class ConvBlock(nn.Module):
        def __init__(
            self, ci, co, kernel, stride=1, padding=None,
            groups=1, activate=True, linear=False,
        ):
            super().__init__()
            if padding is None:
                if stride == 1:
                    padding = "same"
                else:
                    if isinstance(kernel, tuple):
                        padding = (kernel[0] // 2, kernel[1] // 2)
                    else:
                        padding = kernel // 2

            use_norm = cfg["norm"] == "BN" and not linear
            self.conv = nn.Conv2d(
                ci, co, kernel, stride=stride, padding=padding,
                groups=groups, bias=not use_norm,
            )
            self.norm = nn.BatchNorm2d(co) if use_norm else nn.Identity()
            self.act = nn.ReLU(inplace=True) if activate and not linear else nn.Identity()

        def forward(self, x):
            return self.act(self.norm(self.conv(x)))

    class CBAM(nn.Module):
        def __init__(self, c):
            super().__init__()
            h = max(1, c // 16)
            self.fc1 = nn.Linear(c, h)
            self.fc2 = nn.Linear(h, c)
            self.relu = nn.ReLU(inplace=True)
            self.spatial = nn.Conv2d(2, 1, 7, padding=3, bias=True)

        def channel_mlp(self, z):
            return self.fc2(self.relu(self.fc1(z)))

        def forward(self, x):
            av = torch.mean(x, dim=(2, 3))
            mx = torch.amax(x, dim=(2, 3))
            ca = torch.sigmoid(
                self.channel_mlp(av) + self.channel_mlp(mx)
            ).unsqueeze(-1).unsqueeze(-1)
            x = x * ca

            avs = torch.mean(x, dim=1, keepdim=True)
            mxs = torch.amax(x, dim=1, keepdim=True)
            sa = torch.sigmoid(self.spatial(torch.cat([avs, mxs], dim=1)))
            return x * sa

    class BranchOp(nn.Module):
        def __init__(self, c, kernel, kind):
            super().__init__()
            if kind == "DW":
                self.op = ConvBlock(
                    c, c, kernel, stride=1, padding="same",
                    groups=c, activate=True,
                )
            elif kind == "DWSEP":
                self.op = nn.Sequential(
                    ConvBlock(
                        c, c, kernel, stride=1, padding="same",
                        groups=c, activate=True,
                    ),
                    ConvBlock(
                        c, c, 1, stride=1, padding=0,
                        groups=1, activate=True,
                    ),
                )
            elif kind == "FULL":
                self.op = ConvBlock(
                    c, c, kernel, stride=1, padding="same",
                    groups=1, activate=True,
                )
            else:
                raise ValueError(kind)

        def forward(self, x):
            return self.op(x)

    class ADSCM(nn.Module):
        def __init__(self, c, kaxis):
            super().__init__()
            cr = red_channels(c, cfg["r"], cfg["reduction_rule"])
            self.c = c
            self.cr = cr

            self.pre = ConvBlock(c, cr, 3, stride=1, padding="same")
            self.local = BranchOp(cr, 3, cfg["local_operator"])
            self.axis1 = BranchOp(cr, (kaxis, 1), cfg["axis_operator"])
            self.axis2 = BranchOp(cr, (1, kaxis), cfg["axis_operator"])

            hidden = max(1, cr // 4)
            if cfg["branch_weight_mode"] == "CHANNEL":
                outdim = 3 * cr
            else:
                outdim = 3
            self.w1 = nn.Linear(cr, hidden)
            self.w2 = nn.Linear(hidden, outdim)

            self.mix = ConvBlock(3 * cr, 2 * c, 1, padding=0)
            self.cbam = CBAM(2 * c)

        def forward(self, x):
            z = self.pre(x)
            w = torch.sigmoid(
                self.w2(torch.relu(self.w1(torch.mean(z, dim=(2, 3)))))
            )

            b0 = self.local(z)
            b1 = self.axis1(z)
            b2 = self.axis2(z)

            req(
                b0.shape == b1.shape == b2.shape,
                f"ADSCM branch mismatch: {b0.shape}, {b1.shape}, {b2.shape}",
            )

            if cfg["branch_weight_mode"] == "CHANNEL":
                w = w.view(w.shape[0], 3, self.cr, 1, 1)
                b0 = b0 * w[:, 0]
                b1 = b1 * w[:, 1]
                b2 = b2 * w[:, 2]
            else:
                b0 = b0 * w[:, 0, None, None, None]
                b1 = b1 * w[:, 1, None, None, None]
                b2 = b2 * w[:, 2, None, None, None]

            y = torch.cat([b0, b1, b2], dim=1)
            return self.cbam(self.mix(y))

    class AHPM(nn.Module):
        def __init__(self, c):
            super().__init__()
            hidden = max(1, c // 4)
            outdim = 2 if cfg["ahpm_weight_mode"] == "SCALAR" else 2 * c
            self.fc1 = nn.Linear(c, hidden)
            self.fc2 = nn.Linear(hidden, outdim)
            self.c = c

        def forward(self, x):
            z = torch.mean(x, dim=(2, 3))
            w = torch.sigmoid(self.fc2(torch.relu(self.fc1(z))))

            av = torch.nn.functional.avg_pool2d(x, 2, 2)
            mx = torch.nn.functional.max_pool2d(x, 2, 2)

            if cfg["ahpm_weight_mode"] == "SCALAR":
                return (
                    av * w[:, 0, None, None, None]
                    + mx * w[:, 1, None, None, None]
                )

            w = w.view(w.shape[0], 2, self.c, 1, 1)
            return av * w[:, 0] + mx * w[:, 1]

    class LRes(nn.Module):
        def __init__(self, c, kaxis):
            super().__init__()
            self.adscm = ADSCM(c, kaxis)
            # Ghost intrinsic mapping and cheap operation are kept LINEAR,
            # following the paper's description of 3x3 linear operations.
            self.pw = ConvBlock(
                2 * c, c, 1, padding=0, activate=False, linear=True
            )
            self.cheap = ConvBlock(
                c, c, 3, padding="same", groups=c,
                activate=False, linear=True,
            )

        def forward(self, x):
            z = self.adscm(x)
            a = self.pw(z)
            b = self.cheap(a)
            g = torch.cat([a, b], dim=1)
            req(g.shape == z.shape, f"LRes shape mismatch {g.shape} vs {z.shape}")
            return z + g

    class LMDA(nn.Module):
        def __init__(self):
            super().__init__()
            self.stem1 = ConvBlock(3, 16, 7, stride=1, padding="same")
            self.stem2 = ConvBlock(16, 16, 3, stride=2, padding=1)
            self.pool1 = AHPM(16)
            self.lres1 = LRes(16, 9)
            self.pool2 = AHPM(32)
            self.lres2 = LRes(32, 9)
            self.pool3 = AHPM(64)
            self.lres3 = LRes(64, 8)
            self.avg = nn.AvgPool2d(8, 8)
            self.fc = nn.Linear(128, 2)

        def forward(self, x):
            x = self.stem1(x)
            x = self.stem2(x)
            x = self.pool1(x)
            x = self.lres1(x)
            x = self.pool2(x)
            x = self.lres2(x)
            x = self.pool3(x)
            x = self.lres3(x)
            x = self.avg(x)
            x = torch.flatten(x, 1)
            req(x.shape[1] == 128, f"Expected 128 pooled features, got {x.shape}")
            return self.fc(x)

    return LMDA()


class TFMAdapter:
    def __init__(self, torch, device):
        self.torch = torch
        self.device = device
        self.window = torch.hann_window(
            WIN_LEN, periodic=True, dtype=torch.float32, device=device
        )

    def __call__(self, x_complex):
        """
        x_complex: complex tensor [B,512]
        return: float32 [B,3,128,128] in [0,1]
        """
        torch = self.torch
        req(x_complex.ndim == 2 and x_complex.shape[1] == OBS_LEN,
            f"Expected [B,{OBS_LEN}], got {tuple(x_complex.shape)}")
        if not torch.is_complex(x_complex):
            raise RuntimeError("TFMAdapter requires complex tensor")

        z = torch.stft(
            x_complex,
            n_fft=NFFT,
            hop_length=HOP,
            win_length=WIN_LEN,
            window=self.window,
            center=True,
            pad_mode="reflect",
            normalized=False,
            onesided=False,
            return_complex=True,
        )
        # [B,128,129] for L=512/nfft=128/hop=4/center=True.
        z = torch.fft.fftshift(z, dim=1)
        p = z.real.square() + z.imag.square()
        db = 10.0 * torch.log10(torch.clamp(p, min=1e-12))

        # Per-sample peak reference, fixed 50-dB display range.
        mx = torch.amax(db, dim=(1, 2), keepdim=True)
        db = torch.clamp(db - mx, min=-DYNAMIC_RANGE_DB, max=0.0)
        tf = (db + DYNAMIC_RANGE_DB) / DYNAMIC_RANGE_DB
        tf = tf.unsqueeze(1)

        tf = torch.nn.functional.interpolate(
            tf, size=(TF_H, TF_W), mode="bilinear", align_corners=False
        )
        tf = tf.repeat(1, 3, 1, 1).contiguous()
        req(tf.shape[1:] == (3, TF_H, TF_W), f"Bad TFM shape {tf.shape}")
        req(torch.isfinite(tf).all(), "Non-finite TFM")
        return tf.to(dtype=torch.float32)


def auc_binary(y, s):
    y = np.asarray(y, np.uint8)
    s = np.asarray(s, np.float64)
    pos = y == 1
    neg = y == 0
    n1 = int(pos.sum())
    n0 = int(neg.sum())
    if n1 == 0 or n0 == 0:
        return float("nan")

    order = np.argsort(s, kind="mergesort")
    ranks = np.empty(len(s), np.float64)

    i = 0
    while i < len(s):
        j = i + 1
        while j < len(s) and s[order[j]] == s[order[i]]:
            j += 1
        r = 0.5 * ((i + 1) + j)
        ranks[order[i:j]] = r
        i = j

    u = ranks[pos].sum() - n1 * (n1 + 1) / 2.0
    return float(u / (n1 * n0))


def load_cache(cache_dir: Path):
    hp = cache_dir / "r10_lmda2026_train_iq512.h5"
    rp = cache_dir / "r10_lmda2026_train_rows.csv.gz"
    cp = cache_dir / "r10_lmda2026_iq512_cache_contract.json"
    for p in (hp, rp, cp):
        req(p.is_file(), f"Missing LMDA cache artifact: {p}")

    rows = pd.read_csv(rp)
    req("lmda_row" in rows.columns, "rows CSV lacks lmda_row")
    req(np.array_equal(
        rows["lmda_row"].to_numpy(np.int64),
        np.arange(len(rows), dtype=np.int64),
    ), "lmda_row is not contiguous identity")

    print(f"  load IQ cache into RAM: {hp}")
    t0 = time.perf_counter()
    with h5py.File(hp, "r") as h5:
        req(h5["Xiq512"].shape == (len(rows), OBS_LEN),
            f"Bad Xiq512 shape {h5['Xiq512'].shape}")
        X = np.asarray(h5["Xiq512"][:], dtype=np.complex64)
        y = np.asarray(h5["y"][:], dtype=np.uint8)
        req(np.array_equal(y, rows["label"].to_numpy(np.uint8)),
            "H5 labels != rows CSV")
    req(np.isfinite(X.real).all() and np.isfinite(X.imag).all(),
        "IQ cache contains nonfinite values")
    print(f"  X shape={X.shape}, RAM={X.nbytes/1024**2:.1f} MiB, load={time.perf_counter()-t0:.1f}s")
    return X, y, rows, hp, rp, cp


def load_split(split_csv: Path):
    req(split_csv.is_file(), f"Missing split CSV: {split_csv}")
    s = pd.read_csv(split_csv)
    need = {
        "fold_tag", "held_official_id", "official_id",
        "frame_number_1based", "split_role", "is_final_203_frame"
    }
    req(need.issubset(s.columns), f"split missing {sorted(need-set(s.columns))}")
    s["official_id"] = s["official_id"].astype(str)
    s["frame_number_1based"] = pd.to_numeric(
        s["frame_number_1based"], errors="raise"
    ).astype(int)
    return s


def fold_rows(rows: pd.DataFrame, split: pd.DataFrame, held: str):
    tag = f"LOAO__{held}"
    fs = split[split["fold_tag"].astype(str) == tag].copy()
    req(len(fs) > 0, f"Missing split fold {tag}")

    z = rows.merge(
        fs[[
            "official_id", "frame_number_1based",
            "split_role", "is_final_203_frame"
        ]],
        on=["official_id", "frame_number_1based"],
        how="left",
        validate="many_to_one",
    )
    req(z["split_role"].notna().all(), f"{tag}: selected row lacks split")
    req(
        (z.loc[z["official_id"].astype(str) == held, "split_role"] == "OUTER_HELDOUT").all(),
        f"{tag}: held acquisition leakage",
    )
    return z


def make_batch(X, y, ids, tfm, torch, dev):
    xx = np.ascontiguousarray(X[ids])
    yy = np.ascontiguousarray(y[ids].astype(np.int64))
    tx = torch.from_numpy(xx).to(dev, non_blocking=True)
    ty = torch.from_numpy(yy).to(dev, non_blocking=True)
    return tfm(tx), ty


def evaluate(model, X, y, ids, tfm, batch, torch, dev):
    ids = np.asarray(ids, np.int64)
    scores = np.empty(len(ids), np.float64)
    labels = y[ids].astype(np.uint8)
    total_loss = 0.0
    nloss = 0
    ce = torch.nn.CrossEntropyLoss(reduction="sum")

    model.eval()
    with torch.inference_mode():
        for a in range(0, len(ids), batch):
            ii = ids[a:a+batch]
            xb, yb = make_batch(X, y, ii, tfm, torch, dev)
            logits = model(xb)
            total_loss += float(ce(logits, yb).detach().cpu())
            nloss += len(ii)
            scores[a:a+len(ii)] = (
                torch.softmax(logits, dim=1)[:, 1]
                .detach().cpu().numpy().astype(np.float64)
            )

    pred = (scores >= 0.5).astype(np.uint8)
    return {
        "rows": len(ids),
        "ce": total_loss / max(nloss, 1),
        "acc": float(np.mean(pred == labels)),
        "auc": auc_binary(labels, scores),
        "pos": int((labels == 1).sum()),
        "neg": int((labels == 0).sum()),
    }


def train_one(
    variant_name, held, X, y, rows, split, out_dir,
    steps, batch, torch, dev, retrain=False,
):
    cfg = VARIANTS[variant_name]
    tag = f"LOAO__{held}"
    vd = out_dir / variant_name
    vd.mkdir(parents=True, exist_ok=True)

    ckpt_p = vd / f"{tag}.pt"
    hist_p = vd / f"{tag}_history.csv"
    summary_p = vd / f"{tag}_summary.json"

    if ckpt_p.exists() and summary_p.exists() and not retrain:
        d = json.loads(summary_p.read_text(encoding="utf-8"))
        print(f"    REUSE {ckpt_p}")
        return d

    fr = fold_rows(rows, split, held)
    train_ids = fr.index[
        fr["split_role"].astype(str) == "INNER_TRAIN"
    ].to_numpy(np.int64)
    val_ids = fr.index[
        fr["split_role"].astype(str) == "INNER_VAL"
    ].to_numpy(np.int64)

    req(len(train_ids) > 0 and len(val_ids) > 0, f"{tag}: empty train/val")

    # OUTER_HELDOUT is deliberately NOT scored here.
    req(
        not np.intersect1d(train_ids, fr.index[fr["split_role"]=="OUTER_HELDOUT"]).size,
        f"{tag}: outer rows leaked to train",
    )

    seed = SEED_BASE + ACQS.index(held) * 1009 + (0 if variant_name=="lmda_pf" else 503)
    set_seed(seed, torch)

    model = build_lmda(torch, cfg).to(dev)
    tfm = TFMAdapter(torch, dev)
    nparam = int(sum(p.numel() for p in model.parameters()))

    # Architecture/input smoke check.
    with torch.inference_mode():
        sx = torch.ones((2, OBS_LEN), dtype=torch.complex64, device=dev)
        sx[:, 1::2] *= (0.7 + 0.2j)
        stf = tfm(sx)
        slogit = model(stf)
        req(tuple(stf.shape) == (2, 3, 128, 128), f"bad TFM smoke {stf.shape}")
        req(tuple(slogit.shape) == (2, 2), f"bad model smoke {slogit.shape}")

    opt = torch.optim.Adam(model.parameters(), lr=PAPER_LR)
    ce = torch.nn.CrossEntropyLoss()

    rng = np.random.default_rng(seed)
    perm = rng.permutation(train_ids)
    ptr = 0

    log_every = max(100, min(500, steps // 10 if steps >= 10 else 1))
    val_every = max(500, min(1000, steps // 5 if steps >= 5 else 1))

    hist = []
    running = 0.0
    running_n = 0

    t0 = time.perf_counter()
    model.train()

    for step in range(1, steps + 1):
        if ptr + batch > len(perm):
            perm = rng.permutation(train_ids)
            ptr = 0
        ids = perm[ptr:ptr+batch]
        ptr += batch

        xb, yb = make_batch(X, y, ids, tfm, torch, dev)

        opt.zero_grad(set_to_none=True)
        logits = model(xb)
        loss = ce(logits, yb)
        req(torch.isfinite(loss), f"{tag}/{variant_name}: nonfinite loss")
        loss.backward()
        opt.step()

        lv = float(loss.detach().cpu())
        running += lv
        running_n += 1

        do_log = (step % log_every == 0) or step == 1 or step == steps
        do_val = (step % val_every == 0) or step == steps

        row = None
        if do_log:
            row = {
                "variant": variant_name,
                "fold_tag": tag,
                "step": step,
                "train_loss_recent": running / max(running_n, 1),
                "elapsed_min": (time.perf_counter()-t0)/60.0,
            }
            running = 0.0
            running_n = 0

        if do_val:
            # Inner validation only. Final checkpoint is NOT selected by this metric.
            vm = evaluate(
                model, X, y, val_ids, tfm,
                max(batch, 64), torch, dev
            )
            if row is None:
                row = {
                    "variant": variant_name,
                    "fold_tag": tag,
                    "step": step,
                    "train_loss_recent": np.nan,
                    "elapsed_min": (time.perf_counter()-t0)/60.0,
                }
            row.update({
                "val_ce": vm["ce"],
                "val_acc": vm["acc"],
                "val_auc": vm["auc"],
                "val_rows": vm["rows"],
            })

        if row is not None:
            hist.append(row)
            pd.DataFrame(hist).to_csv(
                hist_p, index=False, encoding="utf-8-sig"
            )
            extra = ""
            if "val_auc" in row:
                extra = (
                    f" | val CE={row['val_ce']:.5f} "
                    f"ACC={row['val_acc']:.4f} AUC={row['val_auc']:.6f}"
                )
            print(
                f"    {variant_name} {tag} step {step:4d}/{steps} "
                f"loss={row['train_loss_recent']:.5f}{extra} "
                f"| {row['elapsed_min']:.1f} min",
                flush=True,
            )

    final_val = evaluate(
        model, X, y, val_ids, tfm,
        max(batch, 64), torch, dev
    )

    runtime = (time.perf_counter() - t0) / 60.0

    ck = {
        "version": VERSION,
        "variant": variant_name,
        "display": cfg["display"],
        "scientific_class": cfg["scientific_class"],
        "held_official_id": held,
        "fold_tag": tag,
        "state_dict": {
            k: v.detach().cpu() for k, v in model.state_dict().items()
        },
        "architecture_config": cfg,
        "stft_adapter": {
            "observation_length": OBS_LEN,
            "n_fft": NFFT,
            "win_length": WIN_LEN,
            "hop_length": HOP,
            "window": "Hann periodic=True",
            "center": True,
            "onesided": False,
            "frequency_shift": True,
            "power_db": True,
            "per_sample_peak_reference": True,
            "clip_db": [-DYNAMIC_RANGE_DB, 0.0],
            "resize": [TF_H, TF_W],
            "channels": "repeat scalar TFM x3",
            "paper_exact_claim": False,
        },
        "training": {
            "optimizer": "Adam",
            "lr": PAPER_LR,
            "batch_size": batch,
            "iterations": steps,
            "loss": "CrossEntropyLoss",
            "scheduler": None,
            "weight_decay": 0.0,
            "checkpoint": "FINAL_ITERATION_ONLY",
        },
        "parameter_count": nparam,
        "inner_train_rows": len(train_ids),
        "inner_val_rows": len(val_ids),
        "final_inner_val": final_val,
        "firewall": {
            "outer_heldout_used_for_checkpoint": False,
            "outer_heldout_scored": False,
            "exposed_h0_used": False,
            "h0_threshold_fit": False,
            "final203_specific_scoring": False,
            "synthetic_target": False,
            "baseline_weakened": False,
        },
        "runtime_minutes": runtime,
    }
    torch.save(ck, ckpt_p)

    summ = {
        k: v for k, v in ck.items()
        if k not in ("state_dict",)
    }
    summ["checkpoint"] = str(ckpt_p)
    summ["checkpoint_sha256"] = sha256_file(ckpt_p)
    dump_json(summ, summary_p)
    return summ


def parse_variants(v):
    if v == "both":
        return ["lmda_pf", "lmda_cm"]
    req(v in VARIANTS, f"Unknown variant {v}")
    return [v]


def parse_folds(f):
    if f == "all":
        return list(ACQS)
    if f.startswith("LOAO__"):
        f = f[len("LOAO__"):]
    req(f in ACQS, f"Unknown fold/acquisition {f}")
    return [f]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", choices=("auto","cpu","cuda"), default="auto")
    ap.add_argument("--cache-dir", type=Path)
    ap.add_argument("--split-csv", type=Path)
    ap.add_argument("--out-dir", type=Path,
                    default=Path("output_lmda2026_two_variant_loao_v1"))
    ap.add_argument("--fold", default=ACQS[0])
    ap.add_argument("--variant", choices=("both","lmda_pf","lmda_cm"), default="both")
    ap.add_argument("--steps", type=int, default=PAPER_STEPS)
    ap.add_argument("--batch-size", type=int, default=PAPER_BATCH)
    ap.add_argument("--retrain", action="store_true")
    ap.add_argument("--audit-only", action="store_true")
    args = ap.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    fatal = args.out_dir / "R10_2025_LMDA2026_TWO_VARIANT_LOAO_FATAL.txt"
    if fatal.exists():
        fatal.unlink()

    try:
        import torch

        setup_torch(torch)
        dev = resolve_device(torch, args.device)
        print("=" * 126)
        print("R10 2025 — LMDA-NET 2026 TWO-VARIANT LOAO TRAINING V1")
        print("LMDA-PF + LMDA-CM | SAME STFT / SAME SPLIT / SAME PAPER TRAINING BUDGET")
        print("=" * 126)
        print("device =", dev)

        print("\n[1/6] Architecture + STFT audit")
        audit_rows = []
        for vn, cfg in VARIANTS.items():
            model = build_lmda(torch, cfg).to(dev).eval()
            nparam = int(sum(p.numel() for p in model.parameters()))
            tfm = TFMAdapter(torch, dev)
            with torch.inference_mode():
                x = torch.ones((2, OBS_LEN), dtype=torch.complex64, device=dev)
                x[1] *= (0.5 + 0.5j)
                z = tfm(x)
                yhat = model(z)
            req(tuple(z.shape) == (2,3,128,128), f"{vn}: bad TFM {z.shape}")
            req(tuple(yhat.shape) == (2,2), f"{vn}: bad logits {yhat.shape}")
            audit_rows.append({
                "variant": vn,
                "display": cfg["display"],
                "scientific_class": cfg["scientific_class"],
                "parameter_count_actual": nparam,
                "fp32_MB_actual": nparam*4/1e6,
                "TFM_shape": "2x3x128x128",
                "logit_shape": "2x2",
            })
        adf = pd.DataFrame(audit_rows)
        print(adf.to_string(index=False))
        adf.to_csv(
            args.out_dir / "r10_lmda2026_architecture_runtime_audit.csv",
            index=False, encoding="utf-8-sig"
        )

        if args.audit_only:
            print("\nAUDIT-ONLY PASS. No radar cache opened, no training performed.")
            return 0

        req(args.cache_dir is not None, "--cache-dir required unless --audit-only")
        req(args.split_csv is not None, "--split-csv required unless --audit-only")
        req(args.steps >= 1, "--steps must be >=1")
        req(args.batch_size >= 1, "--batch-size must be >=1")

        print("\n[2/6] Load frozen LMDA IQ512 cache")
        X, y, rows, hp, rp, cp = load_cache(args.cache_dir)
        split = load_split(args.split_csv)
        print(f"  rows = {len(rows):,}; positives={int((y==1).sum()):,}; negatives={int((y==0).sum()):,}")

        folds = parse_folds(args.fold)
        variants = parse_variants(args.variant)
        print("\n[3/6] Frozen run plan")
        print("  folds =", folds)
        print("  variants =", variants)
        print("  paper-fixed optimizer = Adam")
        print("  lr =", PAPER_LR)
        print("  batch =", args.batch_size)
        print("  steps =", args.steps)
        print("  checkpoint = final iteration only")
        print("  OUTER_HELDOUT scoring in this stage = NO")

        print("\n[4/6] Train")
        results = []
        for fi, held in enumerate(folds, 1):
            print(f"\n  FOLD [{fi}/{len(folds)}] LOAO__{held}")
            for vn in variants:
                print(f"  -> {vn} ({VARIANTS[vn]['display']})")
                z = train_one(
                    vn, held, X, y, rows, split, args.out_dir,
                    int(args.steps), int(args.batch_size),
                    torch, dev, bool(args.retrain)
                )
                results.append({
                    "variant": vn,
                    "display": z["display"],
                    "scientific_class": z["scientific_class"],
                    "fold_tag": z["fold_tag"],
                    "held_official_id": z["held_official_id"],
                    "parameter_count": z["parameter_count"],
                    "train_rows": z["inner_train_rows"],
                    "val_rows": z["inner_val_rows"],
                    "val_ce": z["final_inner_val"]["ce"],
                    "val_acc": z["final_inner_val"]["acc"],
                    "val_auc": z["final_inner_val"]["auc"],
                    "runtime_minutes": z["runtime_minutes"],
                    "checkpoint": z["checkpoint"],
                    "checkpoint_sha256": z["checkpoint_sha256"],
                })

        rdf = pd.DataFrame(results)
        metrics_p = args.out_dir / "r10_lmda2026_loao_training_metrics.csv"
        rdf.to_csv(metrics_p, index=False, encoding="utf-8-sig")

        print("\n[5/6] Training audit")
        print(rdf[[
            "variant","fold_tag","parameter_count",
            "train_rows","val_rows","val_ce","val_acc","val_auc","runtime_minutes"
        ]].to_string(index=False))

        complete_expected = len(folds) * len(variants)
        req(len(rdf) == complete_expected, "run result census mismatch")
        req(np.isfinite(rdf["val_ce"]).all(), "nonfinite val CE")
        req(np.isfinite(rdf["val_auc"]).all(), "nonfinite val AUC")

        if len(folds) == 1:
            decision = (
                "PASS_LMDA2026_TWO_VARIANT_ONEFOLD_TRAINING_CANARY__"
                "RUN_IDENTICAL_ALL7_NEXT"
            )
        else:
            decision = (
                "PASS_LMDA2026_TWO_VARIANT_ALL7_TRAINING__"
                "READY_FOR_COMMON_H0_CALIBRATION"
            )

        print("\n[6/6] Freeze summary")
        summary = f"""R10 2025 — LMDA-NET 2026 TWO-VARIANT LOAO TRAINING V1
==============================================================================================================

VARIANTS
LMDA-PF = paper-text-faithful reconstruction
LMDA-CM = paper-complexity-matched diagnostic reconstruction

COMMON STFT ADAPTER
IQ512 -> Hann STFT(n_fft=128,win=128,hop=4,center=True,onesided=False)
-> fftshift -> power dB -> per-sample peak reference -> clip [-50,0] dB
-> bilinear 128x128 -> repeat x3 channels

IMPORTANT
The paper does not publish the exact discrete STFT/colormap settings.
This adapter is frozen MTDSP common-protocol reconstruction, not claimed as
the authors' exact unpublished preprocessing.

TRAINING
optimizer = Adam
lr = {PAPER_LR:g}
batch = {args.batch_size}
iterations = {args.steps}
loss = cross entropy
scheduler = NONE
checkpoint = FINAL ITERATION ONLY

FIREWALL
OUTER_HELDOUT used for checkpoint = NO
OUTER_HELDOUT scored = NO
exposed H0 used = NO
H0 threshold fit = NO
final203-specific scoring = NO
synthetic target = NO
baseline weakened = NO

RESULTS
{rdf[["variant","fold_tag","parameter_count","train_rows","val_rows","val_ce","val_acc","val_auc","runtime_minutes"]].to_string(index=False)}

DECISION
{decision}

NEXT
After one-fold canary PASS: run both variants on all 7 folds unchanged.
After all-7 PASS: calibrate each method on the common exposed-H0 protocol,
then run the common controlled D80/D90 benchmark.  The stronger of LMDA-PF
and LMDA-CM is retained as the conservative LMDA baseline.

OUTPUT
{args.out_dir}
"""
        sp = args.out_dir / "R10_2025_LMDA2026_TWO_VARIANT_LOAO_SUMMARY.txt"
        sp.write_text(summary, encoding="utf-8")
        print(summary)

        contract = {
            "version": VERSION,
            "decision": decision,
            "variants": VARIANTS,
            "stft_adapter": {
                "n_fft": NFFT,
                "win_length": WIN_LEN,
                "hop_length": HOP,
                "window": "hann_periodic",
                "center": True,
                "onesided": False,
                "fftshift": True,
                "power_db": True,
                "clip_db": [-DYNAMIC_RANGE_DB, 0],
                "resize": [128,128],
                "channels": "repeat_x3",
                "paper_exact_claim": False,
            },
            "paper_training": {
                "optimizer": "Adam",
                "lr": PAPER_LR,
                "batch": args.batch_size,
                "iterations": args.steps,
                "loss": "cross_entropy",
            },
            "lineage": {
                "iq_h5": {"path": str(hp), "sha256": sha256_file(hp)},
                "rows_csv": {"path": str(rp), "sha256": sha256_file(rp)},
                "cache_contract": {"path": str(cp), "sha256": sha256_file(cp)},
                "split_csv": {
                    "path": str(args.split_csv),
                    "sha256": sha256_file(args.split_csv),
                },
            },
            "firewall": {
                "outer_heldout_scored": False,
                "h0_used": False,
                "final203_specific_scoring": False,
                "synthetic_target": False,
                "baseline_weakened": False,
            },
        }
        dump_json(
            contract,
            args.out_dir / "r10_lmda2026_two_variant_loao_contract.json"
        )
        return 0

    except Exception:
        tb = traceback.format_exc()
        fatal.write_text(tb, encoding="utf-8")
        print("\nFATAL\n" + tb)
        print("Fatal log:", fatal)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
