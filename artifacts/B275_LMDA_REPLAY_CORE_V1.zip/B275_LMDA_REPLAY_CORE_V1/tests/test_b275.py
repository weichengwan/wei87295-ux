"""LMDA reconstruction and ADSCM experiment checks, using generated CPU data."""
import gc,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np,torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from b271_data import digest_file,load_checkpoint,read_json,write_json
from b273_shared import setup
from b275_core import PaperNet,architecture_audit,paper_source,SOURCE_SHA,ChannelMatchedADSCM
import b275_replay as replay
import b275_train as fresh
import b275_adscm_experiment as core
import b275_rank_reference as rank
import b276_train as trainer
from source_loader import load_frozen_sources
from test_b276 import fixture,original


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):setup(2)

    def test_paper_source_macrogeometry_and_forward_gradient(self):
        report=architecture_audit();self.assertEqual(report['source_sha256'],SOURCE_SHA)
        self.assertEqual(report['variants']['lmda_pf']['parameters'],129039)
        self.assertEqual(report['variants']['lmda_cm']['parameters'],154949)
        self.assertEqual(report['variants']['lmda_pf']['shapes']['lres3'],[128,8,8])
        model=PaperNet();x=torch.randn(2,512,dtype=torch.complex64)
        expected=paper_source().TFMAdapter(torch,torch.device('cpu'))(x)
        torch.testing.assert_close(model.frontend.images(x),expected,atol=0,rtol=0)
        z=model(x);self.assertEqual(z.shape,(2,2));z.square().mean().backward()
        self.assertGreater(float(model.net.stem1.conv.weight.grad.abs().sum()),0)
        fixed=ChannelMatchedADSCM(64,128,2,adaptive=False,cbam=False)
        z=fixed(torch.randn(2,64,56,56));self.assertEqual(z.shape,(2,128,28,28))
        self.assertTrue(torch.equal(fixed.core.w2.weight,torch.zeros_like(fixed.core.w2.weight)))
        self.assertFalse(fixed.core.w2.weight.requires_grad)

    def test_checkpoint_load_requires_entire_matching_keyset(self):
        state=PaperNet().net.state_dict();prefixed={'module.'+k:v for k,v in state.items()}
        loaded,where=replay.compatible_state({'state_dict':prefixed},state)
        self.assertEqual(where['common_prefix_removed'],'module.');self.assertEqual(set(loaded),set(state))
        bad=dict(state);bad.pop(next(iter(bad)))
        with self.assertRaisesRegex(RuntimeError,'exact PF state'):replay.compatible_state({'state_dict':bad},state)
        bad=dict(state);bad['extra']=torch.zeros(1)
        with self.assertRaises(RuntimeError):replay.compatible_state(bad,state)

    def test_readonly_val_and_actual_h0_prefix_replay(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);context,data,generator=fixture(root);old=original(context,generator);old['scene_fingerprint']='fixture scene'
            model=PaperNet().eval();path=root/replay.OLD_WEIGHT;path.parent.mkdir(parents=True)
            torch.save({'state_dict':model.net.state_dict()},path);sha=digest_file(path)
            val=replay.val_replay(model,context,2,torch.device('cpu'))
            write_json(path.with_name('training_contract.json'),dict(checkpoint_sha256=sha,original_source_sha256=SOURCE_SHA,train_steps=5610,
                training_bank_sha256=context['bc']['file_sha256'],val_metrics=val))
            folder=root/'output_sim_r10_b223_external_baselines_v1/dl/LMDA_PF/seed_20261022';folder.mkdir(parents=True)
            p=dict(checkpoint_sha256=sha,b213_scene_fingerprint=old['scene_fingerprint'],h0_cal_n=4,h0_audit_n=4)
            write_json(folder/'protocol_frozen.json',p)
            with torch.no_grad():
                for split in ('h0_cal','h0_audit'):
                    x=np.stack([generator.make_one(old['master_seed'],old[split+'_split'],i,-30,10)['base'] for i in range(4)]).astype('complex64')
                    scores=[]
                    for start in (0,2):
                        z=model(torch.from_numpy(x[start:start+2]));scores.extend((z[:,1]-z[:,0]).double().tolist())
                    np.save(folder/(split+'_scores.npy'),np.array(scores,dtype='float64')[:,None])
            before={f:digest_file(f) for f in (path,folder/'h0_cal_scores.npy',folder/'h0_audit_scores.npy')}
            a=SimpleNamespace(root=root,out_dir=root/'replay',bank_dir=None,batch=2,device=torch.device('cpu'))
            prefix=replay.prefix_replay
            with patch.object(replay,'OLD_WEIGHT_SHA',sha),patch.object(replay,'resolve',return_value=context),\
                 patch.object(replay,'original_protocol',return_value=(None,old,generator)),\
                 patch.object(replay,'prefix_replay',side_effect=lambda *args:prefix(*args,count=4)):
                result=replay.replay(a)
            self.assertEqual(result['status'],'PASS_EXISTING_LMDA_PF_REPLAY');self.assertFalse(result['learning_performed']);self.assertFalse(result['reuse_old_thresholds_authorized'])
            self.assertEqual(before,{f:digest_file(f) for f in before})

    def test_adscm_replacement_preserves_remaining_layers_and_original_tail_loss(self):
        source=core.CoreNet().eval();model=core.CoreNet('adscm');old=source.architecture.state_dict()
        copied=core.initialize(model,source,'adscm');self.assertTrue(copied)
        for k,v in model.architecture.state_dict().items():
            if not k.startswith(('detector.layer2.0.adscm.','detector.layer2.1.adscm.')):self.assertTrue(torch.equal(v,old[k]),k)
        iq=torch.randn(2,512,dtype=torch.complex64);model.train();y=torch.tensor([0,1])
        z,ce,loss=core.objective(model,iq,y);loss.backward()
        self.assertGreater(float(model.architecture.detector.layer2[0].adscm.bridge[0].weight.grad.abs().sum()),0)
        r=load_frozen_sources()[2];margin=z[:,1]-z[:,0];h0,h1=r.get_hard_indices(margin,y,r.PARAMS['rho_h0'],r.PARAMS['rho_h1'])
        expected=ce+.05*(torch.nn.functional.softplus((1+margin[h0,None]-margin[None,h1])/2)*2).mean()
        torch.testing.assert_close(loss,expected)
        self.assertTrue(all(p.requires_grad for p in model.parameters()))

    def test_actual_adscm_finetuning_and_fresh_pf_fixed_step_training(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);context,data,generator=fixture(root);source=core.CoreNet()
            s,tr,r=load_frozen_sources();path=root/'old_l1.pt';torch.save(dict(method='L1_TAIL',cfg=r.CFG,source_sha256=tr.EXPECTED_SOURCE_SHA,state_dict=source.architecture.state_dict()),path)
            info=dict(checkpoint=path,contract={'checkpoint_sha256':digest_file(path)},run_dir=root,config={'backend':source.frontend.backend,'scale':1.})
            a=SimpleNamespace(out_dir=root/'adscm_train',seed=20261022,epochs=1,batch=2,lr=3e-5,new_lr=3e-4,device=torch.device('cpu'))
            hooks=dict(status=core.PASS,version='B275_ADSCM_STAGE2_TRAIN_V1',loss_name='original L1_TAIL',old_l1_weights=True,
                teacher=core.teacher,factory=lambda arm,b,scale:core.CoreNet(arm),migrate=core.initialize,verify_initial=core.initial_check,objective=core.objective,diagnostics=core.diagnostics)
            c=trainer.train_arm(a,context,data,info,'adscm',hooks);self.assertEqual(c['status'],core.PASS);self.assertTrue(c['old_WVD_L1_weights_loaded'])
            self.assertFalse(c['initialization']['initial_function_preserved_within_tolerance'])
            a=SimpleNamespace(out_dir=root/'fresh',seed=20261022,steps=2,device=torch.device('cpu'))
            c=fresh.train(a,context,data);self.assertEqual(c['selected_step'],2);self.assertFalse(c['original_cal_audit_dev_used'])
            state=load_checkpoint(a.out_dir/'fresh/final.pt');self.assertEqual(state['step'],2)
            self.assertEqual(fresh.train(a,context,data)['checkpoint_sha256'],c['checkpoint_sha256'])
            a.steps=3
            with self.assertRaisesRegex(RuntimeError,'config changed'):fresh.train(a,context,data)

    def test_historical_fixed_rank_ecdf_and_bad_full_support(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);left=root/'L1';right=root/'LMDA';left.mkdir();right.mkdir()
            for name,shape in [('h0_cal_scores.npy',(3000000,)),('h0_audit_scores.npy',(1000000,)),('dev_h1_scores_37.npy',(37,1024))]:
                l=np.lib.format.open_memmap(left/name,mode='w+',dtype='float64',shape=shape+(4,));r=np.lib.format.open_memmap(right/name,mode='w+',dtype='float64',shape=shape+(1,))
                if name=='h0_cal_scores.npy':l[:,1]=np.arange(3000000)/3000000;r[:,0]=np.arange(2999999,-1,-1)/3000000
                else:l[...,1]=.5;r[...,0]=.5
                l.flush();r.flush();del l,r
            cached=dict(h0_cal=np.zeros((500000,1)),h0_audit=np.zeros((200000,1)),h1=np.zeros((37,1024,1)))
            info=dict(l1=left,lmda=right,source_protocol_sha256=['fixture','fixture'])
            values,details=rank.arrays(info,cached)
            expected=.75-.75/3000000-.5*np.arange(10)/3000000
            np.testing.assert_allclose(values['h0_cal'][:10,-1],expected,rtol=0,atol=2e-16)
            np.testing.assert_array_equal(values['h0_audit'][:10,-1],np.full(10,.5))
            self.assertEqual(details['expert_ECDF_support'],3000000);self.assertFalse(details['same_as_historical_B227_threshold'])
            bad=np.load(right/'h0_cal_scores.npy',mmap_mode='r+');bad[-1,0]=float('nan');bad.flush();del bad
            with self.assertRaisesRegex(RuntimeError,'full historical ECDF'):rank.arrays(info,cached)


if __name__=='__main__':unittest.main(verbosity=2)
