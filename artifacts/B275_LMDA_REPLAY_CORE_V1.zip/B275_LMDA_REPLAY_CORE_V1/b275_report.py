"""Own-CAL single-branch results alongside unchanged B273 baseline scores."""
from pathlib import Path
import shutil
import numpy as np
from b271_data import fingerprint,need,read_json,write_json
from b273_statistics import metrics_for,save_csv
from paper_plots import generate as paper_plot


def generate(out):
    out=Path(out);p=read_json(out/'protocol_frozen.json');progress=read_json(out/'progress.json')
    need(p['version']=='B275_LMDA_PF_MEDIUM_SCORE_V1' and p['nominal_pfas']==[1e-4] and
         fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==p['fingerprint']==progress['fingerprint'],'Score protocol changed')
    need(progress['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=len(p['scr_grid_db'])),'Scoring incomplete')
    columns=len(p['labels']);values=[]
    for name,shape in [('h0_cal_scores.npy',(p['h0_cal_n'],columns)),('h0_audit_scores.npy',(p['h0_audit_n'],columns)),('dev_h1_scores.npy',(len(p['scr_grid_db']),p['h1_scenes_n'],columns))]:
        x=np.load(out/name,mmap_mode='r',allow_pickle=False)
        need(x.shape==shape and x.dtype==np.dtype('float64'),'Malformed score bank');values.append(x)
    cal,audit,h1=values;curves=[];metrics=[];lookup={}
    # Keep old reference order/colors, and append the newly trained model.
    for label in p['labels'][1:]+p['labels'][:1]:
        j=p['labels'].index(label)
        c,m=metrics_for(p['names'][label],cal[:,j],audit[:,j],h1[:,:,j],p)
        curves.extend(c);metrics.extend(m);lookup[label]=m[0]
    comparisons=[];candidate=lookup['SINGLE']
    for label,reference in lookup.items():
        if label=='SINGLE':continue
        delta=lambda k:candidate[k]-reference[k] if candidate[k] is not None and reference[k] is not None else None
        comparisons.append(dict(candidate=candidate['method'],reference=reference['method'],nominal_pfa=1e-4,
            delta_D80_db=delta('D80_db'),delta_D90_db=delta('D90_db'),pd_at_0_gain_pp=100*delta('pd_at_0'),
            candidate_false_alarms=candidate['audit_false_alarms'],reference_false_alarms=reference['audit_false_alarms'],
            paired_scenes=True,matched_training_procedure=False,negative_delta_means_left=True))
    save_csv(out/'b275_curves.csv',curves);save_csv(out/'b275_metrics.csv',metrics);save_csv(out/'b275_comparisons.csv',comparisons)
    report=dict(status='PASS_B275_MEDIUM_DEV_REPORT',metrics=metrics,comparisons=comparisons,checkpoint=p['checkpoint'],
        scope=p['scope'],backend=p['backend'],baseline_reuse=p['reused_baselines'],independent_final=False,
        historical_training_curve_replay_established=False,full_Wang_three_channel_reproduction=False,
        automatic_promotion=False,matched_training_procedure=False,radar_detection_gain_established=False)
    write_json(out/'b275_report.json',report)
    paper_plot(out/'b275_curves.csv',out/'figures',ours=candidate['method'],nominal=1e-4,metrics=out/'b275_metrics.csv')
    for ext in ('png','pdf','svg'):
        shutil.copyfile(out/'figures'/f'b275_curves_paper_pd_pfa_1e-04.{ext}',out/'figures'/f'b275_pd_scr_pfa_1e-04.{ext}')
    for row in comparisons:print(f"Fresh LMDA-PF vs {row['reference']}: delta_D90={row['delta_D90_db']}; Pd@0 gain={row['pd_at_0_gain_pp']:+.3f}pp",flush=True)
    print(f'B275 stopped after medium DEV. Report: {out/"b275_metrics.csv"}',flush=True)
    return report
