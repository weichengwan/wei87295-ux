"""Paired medium scoring. Render identical SPWVD once, then evaluate each arm."""
from pathlib import Path
import numpy as np
import torch
from b271_data import digest_file,fingerprint,load_checkpoint,need,read_json
from b271_score import SCENE_KEYS,original_protocol
from b274_data import resolve
from b276_model import make_model,NAMES,PowerDiagnostic
from b276_source import metadata,arrays
from b276_train import PASS,code_hashes


@torch.inference_mode()
def predictions(models,source,iq,device,batch):
    need(iq.dtype==np.complex64 and iq.ndim==2 and iq.shape[1]==512,'Expected complex64 IQ512')
    need(all(m.frontend.backend['sha256']==models[0].frontend.backend['sha256'] and
             m.frontend.scale==models[0].frontend.scale for m in models),'Shared frontend differs')
    out=np.empty((len(iq),len(models)),dtype='float64')
    for start in range(0,len(iq),batch):
        x=torch.from_numpy(np.ascontiguousarray(iq[start:start+batch])).to(device)
        images=models[0].frontend.maps(models[0].frontend.components(x))
        for j,m in enumerate(models):
            z=m.prepared_forward(images,x);out[start:start+len(x),j]=(z[:,1]-z[:,0]).double().cpu().numpy()
    need(np.isfinite(out).all(),'Nonfinite candidate score');return out


def score(a,context,data_selection):
    source=a.source_run
    _,old,generator=original_protocol(a.root,context,a.b213_dir)
    info=metadata(source,context,a.device,data_selection,old);cached,reuse=arrays(info)
    models=[];identities=[]
    for arm in a.arms:
        folder=a.out_dir/arm;c=read_json(folder/'training_contract.json');path=folder/'best.pt'
        need(c['status']==PASS and digest_file(path)==c['checkpoint_sha256'] and c['run_config']['code_sha256']==code_hashes(),'Incomplete or changed B276 arm')
        state=load_checkpoint(path);cfg=c['run_config']
        need(cfg==state['run_config'] and c['run_fingerprint']==state['run_fingerprint']==fingerprint(cfg) and state['epoch']==c['best_epoch'],'B276 internal checkpoint identity differs')
        need(cfg['initialization_sha256']==info['contract']['checkpoint_sha256'] and cfg['bank_sha256']==context['bc']['file_sha256'] and cfg['selected_rows']==data_selection,'B276 source data differs')
        model=make_model(arm,cfg['backend'],cfg['scale']);model.load_state_dict(state['state_dict'],strict=True);model.to(a.device).eval()
        models.append(model);identities.append(dict(arm=arm,sha256=c['checkpoint_sha256'],selected_epoch=c['best_epoch'],validation=c['selected_validation'],
            initialization=c['initialization'],module_diagnostics=c['module_diagnostics']))
    scene={k:old[k] for k in SCENE_KEYS};scene.update(h0_cal_n=500000,h0_audit_n=200000)
    models.append(PowerDiagnostic(models[0].frontend).to(a.device).eval())
    labels=a.arms+['BASE_POWER']+['BASE_'+v for v in info['p']['labels']]
    p=dict(version='B276_SPWVD_ADN_PHASE_SCORE_V1',**scene,scene_fingerprint=fingerprint(scene),nominal_pfas=[1e-4],labels=labels,
        names={**{v:NAMES[v] for v in a.arms},'BASE_POWER':'IQ mean power (diagnostic)',**{'BASE_'+v:n for v,n in info['p']['names'].items()}},
        ours_label='phase' if 'phase' in a.arms else a.arms[-1],candidate_labels=a.arms,checkpoints=identities,
        reused_baselines=reuse,batch=32,device=a.device.type,tf32=False,code_sha256=code_hashes(),
        score_definition='float64(float32 logit1 - float32 logit0)',strict_decision='score > own H0 CAL threshold',
        scope='Matched additional TRAIN/VAL budget; previously exposed medium DEV; not independent FINAL')
    p['fingerprint']=fingerprint(p)
    from types import SimpleNamespace
    args=SimpleNamespace(out_dir=a.out_dir/'pd_scr_medium',batch=32,chunk=512)
    print(f'B276 CAL500k CHECK200k H1=1024x37; {a.arms}; cached B274/B273/L1 GPU forwards=0',flush=True)
    stream(args,p,generator,models,None,a.device,cached)
    from b276_report import generate
    return generate(args.out_dir)


# Streaming/resume implementation copied unchanged from the tested B273 release.
import time
from b271_data import write_json
from source_loader import load_frozen_file

def stream(a,p,generator,models,source,device,cached):
    original=load_frozen_file('r10_sim_stage_b216_pdscr_score_v1.py');progress=original.init(a,p)
    files={'h0_cal':'h0_cal_scores.npy','h0_audit':'h0_audit_scores.npy','h1':'dev_h1_scores.npy'}
    for split in files:
        total=len(p['scr_grid_db']) if split=='h1' else p[split+'_n'];done=progress['completed'][split]
        need(isinstance(done,int) and 0<=done<=total,'Invalid committed score prefix')
        need(done==0 or (a.out_dir/files[split]).is_file(),'Score array missing despite committed progress: '+files[split])
    columns=len(p['labels'])
    for split in ('h0_cal','h0_audit'):
        total=p[split+'_n'];path=a.out_dir/files[split]
        array=original.new_array(path,(total,columns),path.exists());first=progress['completed'][split]
        started=time.perf_counter()
        for start in range(first,total,a.chunk):
            stop=min(start+a.chunk,total)
            scenes=[generator.make_one(p['master_seed'],p[split+'_split'],i,-30,10) for i in range(start,stop)]
            need(all(s['label']==0 and not np.any(s['target']) for s in scenes),'Unexpected target in H0')
            iq=np.stack([s['base'] for s in scenes]).astype('complex64')
            array[start:stop,:len(models)]=predictions(models,source,iq,device,a.batch)
            array[start:stop,len(models):]=cached[split][start:stop]
            array.flush();progress['completed'][split]=stop;write_json(a.out_dir/'progress.json',progress)
            if stop==total or stop%10000<a.chunk:
                rate=(stop-first)/max(time.perf_counter()-started,1e-6)
                print(f'[{split}] {stop:,}/{total:,}; {rate:.1f}/s; remaining~{(total-stop)/max(rate,1e-6)/60:.1f}min',flush=True)
        del array
    ns=p['h1_scenes_n'];levels=p['scr_grid_db'];path=a.out_dir/files['h1']
    array=original.new_array(path,(len(levels),ns,columns),path.exists())
    scenes=[generator.make_one(p['master_seed'],p['h1_split'],i,-30,10) for i in range(ns)]
    need(all(s['label']==1 for s in scenes),'H1 split must generate targets')
    base=np.stack([s['base'] for s in scenes]).astype('complex64');unit=np.stack([s['unit'] for s in scenes]).astype('complex64')
    power=np.array([s['cp'] for s in scenes],dtype='float64');need(np.isfinite(power).all() and (power>0).all(),'Invalid clutter power')
    for level in range(progress['completed']['h1'],len(levels)):
        scr=levels[level]
        for start in range(0,ns,a.chunk):
            stop=min(start+a.chunk,ns);amplitude=np.sqrt(power[start:stop]*10**(scr/10))
            iq=(base[start:stop].astype('complex128')+unit[start:stop].astype('complex128')*amplitude[:,None]).astype('complex64')
            array[level,start:stop,:len(models)]=predictions(models,source,iq,device,a.batch)
            array[level,start:stop,len(models):]=cached['h1'][level,start:stop]
        array.flush();progress['completed']['h1']=level+1;write_json(a.out_dir/'progress.json',progress)
        print(f'[dev_h1] SCR={scr:+d} dB {level+1}/{len(levels)}',flush=True)
    del array
