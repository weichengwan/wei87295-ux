# B275：LMDA-PF 源码核对、只读回放与 ADSCM 替换原型

本包优先核对已经完成的 LMDA-PF，避免重复5610步训练。提供三个相互独立的工作：论文结构审计、旧权重回放、可选的独立重训。另有完整的ADSCM替换训练与评分入口core-night；本机仅作CPU功能验证，尚无新检测增益结果。默认仍只回放，不自动启动替换实验。

## 论文与工程复现的边界

Yuan, S.; Gao, H.; Zhang, Z.; Liu, Y. *Small target detection in sea clutter based on lightweight multi-dimensional adaptive network*. Digital Signal Processing175(2026)105999. DOI https://doi.org/10.1016/j.dsp.2026.105999

论文方法：IQ512 → STFT → 128×128×3 → Conv7×7/16 → Conv3×3/16,stride2 → AHPM → L-Res16→32 → AHPM → L-Res32→64 → AHPM → L-Res64→128 → AvgPool8×8 → FC2。

- ADSCM：§4.1、式7—10、图4。3×3预处理后，局部3×3、9×1、1×9方向分支，输入条件Sigmoid权重，拼接、点卷积、CBAM。末级长条核为8。
- AHPM：§4.2、式11。输入条件的均值/最大池化加权；两个Sigmoid输出并不必然相加为1。
- L-Res：§4.3、图5。ADSCM之后有Ghost点卷积/廉价深度卷积和残差相加，主要兼顾表达和轻量化。
- 原实验为IPIX，512点、步长64、训练测试8:2，Adam lr1e-3、batch32、5610更新。用户当前的SIM-R10/MTDSP不是原始IPIX实验，不能声称复现其98.64%准确率。

本包冻结用户上传的已有LMDA重建源码，SHA=`87a11242a7a6befa56f7db3cd12b57829706b13d10288037b1792e9487273c06`，与历史B225契约一致。PF的STFT适配为Hann128、FFT128、hop4、center、完整复频谱、fftshift、逐图峰值相对50dB显示、resize128²、灰度复制3通道。

这不是作者官方代码。原文未完整明确离散窗、归一化、缩减比等细节；已有PF约定为不缩减、DWSEP分支、分支逐通道权重、BN。图4则标DWConv和c'=c(r-1)/r。本包如实保留这些工程约定，不为了凑论文的0.65MB而改网络。实际PF129039参数，FP32参数约0.492MiB；CM诊断154949参数，不能用CM替代PF后声称官方精确复现。

## 先跑只读回放（推荐）

上传ZIP到项目目录后：

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
unzip -n B275_LMDA_REPLAY_CORE_V1.zip
/root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  bash B275_LMDA_REPLAY_CORE_V1/run_b275.sh --stage replay
```

默认只验证既有LMDA-PF权重SHA、严格state keys/shapes、完整5000 VAL的CE与历史值，以及CAL/AUDIT各256条H0分数。不会重新训练、生成大缓存或重跑数百万H0。预计通常几分钟以内，实际GPU耗时未在本机测过。

旧权重默认`output_sim_r10_b225_real_four_dl_train_v1/LMDA_PF/seed_20261022/sim_r10_final.pt`，SHA=`94b0687d8675feec1101cf1158fb926049fc838b0e6d112d456264f9e5de4460`。同目录需要原training_contract.json。还需冻结IQ银行、原B213协议、B223协议与H0原始npy分数。严格拒绝丢弃未知权重层后近似加载。

输出：`output_b275_lmda_replay_core_v1/b275_replay_report.json`。回放失败会记录差异或缺失文件；不会自动训练新模型或改旧阈值。前缀一致也不等于整套低虚警校准完成。旧B251已提示过分数不完全回放风险，因此即使VAL吻合，也要看H0误差。

只核对结构，不需要数据/权重/GPU：

```bash
/root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  bash B275_LMDA_REPLAY_CORE_V1/run_b275.sh --stage audit --device cpu
```

## 可选：独立重训与中等规模Pd评价

不默认重训。确认要重建现有域上的训练过程时，可以使用：

```bash
nohup /root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  bash B275_LMDA_REPLAY_CORE_V1/run_b275.sh --stage fresh-night \
  >> codex_b275_fresh_lmda.log 2>&1 < /dev/null &
tail -F codex_b275_fresh_lmda.log
```

沿用冻结TRAIN16000/VAL3000的B273相同行，Adam无weight_decay，batch32、5610更新、CE，按预先规定的最终一步选模型；VAL仅记录，不用DEV选模型。与旧B225的30000 TRAIN及其具体随机采样序列不同，不保证新训练权重/曲线与旧模型相同。每250步保存可恢复状态。

训练后只跑Pfa1e-4，500k CAL、200k CHECK、每SCR1024个H1，共37点；不会自动全量。仅新LMDA模型做GPU推理，其余B273曲线与旧LMDA/固定75:25融合读取已冻结分数。

固定融合保留B227原3M H0拟合的ECDF，但本轮最终阈值用500k前缀重新估计。因此图中`Fixed rank mix LMDA75/L125 (medium CAL)`是同评分函数的中等校准对照，不是旧3M阈值曲线逐点复制。继承ECDF的历史支持量仍为3M，报告会保留此区别。

fresh-night额外需要原B222/B223完整分数及未改的协议，启动时先核对文件和元数据；训练阶段不读它们的分数数组。默认不创建新的时频缓存。原目录不改写。与B271/272/273/274共用GPU锁，勿重复启动。准确GPU时间未实测，小模型训练通常比整套ResNet18便宜；日志会给出迭代吞吐与评分ETA。

输出：`fresh/final.pt`、`fresh/training_contract.json`、`fresh/train_val_history.csv`；`pd_scr_medium/b275_report.json`、b275_curves/metrics/comparisons.csv，以及黑色虚线空心倒三角的Pd图。所有这些仍是已暴露DEV，不是独立最终测试。

## ADSCM替换实验：完整入口，尚无AutoDL检测增益证据

`b275_core.replace_stage2(l1_wrapper)`作用于已加载L1权重的完整ProposedWrapper：

`WVD → WCSG → stem/Stage1 → Stage2(ACB替换为通道匹配ADSCM) → Stage3/4 → 分类头`。

原ACB是固定3×3、3×1、1×3全卷积分支求和。原ADSCM有长方向分支与输入条件选择。原ADSCM输出2c，与ADN块宽度不同；原型用1×1+BN+ReLU几何桥接到c=cout/2，再调用未改公式的PF ADSCM，保持原块输出通道和步幅。只替换Stage2两个块的第一段ACB；第二个3×3、TFCG、BN、残差捷径和输入WCSG沿用。

新ADSCM权重为随机初始化，不声称与L1初始输出相等，也不是直接移入旧LMDA权重。已提供完整训练与配对评分；本机完成形状、梯度、生成样本上的短训练及结构测试，尚未训练AutoDL新检测器。保留TFCG同时使用CBAM可能有功能重叠，原型提供cbam=False供后续消融；adaptive=False将分支权重固定为0.5，供同预算的动态机制对照。

这与旧B259/B260/B270的残差adapter叠加位置不同，但不能仅凭位置变化宣布创新。下一阶段应对比原L1、同预算继续训练、固定方向分支、输入条件方向分支，并核对实际Pfa、D80/D90、复杂度和多种子。不要在复现未核对前把本原型与B271/B274同时叠加训练。

## 关于融合的创新表述

固定alpha是固定加权融合；训练得到的全局alpha是可学习全局融合；只有alpha=g(输入特征)并在实际数据上呈现有用变化，才有依据称输入/场景自适应。加权、MLP或Sigmoid本身不构成充分新颖性证据。需要与固定75/25强对照比较，并在独立测试上验证。双模型的跨STFT/WVD互补也不能自动归因于ADSCM一个模块。


## 直接运行ADSCM替换（第二步，不必重新训练5610步LMDA）

先执行前面的只读replay，保存报告。论文PF源码已冻结；重新训练LMDA是可选的，不是替换实验的前置要求。

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
nohup /root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  bash B275_LMDA_REPLAY_CORE_V1/run_b275.sh --stage core-night \
  > codex_b275_adscm.log 2>&1 < /dev/null &
tail -F codex_b275_adscm.log
```

两组：原L1-Tail继续训练、Stage2两个第一ACB改为ADSCM后训练。其余WCSG、TFCG、shortcut等加载原L1权重；新ADSCM随机初始化，**不声称初始化与L1输出相同**。全部CNN和BN参与训练，避免重复旧的仅训练残差adapter实验。

TRAIN16000/VAL3000，每组4epoch、batch32，原参数LR3e-5、新参数LR3e-4。继续使用原B215的L1_TAIL目标（CE + 0.05尾部排序），不增加WCSG约束项。按最小VAL CE选模型，包含本组epoch0。替换组epoch0是新随机模块，并非旧L1；不可把两组初始性能认为相同。

训练时仅使用TRAIN/VAL，WVD按冻结原公式从IQ分批生成，不依赖曾被删除的WVD H5，也不生成新的大磁盘缓存。旧L1权重SHA和契约须核对通过。该分支保留WVD，**不加入B271 phase-ARS**，优先分离LMDA模块的作用。

评分只跑500k CAL/200k CHECK/1024×37 H1、Pfa1e-4。读取已完成B274全部原始分数以及B222/B223专家分数，加入旧LMDA和固定75:25秩融合强对照，全部逐模型重新按medium CAL估计阈值。固定融合仍使用历史3M支持的ECDF，不能把它标成仅500k历史支持的新训练方法。报告比较同场景、同名义Pfa，独立CHECK实际Pfa和置信区间同时保留。

额外必需：`output_b274_single_spwvd_resnet18_v1`完整训练/评分结果、B222/B223原始分数和协议。启动时先核对元数据和存在性；训练不读取CAL/CHECK/H1分数。新结果为`output_b275_lmda_replay_core_v1/{continued,adscm,core_pd_scr_medium}`。core-night没有自动全量阶段，重跑会从最后完整epoch恢复。替换不保证提升。

本轮只测输入条件方向卷积这个研究假设。固定权重方向分支、去CBAM、不同插入阶段、多种子和独立海况等消融在有效后再补，不能用本轮两个组就断言ADSCM的全部机制成立。论文应引用LMDA，并准确写明上述通道/步幅改动。
