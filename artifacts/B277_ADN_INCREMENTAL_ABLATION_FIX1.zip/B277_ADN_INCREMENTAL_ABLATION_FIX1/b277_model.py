"""Two missing ablations. Native ADN SimAM remains active in BOTH arms."""
import torch
from torch import nn
from b271_data import need
from b276_model import MigratedADN,migrate
from source_loader import load_frozen_sources

ARMS=('spwvd_adn','spwvd_wcsg')
NAMES={'spwvd_adn':'SPWVD + original ADN (SimAM)',
       'spwvd_wcsg':'SPWVD + ADN + WCSG (SimAM)',
       'FULL':'SPWVD ADN/WCSG/TFCG',
       'ORIGINAL':'Original ADN (WVD; historical training)'}


class IdentityGate(nn.Module):
    def forward(self,x):return x,{}


class StepADN(MigratedADN):
    def __init__(self,arm,backend,scale):
        need(arm in ARMS,'Unknown B277 ablation')
        # Same construction/RNG use as the existing B276 full model, before
        # removing modules. Do not make accidental new randomly seeded ACBs.
        super().__init__(backend,scale,phase=False)
        self.arm=arm;source=load_frozen_sources()[0]
        for stage in ('layer1','layer2','layer3','layer4'):
            for block in getattr(self.detector,stage):
                block.simam=source.SimAM(block.conv2.out_channels,e_lambda=source.SIMAM_LAMBDA)
        if arm=='spwvd_adn':self.suppressor=IdentityGate()
    def spec(self):
        return dict(frontend='SPWVD',ADN_ACB=True,WCSG=self.arm=='spwvd_wcsg',SimAM=True,TFCG=False,phase_ARS=False)


def factory(arm,backend,scale):return StepADN(arm,backend,scale)


def initialize(model,teacher,arm):return migrate(model,teacher,'adn')


@torch.inference_mode()
def initial_check(model,teacher,iq):
    model.eval();teacher.eval();images=teacher.frontend.images(iq)
    expected=teacher.prepared_forward(images,iq);actual=model.prepared_forward(images,iq)
    need(actual.shape==expected.shape and torch.isfinite(actual).all().item(),'Invalid initialized ADN logits')
    # Original SimAM is nonlinear and attenuates features. Keeping it is a
    # genuine architecture ablation: it is not bypassed to fake equivalence.
    return dict(maxabs_logit_difference=float((actual-expected).abs().max()),train_probe_n=len(iq),
        initial_function_preserved_within_tolerance=False,reason='Native ADN SimAM retained; source ResNet18 has no SimAM',
        pretrained_central_convolutions_BN_shortcuts_FC_copied=True,architecture=model.spec())


@torch.inference_mode()
def diagnostics(model,probe):
    result=dict(architecture=model.spec(),axial_BN_gamma_abs_mean=float(torch.cat([
        block.ver_bn.weight.detach().abs().flatten() for stage in ('layer1','layer2','layer3','layer4') for block in getattr(model.detector,stage)]).mean()))
    if model.arm=='spwvd_wcsg':
        _,aux=model(probe,return_aux=True);gain=aux['gate']/model.suppressor.initial_gain
        result.update(wcsg_gain_mean=float(gain.mean()),wcsg_gain_std=float(gain.std()))
    return result
