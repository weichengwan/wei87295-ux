"""Own-CAL strict-decision statistics; medium requests only nominal Pfa1e-4."""
from pathlib import Path
import csv
import numpy as np
from b271_data import need
from source_loader import load_frozen_file

def save_csv(path,rows):
    if not rows:return
    with Path(path).open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def crossing(x,y,level):
    if y[0]>=level:return float(x[0])
    for i in range(1,len(x)):
        if y[i-1]<level<=y[i]:
            return float(x[i-1]+(level-y[i-1])*(x[i]-x[i-1])/(y[i]-y[i-1]))
    return None

def metrics_for(name,cal,audit,h1,protocol):
    statistics=load_frozen_file("r10_sim_stage_b216_pdscr_report_v1.py")
    need(np.isfinite(cal).all() and np.isfinite(audit).all() and np.isfinite(h1).all(),"Nonfinite scores")
    curves,metrics=[],[]
    for nominal in protocol.get("nominal_pfas",(1e-4,1e-5)):
        threshold,k,cal_fp=statistics.cutoff(cal,nominal)
        false=int((audit>threshold).sum())
        low,high=statistics.wilson(false,len(audit))
        hits=(h1>threshold).sum(1)
        pd=hits/h1.shape[1]
        metric=dict(method=name,nominal_pfa=nominal,actual_pfa=false/len(audit),
                    audit_false_alarms=false,audit_n=len(audit),actual_pfa_ci95_low=low,
                    actual_pfa_ci95_high=high,threshold=threshold,cal_n=len(cal),
                    cal_tail_support=k,cal_exceedances=cal_fp,
                    D50_db=crossing(protocol["scr_grid_db"],pd,.5),
                    D80_db=crossing(protocol["scr_grid_db"],pd,.8),
                    D90_db=crossing(protocol["scr_grid_db"],pd,.9))
        for level in (0,6,9,12):
            metric["pd_at_"+str(level)]=float(pd[protocol["scr_grid_db"].index(level)]) if level in protocol["scr_grid_db"] else None
        metrics.append(metric)
        for scr,n in zip(protocol["scr_grid_db"],hits):
            lo,hi=statistics.wilson(int(n),h1.shape[1])
            curves.append(dict(method=name,nominal_pfa=nominal,scr_db=scr,hits=int(n),
                               n_h1=h1.shape[1],pd=float(n/h1.shape[1]),pd_ci95_low=lo,pd_ci95_high=hi))
    return curves,metrics
