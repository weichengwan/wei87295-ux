"""Exercise the real runner/source-metadata boundary that failed on AutoDL."""
import copy
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import torch
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from b271_data import digest_file, read_json
from b273_shared import setup
import b277_run as runner
from test_b276 import fixture, source_fixture
from test_b277 import completed_full
from b276_score import predictions


class Fix1Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        setup(2)

    def test_runner_preflight_real_source_and_full_metadata(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            context, data, generator = fixture(root)
            source = source_fixture(root, context, data, generator)
            argv = ['--root', directory, '--device', 'cpu', '--stage', 'preflight',
                    '--source-run', str(source['run_dir']), '--full-run', str(root/'full'),
                    '--train-limit', '4', '--val-limit', '4']
            args = runner.cli(argv)
            full_folder, original = completed_full(root, context, data, generator, source, args)
            files = [path for folder in (source['run_dir'], full_folder.parent, context['bank_dir'])
                     for path in folder.rglob('*') if path.is_file()]
            before = {str(path): digest_file(path) for path in files}
            # Only the production 30k/5k bank contract and B213 disk lookup are
            # replaced by generated fixtures. The actual source/full validators
            # and their argument binding are exercised through runner.main.
            with patch.object(runner, 'resolve', return_value=context), \
                 patch.object(runner, 'original_protocol', return_value=(None, original, generator)):
                runner.main(argv)
                result = read_json(args.out_dir/'preflight.json')
                self.assertEqual(result['train_rows'], data.selection)
                self.assertEqual(result['full_source'], str(full_folder))
                self.assertFalse(result['historical_original_adn']['available'])
                wrong = copy.deepcopy(data.selection)
                wrong['train']['row_indices_sha256'] = 'genuinely different selection'
                with self.assertRaisesRegex(RuntimeError, 'selection differs'):
                    runner.references(args, context, wrong)
            self.assertEqual(before, {str(path): digest_file(path) for path in files})

    def test_actual_runner_training_and_score_model_reload(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            context, data, generator = fixture(root)
            source = source_fixture(root, context, data, generator)
            common = ['--root', directory, '--device', 'cpu',
                      '--source-run', str(source['run_dir']), '--full-run', str(root/'full'),
                      '--train-limit', '4', '--val-limit', '4']
            args = runner.cli(common)
            full_folder, original = completed_full(root, context, data, generator, source, args)
            files = [path for folder in (source['run_dir'], full_folder.parent, context['bank_dir'])
                     for path in folder.rglob('*') if path.is_file()]
            before = {str(path): digest_file(path) for path in files}
            with patch.object(runner, 'resolve', return_value=context), \
                 patch.object(runner, 'original_protocol', return_value=(None, original, generator)):
                runner.main(common + ['--stage', 'train'])
                contracts = [read_json(args.out_dir/arm/'training_contract.json')
                             for arm in ('spwvd_adn', 'spwvd_wcsg')]
                self.assertTrue(all(value['epochs_executed'] == 4 for value in contracts))
                self.assertTrue(all(value['run_config']['loss'] == 'CE' for value in contracts))
                self.assertEqual([value['trainable_parameters'] for value in contracts],
                                 [14330946, 14331475])
                import b277_score
                import b277_report
                observed = []

                def small_prediction_probe(score_args, protocol, generator_arg, models,
                                           teacher, device, cached):
                    self.assertEqual(len(models), 2)
                    self.assertEqual(protocol['candidate_labels'], ['spwvd_adn', 'spwvd_wcsg'])
                    self.assertEqual(protocol['h0_cal_n'], 500000)
                    self.assertEqual(protocol['h0_audit_n'], 200000)
                    self.assertEqual(protocol['nominal_pfas'], [1e-4])
                    self.assertEqual(cached['h0_cal'].shape, (500000, 2))
                    # Probe the production model reload/render/prediction path;
                    # do not infer hundreds of thousands of CPU fixtures.
                    iq = np.stack([generator_arg.make_one(20261009, 'dev_h1', i, -30, 10)['iq']
                                   for i in range(2)]).astype('complex64')
                    scores = predictions(models, teacher, iq, device, 32)
                    self.assertEqual(scores.shape, (2, 2))
                    self.assertTrue(np.isfinite(scores).all())
                    observed.append(protocol)

                with patch.object(b277_score, 'stream', side_effect=small_prediction_probe), \
                     patch.object(b277_report, 'generate', return_value={'functional_fixture': True}):
                    result = runner.main(common + ['--stage', 'score'])
                self.assertTrue(result['functional_fixture'])
                self.assertEqual(len(observed), 1)
            self.assertEqual(before, {str(path): digest_file(path) for path in files})


if __name__ == '__main__':
    unittest.main(verbosity=2)
