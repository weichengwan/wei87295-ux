"""Generated/synthetic functionality; no trained AutoDL weights or Pd claims."""
import gc,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np,torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from b271_data import digest_file,fingerprint,load_checkpoint,read_json,write_json
from b273_shared import setup
from b273_statistics import metrics_for,save_csv
from b274_model import SingleBranch,select_backend
from b276_train import train_arm,configuration
from b276_model import CenteredWCSG
from b276_score import stream
from b277_model import ARMS,NAMES,factory,initialize,initial_check,diagnostics
import b277_references as refs
from b277_report import generate,table_rows
from b277_run import PASS
import b277_run as runner
import b276_train as trainer
from source_loader import load_frozen_sources
from test_b276 import fixture,original,source_fixture


def hooks():return dict(status=PASS,version='B277_ADN_INCREMENTAL_ABLATION_TRAIN_V1',factory=factory,migrate=initialize,verify_initial=initial_check,diagnostics=diagnostics)


def completed_full(root,context,data,g,source,a):
    directory=root/'full';model=directory/'adn';model.mkdir(parents=True);path=model/'best.pt';path.write_bytes(b'Synthetic full-model checkpoint identity only')
    cfg=configuration(a,context,data,source,'adn');cfg['code_sha256']=read_json(Path(refs.__file__).parent/'b276_release_sources.json')
    identity=dict(arm='adn',sha256=digest_file(path),selected_epoch=4,trainable_parameters=14533299)
    c=dict(status=refs.B276_PASS,run_config=cfg,run_fingerprint=fingerprint(cfg),checkpoint_sha256=digest_file(path),best_epoch=4)
    write_json(model/'training_contract.json',c)
    old=original(context,g);scene=dict(old);scene.update(h0_cal_n=500000,h0_audit_n=200000)
    p=dict(version='B276_SPWVD_ADN_PHASE_SCORE_V1',**scene,scene_fingerprint=fingerprint(scene),nominal_pfas=[1e-4],
        labels=['adn','BASE_L1_TAIL'],names={'adn':NAMES['FULL'],'BASE_L1_TAIL':'L1-Tail'},code_sha256=cfg['code_sha256'],
        checkpoints=[identity],batch=32,device='cpu',tf32=False,score_definition='float64(float32 logit1 - float32 logit0)')
    p['fingerprint']=fingerprint(p);folder=directory/'pd_scr_medium';folder.mkdir()
    write_json(folder/'protocol_frozen.json',p);write_json(folder/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=500000,h0_audit=200000,h1=37)))
    cal=np.tile(np.linspace(-6,6,500000)[:,None],(1,2));audit=np.tile(np.linspace(-6,6,200000)[:,None],(1,2));q=(np.arange(1024)+.5)/1024
    h1=np.stack([6+(scr-np.log(q/(1-q)))/3 for scr in range(-24,13)]);h1=np.stack([h1,h1-1/3],2)
    for name,v in [('h0_cal_scores.npy',cal),('h0_audit_scores.npy',audit),('dev_h1_scores.npy',h1)]:np.save(folder/name,v)
    curves=[];metrics=[]
    for j,label in enumerate(p['labels']):
        cv,mt=metrics_for(p['names'][label],cal[:,j],audit[:,j],h1[:,:,j],p);curves+=cv;metrics+=mt
    save_csv(folder/'b276_curves.csv',curves);save_csv(folder/'b276_metrics.csv',metrics)
    return folder,old


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):setup(2)

    def test_real_simam_architecture_and_shared_initial_backbone(self):
        with tempfile.TemporaryDirectory() as t:
            b=select_backend(Path(t),'recovered');teacher=SingleBranch(b,2.).eval();iq=torch.randn(2,512,dtype=torch.complex64);models=[]
            source,training,_=load_frozen_sources()
            for arm in ARMS:
                torch.manual_seed(11);m=factory(arm,b,2.);copied=initialize(m,teacher,arm)
                self.assertEqual(sum(isinstance(v,source.SimAM) for v in m.modules()),8)
                self.assertEqual(sum(isinstance(v,training.TFCG) for v in m.modules()),0)
                self.assertFalse(m.use_phase);self.assertEqual(m.spec()['WCSG'],arm=='spwvd_wcsg')
                result=initial_check(m,teacher,iq);self.assertFalse(result['initial_function_preserved_within_tolerance'])
                m.eval();models.append(m)
                for stage in ('layer1','layer2','layer3','layer4'):
                    for s,d in zip(getattr(teacher.net,stage),getattr(m.detector,stage)):self.assertTrue(torch.equal(s.conv1.weight,d.conv3.weight))
                self.assertTrue(copied)
            with torch.no_grad():torch.testing.assert_close(models[0](iq),models[1](iq),atol=2e-6,rtol=2e-6)
            for m in models:
                m.train();z=m(iq);torch.nn.functional.cross_entropy(z,torch.tensor([0,1])).backward()
                self.assertGreater(float(m.detector.layer2[0].ver_bn.weight.grad.abs().sum()),0)
                if m.arm=='spwvd_wcsg':self.assertGreater(float(m.suppressor.gate.out.weight.grad.abs().sum()),0)
            self.assertEqual(sum(p.numel() for p in models[0].parameters()),14330946)
            self.assertEqual(sum(p.numel() for p in models[1].parameters()),14331475)

    def test_meta_and_double_prepared_forward_after_move(self):
        with tempfile.TemporaryDirectory() as t:
            b=select_backend(Path(t),'recovered')
            for arm in ARMS:
                m=factory(arm,b,2.).to('meta').eval();self.assertTrue(all(p.device.type=='meta' for p in m.parameters()))
                z=m.prepared_forward(torch.empty(2,3,224,224,device='meta'),torch.empty(2,512,device='meta',dtype=torch.complex64))
                self.assertEqual(tuple(z.shape),(2,2))
            m=factory('spwvd_wcsg',b,2.).double().eval();z=m.prepared_forward(torch.randn(2,3,224,224,dtype=torch.float64),None)
            self.assertEqual(z.dtype,torch.float64)

    @unittest.skipUnless(torch.cuda.is_available(),'Local CUDA unavailable')
    def test_cuda_forward_backward(self):
        with tempfile.TemporaryDirectory() as t:
            b=select_backend(Path(t),'recovered');teacher=SingleBranch(b,2.).cuda().eval()
            for arm in ARMS:
                m=factory(arm,b,2.).cuda();initialize(m,teacher,arm);z=m(torch.randn(2,512,dtype=torch.complex64,device='cuda'))
                z.square().mean().backward();self.assertTrue(all(p.is_cuda for p in m.parameters()))

    def test_actual_training_resume_new_groups_and_teacher_unchanged(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);context,data,g=fixture(root);source=source_fixture(root,context,data,g);sha=digest_file(source['checkpoint'])
            a=SimpleNamespace(out_dir=root/'resume',seed=20261022,epochs=2,batch=2,lr=1e-5,new_lr=1e-4,device=torch.device('cpu'))
            save=trainer.atomic_save;stopped=[False]
            def interrupt(path,state):
                save(path,state)
                if path.name=='last_epoch.pt' and state['epoch']==1 and not stopped[0]:stopped[0]=True;raise InterruptedError('Committed epoch fixture')
            with patch.object(trainer,'atomic_save',side_effect=interrupt):
                with self.assertRaises(InterruptedError):train_arm(a,context,data,source,'spwvd_wcsg',hooks())
            train_arm(a,context,data,source,'spwvd_wcsg',hooks());one=load_checkpoint(a.out_dir/'spwvd_wcsg/last_epoch.pt')
            a.out_dir=root/'continuous';c=train_arm(a,context,data,source,'spwvd_wcsg',hooks());two=load_checkpoint(a.out_dir/'spwvd_wcsg/last_epoch.pt')
            for k,v in one['state_dict'].items():self.assertTrue(torch.equal(v,two['state_dict'][k]),k)
            self.assertEqual(sha,digest_file(source['checkpoint']));self.assertFalse(c['original_cal_audit_dev_used_for_training'])
            a.epochs=1;a.out_dir=root/'plain';c=train_arm(a,context,data,source,'spwvd_adn',hooks());self.assertEqual(c['status'],PASS)

    def test_full_cache_budget_matching_and_historical_adn_reuse_without_weights(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);context,data,g=fixture(root);source=source_fixture(root,context,data,g)
            a=SimpleNamespace(seed=20261022,epochs=4,batch=32,lr=1e-5,new_lr=1e-4)
            folder,old=completed_full(root,context,data,g,source,a)
            info=refs.full_metadata(folder,context,old,torch.device('cpu'),data.selection,source,a);cache,details=refs.full_arrays(info)
            self.assertTrue(details['all_source_counts_replayed']);a.epochs=5
            with self.assertRaisesRegex(RuntimeError,'budget must match'):refs.full_metadata(folder,context,old,torch.device('cpu'),data.selection,source,a)
            self.assertFalse(refs.historical_metadata(root,old)['available'])
            directory=root/'output_sim_r10_b222_gpu_dualpfa_v1/seed_20261022';directory.mkdir(parents=True)
            old['scene_fingerprint']='synthetic full-scene identity'
            p=dict(version='SIM_R10_B222_GPU_DUALPFA_V1',methods=['Original ADN','L1-Tail','Original M2','FT-KD-Order'],
                checkpoint_sha256={'Original ADN':refs.ADN_SHA},scene_fingerprint=old['scene_fingerprint'],batch=16)
            write_json(directory/'protocol_frozen.json',p)
            for name,shape in [('h0_cal_scores.npy',(3000000,4)),('h0_audit_scores.npy',(1000000,4)),('dev_h1_scores_37.npy',(37,1024,4))]:
                v=np.lib.format.open_memmap(directory/name,mode='w+',dtype='float64',shape=shape);v[...,0]=.25;v.flush();del v
            before={str(p):digest_file(p) for p in directory.iterdir()}
            with patch.object(refs,'B222_SHA',digest_file(directory/'protocol_frozen.json')):history=refs.historical_metadata(root,old)
            result,record=refs.append_historical(history,cache);self.assertEqual(result['h0_cal'].shape,(500000,3));self.assertEqual(float(result['h0_cal'][0,-1]),.25)
            self.assertEqual(record['inference_batch'],16);self.assertFalse(record['matched_training_budget']);self.assertFalse(record['original_weights_required_for_score_reuse'])
            self.assertEqual(before,{str(p):digest_file(p) for p in directory.iterdir()})
            bad=np.load(folder/'h0_audit_scores.npy',mmap_mode='r+');bad[0,0]=1000;bad.flush();del bad
            with self.assertRaisesRegex(RuntimeError,'H0 count replay'):refs.full_arrays(info)

    def test_generated_iq_stream_for_two_arms_and_resume(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);context,data,g=fixture(root);b=select_backend(root,'recovered');teacher=SingleBranch(b,2.).eval();models=[]
            for arm in ARMS:
                m=factory(arm,b,2.);initialize(m,teacher,arm);models.append(m.eval())
            p=original(context,g);p.update(h0_cal_n=4,h0_audit_n=4,h1_scenes_n=2,scr_grid_db=[-1,0,1],labels=list(ARMS)+['REF_adn']);p['fingerprint']=fingerprint(p)
            cache=dict(h0_cal=np.zeros((4,1)),h0_audit=np.zeros((4,1)),h1=np.zeros((3,2,1)))
            a=SimpleNamespace(out_dir=root/'score',batch=2,chunk=2);stream(a,p,g,models,None,torch.device('cpu'),cache)
            hashes=[digest_file(a.out_dir/f) for f in ('h0_cal_scores.npy','h0_audit_scores.npy','dev_h1_scores.npy')]
            stream(a,p,g,models,None,torch.device('cpu'),cache)
            self.assertEqual(hashes,[digest_file(a.out_dir/f) for f in ('h0_cal_scores.npy','h0_audit_scores.npy','dev_h1_scores.npy')])

    def test_four_row_table_attention_replacement_report_and_missing_history(self):
        with tempfile.TemporaryDirectory() as t:
            out=Path(t);cal=np.linspace(-6,6,100000);audit=np.linspace(-6,6,20000);q=(np.arange(1024)+.5)/1024
            h1=np.stack([6+(scr-np.log(q/(1-q)))/3 for scr in range(-24,13)])
            p=dict(version='B277_ADN_INCREMENTAL_ABLATION_SCORE_V1',h0_cal_n=100000,h0_audit_n=20000,h1_scenes_n=1024,scr_grid_db=list(range(-24,13)),nominal_pfas=[1e-4],
                labels=['spwvd_adn','spwvd_wcsg','REF_adn','HIST_ADN'],names={'spwvd_adn':NAMES['spwvd_adn'],'spwvd_wcsg':NAMES['spwvd_wcsg'],'REF_adn':NAMES['FULL'],'HIST_ADN':NAMES['ORIGINAL']},
                checkpoints=[{'arm':'spwvd_adn','trainable_parameters':14330946},{'arm':'spwvd_wcsg','trainable_parameters':14331475}],
                reused_full_checkpoint={'trainable_parameters':14533299},scope='Synthetic functional test only',reused_baselines={})
            p['fingerprint']=fingerprint(p);write_json(out/'protocol_frozen.json',p);write_json(out/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=100000,h0_audit=20000,h1=37)))
            for name,v in [('h0_cal_scores.npy',np.stack([cal]*4,1)),('h0_audit_scores.npy',np.stack([audit]*4,1)),('dev_h1_scores.npy',np.stack([h1-2/3,h1-1/3,h1,h1-1],2))]:np.save(out/name,v)
            result=generate(out);rows=result['ablation_table'];self.assertEqual(len(rows),4)
            self.assertTrue(rows[1]['SimAM']);self.assertTrue(rows[2]['SimAM']);self.assertFalse(rows[3]['SimAM']);self.assertTrue(rows[3]['TFCG'])
            self.assertFalse(rows[0]['matched_extra_training_budget']);self.assertFalse(result['isolated_WVD_to_SPWVD_gain_established']);self.assertFalse(result['automatic_promotion'])
            self.assertAlmostEqual(result['comparisons'][1]['delta_D90_db'],-1.,places=8)
            self.assertTrue((out/'b277_ablation_table.pdf').is_file());self.assertTrue((out/'b277_ablation_table.csv').read_bytes().startswith(b'\xef\xbb\xbf'))
            manifest=read_json(out/'figures/b277_ablation_curves_paper_manifest.json');self.assertEqual(manifest['styles'][NAMES['FULL']]['marker'],'v');self.assertFalse(manifest['smoothing'])
            self.assertEqual(list(manifest['styles'])[0],NAMES['ORIGINAL'])
            missing=table_rows(p,{'spwvd_adn':{'D90_db':2.}});self.assertEqual(missing[0]['result_status'],'missing; not filled');self.assertIsNone(missing[0]['D90_db'])
            p['training_budget']=dict(train_n=8000,val_n=1500,epochs=6)
            dynamic=table_rows(p,{})
            self.assertIn('TRAIN8000/VAL1500',dynamic[1]['training_note']);self.assertIn('extra6epoch',dynamic[1]['training_note'])
            self.assertFalse(dynamic[1]['initial_function_same_as_B274']);self.assertTrue(dynamic[3]['initial_function_same_as_B274'])

    def test_runner_defaults_and_gpu_lock(self):
        import fcntl
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);a=runner.cli(['--root',t,'--device','cpu']);self.assertEqual(a.epochs,4);self.assertEqual(a.batch,32)
            with (root/'codex_b271_night.lock').open('a') as lock:
                fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
                with patch.object(runner,'cli',return_value=a):
                    with self.assertRaisesRegex(SystemExit,'GPU lock'):runner.main([])
            with patch.object(runner.fcntl,'flock',side_effect=[BlockingIOError(),None]) as acquire,patch.object(runner.time,'sleep') as sleep:
                runner.acquire_gpu(object(),True);self.assertEqual(acquire.call_count,2);sleep.assert_called_once_with(15)


if __name__=='__main__':unittest.main(verbosity=2)
