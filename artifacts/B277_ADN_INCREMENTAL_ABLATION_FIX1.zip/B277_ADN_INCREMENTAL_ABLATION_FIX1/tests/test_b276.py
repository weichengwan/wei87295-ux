"""Generated/synthetic CPU functionality; no GPU detector gains are claimed."""
import gc,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import h5py,numpy as np,torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from b271_data import digest_file,fingerprint,load_checkpoint,read_json,write_json
from b273_shared import setup
from b273_statistics import metrics_for,save_csv
from b274_data import Data
from b274_model import SingleBranch,select_backend
from source_loader import load_frozen_file
from b276_model import ARMS,SPWVDPhaseEvidence,make_model,migrate,verify_initial,parameter_groups,PowerDiagnostic
from b276_score import stream
from b276_report import generate
import b276_train as trainer
import b276_source as sources
import b276_run as runner


def fixture(root):
    bank=root/'bank';bank.mkdir();hp=bank/'iq.h5';g=load_frozen_file('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
    with h5py.File(hp,'w') as h:
        for split in ('train','val'):
            samples=[g.make_one(20261009,split,i,-30,10) for i in range(4)]
            v=h.create_group(split);v['iq']=np.stack([s['iq'] for s in samples]).astype('complex64');v['label']=np.array([s['label'] for s in samples],dtype='uint8');v['family_index']=np.arange(4)%2
    c=dict(root=root,bank_dir=bank,bank_path=hp,b210=load_frozen_file('r10_sim_stage_b210_a3_adn_earlystop_v1.py'),
           bc=dict(file_sha256=digest_file(hp),generator_sha256=digest_file(g.__file__)))
    return c,Data(c,4,4,20261022),g


def original(c,g):
    return dict(master_seed=20261009,generator_sha=c['bc']['generator_sha256'],h0_cal_n=3000000,h0_audit_n=1000000,h1_scenes_n=1024,
        scr_grid_db=list(range(-24,13)),h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',family_names=list(g.TRAIN_FAMILIES),scr_definition='synthetic fixture')


def source_fixture(root,c,data,g,with_arrays=False):
    folder=root/'source';folder.mkdir();backend=select_backend(root,'recovered');model=SingleBranch(backend,2.)
    cfg=dict(code_sha256=read_json(Path(sources.__file__).parent/'b274_release_sources.json'),bank_sha256=c['bc']['file_sha256'],selected_rows=data.selection,backend=backend,scale=2.)
    fp=fingerprint(cfg);write_json(folder/'run_manifest.json',dict(run_config=cfg,run_fingerprint=fp,bank_dir=str(c['bank_dir'])))
    path=folder/'best.pt';torch.save(dict(state_dict=model.state_dict(),epoch=0,run_config=cfg,run_fingerprint=fp),path)
    contract=dict(status=sources.SOURCE_PASS,run_fingerprint=fp,checkpoint_sha256=digest_file(path),best_epoch=0)
    write_json(folder/'training_contract.json',contract);old=original(c,g);scene=dict(old);scene.update(h0_cal_n=500000,h0_audit_n=200000)
    p=dict(version='B274_SINGLE_SPWVD_RESNET18_SCORE_V1',**scene,scene_fingerprint=fingerprint(scene),nominal_pfas=[1e-4],labels=['SINGLE','L1_TAIL'],names={'SINGLE':'Synthetic B274','L1_TAIL':'L1-Tail'},
        checkpoint={'sha256':contract['checkpoint_sha256']},training_run_fingerprint=fp,code_sha256=cfg['code_sha256'],batch=32,device='cpu',tf32=False,score_definition='float64(float32 logit1 - float32 logit0)')
    p['fingerprint']=fingerprint(p);score=folder/'pd_scr_medium';score.mkdir();write_json(score/'protocol_frozen.json',p);write_json(score/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=500000,h0_audit=200000,h1=37)))
    if with_arrays:
        cal=np.tile(np.linspace(-6,6,500000)[:,None],(1,2));audit=np.tile(np.linspace(-6,6,200000)[:,None],(1,2));q=(np.arange(1024)+.5)/1024
        h1=np.stack([6+(scr-np.log(q/(1-q)))/3 for scr in range(-24,13)]);h1=np.stack([h1,h1-1/3],2)
        for name,v in [('h0_cal_scores.npy',cal),('h0_audit_scores.npy',audit),('dev_h1_scores.npy',h1)]:np.save(score/name,v)
        curves=[];metrics=[]
        for j,label in enumerate(p['labels']):
            cv,mt=metrics_for(p['names'][label],cal[:,j],audit[:,j],h1[:,:,j],p);curves+=cv;metrics+=mt
        save_csv(score/'b274_curves.csv',curves);save_csv(score/'b274_metrics.csv',metrics)
    else:
        for name in ('h0_cal_scores.npy','h0_audit_scores.npy','dev_h1_scores.npy','b274_curves.csv','b274_metrics.csv'):(score/name).touch()
    return sources.metadata(folder,c,torch.device('cpu'),data.selection,old)


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):setup(2)

    def test_warm_transfer_all_three_arms_and_new_parameter_gradients(self):
        with tempfile.TemporaryDirectory() as t:
            b=select_backend(Path(t),'recovered');teacher=SingleBranch(b,2.).eval();iq=torch.randn(2,512,dtype=torch.complex64)
            for arm in ARMS:
                m=make_model(arm,b,2.);copied=migrate(m,teacher,arm);r=verify_initial(m,teacher,iq)
                self.assertLess(r['maxabs_logit_difference'],1e-5)
                groups=parameter_groups(m,copied,1e-5,1e-4)
                self.assertEqual(sum(len(g['params']) for g in groups),len(list(m.parameters())))
                m.train()
                if arm=='continued':z=m(iq);reg=0.
                else:z,aux=m(iq,True);reg=.02*aux['offset_regularizer']
                (z.square().mean()+reg).backward()
                if arm!='continued':
                    self.assertGreater(float(m.detector.layer2[0].ver_bn.weight.grad.abs().sum()),0)
                    self.assertGreater(float(m.suppressor.gate.out.weight.grad.abs().sum()),0)
                    self.assertTrue(all(p.requires_grad for p in m.parameters()))
                if arm=='phase':self.assertGreater(float(m.resample1.offset[-1].weight.grad.abs().sum()),0)
                del m;gc.collect()

    def test_phase_evidence_exact_frequency_axis_alias_and_invariances(self):
        m=SPWVDPhaseEvidence();n=torch.arange(512)
        for f,row in ((.125,96),(-.125,32),(.125+.5,96)):
            x=torch.exp(2j*torch.pi*f*n)[None];v=m(x)
            self.assertEqual(v.shape,(1,2,128,128));self.assertEqual(int(v[0,0].mean(1).argmax()),row)
            self.assertGreater(float(v[0,1,row,40:90].mean()),.95)
        x=torch.randn(2,512,dtype=torch.complex64);v=m(x)
        torch.testing.assert_close(m(x*torch.exp(torch.tensor(.73j))*4),v,atol=2e-5,rtol=2e-5)
        torch.testing.assert_close(torch.cat([m(x[i:i+1]) for i in range(2)]),v,atol=2e-6,rtol=2e-6)
        self.assertEqual(float(m(torch.zeros(1,512,dtype=torch.complex64)).abs().max()),0.)
        diagnostic=PowerDiagnostic(None);iq=torch.randn(2,512,dtype=torch.complex64)
        torch.testing.assert_close(diagnostic.prepared_forward(None,iq)[:,1],iq.abs().square().mean(1))
        self.assertEqual(len(list(diagnostic.parameters())),0)

    def test_actual_training_resume_and_source_preservation(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);c,data,g=fixture(root);info=source_fixture(root,c,data,g)
            original_sha=digest_file(info['checkpoint'])
            a=SimpleNamespace(out_dir=root/'resume',seed=20261022,epochs=2,batch=2,lr=1e-5,new_lr=1e-4,device=torch.device('cpu'))
            save=trainer.atomic_save;stopped=[False]
            def interrupt(path,state):
                save(path,state)
                if path.name=='last_epoch.pt' and state['epoch']==1 and not stopped[0]:stopped[0]=True;raise InterruptedError('committed epoch interruption fixture')
            with patch.object(trainer,'atomic_save',side_effect=interrupt):
                with self.assertRaises(InterruptedError):trainer.train_arm(a,c,data,info,'adn')
            contract=trainer.train_arm(a,c,data,info,'adn');first=load_checkpoint(a.out_dir/'adn/last_epoch.pt')
            a.out_dir=root/'continuous';trainer.train_arm(a,c,data,info,'adn');second=load_checkpoint(a.out_dir/'adn/last_epoch.pt')
            self.assertEqual(first['best_epoch'],second['best_epoch'])
            for k,v in first['state_dict'].items():self.assertTrue(torch.equal(v,second['state_dict'][k]),k)
            self.assertEqual(original_sha,digest_file(info['checkpoint']));self.assertFalse(contract['original_cal_audit_dev_used_for_training'])
            a.lr*=2
            with self.assertRaisesRegex(RuntimeError,'settings changed'):trainer.train_arm(a,c,data,info,'adn')

    def test_b274_cache_replays_thresholds_and_detects_damage(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);c,data,g=fixture(root);info=source_fixture(root,c,data,g,True)
            cache,details=sources.arrays(info);self.assertTrue(details['own_threshold_false_alarms_all37_hits_replayed']);del cache
            path=info['folder']/'h0_audit_scores.npy';a=np.load(path,mmap_mode='r+');a[0,0]=1000;a.flush();del a
            with self.assertRaisesRegex(RuntimeError,'H0 count replay'):sources.arrays(info)

    def test_actual_multi_model_stream_and_resume(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);c,data,g=fixture(root);b=select_backend(root,'recovered');teacher=SingleBranch(b,2.).eval();models=[]
            for arm in ARMS:
                m=make_model(arm,b,2.);migrate(m,teacher,arm);models.append(m.eval())
            p=original(c,g);p.update(h0_cal_n=4,h0_audit_n=4,h1_scenes_n=2,scr_grid_db=[-1,0,1],labels=list(ARMS)+['fixture']);p['fingerprint']=fingerprint(p)
            cached=dict(h0_cal=np.zeros((4,1)),h0_audit=np.zeros((4,1)),h1=np.zeros((3,2,1)))
            a=SimpleNamespace(out_dir=root/'score',batch=2,chunk=2);stream(a,p,g,models,None,torch.device('cpu'),cached)
            names=['h0_cal_scores.npy','h0_audit_scores.npy','dev_h1_scores.npy'];hashes=[digest_file(a.out_dir/f) for f in names]
            stream(a,p,g,models,None,torch.device('cpu'),cached);self.assertEqual(hashes,[digest_file(a.out_dir/f) for f in names])
            x=np.load(a.out_dir/names[0]);np.testing.assert_allclose(x[:,0],x[:,2],atol=1e-5,rtol=1e-5)
            (a.out_dir/names[0]).unlink()
            with self.assertRaisesRegex(RuntimeError,'missing despite'):stream(a,p,g,models,None,torch.device('cpu'),cached)

    def test_analytic_report_and_default_gpu_lock(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);cal=np.linspace(-6,6,100000);audit=np.linspace(-6,6,20000);q=(np.arange(1024)+.5)/1024
            h1=np.stack([6+(scr-np.log(q/(1-q)))/3 for scr in range(-24,13)])
            p=dict(version='B276_SPWVD_ADN_PHASE_SCORE_V1',h0_cal_n=100000,h0_audit_n=20000,h1_scenes_n=1024,scr_grid_db=list(range(-24,13)),nominal_pfas=[1e-4],
                labels=['phase','BASE_SINGLE','BASE_L1_TAIL'],names={'phase':'Synthetic phase','BASE_SINGLE':'Synthetic B274','BASE_L1_TAIL':'L1-Tail'},candidate_labels=['phase'],ours_label='phase',checkpoints=[],reused_baselines={},scope='Synthetic only')
            p['fingerprint']=fingerprint(p);write_json(root/'protocol_frozen.json',p);write_json(root/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=100000,h0_audit=20000,h1=37)))
            for name,v in [('h0_cal_scores.npy',np.stack([cal]*3,1)),('h0_audit_scores.npy',np.stack([audit]*3,1)),('dev_h1_scores.npy',np.stack([h1,h1-1/3,h1-1/3],2))]:np.save(root/name,v)
            r=generate(root);self.assertAlmostEqual(r['comparisons'][0]['delta_D90_db'],-1.,places=8);self.assertFalse(r['automatic_promotion'])
            plot=read_json(root/'figures/b276_curves_paper_manifest.json');self.assertEqual(plot['styles']['Synthetic phase']['marker'],'v');self.assertFalse(plot['smoothing'])
            import fcntl
            a=runner.cli(['--root',t,'--device','cpu']);self.assertEqual(a.arms,list(ARMS));self.assertEqual(a.epochs,4)
            with (root/'codex_b271_night.lock').open('a') as lock:
                fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
                with patch.object(runner,'cli',return_value=a):
                    with self.assertRaisesRegex(SystemExit,'GPU lock'):runner.main([])


if __name__=='__main__':unittest.main(verbosity=2)
