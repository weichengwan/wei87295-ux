"""Train the entire single ResNet18 from scratch; minimum VAL CE selects weights."""
from __future__ import annotations
import argparse, gc, time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from b271_data import digest_file, fingerprint, load_checkpoint, need, read_json, write_json, device_for
from b273_shared import atomic_save, setup, pauc
from b274_data import resolve, Data, fit_scale
from b274_model import select_backend, Frontend, SingleBranch
from source_loader import load_frozen_file

VERSION='B274_SINGLE_SPWVD_RESNET18_TRAIN_V1'
PASS='PASS_B274_SINGLE_SPWVD_FULL_CNN_TRAIN_VAL_ONLY'


def code_hashes():
    return {p.name:digest_file(p) for p in sorted(Path(__file__).parent.glob('*.py'))}


@torch.inference_mode()
def evaluate(model,data,device,batch):
    model.eval();loss=0.;scores=[];ys=[]
    n=len(data.values['val'][1])
    for start in range(0,n,batch):
        x,y=data.fetch('val',slice(start,min(start+batch,n)),device)
        z=model(x)
        need(z.shape==(len(y),2) and torch.isfinite(z).all().item(),'Invalid validation logits')
        loss+=float(F.cross_entropy(z,y,reduction='sum'))
        scores.append((z[:,1]-z[:,0]).double().cpu().numpy());ys.append(y.cpu().numpy())
    scores,ys=np.concatenate(scores),np.concatenate(ys)
    auc=load_frozen_file('r10_sim_stage_b214_ablation_train_v1.py').auc(scores,ys)
    return dict(val_ce=loss/n,val_auc=float(auc),val_pauc01=pauc(scores,ys),n_val=n)


def train(a,context,data,backend):
    out=a.out_dir;out.mkdir(parents=True,exist_ok=True)
    scale=fit_scale(data,Frontend(backend,1.),a.device,a.batch)
    config=dict(version=VERSION,seed=a.seed,backend=backend,bank_sha256=context['bc']['file_sha256'],
        selected_rows=data.selection,scale=scale,scale_fit_split='TRAIN only; first256 selected rows; quantile .99',
        epochs=a.epochs,batch=a.batch,lr=a.lr,weight_decay=1e-4,optimizer='Adam',loss='cross_entropy',
        initialization='from scratch; no ImageNet; all CNN parameters/BN train',code_sha256=code_hashes())
    fp=fingerprint(config);contract_path=out/'training_contract.json';manifest=out/'run_manifest.json'
    manifest_value=dict(version=VERSION,run_fingerprint=fp,run_config=config,bank_dir=str(context['bank_dir']))
    if manifest.exists():need(read_json(manifest)==manifest_value,'B274 run settings changed; use a new output directory')
    else:
        need(not any(out.iterdir()),'Nonempty output without run manifest')
        write_json(manifest,manifest_value)
    best_path=out/'best.pt';latest=out/'last_epoch.pt'
    if contract_path.exists():
        c=read_json(contract_path)
        need(c['status']==PASS and c['run_fingerprint']==fp and digest_file(best_path)==c['checkpoint_sha256'], 'Completed B274 checkpoint/config changed')
        print('B274 training already complete and verified',flush=True);return c
    torch.manual_seed(a.seed)
    model=SingleBranch(backend,scale).to(a.device)
    count=sum(p.numel() for p in model.parameters())
    need(all(p.requires_grad for p in model.parameters()),'Single-branch CNN was accidentally frozen')
    print(f'B274 | backend={backend["kind"]} | all {count:,} CNN parameters train | scale={scale:.6g}',flush=True)
    optimizer=torch.optim.Adam(model.parameters(),lr=a.lr,weight_decay=1e-4)
    start=1;best_epoch=0;best=None;history=[];best_sha=None
    if latest.exists():
        need(a.resume,'Use --resume for an interrupted run')
        state=load_checkpoint(latest)
        need(state['run_fingerprint']==fp and digest_file(best_path)==state['best_sha256'],'Resume identity/checkpoint differs')
        model.load_state_dict(state['state_dict'],strict=True);optimizer.load_state_dict(state['optimizer'])
        start=state['epoch']+1;best=state['best_metrics'];best_epoch=state['best_epoch'];history=state['history'];best_sha=state['best_sha256']
        torch.set_rng_state(state['torch_rng'])
        if a.device.type=='cuda':torch.cuda.set_rng_state_all(state['cuda_rng'])
    else:need(not best_path.exists(),'Uncommitted best checkpoint; preserve it and use a new output directory')
    def snapshot(epoch,metrics):
        return dict(version=VERSION,state_dict=model.state_dict(),epoch=epoch,run_config=config,run_fingerprint=fp,val_metrics=metrics)
    labels=data.values['train'][1]
    for epoch in range(start,a.epochs+1):
        began=time.perf_counter();model.train();total=0.;seen=0
        for step,index in enumerate(context['b210'].indices(labels,epoch,a.batch,a.seed)):
            x,y=data.fetch('train',index,a.device)
            optimizer.zero_grad(set_to_none=True);z=model(x);loss=F.cross_entropy(z,y)
            need(torch.isfinite(loss).item(),'Nonfinite training loss')
            loss.backward();optimizer.step();total+=float(loss.detach())*len(y);seen+=len(y)
            if (step+1)%200==0:print(f'[single] epoch {epoch}/{a.epochs}; {seen:,}/{len(labels):,} TRAIN',flush=True)
        metrics=evaluate(model,data,a.device,a.batch)
        if best is None or metrics['val_ce']<best['val_ce']:
            best,best_epoch=dict(metrics),epoch
            atomic_save(best_path,snapshot(epoch,metrics));best_sha=digest_file(best_path)
        history.append(dict(epoch=epoch,train_ce=total/seen,**metrics,best_epoch=best_epoch,elapsed_s=time.perf_counter()-began))
        state=snapshot(epoch,metrics)
        state.update(optimizer=optimizer.state_dict(),best_epoch=best_epoch,best_metrics=best,best_sha256=best_sha,history=history,
            torch_rng=torch.get_rng_state(),cuda_rng=torch.cuda.get_rng_state_all() if a.device.type=='cuda' else [])
        atomic_save(latest,state)
        from b273_statistics import save_csv
        save_csv(out/'train_val_history.csv',history)
        print(f'[single] {epoch}/{a.epochs} VAL_CE={metrics["val_ce"]:.6f} AUC={metrics["val_auc"]:.6f} '
              f'pAUC01={metrics["val_pauc01"]:.6f} best_epoch={best_epoch} time={history[-1]["elapsed_s"]:.1f}s',flush=True)
    need(best is not None,'No completed epoch')
    state=load_checkpoint(best_path)
    need(state['run_fingerprint']==fp and state['epoch']==best_epoch and digest_file(best_path)==best_sha,'Selected checkpoint identity differs')
    model.load_state_dict(state['state_dict'],strict=True);replay=evaluate(model,data,a.device,a.batch)
    need(abs(replay['val_ce']-best['val_ce'])<1e-6,'Selected VAL CE replay differs')
    contract=dict(status=PASS,run_fingerprint=fp,run_config=config,checkpoint_sha256=best_sha,best_epoch=best_epoch,
        epochs_executed=a.epochs,selected_validation=replay,trainable_parameters=count,all_cnn_layers_trained=True,
        BN_trained=True,selection='minimum VAL cross entropy only',original_cal_audit_dev_used=False,
        historical_curve_replay_established=False,radar_detection_gain_established=False)
    write_json(contract_path,contract);print(f'{PASS}; selected epoch={best_epoch}',flush=True)
    del optimizer,model;gc.collect()
    if a.device.type=='cuda':torch.cuda.empty_cache()
    return contract


def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    p.add_argument('--bank-dir',type=Path);p.add_argument('--out-dir',type=Path)
    p.add_argument('--baseline-dir',type=Path);p.add_argument('--b213-dir',type=Path)
    p.add_argument('--backend',choices=('auto','legacy','recovered'),default='auto');p.add_argument('--legacy-script',type=Path)
    p.add_argument('--epochs',type=int,default=12);p.add_argument('--batch',type=int,default=32)
    p.add_argument('--train-limit',type=int,default=16000);p.add_argument('--val-limit',type=int,default=3000)
    p.add_argument('--lr',type=float,default=1e-3);p.add_argument('--seed',type=int,default=20261022)
    p.add_argument('--device',choices=('cuda','cpu'),default='cuda');p.add_argument('--cpu-threads',type=int,default=4)
    p.add_argument('--resume',action='store_true')
    a=p.parse_args(argv);a.root=a.root.resolve();a.out_dir=(a.out_dir or a.root/'output_b274_single_spwvd_resnet18_v1').resolve()
    need(a.root.is_dir() and a.epochs>0 and a.batch>=2 and a.batch%2==0 and a.cpu_threads>0,'Invalid root/training budget')
    need(2<=a.train_limit<=30000 and 2<=a.val_limit<=5000 and a.train_limit%2==a.val_limit%2==0,'Invalid subset sizes')
    need(np.isfinite(a.lr) and a.lr>0,'Invalid learning rate')
    a.device=device_for(a.device);return a


def main(argv=None):
    a=cli(argv);setup(a.cpu_threads)
    backend=select_backend(a.root,a.backend,a.legacy_script)
    context=resolve(a.root,a.bank_dir);data=Data(context,a.train_limit,a.val_limit,a.seed)
    print('B274 pure SPWVD+ResNet18; TRAIN/VAL only. No WCSG/TFCG/ARS. No ImageNet download.',flush=True)
    return train(a,context,data,backend)


if __name__=='__main__':main()
