"""Matched additional TRAIN/VAL budget; epoch0 is eligible, minimum VAL CE only."""
import gc,time
from pathlib import Path
import torch
import torch.nn.functional as F
from b271_data import digest_file,fingerprint,load_checkpoint,need,read_json,write_json
from b273_shared import atomic_save
from b273_statistics import save_csv
from b274_train import evaluate
from b276_model import make_model,migrate,verify_initial,parameter_groups
from b276_source import teacher

PASS='PASS_B276_SPWVD_ADN_MIGRATION_TRAIN_VAL_ONLY'


def code_hashes():return {p.name:digest_file(p) for p in sorted(Path(__file__).parent.glob('*.py'))}


def configuration(a,context,data,info,arm,hooks=None):
    hooks=hooks or {}
    return dict(version=hooks.get('version','B276_SPWVD_ADN_PHASE_TRAIN_V1'),arm=arm,seed=a.seed,epochs=a.epochs,batch=a.batch,
        backbone_lr=a.lr,new_parameters_lr=a.new_lr,weight_decay=1e-4,optimizer='Adam',loss=hooks.get('loss_name','CE'),
        phase_offset_regularizer=.02 if arm=='phase' else 0.,selection='minimum VAL CE including epoch0; no DEV selection',
        initialization_sha256=info['contract']['checkpoint_sha256'],source_run=str(info['run_dir']),
        backend=info['config']['backend'],scale=info['config']['scale'],bank_sha256=context['bc']['file_sha256'],
        selected_rows=data.selection,code_sha256=code_hashes())


def train_arm(a,context,data,info,arm,hooks=None):
    hooks=hooks or {};status=hooks.get('status',PASS)
    out=a.out_dir/arm;out.mkdir(parents=True,exist_ok=True)
    config=configuration(a,context,data,info,arm,hooks)
    fp=fingerprint(config);manifest=out/'run_manifest.json';best_path=out/'best.pt';latest=out/'last_epoch.pt';cp=out/'training_contract.json'
    mv=dict(run_config=config,run_fingerprint=fp,bank_dir=str(context['bank_dir']))
    if manifest.exists():need(read_json(manifest)==mv,'B276 settings changed; use a new output directory')
    else:
        need(not any(out.iterdir()),'Nonempty B276 output without manifest');write_json(manifest,mv)
    if cp.exists():
        c=read_json(cp);need(c['status']==status and c['run_fingerprint']==fp and digest_file(best_path)==c['checkpoint_sha256'],'Completed migration arm changed')
        print(f'{arm} already complete and verified',flush=True);return c
    torch.manual_seed(a.seed)
    source=hooks.get('teacher',teacher)(info,a.device);model=hooks.get('factory',make_model)(arm,config['backend'],config['scale']).to(a.device)
    copied=hooks.get('migrate',migrate)(model,source,arm)
    expected_device=next(source.parameters()).device
    wrong_device=[n for n,p in model.named_parameters() if p.device!=expected_device]
    need(not wrong_device,'Replacement parameters left on another device: '+', '.join(wrong_device[:4]))
    probe,_=data.fetch('train',slice(0,min(32,len(data.values['train'][1]))),a.device)
    initial=hooks.get('verify_initial',verify_initial)(model,source,probe)
    del source;gc.collect()
    optimizer=torch.optim.Adam(parameter_groups(model,copied,a.lr,a.new_lr))
    start=1;history=[];best_epoch=0
    def snapshot(epoch,metrics):return dict(state_dict=model.state_dict(),epoch=epoch,run_config=config,run_fingerprint=fp,val_metrics=metrics)
    def commit(epoch,metrics,best,best_sha,history):
        state=snapshot(epoch,metrics);state.update(optimizer=optimizer.state_dict(),best_epoch=best_epoch,best_metrics=best,
            best_sha256=best_sha,history=history,initialization=initial,torch_rng=torch.get_rng_state(),
            cuda_rng=torch.cuda.get_rng_state_all() if a.device.type=='cuda' else [])
        atomic_save(latest,state)
    if latest.exists():
        state=load_checkpoint(latest);need(state['run_fingerprint']==fp and digest_file(best_path)==state['best_sha256'],'B276 resume identity differs')
        model.load_state_dict(state['state_dict'],strict=True);optimizer.load_state_dict(state['optimizer'])
        start=state['epoch']+1;history=state['history'];best=state['best_metrics'];best_epoch=state['best_epoch'];best_sha=state['best_sha256'];initial=state['initialization']
        torch.set_rng_state(state['torch_rng'])
        if a.device.type=='cuda':torch.cuda.set_rng_state_all(state['cuda_rng'])
    else:
        # A crash between best.pt and first commit can safely recreate epoch0:
        # there are no completed updates; manifest/source/config already match.
        best=evaluate(model,data,a.device,a.batch);atomic_save(best_path,snapshot(0,best));best_sha=digest_file(best_path)
        history=[dict(epoch=0,train_ce=None,**best,best_epoch=0,elapsed_s=0.)];commit(0,best,best,best_sha,history)
    count=sum(p.numel() for p in model.parameters())
    print(f'{config["version"]} {arm}: {count:,} parameters; init difference={initial["maxabs_logit_difference"]:.3g}; epochs {start}..{a.epochs}',flush=True)
    for epoch in range(start,a.epochs+1):
        began=time.perf_counter();model.train();total=0.;seen=0
        for index in context['b210'].indices(data.values['train'][1],epoch,a.batch,a.seed):
            x,y=data.fetch('train',index,a.device);optimizer.zero_grad(set_to_none=True)
            if 'objective' in hooks:z,ce,loss=hooks['objective'](model,x,y)
            else:
                if arm=='phase':z,aux=model(x,return_aux=True);regularizer=.02*aux['offset_regularizer']
                else:z=model(x);regularizer=0.
                ce=F.cross_entropy(z,y);loss=ce+regularizer
            need(torch.isfinite(loss).item(),'Nonfinite migration objective')
            loss.backward();optimizer.step();total+=float(ce.detach())*len(y);seen+=len(y)
        metrics=evaluate(model,data,a.device,a.batch)
        if metrics['val_ce']<best['val_ce']:
            best,best_epoch=dict(metrics),epoch;atomic_save(best_path,snapshot(epoch,metrics));best_sha=digest_file(best_path)
        history.append(dict(epoch=epoch,train_ce=total/seen,**metrics,best_epoch=best_epoch,elapsed_s=time.perf_counter()-began))
        commit(epoch,metrics,best,best_sha,history);save_csv(out/'train_val_history.csv',history)
        print(f'[{arm}] {epoch}/{a.epochs} CE={metrics["val_ce"]:.6f} pAUC01={metrics["val_pauc01"]:.6f} best={best_epoch} time={history[-1]["elapsed_s"]:.1f}s',flush=True)
    state=load_checkpoint(best_path);need(state['epoch']==best_epoch and state['run_fingerprint']==fp and digest_file(best_path)==best_sha,'Selected B276 checkpoint differs')
    model.load_state_dict(state['state_dict'],strict=True);replay=evaluate(model,data,a.device,a.batch)
    need(abs(replay['val_ce']-best['val_ce'])<1e-6,'Selected B276 validation replay differs')
    diagnostics={}
    if 'diagnostics' in hooks:diagnostics=hooks['diagnostics'](model,probe)
    elif arm!='continued':
        diagnostics['axial_BN_gamma_abs_mean']=float(torch.cat([b.ver_bn.weight.detach().abs().flatten() for stage in ('layer1','layer2','layer3','layer4') for b in getattr(model.detector,stage)]).mean())
        with torch.no_grad():
            _,aux=model(probe,return_aux=True);diagnostics.update(wcsg_gain_mean=float((aux['gate']/model.suppressor.initial_gain).mean()),
                wcsg_gain_std=float((aux['gate']/model.suppressor.initial_gain).std()),offset_diagnostics=aux['offset_diagnostics'])
    c=dict(status=status,arm=arm,run_config=config,run_fingerprint=fp,checkpoint_sha256=best_sha,best_epoch=best_epoch,
        epochs_executed=a.epochs,selected_validation=replay,initialization=initial,module_diagnostics=diagnostics,
        trainable_parameters=count,all_cnn_BN_trainable=True,old_WVD_L1_weights_loaded=hooks.get('old_l1_weights',False),
        original_cal_audit_dev_used_for_training=False,radar_detection_gain_established=False)
    write_json(cp,c);del model,optimizer;gc.collect()
    if a.device.type=='cuda':torch.cuda.empty_cache()
    print(f'{status}; {arm}; selected epoch={best_epoch}',flush=True);return c
