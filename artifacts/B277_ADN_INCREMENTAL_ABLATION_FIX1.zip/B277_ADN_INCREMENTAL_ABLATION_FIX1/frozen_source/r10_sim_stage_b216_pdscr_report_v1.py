#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""B2.16 read-only DEV H0/CAL/AUDIT + H1 report (6 methods x 3 seeds).

Pd-SCR under nominal Pfa=1e-4 / 1e-5, actually-audited Pfa with
Wilson interval, assumed-prevalence CUT Precision and F1, seed means/std,
paired deltas and matched-scene family-specific Pd. NOT localization P/R/F1.
"""
from __future__ import annotations
import argparse,csv,json,math
from collections import defaultdict
from pathlib import Path
import numpy as np

VERSION='SIM_R10_B216_PDSCR_REPORT_V1'
SEEDS=(20261020,20261021,20261022)
METHODS=('ADN','A3_NO_BG','A3','L1_TAIL','L2_GATE','L3_TPHT')
PFAS=(1e-4,1e-5)
FAMILIES=('gaussian_colored','compound_gamma','nonstationary','sea_spikes','mixed')

def need(x,m):
    if not bool(x):raise RuntimeError(m)

def dump_json(f,obj):
    f.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def save_csv(p,rows):
    need(len(rows)>0,'No rows to save '+str(p))
    with Path(p).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def wilson(k,n,z=1.959963984540054):
    if n==0:return (float('nan'),float('nan'))
    q=k/n;den=1+z*z/n;mid=(q+z*z/(2*n))/den
    rad=z*math.sqrt(q*(1-q)/n+z*z/(4*n*n))/den
    return (max(0.,mid-rad),min(1.,mid+rad))

def cutoff(scores,pfa):
    s=np.asarray(scores,dtype=np.float64)
    need(s.ndim==1 and len(s)>=100000 and np.isfinite(s).all(),'Invalid H0 CAL scores')
    n=len(s);k=int(math.floor(n*pfa));need(k>=10 and k<n,'Insufficient CAL extreme-tail support')
    th=float(np.partition(s,n-k-1)[n-k-1])
    return th,k,int(np.count_nonzero(s>th))

def precision_f1(pd,fp,pi):
    need(0<pi<1,'Prevalence must be between 0 and 1')
    # Expected rates for a hypothetical i.i.d. mixture, NOT observed image-localization counts.
    tp=pi*pd;false=(1-pi)*fp;fn=pi*(1-pd)
    pre=tp/(tp+false) if tp+false>0 else 0.
    f1=2*tp/(2*tp+false+fn) if 2*tp+false+fn>0 else 0.
    return pre,f1

def positive_rank(q):
    a=np.asarray(q,dtype=np.float64)
    return float(np.mean(a)),float(np.std(a,ddof=1)) if len(a)>1 else float('nan')

def load_outputs(out,prior):
    p=json.loads((out/'protocol_frozen.json').read_text(encoding='utf-8'))
    old=json.loads((prior/'protocol_frozen.json').read_text(encoding='utf-8'))
    pr=json.loads((out/'progress.json').read_text(encoding='utf-8'))
    need(p.get('scene_fingerprint')==old.get('scene_fingerprint'),'Scene fingerprint mismatch')
    need(p.get('fingerprint')==pr.get('fingerprint'),'Protocol/progress mismatch')
    ns=p['h1_scenes_n'];nscr=len(p['scr_grid_db'])
    need(pr['completed']=={'h0_cal':p['h0_cal_n'],'h0_audit':p['h0_audit_n'],'h1':nscr},
         'Scores are incomplete')
    labels=[(v['seed'],v['method']) for v in p['labels']]
    need(labels==[(s,m) for s in SEEDS for m in METHODS],'Unexpected model ordering')
    c=np.load(out/'h0_cal_scores.npy',mmap_mode='r')
    a=np.load(out/'h0_audit_scores.npy',mmap_mode='r')
    h=np.load(out/'dev_h1_scores.npy',mmap_mode='r')
    need(c.shape==(p['h0_cal_n'],len(labels)) and a.shape==(p['h0_audit_n'],len(labels)) and
         h.shape==(nscr,ns,len(labels)),'Incorrect scorebank shape')
    need(c.dtype==a.dtype==h.dtype==np.dtype('float64'),'Scorebank dtype drift')
    ahf=np.load(prior/'h0_audit_family.npy',mmap_mode='r')
    hhf=np.load(prior/'dev_h1_family.npy',mmap_mode='r')
    need(ahf.shape==(p['h0_audit_n'],) and hhf.shape==(ns,), 'B2.13 family index shape mismatch')
    need(all(np.isfinite(c[:,j]).all() and np.isfinite(a[:,j]).all() and np.isfinite(h[:,:,j]).all()
             for j in range(len(labels))),'Found NaN / Inf detector score')
    return p,labels,c,a,h,ahf,hhf

def create_plot(out,mean_rows,metric_rows,pfas,prevalences,show_family):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    figdir=out/'figures';figdir.mkdir(exist_ok=True)
    for pfa in pfas:
        for metric,pi in [('Pd',None)]+[(x,pr) for pr in prevalences for x in ('Precision','F1')]:
            fig,ax=plt.subplots(figsize=(9,5.4))
            for method in METHODS:
                if metric=='Pd':
                    rr=[r for r in mean_rows if r['pfa']==pfa and r['method']==method]
                    y=np.array([r['pd_mean'] for r in rr],float)
                    sd=np.array([r['pd_std'] for r in rr],float)
                else:
                    rr=[r for r in metric_rows if r['pfa']==pfa and r['method']==method and
                        r['positive_prevalence']==pi]
                    y=np.array([r[metric.lower()+'_mean'] for r in rr],float)
                    sd=np.array([r[metric.lower()+'_std'] for r in rr],float)
                x=np.array([r['scr_db'] for r in rr],float)
                order=np.argsort(x)
                x,y,sd=x[order],y[order],sd[order]
                (ln,)=ax.plot(x,y,label=method,lw=1.55)
                ax.fill_between(x,np.maximum(0,y-sd),np.minimum(1,y+sd),color=ln.get_color(),alpha=.11)
            ax.set_xlim(min(x),max(x));ax.set_ylim(0,1.015)
            ax.set_xlabel('Injected SCR (dB)');ax.set_ylabel(metric)
            suffix='' if pi is None else f'_prior{pi:g}'
            ax.set_title(f'{metric} vs SCR | nominal Pfa={pfa:.0e} | 3-seed mean ± SD' +
                         ('' if pi is None else f' | assumed H1 prevalence={pi:g}'))
            ax.grid(alpha=.3);ax.legend(ncol=2,fontsize=8);fig.tight_layout()
            path=figdir/f'{metric}_SCR_Pfa{pfa:.0e}{suffix}_3seed'
            fig.savefig(str(path)+'.png',dpi=180);fig.savefig(str(path)+'.pdf');plt.close(fig)
    for pfa in pfas:
        fig,axes=plt.subplots(2,3,figsize=(14,8),sharex=True,sharey=True)
        for k,fam in enumerate(FAMILIES):
            ax=axes.flat[k]
            for method in METHODS:
                rr=[r for r in show_family if r['pfa']==pfa and r['method']==method and r['family']==fam]
                xs=np.array([r['scr_db'] for r in rr],float)
                yy=np.array([r['pd_mean'] for r in rr],float)
                o=np.argsort(xs);ax.plot(xs[o],yy[o],label=method,lw=1.1)
            ax.set_title(fam,fontsize=10);ax.grid(alpha=.25)
            ax.set_xlabel('SCR/dB');ax.set_ylabel('Pd');ax.set_ylim(0,1.02)
        axes.flat[5].axis('off');handles,labels=axes.flat[0].get_legend_handles_labels()
        axes.flat[5].legend(handles,labels,loc='center',fontsize=9)
        fig.suptitle(f'Pd–SCR by synthetic clutter family | Pfa={pfa:.0e} | 3-seed mean')
        fig.tight_layout()
        base=figdir/f'Pd_SCR_by_family_Pfa{pfa:.0e}_3seed'
        fig.savefig(str(base)+'.png',dpi=180);fig.savefig(str(base)+'.pdf');plt.close(fig)

def generate(out,prior,prevalences=(.5,.001)):
    out=Path(out).resolve();prior=Path(prior).resolve()
    prev=list(prevalences)
    need(len(prev)==len(set(prev)) and all(0<pi<1 for pi in prev),'Prevalence duplicated or invalid')
    p,labels,c,a,h,ahf,hhf=load_outputs(out,prior)
    scrs=p['scr_grid_db'];ns=p['h1_scenes_n'];naud=p['h0_audit_n']
    audit=[];pdrows=[];metrows=[];familyrows=[]
    a_masks=[np.asarray(ahf[:]==i) for i in range(len(FAMILIES))]
    h_masks=[np.asarray(hhf[:]==i) for i in range(len(FAMILIES))]
    print('B2.16 READ-ONLY Pd/Precision/F1 report (DEV ONLY)',flush=True)
    for j,(seed,method) in enumerate(labels):
        for pfa in PFAS:
            th,k,c_fp=cutoff(c[:,j],pfa)
            fp=int(np.count_nonzero(a[:,j]>th));fp_rate=fp/naud
            lo,hi=wilson(fp,naud)
            audit.append(dict(seed=seed,method=method,pfa=pfa,threshold=th,
                              cal_n=len(c),cal_allowed_tail_k=k,cal_fp=c_fp,
                              audit_n=naud,audit_fp=fp,audit_pfa=fp_rate,
                              audit_pfa_ci95_low=lo,audit_pfa_ci95_high=hi,family='ALL'))
            for f,fam in enumerate(FAMILIES):
                n0=int(a_masks[f].sum());nfp=int(np.count_nonzero(a[a_masks[f],j]>th));fl,fh=wilson(nfp,n0)
                audit.append(dict(seed=seed,method=method,pfa=pfa,threshold=th,
                                  cal_n=len(c),cal_allowed_tail_k=k,cal_fp=c_fp,
                                  audit_n=n0,audit_fp=nfp,audit_pfa=nfp/n0,
                                  audit_pfa_ci95_low=fl,audit_pfa_ci95_high=fh,family=fam))
            for i,scr in enumerate(scrs):
                scores=h[i,:,j];det=int(np.count_nonzero(scores>th));pd=det/ns
                low,high=wilson(det,ns)
                pdrows.append(dict(seed=seed,method=method,pfa=pfa,scr_db=scr,
                                   h1_n=ns,tp=det,fn=ns-det,pd=pd,pd_ci95_low=low,
                                   pd_ci95_high=high,nominal_pfa=pfa,audit_actual_pfa=fp_rate))
                for pi in prev:
                    precision,f1=precision_f1(pd,fp_rate,pi)
                    metrows.append(dict(seed=seed,method=method,pfa=pfa,scr_db=scr,
                                       positive_prevalence=pi,precision=precision,f1=f1,
                                       pd=pd,audit_actual_pfa=fp_rate,
                                       note='Theoretical expected single-CUT metrics under assumed prevalence; NOT observed localization Precision/F1'))
                for f,fam in enumerate(FAMILIES):
                    n1=int(h_masks[f].sum());hits=int(np.count_nonzero(scores[h_masks[f]]>th))
                    familyrows.append(dict(seed=seed,method=method,pfa=pfa,scr_db=scr,family=fam,
                                           n_h1=n1,tp=hits,pd=hits/n1))
            print(f'  {seed} {method:9s} Pfa={pfa:.0e}: audit={fp}/{naud} '
                  f'({fp_rate:.3g}), Pd@SCR0={next(r["pd"] for r in reversed(pdrows) if r["scr_db"]==0):.4f}',flush=True)
    save_csv(out/'b216_pfa_audit_by_seed_and_family.csv',audit)
    save_csv(out/'b216_pd_scr_each_seed.csv',pdrows)
    save_csv(out/'b216_precision_f1_each_seed_by_prevalence.csv',metrows)
    save_csv(out/'b216_pd_scr_by_family_each_seed.csv',familyrows)
    averaged=[];ametric=[];afamily=[];paired=[]
    by={(r['seed'],r['method'],r['pfa'],r['scr_db']):r for r in pdrows}
    for pfa in PFAS:
        for method in METHODS:
            for scr in scrs:
                q=[by[(s,method,pfa,scr)]['pd'] for s in SEEDS];mu,sd=positive_rank(q)
                averaged.append(dict(pfa=pfa,method=method,scr_db=scr,pd_mean=mu,pd_std=sd,n_seeds=len(SEEDS)))
                for pi in prev:
                    mp=[r for r in metrows if r['method']==method and r['pfa']==pfa and
                        r['scr_db']==scr and r['positive_prevalence']==pi]
                    x,y=positive_rank([v['precision'] for v in mp])
                    m,n=positive_rank([v['f1'] for v in mp])
                    ametric.append(dict(pfa=pfa,method=method,scr_db=scr,positive_prevalence=pi,
                                        precision_mean=x,precision_std=y,f1_mean=m,f1_std=n))
                for fam in FAMILIES:
                    vals=[r['pd'] for r in familyrows if r['method']==method and r['pfa']==pfa and
                          r['scr_db']==scr and r['family']==fam]
                    m,n=positive_rank(vals)
                    afamily.append(dict(pfa=pfa,method=method,scr_db=scr,family=fam,pd_mean=m,pd_std=n))
                if method not in ('ADN','A3_NO_BG'):
                    for reference in ('ADN','A3_NO_BG'):
                        diffs=np.array([by[(s,method,pfa,scr)]['pd']-by[(s,reference,pfa,scr)]['pd'] for s in SEEDS])
                        dmean,dstd=positive_rank(diffs)
                        paired.append(dict(pfa=pfa,scr_db=scr,method=method,reference=reference,
                                           delta_pd_mean=dmean,delta_pd_std=dstd,
                                           wins=int((diffs>0).sum()),ties=int((diffs==0).sum()),
                                           losses=int((diffs<0).sum()),n_seeds=len(SEEDS)))
    save_csv(out/'b216_pd_scr_mean_std.csv',averaged)
    save_csv(out/'b216_precision_f1_mean_std_by_prevalence.csv',ametric)
    save_csv(out/'b216_pd_scr_by_family_mean_std.csv',afamily)
    save_csv(out/'b216_paired_pd_deltas.csv',paired)
    # Summary: low-SCR <-24,0> mean; matched seeding; never select best seed ex post.
    summary=[]
    for pfa in PFAS:
        for method in METHODS:
            rows=[r for r in averaged if r['pfa']==pfa and r['method']==method]
            lows=[r['pd_mean'] for r in rows if -24<=r['scr_db']<=0]
            aud=[r['audit_pfa'] for r in audit if r['pfa']==pfa and r['method']==method and r['family']=='ALL']
            result=dict(method=method,pfa=pfa,mean_pd_scr_m24_to_0=float(np.mean(lows)),
                        mean_audit_pfa=float(np.mean(aud)),
                        audit_pfa_min=float(np.min(aud)),audit_pfa_max=float(np.max(aud)))
            for scr in (-12,-6,0,6,12):
                result[f'pd_at_scr_{scr:+d}']=next(r['pd_mean'] for r in rows if r['scr_db']==scr)
            summary.append(result)
    save_csv(out/'b216_low_scr_summary.csv',summary)
    report={'version':VERSION,'status':'PASS_SIM_R10_B216_PDSCR_REPORT_DEV_ONLY',
            'scene_fingerprint':p['scene_fingerprint'],'n_models':len(labels),
            'seeds':list(SEEDS),'methods':list(METHODS),'pfa_nominal':list(PFAS),
            'assumed_target_prevalences':prev,'h0_cal_n':len(c),'h0_audit_n':len(a),
            'h1_per_scr':ns,'scr_grid':scrs,
            'note':'H1 scene templates and prior B2.13 DEV have been explored; NEVER report as independent final. Precision/F1 are hypothetical single-CUT binary classification at stated prevalence, not multi-object detection localization. Actual audited Pfa and CI must accompany any Pd. With 3 seeds inferential power is limited.',
            'mean_low_scr_summary':summary}
    dump_json(out/'b216_report.json',report)
    create_plot(out,averaged,ametric,PFAS,prev,afamily)
    print('PASS_SIM_R10_B216_PDSCR_REPORT_DEV_ONLY',flush=True)
    print('  main figure:',out/'figures'/'Pd_SCR_Pfa1e-05_3seed.png',flush=True)
    print('  summary:',out/'b216_low_scr_summary.csv',flush=True)

def selftest():
    for k,n in ((0,1000000),(10,1000000),(100,1000000)):
        l,h=wilson(k,n);need(0<=l<=h<=1,'Wilson interval problem')
    a,b=precision_f1(.8,1e-5,.5)
    need(abs(a-(.8/(.80001)))<1e-12,'Precision formula error')
    need(abs(b-(1.6/(1.80001)))<1e-12,'F1 formula error')
    a2,b2=precision_f1(.8,1e-5,.001)
    need(a2<a and b2<b,'Prior sensitivity error')
    x=np.r_[np.arange(100000-30,dtype=np.float64),np.full(30,100002.,dtype=np.float64)]
    th,k,nfp=cutoff(x,1e-4)
    need(k==10 and nfp==0 and th==100002.,'Tie calibration strict > mismatch')
    print('PASS_SIM_R10_B216_REPORT_SELFTEST__PFA_PRECISION_F1',flush=True)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--stage',choices=('selftest','report'),default='report')
    p.add_argument('--out-dir',type=Path)
    p.add_argument('--b213-dir',type=Path)
    p.add_argument('--prevalences',default='0.5,0.001')
    a=p.parse_args()
    if a.stage=='selftest':selftest();return
    need(a.out_dir is not None and a.b213_dir is not None,'Provide --out-dir and --b213-dir')
    generate(a.out_dir,a.b213_dir,[float(x) for x in a.prevalences.split(',')])

if __name__=='__main__':main()
