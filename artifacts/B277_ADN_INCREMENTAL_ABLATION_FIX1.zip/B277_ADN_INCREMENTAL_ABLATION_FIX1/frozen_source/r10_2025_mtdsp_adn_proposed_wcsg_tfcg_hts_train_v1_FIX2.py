#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
R10 2025 MTDSP — ADN-derived Proposed V1 FIX2 formal ablation trainer

Scientific goal
---------------
Build an ADN-derived detector that has BOTH:
  (1) an explicit, visualizable sea-clutter-response suppression output; and
  (2) improved extreme-low-FAR detection behavior.

Frozen parent:
  WVD -> ADN18 (ResNet18 + ACB + SimAM) -> 2 logits

Prospective innovations (frozen BEFORE Proposed H0/H1/final203):
  I1) WCSG: Weakly-supervised Clutter Suppression Gate
      - explicit WVD-domain gate and suppressed WVD map
      - H0-only clutter-energy attenuation regularizer
      - no clean-target image is assumed
  I2) TFCG: Time-Frequency Context Gating
      - replaces SimAM inside ADN residual blocks
      - anisotropic time/frequency context, stage-specific kernels
  I3) HTS: Hard-Tail Separation
      - upper H0 score tail vs lower H1 score tail margin surrogate
      - NOT a numerical estimator of Pfa=1e-5/1e-6

Formal ablation panel:
  A0 ADN                         : existing frozen baseline; DO NOT retrain here
  A1 ADN + WCSG                 : explicit suppression only
  A2 ADN + TFCG                 : context representation only
  A3 ADN + WCSG + TFCG          : structural combination
  A4 ADN + WCSG + TFCG + HTS    : FULL PROPOSED

Training fairness:
  - reuses EXACT existing ADN LOAO plans and deduplicated WVD cache
  - 10,752 TRAIN / fold, 3,584 VAL / fold
  - 25 epochs, batch=256
  - Adam lr=1e-3 betas=(0.9,0.99)
  - StepLR gamma=0.5 every 5 epochs
  - FINAL EPOCH ONLY
  - INNER_VAL descriptive only
  - no augmentation, no weight decay, no AMP
  - no 2022 H0, no held-out 2025 H1, no final203, no threshold fitting

FIX2 implementation-only memory correction
------------------------------------------
FIX1 formal training OOMed before any fold checkpoint was saved. Root cause:
its one-step canary did not test the next forward after Adam moment buffers
were materialized, and the training loop retained previous-batch aux/output
references until the next forward assignment. FIX2 keeps the scientific
model/loss/batch/FP32 protocol unchanged, explicitly releases those references,
and requires a three-step steady-state full-batch canary before training.

IMPORTANT:
  This training script does NOT promise that Proposed will beat every baseline.
  It prospectively fixes mechanisms and evaluation firewalls. Superiority must
  be demonstrated later on frozen H0/H1/final203 metrics without rescue.

Expected server inputs
----------------------
<code-root>/
  r10_2025_mtdsp_adn_source_protocol_freeze_canary_v1.py

<baseline-train-dir>/
  plans/
    LOAO__*__adn_plan.csv.gz
    r10_adn_selected_union_flat_ids_v1.npy
  wvd_cache/
    r10_adn_wvd128_selected_union_v1.h5
  r10_adn_balanced_loao_plan_contract_v1.json
  r10_adn_wvd_cache_contract_v1.json
  r10_adn_full_train_contract_v1.json

<module-canary-dir>/
  r10_adn_tfcg_tail_canary_v1_contract.json

Stages
------
canary : exact-interface FULL-BATCH-256 memory/forward/backward canary; no checkpoint
train  : train A1-A4, all 7 folds, final epoch only
all    : canary -> train
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import importlib.util
import json
import math
import time
import traceback
from pathlib import Path
from typing import Dict, List, Tuple

import h5py
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F


VERSION = "R10_2025_MTDSP_ADN_PROPOSED_WCSG_TFCG_HTS_TRAIN_V1_FIX2"

SOURCE_NAME = "r10_2025_mtdsp_adn_source_protocol_freeze_canary_v1.py"
EXPECTED_SOURCE_SHA = "0372818d8765520716407f97a0ec69df5a3bf42fb73d93a35739faa5bb71175e"

BASELINE_PLAN_STATUS = "PASS_ADN_BALANCED_LOAO_PLAN_V1__READY_FOR_WVD_CACHE"
BASELINE_CACHE_STATUS = "PASS_ADN_WVD128_SELECTED_UNION_CACHE_V1__READY_FOR_7FOLD_TRAINING"
BASELINE_TRAIN_STATUS = (
    "PASS_ADN_BALANCED_LOAO_TRAIN_V1__"
    "ALL7_FINAL_EPOCH_CHECKPOINTS_FROZEN__READY_FOR_2022_H0"
)
MODULE_CANARY_STATUS = "PASS_ADN_TFCG_TAIL_CANARY_V1__READY_FOR_TRAIN_PROTOCOL_FREEZE"

PLAN_CONTRACT = "r10_adn_balanced_loao_plan_contract_v1.json"
CACHE_CONTRACT = "r10_adn_wvd_cache_contract_v1.json"
BASELINE_TRAIN_CONTRACT = "r10_adn_full_train_contract_v1.json"
MODULE_CANARY_CONTRACT = "r10_adn_tfcg_tail_canary_v1_contract.json"

ACQS = (
    "20250106102221_2002_AT_412450000_1",
    "20250106103943_2002_AT_413212990_1",
    "20250107155816_2002_AT_412331720_1",
    "20250117093108_2002_AT_413324410_1",
    "20250117103141_2002_AT_413020540_1",
    "20250117110751_2002_AT_414211000_1",
    "20250312101233_2002_AT_413203610_1",
)
FOLDS = tuple("LOAO__" + x for x in ACQS)

TRAIN_TOTAL = 10752
TRAIN_PER_CLASS = 5376
VAL_TOTAL = 3584
VAL_PER_CLASS = 1792
EPOCHS = 25
BATCH = 256
LR = 1e-3
BETAS = (0.9, 0.99)
STEP_SIZE = 5
GAMMA = 0.5
WEIGHT_DECAY = 0.0
SEED_BASE = 20261005

# Prospective loss / module constants. Frozen before Proposed H0/H1/final203.
LAMBDA_BG = 0.10
LAMBDA_HTS = 0.50
HTS_RHO_H0 = 0.10
HTS_RHO_H1 = 0.20
HTS_MARGIN = 1.0

WCSG_MASK_FLOOR = 0.05
WCSG_INIT_BIAS = 4.0
WCSG_HIDDEN = 8
WCSG_CONTEXT_HW = 128

TFCG_KERNELS = {64: 11, 128: 9, 256: 7, 512: 5}
TFCG_REDUCTION = 8
TFCG_GAMMA = 0.20

VARIANTS = {
    "A1_WCSG": {"wcsg": True,  "tfcg": False, "hts": False},
    "A2_TFCG": {"wcsg": False, "tfcg": True,  "hts": False},
    "A3_WCSG_TFCG": {"wcsg": True, "tfcg": True, "hts": False},
    "A4_FULL": {"wcsg": True, "tfcg": True, "hts": True},
}


def req(c, msg):
    if not bool(c):
        raise RuntimeError(msg)


def sha256_file(p: Path, chunk=8 * 1024 * 1024):
    h = hashlib.sha256()
    with p.open("rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def dump_json(x, p: Path):
    def cv(v):
        if isinstance(v, Path):
            return str(v)
        if isinstance(v, np.integer):
            return int(v)
        if isinstance(v, np.floating):
            return float(v)
        if isinstance(v, np.ndarray):
            return v.tolist()
        raise TypeError(type(v))
    p.write_text(json.dumps(x, indent=2, ensure_ascii=False, default=cv), encoding="utf-8")


def load_json(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))


def load_module(p: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, p)
    req(spec is not None and spec.loader is not None, f"cannot load {p}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def choose_device(s: str):
    if s == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    d = torch.device(s)
    if d.type == "cuda":
        req(torch.cuda.is_available(), "CUDA requested but unavailable")
    return d


def auc_binary(y, s):
    y = np.asarray(y, dtype=np.int64)
    s = np.asarray(s, dtype=np.float64)
    pos = y == 1
    neg = y == 0
    np_ = int(pos.sum())
    nn_ = int(neg.sum())
    if np_ == 0 or nn_ == 0:
        return float("nan")
    order = np.argsort(s, kind="mergesort")
    ranks = np.empty_like(order, dtype=np.float64)
    ranks[order] = np.arange(1, len(s) + 1, dtype=np.float64)

    # Tie-correct average ranks.
    ss = s[order]
    a = 0
    while a < len(ss):
        b = a + 1
        while b < len(ss) and ss[b] == ss[a]:
            b += 1
        if b - a > 1:
            avg = 0.5 * ((a + 1) + b)
            ranks[order[a:b]] = avg
        a = b

    return float((ranks[pos].sum() - np_ * (np_ + 1) / 2.0) / (np_ * nn_))


def read_cache_rows(ds, rows):
    rows = np.asarray(rows, dtype=np.int64)
    order = np.argsort(rows, kind="mergesort")
    sorted_rows = rows[order]
    req(np.all(np.diff(sorted_rows) >= 0), "cache rows sort failure")
    z = np.asarray(ds[sorted_rows], dtype=np.float32)
    inv = np.empty_like(order)
    inv[order] = np.arange(len(order))
    return z[inv]


def plan_to_cache_rows(plan: pd.DataFrame, union: np.ndarray):
    flat = plan["flat_id"].to_numpy(np.int64)
    idx = np.searchsorted(union, flat)
    req(np.all(idx >= 0) and np.all(idx < len(union)), "plan/cache row out of range")
    req(np.array_equal(union[idx], flat), "plan flat_id absent from union")
    return idx


class WCSG(nn.Module):
    """
    Weakly-supervised Clutter Suppression Gate — FIX1 memory-safe implementation.

    Scientific mechanism is unchanged:
        x_supp = x * gate_eff

    FIX1 changes ONLY the implementation scale before any Proposed training/H0/H1:
      * gate context is estimated at the native frozen WVD-cache resolution
        (128x128) rather than at ADN's display/input resolution (224x224);
      * hidden width is reduced from 16 to 8;
      * the learned gate is bilinearly lifted to 224x224 before multiplication.

    This is both radar-natural (the frozen WVD representation is natively 128x128)
    and much lower-memory, while still producing an explicit visualizable
    suppression gate and suppressed WVD map.
    """
    def __init__(self, hidden=WCSG_HIDDEN, mask_floor=WCSG_MASK_FLOOR,
                 context_hw=WCSG_CONTEXT_HW):
        super().__init__()
        self.mask_floor = float(mask_floor)
        self.context_hw = int(context_hw)
        self.pre = nn.Sequential(
            nn.Conv2d(4, hidden, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(hidden),
            nn.GELU(),
            nn.Conv2d(hidden, hidden, kernel_size=5, padding=2,
                      groups=hidden, bias=False),
            nn.BatchNorm2d(hidden),
            nn.GELU(),
        )
        self.out = nn.Conv2d(hidden, 1, kernel_size=1, bias=True)
        nn.init.normal_(self.out.weight, mean=0.0, std=1e-3)
        nn.init.constant_(self.out.bias, WCSG_INIT_BIAS)

    def forward(self, x):
        req(x.ndim == 4 and x.shape[1] == 3,
            f"WCSG expects Bx3xHxW, got {tuple(x.shape)}")

        # ADN input is a repeated grayscale WVD; estimate context at native
        # WVD-cache scale to avoid retaining large 224x224 hidden tensors.
        g_hi = x[:, :1]
        g = F.interpolate(
            g_hi, size=(self.context_hw, self.context_hw),
            mode="bilinear", align_corners=False
        )

        c3 = F.avg_pool2d(g, 3, stride=1, padding=1)
        c7 = F.avg_pool2d(g, 7, stride=1, padding=3)
        c15 = F.avg_pool2d(g, 15, stride=1, padding=7)
        f = self.pre(torch.cat([g, c3, c7, c15], dim=1))
        raw_low = torch.sigmoid(self.out(f))
        gate_low = self.mask_floor + (1.0 - self.mask_floor) * raw_low

        gate = F.interpolate(
            gate_low, size=x.shape[-2:],
            mode="bilinear", align_corners=False
        )
        y = x * gate
        return y, {
            "gate": gate,
            "gate_native": gate_low,
            "input_gray": g_hi,
            "output_gray": y[:, :1],
        }


class TFCG(nn.Module):
    """
    Time-Frequency Context Gating — FIX1 bottleneck-first implementation.

    The V1 canary proved the axis-separated gating concept, but its full-channel
    strip branches retained unnecessarily large feature tensors. FIX1 preserves
    the same scientific idea while moving context extraction into a reduced
    channel space:

        C -> C/r -> time/frequency strip context -> C gate -> residual scaling

    The final expansion is zero initialized, therefore TFCG is still exactly
    identity-preserving at initialization.
    """
    def __init__(self, channels, kernel, reduction=TFCG_REDUCTION,
                 gamma=TFCG_GAMMA):
        super().__init__()
        req(kernel % 2 == 1, "TFCG kernel must be odd")
        hidden = max(8, channels // reduction)
        self.channels = int(channels)
        self.kernel = int(kernel)
        self.gamma = float(gamma)

        self.reduce = nn.Sequential(
            nn.Conv2d(channels, hidden, 1, bias=False),
            nn.BatchNorm2d(hidden),
            nn.GELU(),
        )
        self.time_dw = nn.Conv2d(
            hidden, hidden, kernel_size=(1, kernel),
            padding=(0, kernel // 2), groups=hidden, bias=False
        )
        self.freq_dw = nn.Conv2d(
            hidden, hidden, kernel_size=(kernel, 1),
            padding=(kernel // 2, 0), groups=hidden, bias=False
        )
        self.fuse = nn.Sequential(
            nn.Conv2d(2 * hidden, hidden, 1, bias=False),
            nn.BatchNorm2d(hidden),
            nn.GELU(),
            nn.Conv2d(hidden, channels, 1, bias=True),
        )
        nn.init.zeros_(self.fuse[-1].weight)
        nn.init.zeros_(self.fuse[-1].bias)

    def forward(self, x):
        u = self.reduce(x)
        u = F.avg_pool2d(u, 3, stride=1, padding=1)
        t = self.time_dw(u)
        f = self.freq_dw(u)
        gate = torch.sigmoid(self.fuse(torch.cat([t, f], dim=1)))
        mult = 1.0 + self.gamma * (2.0 * gate - 1.0)
        return x * mult


def replace_simam_with_tfcg(model):
    replaced = []
    for name, m in model.named_modules():
        if hasattr(m, "simam") and hasattr(m, "conv2"):
            c = int(m.conv2.out_channels)
            req(c in TFCG_KERNELS, f"unexpected ADN block channels={c}")
            m.simam = TFCG(c, TFCG_KERNELS[c])
            replaced.append((name, c, TFCG_KERNELS[c]))
    req(len(replaced) == 8, f"expected 8 ADN SimAM blocks, replaced={len(replaced)}")
    return replaced


class ProposedWrapper(nn.Module):
    def __init__(self, src, cfg):
        super().__init__()
        # IMPORTANT: instantiate frozen ADN first, so with the same fold seed the
        # parent ADN weights are initialized identically across ablations.
        self.detector = src.ADN18(num_classes=2)
        self.cfg = dict(cfg)
        self.replaced = []
        if self.cfg["tfcg"]:
            self.replaced = replace_simam_with_tfcg(self.detector)
        self.suppressor = WCSG() if self.cfg["wcsg"] else None

    def forward(self, x, return_aux=False):
        aux = {}
        if self.suppressor is not None:
            x, a = self.suppressor(x)
            aux.update(a)
        logits = self.detector(x)
        if return_aux:
            return logits, aux
        return logits


def hts_tail_loss(logits, y):
    z = logits[:, 1] - logits[:, 0]
    z0 = z[y == 0]
    z1 = z[y == 1]
    if z0.numel() == 0 or z1.numel() == 0:
        return logits.new_zeros(()), {
            "k_h0": 0, "k_h1": 0,
            "h0_tail_mean": float("nan"), "h1_weak_mean": float("nan"),
        }

    k0 = max(1, min(int(z0.numel()), int(math.ceil(z0.numel() * HTS_RHO_H0))))
    k1 = max(1, min(int(z1.numel()), int(math.ceil(z1.numel() * HTS_RHO_H1))))
    hard0 = torch.topk(z0, k=k0, largest=True).values
    weak1 = torch.topk(z1, k=k1, largest=False).values
    m0 = hard0.mean()
    m1 = weak1.mean()
    loss = F.softplus(HTS_MARGIN + m0 - m1)
    return loss, {
        "k_h0": k0,
        "k_h1": k1,
        "h0_tail_mean": float(m0.detach().cpu()),
        "h1_weak_mean": float(m1.detach().cpu()),
    }


def h0_suppression_loss(aux, y):
    if "input_gray" not in aux:
        return y.new_zeros((), dtype=torch.float32), None

    sel = y == 0
    if not bool(sel.any()):
        return aux["output_gray"].new_zeros(()), None

    xin = aux["input_gray"][sel]
    xout = aux["output_gray"][sel]
    ein = xin.square().mean(dim=(1, 2, 3))
    eout = xout.square().mean(dim=(1, 2, 3))
    ratio = eout / (ein + 1e-12)
    return ratio.mean(), ratio.detach()


def compose_loss(logits, y, aux, cfg):
    ce = F.cross_entropy(logits, y)
    bg = logits.new_zeros(())
    hts = logits.new_zeros(())
    bg_ratio = None
    hts_stats = None

    if cfg["wcsg"]:
        bg, bg_ratio = h0_suppression_loss(aux, y)
    if cfg["hts"]:
        hts, hts_stats = hts_tail_loss(logits, y)

    total = ce + (LAMBDA_BG * bg if cfg["wcsg"] else 0.0) + (LAMBDA_HTS * hts if cfg["hts"] else 0.0)
    return total, ce, bg, hts, bg_ratio, hts_stats


def suppression_batch_metrics(aux, y):
    if "input_gray" not in aux:
        return {}
    out = {}
    xin = aux["input_gray"].detach()
    xout = aux["output_gray"].detach()
    gate = aux["gate"].detach()
    for lab, nm in ((0, "h0"), (1, "h1")):
        sel = y == lab
        if bool(sel.any()):
            ein = xin[sel].square().mean(dim=(1,2,3))
            eout = xout[sel].square().mean(dim=(1,2,3))
            ratio = eout / (ein + 1e-12)
            out[f"{nm}_energy_ratio_mean"] = float(ratio.mean().cpu())
            out[f"{nm}_attenuation_db_mean"] = float((-10.0 * torch.log10(ratio + 1e-12)).mean().cpu())
            out[f"{nm}_gate_mean"] = float(gate[sel].mean().cpu())
            peak_in = xin[sel].flatten(1).amax(dim=1)
            peak_out = xout[sel].flatten(1).amax(dim=1)
            out[f"{nm}_peak_retention_mean"] = float((peak_out/(peak_in+1e-12)).mean().cpu())
    return out


@torch.inference_mode()
def eval_model(src, model, maps, y, dev, batch_size, cfg):
    model.eval()
    n = len(y)
    logits_all = np.empty((n, 2), dtype=np.float32)
    ce_sum = 0.0

    e_in_h0 = e_out_h0 = 0.0
    e_in_h1 = e_out_h1 = 0.0
    gate_sum_h0 = gate_n_h0 = 0.0
    gate_sum_h1 = gate_n_h1 = 0.0
    peak_ret_h0 = []
    peak_ret_h1 = []

    for a in range(0, n, batch_size):
        b = min(n, a + batch_size)
        z = torch.from_numpy(np.ascontiguousarray(maps[a:b])).to(dev)
        x = src.map_to_adn_input(z)
        yy = torch.from_numpy(y[a:b]).to(dev)
        logits, aux = model(x, return_aux=True)
        loss = F.cross_entropy(logits, yy, reduction="sum")
        ce_sum += float(loss.item())
        logits_all[a:b] = logits.detach().float().cpu().numpy()

        if cfg["wcsg"]:
            xi = aux["input_gray"]
            xo = aux["output_gray"]
            gg = aux["gate"]
            for lab in (0, 1):
                sel = yy == lab
                if not bool(sel.any()):
                    continue
                ein = float(xi[sel].square().sum().item())
                eout = float(xo[sel].square().sum().item())
                gs = float(gg[sel].sum().item())
                gn = int(gg[sel].numel())
                pin = xi[sel].flatten(1).amax(dim=1)
                pout = xo[sel].flatten(1).amax(dim=1)
                pr = (pout/(pin+1e-12)).detach().cpu().numpy().tolist()
                if lab == 0:
                    e_in_h0 += ein; e_out_h0 += eout
                    gate_sum_h0 += gs; gate_n_h0 += gn
                    peak_ret_h0.extend(pr)
                else:
                    e_in_h1 += ein; e_out_h1 += eout
                    gate_sum_h1 += gs; gate_n_h1 += gn
                    peak_ret_h1.extend(pr)

    prob = torch.softmax(torch.from_numpy(logits_all), dim=1).numpy()[:, 1]
    pred = np.argmax(logits_all, axis=1)
    d = {
        "val_ce": ce_sum / n,
        "val_acc": float(np.mean(pred == y)),
        "val_auc": auc_binary(y, prob),
        "val_target_prob_mean_pos": float(prob[y == 1].mean()),
        "val_target_prob_mean_neg": float(prob[y == 0].mean()),
        "val_target_prob_max_neg": float(prob[y == 0].max()),
    }
    if cfg["wcsg"]:
        d.update({
            "val_h0_suppression_db":
                float(10.0 * math.log10((e_in_h0 + 1e-12)/(e_out_h0 + 1e-12))),
            "val_h1_energy_retention_db":
                float(10.0 * math.log10((e_out_h1 + 1e-12)/(e_in_h1 + 1e-12))),
            "val_h0_gate_mean": float(gate_sum_h0/max(gate_n_h0,1)),
            "val_h1_gate_mean": float(gate_sum_h1/max(gate_n_h1,1)),
            "val_h0_peak_retention_mean": float(np.mean(peak_ret_h0)) if peak_ret_h0 else float("nan"),
            "val_h1_peak_retention_mean": float(np.mean(peak_ret_h1)) if peak_ret_h1 else float("nan"),
        })
    return d


def verify_inputs(args):
    source_p = args.code_root / SOURCE_NAME
    req(source_p.is_file(), f"missing source {source_p}")
    req(sha256_file(source_p) == EXPECTED_SOURCE_SHA, "frozen ADN source SHA drift")

    plan_cp = args.baseline_train_dir / PLAN_CONTRACT
    cache_cp = args.baseline_train_dir / CACHE_CONTRACT
    train_cp = args.baseline_train_dir / BASELINE_TRAIN_CONTRACT
    mod_cp = args.module_canary_dir / MODULE_CANARY_CONTRACT

    for p in (plan_cp, cache_cp, train_cp, mod_cp):
        req(p.is_file(), f"missing contract {p}")

    pc = load_json(plan_cp)
    cc = load_json(cache_cp)
    tc = load_json(train_cp)
    mc = load_json(mod_cp)

    req(pc.get("status") == BASELINE_PLAN_STATUS, f"plan status {pc.get('status')}")
    req(cc.get("status") == BASELINE_CACHE_STATUS, f"cache status {cc.get('status')}")
    req(tc.get("status") == BASELINE_TRAIN_STATUS, f"baseline train status {tc.get('status')}")
    req(mc.get("status") == MODULE_CANARY_STATUS, f"module canary status {mc.get('status')}")

    # Firewall must still be clean in parent training.
    req(tc.get("firewall", {}).get("H0_used") is False, "baseline train contract used H0")
    req(tc.get("firewall", {}).get("H1_outer_scored") is False, "baseline train contract used H1")
    req(tc.get("firewall", {}).get("threshold_fit") is False, "baseline train contract fit threshold")
    req(tc.get("firewall", {}).get("checkpoint_selection") is False, "baseline train selected checkpoint")

    plans_dir = args.baseline_train_dir / "plans"
    union_p = plans_dir / "r10_adn_selected_union_flat_ids_v1.npy"
    cache_h5 = args.baseline_train_dir / "wvd_cache" / "r10_adn_wvd128_selected_union_v1.h5"
    req(union_p.is_file(), f"missing union {union_p}")
    req(cache_h5.is_file(), f"missing WVD cache {cache_h5}")
    plan_paths = [plans_dir / f"{fold}__adn_plan.csv.gz" for fold in FOLDS]
    for p in plan_paths:
        req(p.is_file(), f"missing plan {p}")

    union = np.load(union_p, allow_pickle=False)
    return source_p, plan_paths, union, cache_h5, {
        "plan_contract": plan_cp,
        "cache_contract": cache_cp,
        "baseline_train_contract": train_cp,
        "module_canary_contract": mod_cp,
    }


def load_fold_maps(plan_p, cache_h5_p, union):
    plan = pd.read_csv(plan_p)
    tr = plan[plan["split_role"].astype(str) == "INNER_TRAIN"].copy()
    va = plan[plan["split_role"].astype(str) == "INNER_VAL"].copy()
    req(len(tr) == TRAIN_TOTAL and len(va) == VAL_TOTAL, "plan count drift")
    ty = tr["y"].to_numpy(np.int64)
    vy = va["y"].to_numpy(np.int64)
    req(int(ty.sum()) == TRAIN_PER_CLASS, "train class drift")
    req(int(vy.sum()) == VAL_PER_CLASS, "val class drift")

    tr_rows = plan_to_cache_rows(tr, union)
    va_rows = plan_to_cache_rows(va, union)
    with h5py.File(cache_h5_p, "r") as h:
        ds = h["wvd128"]
        train_maps = read_cache_rows(ds, tr_rows)
        val_maps = read_cache_rows(ds, va_rows)
    return train_maps, ty, val_maps, vy


def model_param_count(model):
    return int(sum(p.numel() for p in model.parameters() if p.requires_grad))


def stage_canary(src, args, plan_paths, union, cache_h5_p, dev, lineage):
    """
    FIX2 steady-state exact-interface memory canary.

    Why FIX2 exists
    ---------------
    FIX1 tested only ONE full batch. Adam allocates exp_avg/exp_avg_sq lazily
    at the first optimizer.step(), so the next forward runs with ~2x parameter
    bytes of persistent optimizer state resident on the GPU. In addition, Python
    references to the previous batch's aux/logit tensors can otherwise survive
    until the next forward assignment.

    FIX2 therefore:
      * uses the EXACT first three formal epoch-1 batches of fold 0;
      * keeps formal batch=256, FP32, no AMP, no gradient accumulation;
      * explicitly releases per-batch graph/output references after every step;
      * verifies step 2/3 memory with Adam state already resident.

    No checkpoint is saved and no 2022 H0 / held-out H1 / final203 is touched.
    """
    CANARY_STEPS = 3

    plan = pd.read_csv(plan_paths[0])
    tr = plan[plan["split_role"].astype(str) == "INNER_TRAIN"].copy()
    req(len(tr) == TRAIN_TOTAL, "canary train count drift")

    # EXACT formal fold-0 epoch-1 ordering.
    formal_seed = SEED_BASE + 501
    rng = np.random.default_rng(formal_seed)
    order = rng.permutation(TRAIN_TOTAL)
    sel_idx = order[:CANARY_STEPS * BATCH]
    ca = tr.iloc[sel_idx].copy()
    req(len(ca) == CANARY_STEPS * BATCH, "steady-state canary sample count drift")

    rows = plan_to_cache_rows(ca, union)
    with h5py.File(cache_h5_p, "r") as h:
        maps = read_cache_rows(h["wvd128"], rows)
    y_np = ca["y"].to_numpy(np.int64)

    rows_out = []
    for variant, cfg in VARIANTS.items():
        gc.collect()
        if dev.type == "cuda":
            torch.cuda.empty_cache()
            torch.cuda.reset_peak_memory_stats(dev)

        # Match formal fold-0 initialization.
        seed = formal_seed
        np.random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)

        model = ProposedWrapper(src, cfg).to(dev)
        model.train()
        optimizer = torch.optim.Adam(
            model.parameters(), lr=LR, betas=BETAS, weight_decay=WEIGHT_DECAY
        )

        step_peaks = []
        step_losses = []
        grad_ok_all = True
        final_sm = {}
        final_hts_stats = None
        t0 = time.perf_counter()

        for si in range(CANARY_STEPS):
            a = si * BATCH
            b = (si + 1) * BATCH

            z = torch.from_numpy(np.ascontiguousarray(maps[a:b])).to(dev)
            x = src.map_to_adn_input(z)
            yy = torch.from_numpy(y_np[a:b]).to(dev)

            if dev.type == "cuda":
                torch.cuda.reset_peak_memory_stats(dev)

            optimizer.zero_grad(set_to_none=True)
            logits, aux = model(x, return_aux=True)
            loss, ce, bg, hts, _, hts_stats = compose_loss(logits, yy, aux, cfg)
            req(torch.isfinite(loss).item(), f"{variant}: nonfinite loss at canary step {si+1}")
            loss.backward()
            grad_ok = all(
                p.grad is None or torch.isfinite(p.grad).all().item()
                for p in model.parameters()
            )
            req(grad_ok, f"{variant}: nonfinite gradient at canary step {si+1}")
            grad_ok_all = grad_ok_all and grad_ok
            optimizer.step()

            if dev.type == "cuda":
                torch.cuda.synchronize(dev)
                step_peak = float(torch.cuda.max_memory_allocated(dev) / (1024 ** 2))
            else:
                step_peak = float("nan")
            step_peaks.append(step_peak)
            step_losses.append(float(loss.detach().cpu()))

            if si == CANARY_STEPS - 1:
                final_sm = suppression_batch_metrics(aux, yy)
                final_hts_stats = hts_stats

            # CRITICAL FIX2: do not let previous-batch outputs/aux/graph roots
            # coexist with the next full forward.
            del logits, aux, loss, ce, bg, hts, x, z, yy
            if hts_stats is not None:
                del hts_stats

        runtime = time.perf_counter() - t0

        # Adam state should be materialized after step 1. Measure it explicitly.
        opt_bytes = 0
        for st in optimizer.state.values():
            for v in st.values():
                if torch.is_tensor(v):
                    opt_bytes += v.numel() * v.element_size()
        opt_state_mib = float(opt_bytes / (1024 ** 2))

        row = {
            "variant": variant,
            **cfg,
            "formal_batch_size_tested": BATCH,
            "steady_state_steps_tested": CANARY_STEPS,
            "parameter_count": model_param_count(model),
            "loss_step1": step_losses[0],
            "loss_step2": step_losses[1],
            "loss_step3": step_losses[2],
            "grad_finite": grad_ok_all,
            "runtime_s_3steps": runtime,
            "peak_cuda_mib_step1": step_peaks[0],
            "peak_cuda_mib_step2": step_peaks[1],
            "peak_cuda_mib_step3": step_peaks[2],
            "peak_cuda_mib_max": max(step_peaks),
            "adam_state_mib_after_step1": opt_state_mib,
            **final_sm,
        }
        if final_hts_stats:
            row.update({f"hts_{k}": v for k, v in final_hts_stats.items()})
        rows_out.append(row)

        del optimizer, model
        gc.collect()
        if dev.type == "cuda":
            torch.cuda.empty_cache()

    df = pd.DataFrame(rows_out)
    csv_p = args.out_dir / "r10_adn_proposed_steady_state_3step_canary_v1_FIX2.csv"
    df.to_csv(csv_p, index=False)

    status = (
        "PASS_ADN_PROPOSED_WCSG_TFCG_HTS_CANARY_V1_FIX2__"
        "STEADY_STATE_3STEP_BATCH256__READY_FOR_FORMAL_7FOLD_TRAINING"
    )
    contract = {
        "version": VERSION,
        "status": status,
        "role": (
            "Prospective implementation-only memory validation after FIX1 formal "
            "training OOMed before any fold checkpoint was saved. Scientific model, "
            "loss, batch=256, FP32 arithmetic, data plans, and firewalls are unchanged."
        ),
        "canary": {
            "batch": BATCH,
            "steps": CANARY_STEPS,
            "fold": FOLDS[0],
            "ordering": "EXACT formal fold-0 epoch-1 first three batches",
            "optimizer": "Adam",
            "optimizer_state_tested": True,
            "explicit_per_batch_reference_cleanup": True,
            "amp": False,
            "gradient_accumulation": False,
        },
        "results_csv": str(csv_p),
        "variants": df.to_dict(orient="records"),
        "firewall": {
            "2022_H0_used": False,
            "heldout_2025_H1_used": False,
            "final203_used": False,
            "threshold_fit": False,
            "checkpoint_selection": False,
        },
        "lineage": {k: {"path": str(p), "sha256": sha256_file(p)} for k,p in lineage.items()},
    }
    cp = args.out_dir / "r10_adn_proposed_wcsg_tfcg_hts_canary_v1_FIX2_contract.json"
    dump_json(contract, cp)

    print("\n" + "=" * 170)
    print("EXACT-INTERFACE STEADY-STATE 3-STEP FULL-BATCH-256 MEMORY CANARY — FIX2")
    print(df.to_string(index=False))
    print("=" * 170)
    print(status)
    print("contract =", cp)
    return cp


def train_one_fold(src, args, variant, cfg, fold, fold_idx, plan_p, cache_h5_p, union, dev):
    vdir = args.out_dir / variant
    ckpt_dir = vdir / "full_checkpoints"
    hist_dir = vdir / "history"
    ckpt_dir.mkdir(parents=True, exist_ok=True)
    hist_dir.mkdir(parents=True, exist_ok=True)

    ckpt_p = ckpt_dir / f"{fold}.pt"
    hist_p = hist_dir / f"{fold}__history.csv"
    summary_p = hist_dir / f"{fold}__summary.json"

    if ckpt_p.exists() and summary_p.exists() and not args.retrain:
        d = load_json(summary_p)
        req(d.get("status") == "FULL_FINAL_EPOCH_FROZEN", f"{variant}/{fold}: existing summary status")
        print(f"  REUSE {variant}/{fold}")
        return d

    train_maps, ty, val_maps, vy = load_fold_maps(plan_p, cache_h5_p, union)

    seed = SEED_BASE + 1000 * fold_idx + 501
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    model = ProposedWrapper(src, cfg).to(dev)
    optimizer = torch.optim.Adam(
        model.parameters(), lr=LR, betas=BETAS, weight_decay=WEIGHT_DECAY
    )
    scheduler = torch.optim.lr_scheduler.StepLR(
        optimizer, step_size=STEP_SIZE, gamma=GAMMA
    )

    history = []
    total_steps = 0
    ft0 = time.perf_counter()
    first_loss = float("nan")
    last_loss = float("nan")

    for epoch in range(EPOCHS):
        model.train()
        rng = np.random.default_rng(seed + epoch)
        order = rng.permutation(TRAIN_TOTAL)

        sums = {"total":0.0, "ce":0.0, "bg":0.0, "hts":0.0}
        seen = 0
        lr_this = float(optimizer.param_groups[0]["lr"])

        for a in range(0, TRAIN_TOTAL, BATCH):
            b = min(TRAIN_TOTAL, a + BATCH)
            idx = order[a:b]

            z = torch.from_numpy(np.ascontiguousarray(train_maps[idx])).to(dev)
            x = src.map_to_adn_input(z)
            yy = torch.from_numpy(ty[idx]).to(dev)

            optimizer.zero_grad(set_to_none=True)
            logits, aux = model(x, return_aux=True)
            loss, ce, bg, hts, _, _ = compose_loss(logits, yy, aux, cfg)
            req(torch.isfinite(loss).item(), f"{variant}/{fold}: nonfinite loss")
            loss.backward()
            optimizer.step()

            lv = float(loss.detach().cpu())
            if total_steps == 0:
                first_loss = lv
            last_loss = lv
            total_steps += 1
            n = b-a
            sums["total"] += lv*n
            sums["ce"] += float(ce.detach().cpu())*n
            sums["bg"] += float(bg.detach().cpu())*n
            sums["hts"] += float(hts.detach().cpu())*n
            seen += n

            # FIX2 memory hygiene: free previous-batch graph/output roots before
            # the next full batch forward. This changes no model/loss arithmetic.
            del logits, aux, loss, ce, bg, hts, x, z, yy, idx

        req(seen == TRAIN_TOTAL, "epoch sample count drift")
        scheduler.step()
        history.append({
            "epoch_1based": epoch+1,
            "lr_start": lr_this,
            "train_total": sums["total"]/seen,
            "train_ce": sums["ce"]/seen,
            "train_bg": sums["bg"]/seen,
            "train_hts": sums["hts"]/seen,
            "steps_cumulative": total_steps,
            "runtime_minutes_cumulative": (time.perf_counter()-ft0)/60.0,
        })
        print(
            f"    {variant} {fold} epoch {epoch+1:02d}/{EPOCHS} | "
            f"lr={lr_this:.6g} | total={sums['total']/seen:.6f} | "
            f"ce={sums['ce']/seen:.6f} bg={sums['bg']/seen:.6f} hts={sums['hts']/seen:.6f} | "
            f"elapsed={(time.perf_counter()-ft0)/60:.2f}m",
            flush=True,
        )

    val = eval_model(src, model, val_maps, vy, dev, BATCH, cfg)
    runtime = (time.perf_counter()-ft0)/60.0

    state_cpu = {k:v.detach().cpu() for k,v in model.state_dict().items()}
    ckpt = {
        "version": VERSION,
        "status": "FULL_FINAL_EPOCH_FROZEN",
        "variant": variant,
        "variant_cfg": cfg,
        "fold_tag": fold,
        "fold_index": fold_idx,
        "state_dict": state_cpu,
        "source_name": SOURCE_NAME,
        "source_sha256": EXPECTED_SOURCE_SHA,
        "plan_sha256": sha256_file(plan_p),
        "training": {
            "epochs": EPOCHS, "batch": BATCH,
            "optimizer": "Adam", "lr": LR, "betas": BETAS,
            "scheduler": "StepLR", "step_size": STEP_SIZE, "gamma": GAMMA,
            "weight_decay": WEIGHT_DECAY,
            "loss": {
                "ce": 1.0,
                "lambda_bg": LAMBDA_BG if cfg["wcsg"] else 0.0,
                "lambda_hts": LAMBDA_HTS if cfg["hts"] else 0.0,
                "hts_rho_h0": HTS_RHO_H0,
                "hts_rho_h1": HTS_RHO_H1,
                "hts_margin": HTS_MARGIN,
            },
            "checkpoint": "FINAL_EPOCH_ONLY",
            "inner_val": "DESCRIPTIVE_ONLY",
            "amp": False,
            "seed": seed,
        },
        "validation": val,
        "firewall": {
            "2022_H0_used": False,
            "heldout_2025_H1_used": False,
            "final203_used": False,
            "threshold_fit": False,
            "checkpoint_selection": False,
        },
    }
    torch.save(ckpt, ckpt_p)
    pd.DataFrame(history).to_csv(hist_p, index=False)

    summary = {
        "version": VERSION,
        "status": "FULL_FINAL_EPOCH_FROZEN",
        "variant": variant,
        "fold_tag": fold,
        "runtime_minutes": runtime,
        "steps": total_steps,
        "first_batch_loss": first_loss,
        "last_batch_loss": last_loss,
        "parameter_count": model_param_count(model),
        "checkpoint_sha256": sha256_file(ckpt_p),
        "plan_sha256": sha256_file(plan_p),
        **{f"final_{k}": v for k,v in val.items()},
        "firewall": ckpt["firewall"],
    }
    dump_json(summary, summary_p)

    del model, train_maps, val_maps
    gc.collect()
    if dev.type == "cuda":
        torch.cuda.empty_cache()

    print(
        f"  DONE {variant}/{fold} | runtime={runtime:.2f}m | "
        f"val_auc={val['val_auc']:.6f}"
        + (f" | val_H0_supp={val.get('val_h0_suppression_db', float('nan')):.3f}dB"
           if cfg["wcsg"] else "")
    )
    return summary


def stage_train(src, args, plan_paths, union, cache_h5_p, dev, lineage):
    canary_cp = args.out_dir / "r10_adn_proposed_wcsg_tfcg_hts_canary_v1_FIX2_contract.json"
    req(canary_cp.is_file(), "formal train requires FIX2 steady-state 3-step canary contract in same out-dir")
    can = load_json(canary_cp)
    req(can.get("status") == "PASS_ADN_PROPOSED_WCSG_TFCG_HTS_CANARY_V1_FIX2__STEADY_STATE_3STEP_BATCH256__READY_FOR_FORMAL_7FOLD_TRAINING",
        "FIX2 steady-state canary status mismatch")

    requested = [x.strip() for x in args.variants.split(",") if x.strip()]
    for v in requested:
        req(v in VARIANTS, f"unknown variant {v}")

    all_results = []
    for variant in requested:
        cfg = VARIANTS[variant]
        print("\n" + "=" * 140)
        print("FORMAL VARIANT", variant, cfg)
        print("=" * 140)

        results = []
        for i, (fold, plan_p) in enumerate(zip(FOLDS, plan_paths)):
            print("\n" + "-" * 120)
            print(f"[{i+1}/7] {variant} | {fold}")
            r = train_one_fold(
                src, args, variant, cfg, fold, i,
                plan_p, cache_h5_p, union, dev
            )
            results.append(r)
            all_results.append(r)

        vdir = args.out_dir / variant
        df = pd.DataFrame(results)
        df.to_csv(vdir / f"r10_{variant.lower()}_fold_results_v1.csv", index=False)

        status = f"PASS_{variant}_TRAIN_V1_FIX2__ALL7_FINAL_EPOCH_CHECKPOINTS_FROZEN"
        contract = {
            "version": VERSION,
            "status": status,
            "variant": variant,
            "variant_cfg": cfg,
            "training_budget": {
                "folds": 7, "train_per_fold": TRAIN_TOTAL, "val_per_fold": VAL_TOTAL,
                "epochs": EPOCHS, "batch": BATCH,
                "optimizer": "Adam", "lr": LR, "betas": list(BETAS),
                "scheduler": "StepLR", "step_size": STEP_SIZE, "gamma": GAMMA,
                "checkpoint": "FINAL_EPOCH_ONLY", "inner_val": "DESCRIPTIVE_ONLY",
            },
            "loss_freeze": {
                "ce": 1.0,
                "lambda_bg": LAMBDA_BG if cfg["wcsg"] else 0.0,
                "lambda_hts": LAMBDA_HTS if cfg["hts"] else 0.0,
                "hts_rho_h0": HTS_RHO_H0,
                "hts_rho_h1": HTS_RHO_H1,
                "hts_margin": HTS_MARGIN,
            },
            "lineage": {k: {"path": str(p), "sha256": sha256_file(p)} for k,p in lineage.items()},
            "checkpoints": {
                r["fold_tag"]: {
                    "sha256": r["checkpoint_sha256"],
                    "runtime_minutes": r["runtime_minutes"],
                    "val_auc": r["final_val_auc"],
                    "val_h0_suppression_db": r.get("final_val_h0_suppression_db"),
                } for r in results
            },
            "firewall": {
                "2022_H0_used": False,
                "heldout_2025_H1_used": False,
                "final203_used": False,
                "threshold_fit": False,
                "checkpoint_selection": False,
            },
        }
        dump_json(contract, vdir / f"r10_{variant.lower()}_train_contract_v1.json")

        summary_cols = [
            "variant","fold_tag","runtime_minutes","steps","first_batch_loss","last_batch_loss",
            "parameter_count","final_val_ce","final_val_acc","final_val_auc",
            "final_val_target_prob_mean_pos","final_val_target_prob_mean_neg",
            "final_val_target_prob_max_neg","final_val_h0_suppression_db",
            "final_val_h1_energy_retention_db","checkpoint_sha256",
        ]
        keep = [c for c in summary_cols if c in df.columns]
        (vdir / f"R10_2025_{variant}_TRAIN_V1_SUMMARY.txt").write_text(
            f"{status}\n\n" + df[keep].to_string(index=False) + "\n",
            encoding="utf-8",
        )
        print(status)

    # Aggregate formal panel freeze: checkpoint hashes only, still no H0/H1/final203.
    adf = pd.DataFrame(all_results)
    adf.to_csv(args.out_dir / "r10_adn_proposed_all_variants_train_results_v1.csv", index=False)
    final_status = "PASS_ADN_PROPOSED_WCSG_TFCG_HTS_TRAIN_V1_FIX2__REQUESTED_VARIANTS_ALL7_FROZEN__READY_FOR_BLIND_H0_CALIBRATION"
    final_contract = {
        "version": VERSION,
        "status": final_status,
        "requested_variants": requested,
        "formal_ablation": {
            "A0_ADN": "reuse existing frozen baseline; not retrained",
            **VARIANTS,
        },
        "explicit_suppression_output": {
            "available_for": [v for v in requested if VARIANTS[v]["wcsg"]],
            "representation": "WVD-domain gate and suppressed WVD map",
            "claim_boundary": "feature/representation-domain sea-clutter-response suppression; not physical clean-target reconstruction",
        },
        "next_stage": (
            "For each trained variant: frozen external-2022-H0 threshold calibration "
            "at 1e-5/1e-6, then held-out 2025 H1, then canonical final203 controlled "
            "D80/D90 + alpha=0 floor. No rescue after test exposure."
        ),
        "firewall": {
            "2022_H0_used": False,
            "heldout_2025_H1_used": False,
            "final203_used": False,
            "threshold_fit": False,
            "checkpoint_selection": False,
        },
    }
    dump_json(final_contract, args.out_dir / "r10_adn_proposed_formal_train_panel_contract_v1_FIX2.json")
    print("\n" + "=" * 140)
    print(final_status)
    print("=" * 140)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--code-root", type=Path, required=True)
    ap.add_argument("--baseline-train-dir", type=Path, required=True)
    ap.add_argument("--module-canary-dir", type=Path, required=True)
    ap.add_argument("--out-dir", type=Path, required=True)
    ap.add_argument("--stage", choices=("canary","train","all"), default="canary")
    ap.add_argument("--device", choices=("auto","cuda","cpu"), default="auto")
    ap.add_argument("--variants", type=str,
                    default="A1_WCSG,A2_TFCG,A3_WCSG_TFCG,A4_FULL")
    ap.add_argument("--retrain", action="store_true")
    args = ap.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    fatal = args.out_dir / "R10_2025_ADN_PROPOSED_WCSG_TFCG_HTS_TRAIN_V1_FIX2_FATAL.txt"
    if fatal.exists():
        fatal.unlink()

    try:
        source_p, plan_paths, union, cache_h5_p, lineage = verify_inputs(args)
        src = load_module(source_p, "adn_frozen_source_for_proposed")
        dev = choose_device(args.device)

        if dev.type == "cuda":
            torch.backends.cudnn.benchmark = True
            if hasattr(torch.backends.cuda.matmul, "allow_tf32"):
                torch.backends.cuda.matmul.allow_tf32 = False
            if hasattr(torch.backends.cudnn, "allow_tf32"):
                torch.backends.cudnn.allow_tf32 = False
        torch.set_float32_matmul_precision("highest")

        print("=" * 140)
        print("R10 2025 — ADN-DERIVED PROPOSED V1 FIX2 | WCSG + TFCG + HTS")
        print("REUSE FROZEN WVD CACHE/LOAO PLANS | FINAL EPOCH ONLY")
        print("NO 2022 H0 | NO HELD-OUT H1 | NO FINAL203 | NO THRESHOLD FIT")
        print("=" * 140)
        print("stage      =", args.stage)
        print("device     =", dev)
        if dev.type == "cuda":
            print("GPU        =", torch.cuda.get_device_name(dev))
        print("variants   =", args.variants)
        print("WVD cache  =", cache_h5_p)
        print("union rows =", len(union))
        print("innovations = WCSG explicit suppression + TFCG context + HTS tail separation")
        print()

        if args.stage in ("canary","all"):
            stage_canary(src, args, plan_paths, union, cache_h5_p, dev, lineage)
            if args.stage == "canary":
                return 0

        if args.stage in ("train","all"):
            stage_train(src, args, plan_paths, union, cache_h5_p, dev, lineage)

        return 0
    except Exception:
        txt = traceback.format_exc()
        print(txt, file=sys.stderr)
        fatal.write_text(txt, encoding="utf-8")
        return 2


if __name__ == "__main__":
    import sys
    raise SystemExit(main())
