#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SIM-R10 Stage B2.13: resumable, fixed-scene 3-checkpoint scorebank.

Development-only, post-hoc selections. No train/val reads at scoring time.
Outputs frozen sample-index-defined H0 CAL, H0 AUDIT, DEV H1 score arrays.
New baseline integrations must use the same generator SHA, scene index and SCR grid.
"""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, sys, time
from datetime import datetime, timezone
from pathlib import Path
import numpy as np

VERSION='SIM_R10_B213_SCOREBANK_V1'
MODELS=(('A3_20261022','A3',20261022),('A3_20261024','A3',20261024),('ADN_20261024','ADN',20261024))
FAMILIES=('gaussian_colored','compound_gamma','nonstationary','sea_spikes','mixed')

def req(cond,msg):
    if not bool(cond): raise RuntimeError(msg)

def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(8<<20),b''):h.update(b)
    return h.hexdigest()

def write_json_atomic(p,obj):
    p=Path(p);temp=p.with_suffix(p.suffix+'.tmp')
    temp.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');os.replace(temp,p)

def imported(path,key):
    sp=importlib.util.spec_from_file_location(key,str(path));req(sp and sp.loader,'Cannot import '+str(path))
    m=importlib.util.module_from_spec(sp);sys.modules[key]=m;sp.loader.exec_module(m)
    return m

def parse_args():
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('root','bank-dir','cache-dir','sweep-dir','out-dir'):
        p.add_argument('--'+k,required=True,type=Path)
    p.add_argument('--stage',choices=('canary','score','render','all'),default='all')
    p.add_argument('--device',choices=('auto','cuda','cpu'),default='cuda')
    p.add_argument('--batch',type=int,default=32);p.add_argument('--chunk',type=int,default=512)
    p.add_argument('--h0-cal',type=int,default=3000000)
    p.add_argument('--h0-audit',type=int,default=1000000)
    p.add_argument('--h1-scenes',type=int,default=1024)
    p.add_argument('--scr-min',type=int,default=-24);p.add_argument('--scr-max',type=int,default=12)
    p.add_argument('--scr-step',type=int,default=1)
    p.add_argument('--extra-score',action='append',type=Path,default=[],help='additional baseline score NPZ with matching frozen protocol fingerprint')
    return p.parse_args()

def input_context(a):
    root=a.root.resolve();bank=a.bank_dir.resolve();sweep=a.sweep_dir.resolve();cache=a.cache_dir.resolve()
    for p in (root,bank,sweep,cache):req(p.is_dir(),'Missing directory '+str(p))
    b212_path=root/'r10_sim_stage_b212_two_pair_pd_scr_preview_v1.py'
    req(b212_path.is_file(),'Upload original B2.12 source to AutoDL root')
    b212=imported(b212_path,'b213_orig_b212')
    # Re-use exact B2.12 checkpoint and training-bank lineage verification.
    aa=argparse.Namespace(root=root,bank_dir=bank,sweep_dir=sweep,cache_dir=cache)
    v=b212.verify_inputs(aa)
    genpath=v['generator_path']
    gen=imported(genpath,'b213_frozen_generator')
    req(sha(genpath)==v['bc'].get('generator_sha256'),'Generator SHA drift')
    req(tuple(gen.TRAIN_FAMILIES)==FAMILIES,'Generator family order drift')
    return v,b212,gen

def protocol(a,v):
    req(a.h0_cal>=100000 and a.h0_audit>=10000 and a.h1_scenes>=128,'Too few observations')
    req(a.chunk>=a.batch>=1 and a.chunk%a.batch==0,'chunk must be divisible by batch')
    req(a.scr_step>0 and a.scr_max>a.scr_min and (a.scr_max-a.scr_min)%a.scr_step==0,'Bad SCR grid')
    scr=list(range(a.scr_min,a.scr_max+1,a.scr_step))
    data=dict(version=VERSION,master_seed=int(v['bc']['seed']),generator_sha=v['bc']['generator_sha256'],
              training_bank_sha=v['bc']['file_sha256'],models=[k for k,_,_ in MODELS],
              checkpoints={k:sha(v['ck'][k]) for k,_,_ in MODELS},
              h0_cal_n=a.h0_cal,h0_audit_n=a.h0_audit,h1_scenes_n=a.h1_scenes,scr_grid_db=scr,
              h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',
              family_names=list(FAMILIES),
              score='target logit minus clutter logit',
              scr_definition='10log10(mean(|target IQ|^2)/mean(|clutter IQ|^2)), pre-Doppler',
              exploratory=True,selection='post-hoc extreme/matched seed; NOT fair headline',
              final_test_read=False)
    scene_fields={k:data[k] for k in ('master_seed','generator_sha','h0_cal_n','h0_audit_n','h1_scenes_n','scr_grid_db','h0_cal_split','h0_audit_split','h1_split','family_names','scr_definition')}
    data['scene_fingerprint']=hashlib.sha256(json.dumps(scene_fields,sort_keys=True).encode()).hexdigest()
    fingerprint=hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()
    data['fingerprint']=fingerprint
    return data

def progress_for(out,proto):
    p=out/'progress.json'
    if p.exists():
        s=json.loads(p.read_text(encoding='utf-8'))
        req(s.get('fingerprint')==proto['fingerprint'],'Existing output protocol differs; select new --out-dir')
    else:
        s=dict(fingerprint=proto['fingerprint'],completed=dict(h0_cal=0,h0_audit=0,h1=0),
               created_utc=datetime.now(timezone.utc).isoformat())
        write_json_atomic(p,s)
    return s

def array_open(path,shape,dtype,exists,fill=None):
    if exists:
        req(path.exists(),'Missing score array '+str(path))
        m=np.load(path,mmap_mode='r+')
        req(m.shape==shape and m.dtype==np.dtype(dtype),f'Array shape/dtype mismatch: {path}')
    else:
        req(not path.exists(),'Unregistered existing score array: '+str(path))
        m=np.lib.format.open_memmap(path,mode='w+',dtype=dtype,shape=shape)
        if fill is not None:m[:]=fill
        m.flush()
    return m

def make_models(v,a):
    import torch
    dev=torch.device('cuda' if a.device=='auto' and torch.cuda.is_available() else
                     'cpu' if a.device=='auto' else a.device)
    req(dev.type!='cuda' or torch.cuda.is_available(),'CUDA unavailable')
    b210=imported(v['trainer_path'],'b213_b210_trainer')
    src=b210.load_exact(v['root']/b210.SOURCE_NAME,b210.SOURCE_SHA,'b213_model_source')
    tr=b210.load_exact(v['root']/b210.TRAINER_NAME,b210.TRAINER_SHA,'b213_model_trainer')
    m={}
    for key,method,seed in MODELS:
        path=v['ck'][key]
        try:z=torch.load(path,map_location='cpu',weights_only=True)
        except TypeError:z=torch.load(path,map_location='cpu')
        req(z['method']==method and int(z['seed'])==seed,'Checkpoint identity mismatch')
        req(z['bank_sha256']==v['bc']['file_sha256'] and z['wvd_cache_sha256']==v['cc']['wvd_cache_sha256'],'Checkpoint data lineage mismatch')
        req(z['source_sha256']==b210.SOURCE_SHA and z['trainer_sha256']==b210.TRAINER_SHA,'Checkpoint source drift')
        mm=b210.instantiate(src,tr,method,dev,seed);mm.load_state_dict(z['state_dict'],strict=True)
        mm.eval()
        for param in mm.parameters():param.requires_grad_(False)
        m[key]=mm
        print(f'  {key}: epoch={z["epoch"]} checkpoint_sha={sha(path)[:16]}',flush=True)
    return m,src,dev

def model_scores(m,src,iq,dev,batch):
    import torch
    r=np.empty((len(iq),len(MODELS)),dtype=np.float64)
    with torch.inference_mode():
        for st in range(0,len(iq),batch):
            x=torch.from_numpy(np.ascontiguousarray(iq[st:st+batch])).to(dev)
            w=src.wvd_base_map(x);img=src.map_to_adn_input(w)
            for j,(key,_,_) in enumerate(MODELS):
                z=m[key](img)
                req(z.ndim==2 and z.shape[1]==2,'Unexpected logits')
                r[st:st+len(x),j]=(z[:,1].to(torch.float64)-z[:,0].to(torch.float64)).cpu().numpy()
    req(np.isfinite(r).all(),'NaN/Inf detector score')
    return r

def stream_h0(kind,a,out,proto,prog,gen,models,src,dev):
    n=proto[kind+'_n'];nmod=len(MODELS)
    array=out/(kind+'_scores.npy');families=out/(kind+'_family.npy')
    exists=(array.exists() or families.exists())
    req(array.exists()==families.exists(),'Partial H0 arrays present, refuse implicit reset')
    scores=array_open(array,(n,nmod),np.float64,exists)
    family=array_open(families,(n,),np.uint8,exists)
    start=int(prog['completed'][kind]);master=proto['master_seed']
    req(0<=start<=n,'Bad H0 progress')
    print(f'[{kind}] resume {start}/{n}',flush=True)
    for st in range(start,n,a.chunk):
        en=min(n,st+a.chunk)
        batch=[gen.make_one(master,kind,i,-30,10) for i in range(st,en)]
        req(all(x['label']==0 and np.all(x['target']==0) for x in batch),'H0 contaminated')
        iq=np.stack([x['base'] for x in batch]).astype(np.complex64)
        scores[st:en]=model_scores(models,src,iq,dev,a.batch)
        family[st:en]=[int(x['family']) for x in batch]
        scores.flush();family.flush()
        prog['completed'][kind]=en;write_json_atomic(out/'progress.json',prog)
        if en==n or en%10000<a.chunk:print(f'  {kind}: {en}/{n}',flush=True)
    del scores,family

def stream_h1(a,out,proto,prog,gen,models,src,dev):
    n=proto['h1_scenes_n'];levels=proto['scr_grid_db'];num=len(levels);master=proto['master_seed']
    p=out/'dev_h1_scores.npy';fp=out/'dev_h1_family.npy'
    exists=p.exists() or fp.exists()
    req(p.exists()==fp.exists(),'Partial H1 arrays present')
    scores=array_open(p,(num,n,len(MODELS)),np.float64,exists)
    fam=array_open(fp,(n,),np.uint8,exists)
    start=int(prog['completed']['h1']);req(0<=start<=num,'Invalid H1 progress')
    print(f'[dev_h1] resume SCR index={start}/{num}',flush=True)
    # Deterministically regenerate the same scene templates at every restart.
    base=np.empty((n,512),np.complex64);unit=np.empty_like(base);cp=np.empty(n,np.float64)
    for i in range(n):
        z=gen.make_one(master,'dev_h1',i,-30,10)
        req(z['label']==1 and z['family'] in range(len(FAMILIES)),'H1 generation invalid')
        base[i]=z['base'];unit[i]=z['unit'];cp[i]=z['cp'];fam[i]=z['family']
    fam.flush()
    for idx in range(start,num):
        scr=levels[idx]
        for st in range(0,n,a.chunk):
            en=min(n,st+a.chunk)
            amp=np.sqrt(cp[st:en]*10**(scr/10.0))
            iq=(base[st:en].astype(np.complex128)+unit[st:en].astype(np.complex128)*amp[:,None]).astype(np.complex64)
            scores[idx,st:en,:]=model_scores(models,src,iq,dev,a.batch)
        scores.flush();prog['completed']['h1']=idx+1;write_json_atomic(out/'progress.json',prog)
        print(f'  SCR={scr:+3d} dB {idx+1}/{num}',flush=True)
    del scores,fam

def render(a,out,proto):
    p=out/'progress.json';req(p.is_file(),'No score progress file')
    s=json.loads(p.read_text(encoding='utf-8'))
    req(s.get('fingerprint')==proto['fingerprint'],'Protocol mismatch on render')
    req(s['completed']['h0_cal']==proto['h0_cal_n']
        and s['completed']['h0_audit']==proto['h0_audit_n']
        and s['completed']['h1']==len(proto['scr_grid_db']),
        'Scores incomplete; finish --stage score first')
    script=Path(__file__).with_name('r10_sim_stage_b213_figures_v1.py')
    req(script.is_file(),'Missing B2.13 plot script')
    mod=imported(script,'b213_figure_mod')
    mod.create_figures(out,proto,a.extra_score)

def main():
    a=parse_args();v,b212,gen=input_context(a)
    proto=protocol(a,v)
    out=a.out_dir.resolve()
    print('SIM R10 B2.13 — FIXED-SCENE LOW-Pfa SCOREBANK')
    print('  split: DEV ONLY (post-hoc seed choice), no TRAIN/VAL/H1 FINAL opened')
    print('  CAL/AUDIT/H1:',a.h0_cal,a.h0_audit,a.h1_scenes)
    print('  fingerprint:',proto['fingerprint'])
    if a.stage=='canary':
        req(proto['h0_cal_n']*1e-5>=10,'Must have >=10 nominal calibration exceedances at 1e-5')
        print('PASS_B213_INTERFACE_CANARY__NO_GPU_NO_TEST_SCORING')
        return
    out.mkdir(parents=True,exist_ok=True)
    f=out/'protocol_frozen.json'
    if f.exists():req(json.loads(f.read_text(encoding='utf-8'))==proto,'Frozen protocol mismatch')
    else:
        req(not any(out.iterdir()),'Nonempty output directory without protocol: refuse overwrite')
        write_json_atomic(f,proto)
    prog=progress_for(out,proto)
    if a.stage in ('score','all'):
        req(a.h0_cal*1e-5>=10,'At least 10 nominal H0 tail observations required for 1e-5')
        models,src,dev=make_models(v,a)
        stream_h0('h0_cal',a,out,proto,prog,gen,models,src,dev)
        stream_h0('h0_audit',a,out,proto,prog,gen,models,src,dev)
        stream_h1(a,out,proto,prog,gen,models,src,dev)
        print('PASS_B213_SCOREBANK__RESUMABLE__BOTH_PFA__DEV_ONLY',flush=True)
    if a.stage in ('render','all'):
        render(a,out,proto)
        print('PASS_B213_FIGURES__TWO_PFA__EXPLORATORY_ONLY',flush=True)

if __name__=='__main__': main()
