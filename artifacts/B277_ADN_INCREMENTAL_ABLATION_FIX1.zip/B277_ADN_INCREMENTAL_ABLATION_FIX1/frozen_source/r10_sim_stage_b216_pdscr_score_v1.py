#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SIM-R10 B2.16 fixed-scene *DEV ONLY* 18-checkpoint low-Pfa scorer.

6 methods (ADN, A3_NO_BG, A3, L1_TAIL, L2_GATE, L3_TPHT) × training
seeds (20261020,21,22). Uses EXACT prior B2.13 generator and scene indices,
H0_CAL, H0_AUDIT, DEV_H1, SCR grid; WVD computed ONCE per batch and passed
to all models. Fully resumable; NEVER accesses TRAIN/VAL samples or FINAL.

Pass --stage canary to audit immutable input and checkpoint contracts; stage
score requires a GPU for practical execution; stage report uses companion script.
"""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, math, os, sys, time
from datetime import datetime, timezone
from pathlib import Path
import numpy as np

VERSION='SIM_R10_B216_PDSCR_V1'
PASS='PASS_SIM_R10_B216_SCOREBANK_DEV_ONLY__THREE_SEEDS_SIX_METHODS'
SEEDS=(20261020,20261021,20261022)
METHODS=('ADN','A3_NO_BG','A3','L1_TAIL','L2_GATE','L3_TPHT')
LABELS=tuple((seed,method) for seed in SEEDS for method in METHODS)
FAMILIES=('gaussian_colored','compound_gamma','nonstationary','sea_spikes','mixed')

def need(x,m):
    if not bool(x): raise RuntimeError(m)

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(8<<20),b''):h.update(b)
    return h.hexdigest()

def write_json(p,obj):
    p=Path(p);t=p.with_suffix(p.suffix+'.tmp')
    t.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    os.replace(t,p)

def imported(p,name):
    spec=importlib.util.spec_from_file_location(name,str(p))
    need(spec and spec.loader,'Missing import '+str(p))
    mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod)
    return mod

def cli():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--stage',choices=('selftest','canary','gpu-canary','score','report'),default='canary')
    for s in ('root','bank-dir','cache-dir','sweep-dir','b214-dir','b215-dir','b213-dir','out-dir'):
        p.add_argument('--'+s,type=Path)
    p.add_argument('--device',choices=('cuda','cpu','auto'),default='cuda')
    p.add_argument('--batch',type=int,default=32)
    p.add_argument('--chunk',type=int,default=512)
    p.add_argument('--prevalences',default='0.5,0.001',help='Report-only hypothetical H1 prevalences')
    return p.parse_args()

def all_paths(a):
    for key in ('root','bank_dir','cache_dir','sweep_dir','b214_dir','b215_dir','b213_dir','out_dir'):
        val=getattr(a,key)
        need(val is not None,'Missing --'+key.replace('_','-'))
        setattr(a,key,val.resolve())
    for key in ('root','bank_dir','cache_dir','sweep_dir','b214_dir','b215_dir','b213_dir'):
        need(getattr(a,key).is_dir(),'Missing directory '+str(getattr(a,key)))

def input_audit(a):
    b213=imported(a.root/'r10_sim_stage_b213_scorebank_v1.py','b216_orig_b213')
    v,b212,gen=b213.input_context(a)
    old_path=a.b213_dir/'protocol_frozen.json'
    progpath=a.b213_dir/'progress.json'
    need(old_path.is_file() and progpath.is_file(),'Prior B2.13 scorebank protocol/progress missing')
    old=json.loads(old_path.read_text(encoding='utf-8'))
    oldprog=json.loads(progpath.read_text(encoding='utf-8'))
    reqfields=('master_seed','generator_sha','h0_cal_n','h0_audit_n','h1_scenes_n','scr_grid_db',
               'h0_cal_split','h0_audit_split','h1_split','family_names','scr_definition')
    fields={k:old[k] for k in reqfields}
    fingerprint=hashlib.sha256(json.dumps(fields,sort_keys=True).encode()).hexdigest()
    need(old.get('scene_fingerprint')==fingerprint,'B2.13 scene fingerprint drift')
    need(oldprog.get('fingerprint')==old['fingerprint'],'B2.13 progress protocol mismatch')
    need(all(oldprog['completed'][k]==old[k+'_n'] for k in ('h0_cal','h0_audit')) and
         oldprog['completed']['h1']==len(old['scr_grid_db']),'B2.13 scorebank not complete')
    need(int(old['h0_cal_n'])==3000000 and int(old['h0_audit_n'])==1000000 and int(old['h1_scenes_n'])==1024,
         'Refusing noncanonical size; require original B2.13 scenes')
    need(old['scr_grid_db']==list(range(-24,13)),'Refusing changed SCR grid')
    need(old['master_seed']==v['bc']['seed'] and old['generator_sha']==v['bc']['generator_sha256'],
         'B2.13 generator/bank drift')
    need(old['training_bank_sha']==v['bc']['file_sha256'],'B2.13 bank differs')
    need(tuple(old['family_names'])==FAMILIES,'B2.13 families changed')
    # frozen exact original training-source imports; SHA checked by b210.load_exact
    b210=imported(v['trainer_path'],'b216_orig_b210')
    need(b210.SOURCE_SHA==v['cc']['source_sha256'] and b210.TRAINER_SHA==v['cc']['trainer_sha256'],
         'WVD cache lineage inconsistent')
    b215=imported(a.root/'r10_sim_stage_b215_tpht_train_v1.py','b216_orig_b215')
    need(sha(a.root/b215.B214_FILE)==b215.B214_SHA,'B2.14 source checksum mismatch')
    b214=b215.load_b214(a.root)
    cps=[]
    for seed,method in LABELS:
        if method in ('ADN','A3'):
            folder=a.sweep_dir/f'trainseed_{seed}'/method
        elif method=='A3_NO_BG':
            folder=a.b214_dir/f'trainseed_{seed}'/method
        else:
            folder=a.b215_dir/f'trainseed_{seed}'/method
        path=folder/'best_val_ce.pt';ct=folder/'training_contract.json'
        need(path.is_file() and ct.is_file(),f'Missing checkpoint/contract: {folder}')
        contract=json.loads(ct.read_text(encoding='utf-8'))
        need(contract.get('seed')==seed and contract.get('method')==method,f'Checkpoint contract ID mismatch: {folder}')
        need(contract.get('bank_sha256')==v['bc']['file_sha256'] and
             contract.get('wvd_cache_sha256')==v['cc']['wvd_cache_sha256'],f'Lineage mismatch: {folder}')
        digest=sha(path)
        if method in ('ADN','A3'):
            need(digest==contract.get('outputs',{}).get('best',{}).get('sha256'),
                 f'B2.10 checkpoint SHA mismatch: {folder}')
        else:
            need(digest==contract.get('best_checkpoint_sha256'),f'Checkpoint SHA mismatch: {folder}')
        need(contract.get('source_sha256')==b210.SOURCE_SHA and
             contract.get('trainer_sha256')==b210.TRAINER_SHA,
             f'Trainer/source lineage mismatch: {folder}')
        cps.append(dict(seed=seed,method=method,path=str(path),sha256=digest,epoch=contract.get('best_epoch')))
    proto=dict(version=VERSION,scene_fingerprint=fingerprint,b213_original_protocol_sha256=sha(old_path),
               generator_sha256=old['generator_sha'],bank_sha256=old['training_bank_sha'],
               source_sha256=b210.SOURCE_SHA,trainer_sha256=b210.TRAINER_SHA,
               labels=[dict(seed=s,method=m) for s,m in LABELS],checkpoints=cps,
               h0_cal_n=old['h0_cal_n'],h0_audit_n=old['h0_audit_n'],
               h1_scenes_n=old['h1_scenes_n'],scr_grid_db=old['scr_grid_db'],
               master_seed=old['master_seed'],family_names=list(FAMILIES),
               h0_cal_split=old['h0_cal_split'],h0_audit_split=old['h0_audit_split'],h1_split=old['h1_split'],
               score_definition='target logit minus clutter logit, float64 subtraction of float32 logits',
               strict_decision='score > threshold',checkpoint_selection='min TRAIN/VAL CE (previously frozen)',
               exploratory=True,independent_final=False,source_protocol='Existing B2.13 reused scene fingerprint',
               caution='B2.13 DEV/H1 has been explored. No post-hoc FINAL claims. Precision/F1 depend on prior.')
    proto['fingerprint']=hashlib.sha256(json.dumps(proto,sort_keys=True).encode()).hexdigest()
    return proto,v,gen,b210

def load_models(a,proto,v,b210):
    import torch
    dev=torch.device('cuda' if a.device=='auto' and torch.cuda.is_available() else
                     'cpu' if a.device=='auto' else a.device)
    need(dev.type!='cuda' or torch.cuda.is_available(),'CUDA unavailable')
    src=b210.load_exact(v['root']/b210.SOURCE_NAME,b210.SOURCE_SHA,'b216_exact_src')
    tr=b210.load_exact(v['root']/b210.TRAINER_NAME,b210.TRAINER_SHA,'b216_exact_tr')
    models=[]
    for z in proto['checkpoints']:
        method=z['method'];seed=z['seed']
        try:ck=torch.load(z['path'],map_location='cpu',weights_only=True)
        except TypeError:ck=torch.load(z['path'],map_location='cpu')
        need(ck.get('method')==method and int(ck.get('seed',-1))==seed,
             f'Checkpoint internal ID mismatch {seed} {method}')
        need(ck.get('bank_sha256')==proto['bank_sha256'] and
             ck.get('wvd_cache_sha256')==v['cc']['wvd_cache_sha256'], 'Internal bank/cache mismatch')
        need(ck.get('source_sha256')==b210.SOURCE_SHA and ck.get('trainer_sha256')==b210.TRAINER_SHA,
             'Internal source/trainer mismatch')
        if method=='ADN':
            model=b210.instantiate(src,tr,'ADN',dev,seed)
        else:
            # Same class/parameterization for A3, A3_NO_BG, L1/L2/L3;
            # only training loss differs; strict=True validates every tensor.
            need(ck.get('cfg')=={'wcsg':True,'tfcg':True,'hts':False},f'Bad WCSG/TFCG cfg: {method}')
            model=b210.instantiate(src,tr,'A3',dev,seed)
        model.load_state_dict(ck['state_dict'],strict=True)
        model.eval()
        for p in model.parameters():p.requires_grad_(False)
        models.append(model)
        print(f'  model {seed} {method}: epoch={ck["epoch"]}, SHA={z["sha256"][:16]}',flush=True)
        del ck
    return models,src,dev

def predict(models,src,iq,dev,batch):
    import torch
    need(iq.ndim==2 and iq.shape[1]==512 and iq.dtype==np.complex64,'Incorrect IQ dimensions/type')
    arr=np.empty((len(iq),len(LABELS)),np.float64)
    with torch.inference_mode():
        for st in range(0,len(iq),batch):
            en=min(len(iq),st+batch)
            x=torch.from_numpy(np.ascontiguousarray(iq[st:en])).to(dev)
            w=src.wvd_base_map(x)
            z=src.map_to_adn_input(w)
            need(z.shape==(en-st,3,224,224),'ADN frozen mapping drift')
            for j,m in enumerate(models):
                logits=m(z)
                need(logits.shape==(en-st,2),'Unexpected logits shape')
                score=(logits[:,1].to(torch.float64)-logits[:,0].to(torch.float64)).cpu().numpy()
                need(np.isfinite(score).all(),'Nonfinite detector score')
                arr[st:en,j]=score
            del x,w,z
    return arr

def new_array(p,shape,exists):
    if exists:
        need(p.exists(),f'Missing array: {p}')
        m=np.load(p,mmap_mode='r+')
        need(m.shape==shape and m.dtype==np.dtype('float64'),f'Bad score file: {p}')
    else:
        need(not p.exists(),'Existing unregistered score array '+str(p))
        m=np.lib.format.open_memmap(p,mode='w+',shape=shape,dtype='float64')
        m.flush()
    return m

def init(a,p):
    out=a.out_dir
    out.mkdir(parents=True,exist_ok=True)
    f=out/'protocol_frozen.json'
    if f.exists():need(json.loads(f.read_text(encoding='utf-8'))==p,'B2.16 frozen protocol mismatch; do not overwrite')
    else:
        need(not any(out.iterdir()),'Nonempty B2.16 output without protocol; refusing overwrite')
        write_json(f,p)
    progpath=out/'progress.json'
    if progpath.exists():
        prog=json.loads(progpath.read_text(encoding='utf-8'))
        need(prog.get('fingerprint')==p['fingerprint'],'B2.16 progress fingerprint mismatch')
    else:
        need(not any((out/x).exists() for x in ('h0_cal_scores.npy','h0_audit_scores.npy','dev_h1_scores.npy')),
             'Score arrays without progress; refusing reset')
        prog=dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=0,h0_audit=0,h1=0),
                  created_utc=datetime.now(timezone.utc).isoformat())
        write_json(progpath,prog)
    return prog

def score_h0(split,a,p,prog,gen,models,src,dev):
    count=int(p[split+'_n']);fn=a.out_dir/(split+'_scores.npy')
    arr=new_array(fn,(count,len(LABELS)),exists=(fn.exists()))
    st=int(prog['completed'][split]);need(0<=st<=count,'H0 progress invalid')
    print(f'[{split}] resume {st:,}/{count:,}',flush=True)
    for start in range(st,count,a.chunk):
        end=min(count,start+a.chunk)
        samples=[gen.make_one(p['master_seed'],split,i,-30,10) for i in range(start,end)]
        need(all(d['label']==0 and np.all(d['target']==0) for d in samples),'Nonempty H0')
        iq=np.stack([d['base'] for d in samples]).astype(np.complex64)
        arr[start:end]=predict(models,src,iq,dev,a.batch)
        arr.flush();prog['completed'][split]=end;write_json(a.out_dir/'progress.json',prog)
        if end==count or end%10000<a.chunk: print(f'[{split}] {end:,}/{count:,}',flush=True)
    del arr

def score_h1(a,p,prog,gen,models,src,dev):
    levels=p['scr_grid_db'];ns=p['h1_scenes_n'];fn=a.out_dir/'dev_h1_scores.npy'
    arr=new_array(fn,(len(levels),ns,len(LABELS)),exists=fn.exists())
    idx=int(prog['completed']['h1']);need(0<=idx<=len(levels),'H1 progress invalid')
    print(f'[dev_h1] resume SCR index {idx}/{len(levels)}',flush=True)
    base=np.empty((ns,512),np.complex64);unit=np.empty_like(base);cp=np.empty(ns,np.float64)
    for i in range(ns):
        d=gen.make_one(p['master_seed'],'dev_h1',i,-30,10)
        need(d['label']==1,'H1 generation label error')
        base[i]=d['base'];unit[i]=d['unit'];cp[i]=d['cp']
    need(np.isfinite(cp).all() and np.all(cp>0),'Invalid H1 power')
    for j in range(idx,len(levels)):
        scr=levels[j]
        for st in range(0,ns,a.chunk):
            en=min(ns,st+a.chunk)
            amp=np.sqrt(cp[st:en]*10**(scr/10.))
            iq=(base[st:en].astype(np.complex128)+unit[st:en].astype(np.complex128)*amp[:,None]).astype(np.complex64)
            arr[j,st:en]=predict(models,src,iq,dev,a.batch)
        arr.flush();prog['completed']['h1']=j+1;write_json(a.out_dir/'progress.json',prog)
        print(f'[dev_h1] SCR={scr:+3d} {j+1}/{len(levels)}',flush=True)
    del arr

def verify_against_b213(a,p):
    # Compare exact unrounded frozen A3 seed20261022 to B2.13 native scores.
    orig={'h0_cal':'h0_cal_scores.npy','h0_audit':'h0_audit_scores.npy','dev_h1':'dev_h1_scores.npy'}
    j=LABELS.index((20261022,'A3'))
    for kind,fn in orig.items():
        old=np.load(a.b213_dir/fn,mmap_mode='r')
        new=np.load(a.out_dir/fn,mmap_mode='r')
        if kind=='dev_h1':
            a0=old[:,:,0];a1=new[:,:,j];delta=float(np.max(np.abs(a0-a1)))
        else:
            inds=np.unique(np.array([0,123,1000,10000,len(new)//2,len(new)-1]))
            delta=float(np.max(np.abs(old[inds,0]-new[inds,j])))
        need(delta<=1e-5,f'B2.13 A3 seed22 score identity discrepancy for {kind}: {delta}')
        print(f'  B2.13 A3s20261022 score identity {kind}: maxdiff={delta:.3g}',flush=True)

def selftest():
    need(len(LABELS)==18 and LABELS[0]==(20261020,'ADN') and LABELS[-1]==(20261022,'L3_TPHT'),
         'Label structure mismatch')
    import numpy as np
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as d:
        q=Path(d)/'x.npy';m=new_array(q,(5,18),False);m[:]=7.;m.flush();del m
        n=new_array(q,(5,18),True);need(np.all(n[:]==7.),'Memmap reload failure')
    print('PASS_SIM_R10_B216_SELFTEST__PROTOCOL_AND_MEMMAP',flush=True)

def main():
    a=cli()
    if a.stage=='selftest':selftest();return
    all_paths(a)
    p,v,gen,b210=input_audit(a)
    if a.stage=='canary':
        print(f'B2.16 DEV interface CANARY: {len(LABELS)} checkpoint hashes verified')
        print('  scene fingerprint:',p['scene_fingerprint'])
        print('  models:',[(seed,method) for seed,method in LABELS])
        print('  H0 CAL/AUDIT/H1:',p['h0_cal_n'],p['h0_audit_n'],p['h1_scenes_n'])
        print('PASS_SIM_R10_B216_INTERFACE_CANARY__NO_GPU_NO_SCENE_SCORING',flush=True);return
    if a.stage=='report':
        f=a.root/'r10_sim_stage_b216_pdscr_report_v1.py'
        report=imported(f,'b216_reports')
        report.generate(a.out_dir,a.b213_dir,[float(z) for z in a.prevalences.split(',')])
        return
    need(a.batch>=1 and a.chunk>=a.batch and a.chunk%a.batch==0,'Bad batch/chunk')
    if a.stage!='gpu-canary':prog=init(a,p)
    models,src,dev=load_models(a,p,v,b210)
    if a.stage=='gpu-canary':
        h0=[gen.make_one(p['master_seed'],'h0_cal',i,-30,10) for i in range(a.batch)]
        need(all(row['label']==0 for row in h0),'GPU canary H0 contamination')
        iq=np.stack([row['base'] for row in h0]).astype(np.complex64)
        test=predict(models,src,iq,dev,a.batch)
        need(test.shape==(a.batch,18) and np.isfinite(test).all(),'GPU canary invalid output')
        print('PASS_SIM_R10_B216_GPU_CANARY__18_CHECKPOINTS_SHARED_WVD__NO_OUTPUT',flush=True)
        return
    print('B2.16 frozen scene scorebank, DEV ONLY, 18 models, shared WVD',flush=True)
    print('  scene fingerprint:',p['scene_fingerprint'],flush=True)
    score_h0('h0_cal',a,p,prog,gen,models,src,dev)
    score_h0('h0_audit',a,p,prog,gen,models,src,dev)
    score_h1(a,p,prog,gen,models,src,dev)
    verify_against_b213(a,p)
    print(PASS,flush=True)

if __name__=='__main__': main()
