#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SIM-R10 B2.15 experimental loss ablation (TRAIN/VAL ONLY).

L1_TAIL : A3 architecture + CE + differentiable hard-score tail separation.
L2_GATE : A3 architecture + CE + score-selected hard H0 suppression + H1 energy retention.
L3_TPHT : A3 architecture + CE + both terms.

Explicitly development only. No independent H0 CAL/AUDIT, B2.13 DEV-H1,
2022 or 2025 measured data. Earlier B2.10 and B2.14 models are untouched.
"""
from __future__ import annotations
import argparse, gc, hashlib, json, math, sys, time
from pathlib import Path
import h5py
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

VERSION = 'SIM_R10_B215_TPHT_TRAIN_VAL_ONLY_V1'
PASS = 'PASS_SIM_R10_B215_TPHT_TRAIN_VAL_ONLY__NO_H0_NO_DEV'
B214_FILE = 'r10_sim_stage_b214_ablation_train_v1.py'
B214_SHA = '5fafffcbc4b561d7898004244e476e98ff75436e10602e242fde240375287383'
METHODS = ('L1_TAIL', 'L2_GATE', 'L3_TPHT')
CFG = {'wcsg': True, 'tfcg': True, 'hts': False}

# These exploratory hyperparameters are frozen together for this first B2.15 run.
# They are not derived from a target Pfa and must NOT be tuned using B2.13 DEV Pd.
PARAMS = {
 'rho_h0': .25, 'rho_h1': .25,
 'tail_margin': 1.0, 'tail_temperature': 2.0, 'lambda_tail': .05,
 'gate_h0_upper': .92, 'gate_h1_lower': .98, 'gate_scale': .10,
 'lambda_h0': .10, 'lambda_pres': .10,
}

def require(cond, msg):
    if not bool(cond): raise RuntimeError(msg)

def file_sha(p: Path):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):
            h.update(b)
    return h.hexdigest()

def load_b214(root:Path):
    p=root/B214_FILE
    require(p.is_file(),f'Missing original B2.14 trainer: {p}')
    require(file_sha(p)==B214_SHA,'B2.14 SHA drift: do not substitute altered trainer')
    import importlib.util
    spec=importlib.util.spec_from_file_location('b215_frozen_b214',p)
    require(spec is not None and spec.loader is not None,'Cannot import B2.14')
    m=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=m
    spec.loader.exec_module(m)
    return m

def ratio_per_sample(aux):
    xi=aux['input_gray']
    xo=aux['output_gray']
    require(xi.shape==xo.shape and xi.ndim==4,'Unexpected suppressor tensors')
    # Identical definition to the frozen original h0_suppression_loss, samplewise.
    pin=xi.square().mean(dim=(1,2,3))
    pout=xo.square().mean(dim=(1,2,3))
    return pout/(pin+1e-12)

def get_hard_indices(scores, labels, ratio_h0=.25, ratio_h1=.25):
    # Use detached rankings: the top-k selection itself is not differentiated.
    ix0=torch.nonzero(labels==0,as_tuple=False).flatten()
    ix1=torch.nonzero(labels==1,as_tuple=False).flatten()
    if ix0.numel()==0 or ix1.numel()==0:
        return None,None
    k0=max(1,min(ix0.numel(),int(math.ceil(ix0.numel()*ratio_h0))))
    k1=max(1,min(ix1.numel(),int(math.ceil(ix1.numel()*ratio_h1))))
    a=torch.topk(scores.detach()[ix0],k=k0,largest=True).indices
    b=torch.topk(scores.detach()[ix1],k=k1,largest=False).indices
    return ix0[a],ix1[b]

def tpht_components(logits, labels, aux, params=PARAMS):
    """Return differentiable components and diagnostic counts. Requires both labels."""
    z=logits[:,1]-logits[:,0]
    zero=logits.new_zeros(())
    h0,h1=get_hard_indices(z,labels,params['rho_h0'],params['rho_h1'])
    if h0 is None:
        return {'tail':zero,'hard_h0':zero,'preserve_h1':zero,
                'ratio_h0':float('nan'),'ratio_h1':float('nan'),
                'num_hard_h0':0,'num_weak_h1':0}
    t=float(params['tail_temperature'])
    m=float(params['tail_margin'])
    # Pairwise softplus smoothly penalizes H0 upper vs H1 lower scores.
    tail=(F.softplus((m+z[h0,None]-z[None,h1])/t)*t).mean()
    r=ratio_per_sample(aux)
    sc=float(params['gate_scale'])
    # H0 uses highest-scoring negatives, not all clutter instances.
    hard_h0=F.relu((r[h0]-params['gate_h0_upper'])/sc).square().mean()
    # Retain H1 energy on all targets. Only a proxy; it is NOT target ROI/SCR.
    pres=F.relu((params['gate_h1_lower']-r[labels==1])/sc).square().mean()
    return {
        'tail':tail,'hard_h0':hard_h0,'preserve_h1':pres,
        'ratio_h0':float(r[labels==0].detach().mean().cpu()),
        'ratio_h1':float(r[labels==1].detach().mean().cpu()),
        'num_hard_h0':int(h0.numel()),'num_weak_h1':int(h1.numel()),
    }

def compute_loss(method,logits,labels,aux,params=PARAMS):
    require(method in METHODS,f'Unknown method {method}')
    ce=F.cross_entropy(logits,labels)
    c=tpht_components(logits,labels,aux,params)
    tail=params['lambda_tail']*c['tail'] if method in ('L1_TAIL','L3_TPHT') else ce.new_zeros(())
    h0=params['lambda_h0']*c['hard_h0'] if method in ('L2_GATE','L3_TPHT') else ce.new_zeros(())
    pres=params['lambda_pres']*c['preserve_h1'] if method in ('L2_GATE','L3_TPHT') else ce.new_zeros(())
    return ce+tail+h0+pres,ce,c,{'tail':tail,'hard_h0':h0,'preserve_h1':pres}

def selftest():
    assert len(METHODS)==3
    assert all(0<PARAMS[x]<=1 for x in ('rho_h0','rho_h1'))
    labels=torch.tensor([0,0,0,0,1,1,1,1],dtype=torch.long)
    scores=torch.tensor([-.5,.1,2.,-.1,1.5,.2,0.,2.],dtype=torch.float32)
    i0,i1=get_hard_indices(scores,labels,.25,.25)
    assert int(i0[0])==2 and int(i1[0])==6, 'Top-k selection failed'
    logits=torch.stack([torch.zeros_like(scores),scores],dim=1).requires_grad_()
    xi=torch.ones((8,1,8,8))
    gate=torch.tensor([.96,.95,.98,.95,.96,.99,.99,.95],requires_grad=True)
    aux={'input_gray':xi,'output_gray':xi*gate[:,None,None,None]}
    for method in METHODS:
        if logits.grad is not None: logits.grad.zero_()
        if gate.grad is not None: gate.grad.zero_()
        total,ce,c,items=compute_loss(method,logits,labels,aux)
        assert bool(torch.isfinite(total)),f'{method} loss not finite'
        total.backward(retain_graph=True)
        assert bool(torch.isfinite(logits.grad).all()),'Nonfinite logit gradients'
        if method!='L1_TAIL':
            assert gate.grad is not None and bool(torch.isfinite(gate.grad).all()),'Nonfinite gate gradients'
            assert float(gate.grad.abs().sum())>0,'Zero gate gradient'
        print(f'  {method}: total={total.item():.6f} ce={ce.item():.6f} '
              f'tail_raw={c["tail"].item():.6f} h0_raw={c["hard_h0"].item():.6f} '
              f'pres_raw={c["preserve_h1"].item():.6f}')
    # Zero-label batch guard must not produce NaNs.
    fake=torch.randn(3,2,requires_grad=True)
    single_y=torch.zeros(3,dtype=torch.long)
    g=torch.ones((3,1,2,2),requires_grad=True)
    single={'input_gray':g,'output_gray':g*.97}
    for meth in METHODS:
        loss,*_=compute_loss(meth,fake,single_y,single)
        assert bool(torch.isfinite(loss))
    print('PASS_SIM_R10_B215_SELFTEST__LOSS_GRADIENTS')

def prepare(args):
    b214=load_b214(args.root)
    b2,src,tr,dev,bank,cc,cache,hp=b214.prepare(args)
    require(bool(cc.get('wvd_cache_sha256')),'Missing cache checksum')
    return b214,b2,src,tr,dev,bank,cc,cache

def gpu_canary(b214,b2,src,tr,dev,cache):
    with h5py.File(cache,'r') as h:
        labs=h['train']['label'][:].astype(np.int64)
        ix=np.r_[np.flatnonzero(labs==0)[:2],np.flatnonzero(labs==1)[:2]]
        require(len(ix)==4,'Canary requires 2 TRAIN H0 and 2 TRAIN H1')
        ww=b2.h5_rows(h['train']['wvd'],ix)
        x=src.map_to_adn_input(torch.from_numpy(ww).to(dev))
        labels=torch.from_numpy(labs[ix]).long().to(dev)
        for method in METHODS:
            model=b214.construct(b2,src,tr,dev,CFG,20261020)
            model.train()
            logits,aux=model(x,return_aux=True)
            total,ce,c,weighted=compute_loss(method,logits,labels,aux)
            require(bool(torch.isfinite(total).item()),f'{method} nonfinite canary loss')
            total.backward()
            require(all(p.grad is None or bool(torch.isfinite(p.grad).all().item()) for p in model.parameters()),
                    f'{method} nonfinite gradients')
            print(f'  {method} CANARY PASS ce={float(ce):.5f} '
                  f'tail={float(weighted["tail"]):.5f} '
                  f'h0={float(weighted["hard_h0"]):.5f} '
                  f'pres={float(weighted["preserve_h1"]):.5f}',flush=True)
            del model,logits,aux,total,ce,c,weighted
            gc.collect()
            if dev.type=='cuda':torch.cuda.empty_cache()
    print('PASS_SIM_R10_B215_GPU_CANARY__TRAIN_ONLY__NO_OPTIMIZER_STEP',flush=True)

def train_one(b214,b2,src,tr,dev,bank,cc,cache,args,seed,method):
    out=args.out_dir/f'trainseed_{seed}'/method
    status=out/'training_contract.json'
    if status.is_file():
        c=json.loads(status.read_text(encoding='utf-8'))
        if c.get('status')==PASS and (out/'best_val_ce.pt').is_file() and c.get('seed')==seed:
            require(c.get('method')==method and c.get('params_loss')==PARAMS, 'Existing checkpoint method/loss drift')
            require(c.get('bank_sha256')==bank['file_sha256'],'Existing bank SHA mismatch')
            require(c.get('wvd_cache_sha256')==cc['wvd_cache_sha256'],'Existing WVD SHA mismatch')
            require(file_sha(out/'best_val_ce.pt')==c.get('best_checkpoint_sha256'),
                    'Existing checkpoint checksum mismatch')
            print(f'[{seed} {method}] COMPLETED; SKIP',flush=True)
            return
    if out.exists():
        require(not any(out.iterdir()),f'Incomplete experiment directory: {out}. Do not overwrite.')
    out.mkdir(parents=True,exist_ok=True)
    model=b214.construct(b2,src,tr,dev,CFG,seed)
    optim=torch.optim.Adam(model.parameters(),lr=args.lr,betas=(.9,.99))
    hist=[];best=float('inf');best_ep=0
    print(f'[{seed} {method}] START max_epoch={args.epochs} min_epoch={args.min_epochs}',flush=True)
    with h5py.File(cache,'r') as h:
        labels=h['train']['label'][:].astype(np.int64)
        require(len(labels)==30000 and len(h['val']['label'])==5000,'Incorrect frozen 30K/5K bank')
        for ep in range(1,args.epochs+1):
            model.train()
            total_sum=ce_sum=tail_sum=h0_sum=pres_sum=0.
            rr0=rr1=0.;nratio=0;n=0
            start=time.perf_counter()
            for ix in b2.indices(labels,ep,args.batch,seed):
                ww=b2.h5_rows(h['train']['wvd'],ix)
                w=torch.from_numpy(ww).to(dev)
                x=src.map_to_adn_input(w)
                yy=torch.from_numpy(labels[ix]).long().to(dev)
                optim.zero_grad(set_to_none=True)
                lg,aux=model(x,return_aux=True)
                total,ce,parts,weighted=compute_loss(method,lg,yy,aux)
                require(bool(torch.isfinite(total).item()),'Nonfinite training loss')
                total.backward()
                norm=torch.nn.utils.clip_grad_norm_(model.parameters(),args.clip_norm)
                require(bool(torch.isfinite(norm).item()),'Nonfinite gradient norm')
                optim.step()
                nn=len(ix);n+=nn
                total_sum+=float(total.detach())*nn
                ce_sum+=float(ce.detach())*nn
                tail_sum+=float(weighted['tail'].detach())*nn
                h0_sum+=float(weighted['hard_h0'].detach())*nn
                pres_sum+=float(weighted['preserve_h1'].detach())*nn
                if np.isfinite(parts['ratio_h0']) and np.isfinite(parts['ratio_h1']):
                    rr0+=parts['ratio_h0'];rr1+=parts['ratio_h1'];nratio+=1
                del ww,w,x,yy,lg,aux,total,ce,parts,weighted,norm
            # Preserve B2.14 choice criterion: minimum VAL cross-entropy, never VAL AUC.
            val=b214.val_predict(src,model,h['val'],dev,args.batch)
            row={'seed':seed,'method':method,'epoch':ep,
                 'train_loss':total_sum/n,'train_ce':ce_sum/n,
                 'train_tail_weighted':tail_sum/n,
                 'train_hard_h0_weighted':h0_sum/n,
                 'train_h1_pres_weighted':pres_sum/n,
                 'train_ratio_h0_batch_avg':rr0/max(1,nratio),
                 'train_ratio_h1_batch_avg':rr1/max(1,nratio),
                 **val,'elapsed_s':time.perf_counter()-start}
            hist.append(row)
            if val['val_ce']<best:
                best=float(val['val_ce']);best_ep=ep
                state={'version':VERSION,'method':method,'seed':seed,'epoch':ep,
                       'state_dict':model.state_dict(),'cfg':CFG,
                       'loss_params':PARAMS,'val_metrics':val,
                       'selected_by':'min VAL CE',
                       'bank_sha256':bank['file_sha256'],
                       'wvd_cache_sha256':cc['wvd_cache_sha256'],
                       'source_sha256':b2.SOURCE_SHA,'trainer_sha256':b2.TRAINER_SHA,
                       'b214_script_sha256':B214_SHA}
                tmp=out/'best_val_ce.pt.tmp'
                torch.save(state,tmp)
                tmp.replace(out/'best_val_ce.pt')
            print(f'  [{seed} {method}] ep={ep:02}/{args.epochs} '
                  f'VAL_CE={val["val_ce"]:.5f} VAL_AUC={val["auc"]:.5f} '
                  f'best_ep={best_ep} time={row["elapsed_s"]:.1f}s',flush=True)
            if args.patience>0 and ep>=args.min_epochs and ep-best_ep>=args.patience:
                print(f'  [{seed} {method}] EARLY STOP ep={ep}, best={best_ep}',flush=True)
                break
    pd.DataFrame(hist).to_csv(out/'train_val_history.csv',index=False)
    cp=out/'best_val_ce.pt'
    try:
        state=torch.load(cp,map_location='cpu',weights_only=True)
    except TypeError:
        state=torch.load(cp,map_location='cpu')
    model.load_state_dict(state['state_dict'],strict=True)
    with h5py.File(cache,'r') as h:
        val=b214.val_predict(src,model,h['val'],dev,args.batch)
    require(abs(val['val_ce']-best)<1e-4,'Checkpoint VAL CE restoration mismatch')
    ct={'version':VERSION,'status':PASS,'seed':seed,'method':method,'cfg':CFG,
        'params_loss':PARAMS,'epochs_executed':ep,'best_epoch':best_ep,
        'best_val_ce':best,'best_val_auc':val['auc'],
        'selected_by':'min VAL CE',
        'lr':args.lr,'batch':args.batch,'patience':args.patience,
        'min_epochs':args.min_epochs,'clip_norm':args.clip_norm,
        'params_model':sum(p.numel() for p in model.parameters()),
        'bank_sha256':bank['file_sha256'],
        'wvd_cache_sha256':cc['wvd_cache_sha256'],
        'source_sha256':b2.SOURCE_SHA,'trainer_sha256':b2.TRAINER_SHA,
        'b214_script_sha256':B214_SHA,
        'best_checkpoint_sha256':file_sha(cp),
        'training_splits':['train','val'],'h0_test_opened':False,'h1_dev_opened':False,
        'scope':'TRAIN/VAL development only; no independent Pfa/Pd'}
    status.write_text(json.dumps(ct,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(f'[{seed} {method}] PASS best_ep={best_ep} VAL_AUC={val["auc"]:.5f}',flush=True)
    del model,optim
    gc.collect()
    if dev.type=='cuda':torch.cuda.empty_cache()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('root','bank-dir','cache-dir','out-dir'):
        p.add_argument('--'+name,type=Path)
    p.add_argument('--mode',choices=['selftest','canary','train'],default='selftest')
    p.add_argument('--seeds',default='20261020:20261022')
    p.add_argument('--methods',default=','.join(METHODS))
    p.add_argument('--device',choices=['auto','cpu','cuda'],default='auto')
    p.add_argument('--batch',type=int,default=32)
    p.add_argument('--epochs',type=int,default=15)
    p.add_argument('--min-epochs',type=int,default=6)
    p.add_argument('--patience',type=int,default=4)
    p.add_argument('--lr',type=float,default=3e-5)
    p.add_argument('--clip-norm',type=float,default=5.0)
    p.add_argument('--skip-cache-sha',action='store_true')
    args=p.parse_args()
    if args.mode=='selftest':selftest();return
    require(all(getattr(args,k) is not None for k in ('root','bank_dir','cache_dir','out_dir')),
            'Missing --root/--bank-dir/--cache-dir/--out-dir')
    require(args.batch>0 and args.batch%2==0 and args.epochs>=args.min_epochs>=1,
            'Invalid batch/epoch settings')
    require(args.patience>=0 and args.lr>0 and math.isfinite(args.lr),'Invalid optimizer args')
    methods=[s.strip() for s in args.methods.split(',')]
    require(methods and len(methods)==len(set(methods)) and set(methods)<=set(METHODS),
            'Unknown or duplicate method')
    b214,b2,src,tr,dev,bank,cc,cache=prepare(args)
    if args.mode=='canary':
        gpu_canary(b214,b2,src,tr,dev,cache)
        return
    for seed in b214.seed_list(args.seeds):
        for method in methods:
            train_one(b214,b2,src,tr,dev,bank,cc,cache,args,seed,method)
    print(PASS,flush=True)

if __name__=='__main__':
    main()
