#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SIM-R10 B2.14 TRAIN/VAL ONLY ablation.

New models per seed: A1_WCSG_BG, A2_TFCG, A3_NO_BG.
Existing B2.10 ADN and A3 checkpoints are NEVER trained or modified.
Same bank, frozen WVD cache, seed, batch order, optimizer and early stopping.
No H0 CAL/AUDIT, DEV H1, OOD or measured data opened.

Design:
  ADN      : original frozen B2.10 checkpoint
  A1       : WCSG+0.1*L_bg, original SimAM (new training)
  A2       : TFCG, no WCSG, CE (new training)
  A3_NO_BG : WCSG+TFCG, CE only (new training)
  A3       : WCSG+TFCG+0.1*L_bg, existing B2.10 checkpoint
"""
from __future__ import annotations
import argparse, gc, importlib.util, json, math, os, random, sys, time, hashlib
from pathlib import Path
import h5py, numpy as np, pandas as pd, torch
import torch.nn.functional as F

VERSION='SIM_R10_B214_ABLATION_TRAIN_VAL_ONLY_V1'
METHODS={
 'A1_WCSG_BG': {'wcsg': True,'tfcg':False,'hts':False},
 'A2_TFCG': {'wcsg': False,'tfcg':True,'hts':False},
 'A3_NO_BG': {'wcsg': True,'tfcg':True,'hts':False},
}
PASS='PASS_SIM_R10_B214_ABLATION_TRAIN_VAL_ONLY__NO_H0_NO_DEV'


def require(x,msg):
 if not bool(x): raise RuntimeError(msg)


def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()


def import_module(p,name):
 spec=importlib.util.spec_from_file_location(name,str(p))
 require(spec is not None and spec.loader is not None,f'Missing import {p}')
 m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m)
 return m


def seed_list(value):
 if ':' in value:
  a,b=map(int,value.split(':'))
  require(b>=a and b-a<=31,'Invalid seed range')
  return list(range(a,b+1))
 out=[int(s.strip()) for s in value.split(',')]
 require(len(out)==len(set(out)) and len(out)<=32,'Duplicated/many seeds')
 return out


def auc(s,y):
 x=np.asarray(s,dtype=np.float64);y=np.asarray(y,dtype=np.int64)
 n=np.sort(x[y==0]);p=x[y==1]
 require(len(n)>0 and len(p)>0,'Need H0 and H1')
 return float(np.mean((np.searchsorted(n,p,'left')+np.searchsorted(n,p,'right'))*.5/len(n)))


@torch.inference_mode()
def val_predict(src,model,group,dev,batch):
 model.eval();scores=[];labs=[];ce=0.;acc=0
 for j in range(0,len(group['label']),batch):
  k=min(j+batch,len(group['label']))
  w=torch.from_numpy(np.ascontiguousarray(group['wvd'][j:k],dtype=np.float32)).to(dev)
  x=src.map_to_adn_input(w)
  y=torch.from_numpy(group['label'][j:k].astype('int64')).to(dev)
  lg=model(x)
  require(lg.shape==(k-j,2) and bool(torch.isfinite(lg).all().item()),'Bad val logits')
  ce+=float(F.cross_entropy(lg,y,reduction='sum').item())
  acc+=int((lg.argmax(1)==y).sum().item())
  scores.append((lg[:,1]-lg[:,0]).detach().cpu().numpy())
  labs.append(y.cpu().numpy())
 s=np.concatenate(scores);y=np.concatenate(labs)
 return {'auc':auc(s,y),'val_ce':ce/len(y),'val_acc':acc/len(y),'n_val':len(y),'n_h0':int((y==0).sum()),'n_h1':int((y==1).sum())}


def prepare(args):
 root=args.root.resolve();bank=args.bank_dir.resolve();cache_dir=args.cache_dir.resolve()
 b2=import_module(root/'r10_sim_stage_b210_a3_adn_earlystop_v1.py','b214_original_b210')
 hp,bc,_=b2.bank_contract(bank,'pilot')
 ctp=cache_dir/b2.CACHE_CT; cfp=cache_dir/b2.CACHE_H5
 require(ctp.is_file() and cfp.is_file(),'Missing frozen WVD cache')
 cc=json.loads(ctp.read_text(encoding='utf-8'))
 require(cc.get('status')==b2.PASS_CACHE and cc.get('bank_sha256')==bc['file_sha256'],
         'WVD cache is from a different bank')
 # 2.2GiB SHA expensive; explicit check lineage by default, allow skip only after audit
 if not args.skip_cache_sha:
  require(sha(cfp)==cc.get('wvd_cache_sha256'),'WVD cache checksum mismatch')
 src=b2.load_exact(root/b2.SOURCE_NAME,b2.SOURCE_SHA,'b214_exact_adn')
 tr=b2.load_exact(root/b2.TRAINER_NAME,b2.TRAINER_SHA,'b214_exact_proposed')
 require(abs(float(tr.LAMBDA_BG)-.1)<1e-8,'Frozen background loss changed')
 dev=torch.device('cuda' if args.device=='auto' and torch.cuda.is_available() else 'cpu' if args.device=='auto' else args.device)
 require(dev.type!='cuda' or torch.cuda.is_available(),'GPU requested, CUDA not available')
 return b2,src,tr,dev,bc,cc,cfp,hp


def construct(b2,src,tr,dev,cfg,seed):
 random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
 if torch.cuda.is_available():torch.cuda.manual_seed_all(seed)
 model=tr.ProposedWrapper(src,dict(cfg)).to(dev)
 tfmods=sum(type(m).__name__=='TFCG' for m in model.modules())
 require(tfmods==(8 if cfg['tfcg'] else 0),f'TFCG replacement count={tfmods}')
 require((model.suppressor is not None)==bool(cfg['wcsg']),'WCSG mismatch')
 return model


def do_canary(b2,src,tr,dev,cache,args):
 with h5py.File(cache,'r') as h:
  w=torch.from_numpy(np.ascontiguousarray(h['train']['wvd'][:4])).to(dev)
  y=torch.from_numpy(h['train']['label'][:4].astype(np.int64)).to(dev)
  for method,cfg in METHODS.items():
   m=construct(b2,src,tr,dev,cfg,20261020);m.train()
   x=src.map_to_adn_input(w)
   lg,aux=m(x,return_aux=True)
   require(lg.shape==(4,2),'Bad logits')
   ce=F.cross_entropy(lg,y)
   if method=='A1_WCSG_BG':
    loss,ce,bg,hts,*_=tr.compose_loss(lg,y,aux,cfg)
    require('gate' in aux and float(bg)>=0,'A1 bg gate invalid')
   elif method=='A3_NO_BG':
    require('gate' in aux,'A3-NOBG missing gate')
    loss=ce
   else:
    require('gate' not in aux,'A2 should not have WCSG gate');loss=ce
   require(bool(torch.isfinite(loss).item()),'Nonfinite loss')
   loss.backward()
   require(all(p.grad is None or bool(torch.isfinite(p.grad).all().item()) for p in m.parameters()),'Bad gradient')
   print(f'  {method} forward/backward PASS params={sum(p.numel() for p in m.parameters()):,}',flush=True)
   del m,lg,aux,ce,loss,x
   gc.collect()
   if dev.type=='cuda':torch.cuda.empty_cache()
 print('PASS_SIM_R10_B214_ABLATION_CANARY__TRAIN_ONLY__NO_OPTIMIZER_STEP',flush=True)


def train_one(b2,src,tr,dev,bank,cache_contract,cache,args,seed,method):
 cfg=METHODS[method];out=args.out_dir/f'trainseed_{seed}'/method
 status=out/'training_contract.json'
 if status.exists():
  c=json.loads(status.read_text())
  if c.get('status')==PASS and (out/'best_val_ce.pt').is_file() and c.get('seed')==seed:
   require(c.get('bank_sha256')==bank['file_sha256'],'Finished checkpoint bank mismatch')
   require(c.get('wvd_cache_sha256')==cache_contract['wvd_cache_sha256'],'Finished cache mismatch')
   require(c.get('cfg')==cfg,'Finished checkpoint config mismatch')
   print(f'[{seed} {method}] COMPLETED; SKIP',flush=True);return
 if out.exists():
  require(not any(out.iterdir()),f'Incomplete output at {out}; DO NOT overwrite. Move it to an archive location after inspection.')
 out.mkdir(parents=True,exist_ok=True)
 model=construct(b2,src,tr,dev,cfg,seed)
 optim=torch.optim.Adam(model.parameters(),lr=args.lr,betas=(.9,.99))
 print(f'[{seed} {method}] START max_epoch={args.epochs} min_epoch={args.min_epochs}',flush=True)
 hist=[];best=float('inf');bestep=0
 with h5py.File(cache,'r') as h:
  labels=h['train']['label'][:].astype(np.int64)
  require(len(labels)==30000 and len(h['val']['label'])==5000,'Expected frozen 30K/5K bank')
  for ep in range(1,args.epochs+1):
   model.train();loss_total=0.;ce_total=0.;bg_total=0.;n=0;t0=time.perf_counter()
   for ix in b2.indices(labels,ep,args.batch,seed):
    ww=b2.h5_rows(h['train']['wvd'],ix)
    w=torch.from_numpy(ww).to(dev);x=src.map_to_adn_input(w)
    yy=torch.from_numpy(labels[ix]).long().to(dev)
    optim.zero_grad(set_to_none=True)
    lg,aux=model(x,return_aux=True)
    ce=F.cross_entropy(lg,yy)
    if method=='A1_WCSG_BG':
     loss,ce,bg,hts,*_=tr.compose_loss(lg,yy,aux,cfg)
     require(bool(torch.isfinite(bg).item()),'Nonfinite bg loss')
    else:
     loss=ce;bg=ce.detach().new_zeros(())
    require(bool(torch.isfinite(loss).item()),'Nonfinite train loss')
    loss.backward()
    norm=torch.nn.utils.clip_grad_norm_(model.parameters(),args.clip_norm)
    require(bool(torch.isfinite(norm).item()),'Bad gradients')
    optim.step()
    nn=len(ix);n+=nn
    loss_total+=float(loss.detach())*nn;ce_total+=float(ce.detach())*nn;bg_total+=float(bg.detach())*nn
    del ww,w,x,yy,lg,aux,loss,ce,bg,norm
   report=val_predict(src,model,h['val'],dev,args.batch)
   row={'seed':seed,'method':method,'epoch':ep,'train_loss':loss_total/n,'train_ce':ce_total/n,
        'train_bg':bg_total/n,**report,'elapsed_s':time.perf_counter()-t0}
   hist.append(row)
   if report['val_ce']<best:
    best=report['val_ce'];bestep=ep
    checkpoint={'version':VERSION,'method':method,'seed':seed,'epoch':ep,
                'state_dict':model.state_dict(),'cfg':cfg,
                'lambda_bg':.1 if method=='A1_WCSG_BG' else 0.,
                'val_metrics':report,'selected_by':'min VAL CE',
                'bank_sha256':bank['file_sha256'],'wvd_cache_sha256':cache_contract['wvd_cache_sha256'],
                'source_sha256':b2.SOURCE_SHA,'trainer_sha256':b2.TRAINER_SHA}
    tmp=out/'best_val_ce.pt.tmp';torch.save(checkpoint,tmp);tmp.replace(out/'best_val_ce.pt')
   print(f'  [{seed} {method}] ep={ep:02}/{args.epochs} '
         f'VAL_CE={report["val_ce"]:.5f} VAL_AUC={report["auc"]:.5f} '
         f'best_ep={bestep} time={row["elapsed_s"]:.1f}s',flush=True)
   if args.patience>0 and ep>=args.min_epochs and ep-bestep>=args.patience:
    print(f'  [{seed} {method}] EARLY STOP ep={ep}, best={bestep}',flush=True);break
 pd.DataFrame(hist).to_csv(out/'train_val_history.csv',index=False)
 # Re-load the frozen best checkpoint before the final AUC report; don't use last-epoch AUC.
 cp=out/'best_val_ce.pt'
 try:s=torch.load(cp,map_location='cpu',weights_only=True)
 except TypeError:s=torch.load(cp,map_location='cpu')
 model.load_state_dict(s['state_dict'],strict=True)
 with h5py.File(cache,'r') as h:report=val_predict(src,model,h['val'],dev,args.batch)
 require(abs(report['val_ce']-best)<1e-4,'Best-checkpoint CE restoration mismatch')
 ct={'version':VERSION,'status':PASS,'seed':seed,'method':method,'cfg':cfg,
     'loss':'CE + 0.1*Lbg' if method=='A1_WCSG_BG' else 'CE only',
     'epochs_executed':ep,'best_epoch':bestep,'best_val_ce':best,'best_val_auc':report['auc'],
     'lr':args.lr,'batch':args.batch,'patience':args.patience,'min_epochs':args.min_epochs,
     'params':sum(p.numel() for p in model.parameters()),
     'bank_sha256':bank['file_sha256'],'wvd_cache_sha256':cache_contract['wvd_cache_sha256'],
     'source_sha256':b2.SOURCE_SHA,'trainer_sha256':b2.TRAINER_SHA,
     'best_checkpoint_sha256':sha(cp),
     'training_splits':['train','val'],'h0_test_opened':False,'h1_dev_opened':False,
     'metric_scope':'VAL-only (development). Not Pfa/Pd.'}
 status.write_text(json.dumps(ct,indent=2)+'\n',encoding='utf-8')
 print(f'[{seed} {method}] PASS best_ep={bestep} VAL_AUC={report["auc"]:.5f}',flush=True)
 del model,optim;gc.collect()
 if dev.type=='cuda':torch.cuda.empty_cache()


def selftest():
 require(seed_list('20261020:20261022')==[20261020,20261021,20261022],'seed parse error')
 rng=np.random.default_rng(1)
 x=rng.normal(size=100);y=np.r_[np.zeros(50,dtype=np.int64),np.ones(50,dtype=np.int64)]
 require(abs(auc(x,y)-auc(x+10,y))<1e-12,'AUC shift error')
 require(METHODS['A3_NO_BG']=={'wcsg':True,'tfcg':True,'hts':False},'Bad no-bg config')
 require(METHODS['A1_WCSG_BG']['tfcg']==False,'A1 wrong')
 print('PASS_B214_SELFTEST',flush=True)


def main():
 p=argparse.ArgumentParser(description=__doc__)
 for name in ('root','bank-dir','cache-dir','out-dir'):
  p.add_argument('--'+name,required=False,type=Path)
 p.add_argument('--mode',choices=['selftest','canary','train'],default='canary')
 p.add_argument('--methods',default='A1_WCSG_BG,A2_TFCG,A3_NO_BG')
 p.add_argument('--seeds',default='20261020:20261022')
 p.add_argument('--device',choices=['auto','cpu','cuda'],default='auto')
 p.add_argument('--batch',type=int,default=32)
 p.add_argument('--epochs',type=int,default=15)
 p.add_argument('--min-epochs',type=int,default=6)
 p.add_argument('--patience',type=int,default=4)
 p.add_argument('--lr',type=float,default=3e-5)
 p.add_argument('--clip-norm',type=float,default=5.)
 p.add_argument('--skip-cache-sha',action='store_true',help='Skip 2.2GiB cache checksum if already frozen/audited')
 args=p.parse_args()
 if args.mode=='selftest':selftest();return
 require(all(getattr(args,k) is not None for k in ('root','bank_dir','cache_dir','out_dir')),'Need root/bank/cache/out paths')
 require(args.batch>0 and args.batch%2==0 and args.epochs>=args.min_epochs>=1,'Bad batch/epochs')
 require(args.patience>=0 and math.isfinite(args.lr) and args.lr>0,'Bad patience/lr')
 methods=[m.strip() for m in args.methods.split(',')]
 require(methods and len(methods)==len(set(methods)) and set(methods)<=set(METHODS),'Bad method list')
 b2,src,tr,dev,bc,cc,cache,hp=prepare(args)
 if args.mode=='canary':do_canary(b2,src,tr,dev,cache,args);return
 for seed in seed_list(args.seeds):
  for method in methods:
   train_one(b2,src,tr,dev,bc,cc,cache,args,seed,method)
 print(PASS,flush=True)

if __name__=='__main__':main()
