#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
R10 2025 — ADN (Qu et al., IEEE Sensors Journal 2023)
SOURCE/PROTOCOL FREEZE + WVD/NETWORK CANARY V1
=================================================

PURPOSE
-------
Freeze a source-faithful ADN network reconstruction and a predeclared MTDSP
adaptation BEFORE any ADN-specific 2022 H0 or held-out 2025 H1 result is seen.

SOURCE PAPER
------------
Q. Qu et al.,
"Enhanced CNN-Based Small Target Detection in Sea Clutter With Controllable
False Alarm," IEEE Sensors Journal, 23(9), 2023, 10193-10205.
DOI: 10.1109/JSEN.2023.3259953

OFFICIAL SOURCE REPOSITORY
--------------------------
https://github.com/quqizhe-whu/ADN

The official repository provides ADN.py and simam_module.py for the network,
but does NOT publish the end-to-end WVD preprocessing / dataset / training
pipeline. Therefore this script distinguishes:

  A) SOURCE-FAITHFUL NETWORK:
     * ResNet18 topology [2,2,2,2]
     * first convolution inside each residual block is an ACB:
         3x3 + 3x1 + 1x3 parallel convolution branches, each with BN
     * standard second 3x3 convolution
     * SimAM immediately after the second convolution and before BN
       (matching the official repository)
     * SimAM e_lambda = 1e-4
     * 224x224x3 input
     * 2 output logits (H0/H1)

  B) PAPER-TEXT-FAITHFUL PRINCIPLES:
     * Wigner-Ville distribution (WVD) input
     * cross-entropy
     * Adam lr=1e-3, beta1=0.9, beta2=0.99
     * batch size 256
     * LR halved every 5 epochs
     * false-alarm control is threshold-based after network scoring

  C) PREDECLARED MTDSP ADAPTATIONS (paper under-specifies these details):
     * observation length: 512 pulses, because physical MTDSP frames contain
       ~537-575 pulses and cross-frame concatenation is prohibited
     * one native 512-pulse observation per cached physical frame
     * complex discrete WVD computed directly from IQ
     * WVD display: abs(real(WVD)) -> 10log10 -> per-sample peak reference
       -> clip [-60,0] dB -> [0,1]
     * resize WVD to 128x128 base representation for cache, then bilinear
       resize to 224x224 and repeat to 3 channels for ADN
     * no arbitrary colormap (paper says RGB but does not specify the mapping)
     * no ImageNet pretraining
     * no data augmentation
     * no weight decay
     * balanced unique TRAIN/VAL sampler to match the already-frozen
       FSST+SimAM discriminative-TF baseline sample budget:
           TRAIN = 10,752 = 5,376 H1 + 5,376 H0
           VAL   =  3,584 = 1,792 H1 + 1,792 H0
       per LOAO fold
     * fixed LOAO frame split already frozen in the MTDSP project
     * 25 epochs is an MTDSP compute adaptation because the ADN paper does not
       state the number of epochs. It is frozen BEFORE ADN H0/H1.
     * final epoch only; INNER_VAL is descriptive, not checkpoint selection

IMPORTANT LOW-FAR NOTE
----------------------
The paper's false-alarm unit selects a threshold from clutter scores in the
training data. That is viable for source Pfa around 1e-3 / 1e-4 with many
clutter samples, but our target is 1e-5 / 1e-6. A 5,376-negative balanced
training subset cannot empirically resolve those tails.

Therefore:
  * source-style train-clutter thresholding will be retained only as a
    descriptive diagnostic if desired;
  * PRIMARY MTDSP low-FAR threshold calibration will later use the same frozen
    two target-absent 2022 VV H0 files as other trainable baselines;
  * strict final decision will remain target_score > threshold.

THIS SCRIPT DOES NOT:
  * train the full 7 folds
  * score the 2022 H0
  * score held-out 2025 H1
  * fit any threshold

It only freezes/audits the scientific contract and runs a small WVD + forward /
backward canary.

EXPECTED RUNTIME
----------------
CANARY only: usually a few minutes or less on RTX 3080 Ti.
Full WVD caching/training is a later GPU stage and is expected to be
hours-scale; its exact estimate should use the throughput printed by this
canary.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import time
import traceback
from pathlib import Path
from typing import Dict, Tuple

import h5py
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F


VERSION = "R10_2025_MTDSP_ADN_SOURCE_PROTOCOL_FREEZE_CANARY_V1"

PAPER = {
    "title": "Enhanced CNN-Based Small Target Detection in Sea Clutter With Controllable False Alarm",
    "journal": "IEEE Sensors Journal",
    "year": 2023,
    "doi": "10.1109/JSEN.2023.3259953",
    "official_repo": "https://github.com/quqizhe-whu/ADN",
}

CACHE_H5 = "r10_lmda_native_train_iq512.h5"
WINDOWS_CSV = "r10_lmda_native_train_windows.csv.gz"
SPLIT_CANDIDATES = (
    "r10_lmda_native_train_loao_frame_split_manifest.csv.gz",
    "r10_deep_baseline_loao_frame_split_manifest.csv.gz",
)

ACQS = (
    "20250106102221_2002_AT_412450000_1",
    "20250106103943_2002_AT_413212990_1",
    "20250107155816_2002_AT_412331720_1",
    "20250117093108_2002_AT_413324410_1",
    "20250117103141_2002_AT_413020540_1",
    "20250117110751_2002_AT_414211000_1",
    "20250312101233_2002_AT_413203610_1",
)
FOLDS = tuple("LOAO__" + x for x in ACQS)

M = 512
RANGE_BINS = 800
EXPECTED_WINDOWS = 2111
EXPECTED_POS = 207573
EXPECTED_NEG = 1481227

SOURCE_INPUT_HW = 224
WVD_CACHE_HW = 128
WVD_CLIP_DB = 60.0
SIMAM_LAMBDA = 1e-4

TRAIN_TOTAL = 10752
TRAIN_PER_CLASS = TRAIN_TOTAL // 2
VAL_TOTAL = 3584
VAL_PER_CLASS = VAL_TOTAL // 2

EPOCHS = 25
BATCH = 256
LR = 1e-3
ADAM_BETAS = (0.9, 0.99)
LR_STEP = 5
LR_GAMMA = 0.5
WEIGHT_DECAY = 0.0
SEED_BASE = 20261005

EXPECTED_PARAMETER_COUNT = 14330946


def req(x, msg):
    if not bool(x):
        raise RuntimeError(msg)


def sha256_file(p: Path, chunk=8 * 1024 * 1024):
    h = hashlib.sha256()
    with p.open("rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def dump_json(obj, p: Path):
    def cv(v):
        if isinstance(v, Path):
            return str(v)
        if isinstance(v, np.integer):
            return int(v)
        if isinstance(v, np.floating):
            return float(v)
        if isinstance(v, np.bool_):
            return bool(v)
        return str(v)
    p.write_text(
        json.dumps(obj, ensure_ascii=False, indent=2, default=cv) + "\n",
        encoding="utf-8"
    )


def choose_device(s):
    if s == "cpu":
        return torch.device("cpu")
    if s == "cuda":
        req(torch.cuda.is_available(), "CUDA requested but unavailable")
        return torch.device("cuda")
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def locate_split(cache_dir: Path):
    for n in SPLIT_CANDIDATES:
        p = cache_dir / n
        if p.is_file():
            return p
    # Also allow code-root sibling if user kept the original manifest there.
    raise RuntimeError(
        "Frozen LOAO split manifest not found. Expected one of:\n  " +
        "\n  ".join(str(cache_dir / x) for x in SPLIT_CANDIDATES)
    )


# -----------------------------------------------------------------------------
# Source-faithful ADN network reconstruction
# -----------------------------------------------------------------------------
class SimAM(nn.Module):
    def __init__(self, channels=None, e_lambda=SIMAM_LAMBDA):
        super().__init__()
        self.e_lambda = float(e_lambda)
        self.activation = nn.Sigmoid()

    @staticmethod
    def get_module_name():
        return "simam"

    def forward(self, x):
        b, c, h, w = x.size()
        n = h * w - 1
        req(n > 0, "SimAM spatial support must exceed 1")
        x_minus_mu_square = (
            x - x.mean(dim=(2, 3), keepdim=True)
        ).pow(2)
        y = (
            x_minus_mu_square
            / (
                4.0
                * (
                    x_minus_mu_square.sum(dim=(2, 3), keepdim=True) / n
                    + self.e_lambda
                )
            )
            + 0.5
        )
        return x * self.activation(y)


class ADNBasicBlock(nn.Module):
    """
    Mirrors the official ADN repository:
      ACB = 3x3 + 3x1 + 1x3, each branch BN, sum, ReLU
      -> 3x3
      -> SimAM
      -> BN
      -> residual add
      -> ReLU
    """
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, downsample=None):
        super().__init__()

        self.conv3 = nn.Conv2d(
            inplanes, planes, kernel_size=3, stride=stride,
            padding=1, bias=False
        )
        self.bn3 = nn.BatchNorm2d(planes)

        self.ver_conv = nn.Conv2d(
            inplanes, planes, kernel_size=(3, 1), stride=stride,
            padding=(1, 0), bias=False
        )
        self.ver_bn = nn.BatchNorm2d(planes)

        self.hor_conv = nn.Conv2d(
            inplanes, planes, kernel_size=(1, 3), stride=stride,
            padding=(0, 1), bias=False
        )
        self.hor_bn = nn.BatchNorm2d(planes)

        self.relu = nn.ReLU(inplace=True)

        self.conv2 = nn.Conv2d(
            planes, planes, kernel_size=3, stride=1,
            padding=1, bias=False
        )
        self.simam = SimAM(planes, e_lambda=SIMAM_LAMBDA)
        self.bn2 = nn.BatchNorm2d(planes)

        self.downsample = downsample

    def forward(self, x):
        identity = x

        out = (
            self.bn3(self.conv3(x))
            + self.ver_bn(self.ver_conv(x))
            + self.hor_bn(self.hor_conv(x))
        )
        out = self.relu(out)

        out = self.conv2(out)
        out = self.simam(out)
        out = self.bn2(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out = out + identity
        out = self.relu(out)
        return out


class ADN18(nn.Module):
    def __init__(self, num_classes=2):
        super().__init__()
        self.inplanes = 64

        self.conv1 = nn.Conv2d(
            3, 64, kernel_size=7, stride=2, padding=3, bias=False
        )
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        self.layer1 = self._make_layer(64, 2, stride=1)
        self.layer2 = self._make_layer(128, 2, stride=2)
        self.layer3 = self._make_layer(256, 2, stride=2)
        self.layer4 = self._make_layer(512, 2, stride=2)

        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(512, num_classes)

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(
                    m.weight, mode="fan_out", nonlinearity="relu"
                )
            elif isinstance(m, (nn.BatchNorm2d, nn.GroupNorm)):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def _make_layer(self, planes, blocks, stride):
        downsample = None
        if stride != 1 or self.inplanes != planes:
            downsample = nn.Sequential(
                nn.Conv2d(
                    self.inplanes, planes, kernel_size=1,
                    stride=stride, bias=False
                ),
                nn.BatchNorm2d(planes),
            )

        layers = [
            ADNBasicBlock(
                self.inplanes, planes, stride=stride,
                downsample=downsample
            )
        ]
        self.inplanes = planes
        for _ in range(1, blocks):
            layers.append(ADNBasicBlock(self.inplanes, planes))
        return nn.Sequential(*layers)

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)

        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        return self.fc(x)


# -----------------------------------------------------------------------------
# Frozen MTDSP WVD reconstruction
# -----------------------------------------------------------------------------
def build_wvd_indices(n: int, dev):
    t = torch.arange(n, device=dev, dtype=torch.long)[:, None]
    k = torch.arange(-n // 2, n // 2, device=dev, dtype=torch.long)[None, :]
    ip = t + k
    im = t - k
    valid = (ip >= 0) & (ip < n) & (im >= 0) & (im < n)
    return ip.clamp(0, n - 1), im.clamp(0, n - 1), valid


@torch.inference_mode()
def wvd_base_map(iq: torch.Tensor, cache_hw=WVD_CACHE_HW):
    """
    iq: complex64 [B,512]
    return float32 [B,cache_hw,cache_hw] in [0,1]

    Discrete reconstruction of paper Eq. (12):
        W(t,f) = Fourier_tau{x(t+tau/2) x*(t-tau/2)}
    On discrete integer samples we use symmetric integer lag k:
        x[t+k] x*[t-k]
    then FFT over the lag axis.

    The paper does not publish its discrete WVD implementation, display
    normalization, or RGB colormap. These are therefore explicit MTDSP
    reconstruction choices and are frozen here before H0/H1.
    """
    req(iq.ndim == 2 and iq.shape[1] == M, f"IQ shape {tuple(iq.shape)}")
    req(torch.is_complex(iq), "WVD input must be complex IQ")

    b, n = iq.shape
    ip, im, valid = build_wvd_indices(n, iq.device)

    xp = iq[:, ip]          # [B,N,N]
    xm = iq[:, im]
    prod = xp * torch.conj(xm)
    prod = prod * valid.unsqueeze(0)

    # Lag zero currently sits at N/2; shift it to index zero before FFT.
    spec = torch.fft.fft(
        torch.fft.ifftshift(prod, dim=-1),
        dim=-1
    )
    spec = torch.fft.fftshift(spec, dim=-1)

    # The ideal WVD is real-valued; finite discrete boundaries may create tiny
    # imaginary residuals. Use magnitude of the real WVD energy pattern.
    a = torch.abs(spec.real).float()

    db = 10.0 * torch.log10(a + 1e-12)
    db = db - db.amax(dim=(1, 2), keepdim=True)
    db = torch.clamp(db, min=-WVD_CLIP_DB, max=0.0)
    z = (db + WVD_CLIP_DB) / WVD_CLIP_DB

    z = F.interpolate(
        z.unsqueeze(1),
        size=(cache_hw, cache_hw),
        mode="bilinear",
        align_corners=False,
    ).squeeze(1)

    req(torch.isfinite(z).all().item(), "Non-finite WVD map")
    return z


def map_to_adn_input(base_map: torch.Tensor):
    req(base_map.ndim == 3, f"base map shape {tuple(base_map.shape)}")
    x = F.interpolate(
        base_map.unsqueeze(1),
        size=(SOURCE_INPUT_HW, SOURCE_INPUT_HW),
        mode="bilinear",
        align_corners=False,
    )
    return x.repeat(1, 3, 1, 1)


# -----------------------------------------------------------------------------
# Split / census audit
# -----------------------------------------------------------------------------
def load_inputs(cache_dir: Path):
    hp = cache_dir / CACHE_H5
    wp = cache_dir / WINDOWS_CSV
    sp = locate_split(cache_dir)
    for p in (hp, wp, sp):
        req(p.is_file(), f"Missing input {p}")

    windows = pd.read_csv(wp)
    split = pd.read_csv(sp)

    needw = {
        "native_window_index", "official_id", "frame_number_1based",
        "positive_range_cells", "negative_range_cells"
    }
    needs = {
        "fold_tag", "official_id", "frame_number_1based", "split_role"
    }
    req(needw.issubset(windows.columns),
        f"windows missing {needw - set(windows.columns)}")
    req(needs.issubset(split.columns),
        f"split missing {needs - set(split.columns)}")

    windows = windows.copy()
    split = split.copy()
    windows["official_id"] = windows["official_id"].astype(str)
    split["official_id"] = split["official_id"].astype(str)
    windows["native_window_index"] = pd.to_numeric(
        windows["native_window_index"], errors="raise"
    ).astype(int)
    windows["frame_number_1based"] = pd.to_numeric(
        windows["frame_number_1based"], errors="raise"
    ).astype(int)
    split["frame_number_1based"] = pd.to_numeric(
        split["frame_number_1based"], errors="raise"
    ).astype(int)

    req(len(windows) == EXPECTED_WINDOWS,
        f"native windows {len(windows)} != {EXPECTED_WINDOWS}")
    req(windows["native_window_index"].is_unique,
        "native_window_index duplicate")
    req(np.array_equal(
        np.sort(windows["native_window_index"].to_numpy(int)),
        np.arange(EXPECTED_WINDOWS)
    ), "native_window_index census drift")

    pos = int(pd.to_numeric(
        windows["positive_range_cells"], errors="raise"
    ).sum())
    neg = int(pd.to_numeric(
        windows["negative_range_cells"], errors="raise"
    ).sum())
    req(pos == EXPECTED_POS, f"positive census {pos} != {EXPECTED_POS}")
    req(neg == EXPECTED_NEG, f"negative census {neg} != {EXPECTED_NEG}")

    return hp, wp, sp, windows, split


def fold_census(windows, split):
    rows = []
    for held, fold in zip(ACQS, FOLDS):
        fs = split[split["fold_tag"].astype(str) == fold][
            ["official_id", "frame_number_1based", "split_role"]
        ].copy()
        req(len(fs) > 0, f"{fold}: no split rows")

        z = windows.merge(
            fs,
            on=["official_id", "frame_number_1based"],
            how="left",
            validate="many_to_one",
        )
        req(z["split_role"].notna().all(),
            f"{fold}: some windows lack split role")

        for role in ("INNER_TRAIN", "INNER_VAL", "OUTER_HELDOUT"):
            q = z[z["split_role"].astype(str) == role]
            pos = int(q["positive_range_cells"].sum())
            neg = int(q["negative_range_cells"].sum())
            rows.append({
                "fold_tag": fold,
                "heldout_acquisition": held,
                "split_role": role,
                "native_windows": int(len(q)),
                "positive_observations": pos,
                "negative_observations": neg,
                "total_observations": pos + neg,
                "enough_for_frozen_balanced_budget": bool(
                    (
                        role == "INNER_TRAIN"
                        and pos >= TRAIN_PER_CLASS and neg >= TRAIN_PER_CLASS
                    )
                    or (
                        role == "INNER_VAL"
                        and pos >= VAL_PER_CLASS and neg >= VAL_PER_CLASS
                    )
                    or role == "OUTER_HELDOUT"
                ),
            })
    return pd.DataFrame(rows)


def choose_canary_examples(h5, windows, split, held: str, seed: int):
    fold = "LOAO__" + held
    fs = split[
        (split["fold_tag"].astype(str) == fold)
        & (split["split_role"].astype(str) == "INNER_TRAIN")
    ][["official_id", "frame_number_1based"]].copy()

    z = windows.merge(
        fs,
        on=["official_id", "frame_number_1based"],
        how="inner",
        validate="many_to_one"
    )
    ids = z["native_window_index"].to_numpy(np.int64)
    rng = np.random.default_rng(seed)
    ids = ids[rng.permutation(len(ids))]

    X = h5["Xiq512"]
    Y = h5["y_range"]
    W = h5["written"]

    seq = []
    lab = []
    meta = []
    need_pos = 8
    need_neg = 8

    for wid in ids:
        req(int(W[int(wid)]) == 1, f"cache row {wid} not written")
        yy = np.asarray(Y[int(wid)], dtype=np.uint8)
        pidx = np.flatnonzero(yy == 1)
        nidx = np.flatnonzero(yy == 0)

        if need_pos > 0 and len(pidx):
            r = int(rng.choice(pidx))
            seq.append(np.asarray(X[int(wid), r, :], dtype=np.complex64))
            lab.append(1)
            meta.append((int(wid), r, 1))
            need_pos -= 1

        if need_neg > 0 and len(nidx):
            r = int(rng.choice(nidx))
            seq.append(np.asarray(X[int(wid), r, :], dtype=np.complex64))
            lab.append(0)
            meta.append((int(wid), r, 0))
            need_neg -= 1

        if need_pos == 0 and need_neg == 0:
            break

    req(need_pos == 0 and need_neg == 0,
        f"could not collect canary samples pos_left={need_pos} neg_left={need_neg}")

    seq = np.ascontiguousarray(np.stack(seq, axis=0), dtype=np.complex64)
    lab = np.asarray(lab, dtype=np.int64)
    req(seq.shape == (16, M), f"canary IQ shape {seq.shape}")
    req(int(lab.sum()) == 8, "canary not balanced")
    return seq, lab, meta


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cache-dir", type=Path, required=True)
    ap.add_argument("--out-dir", type=Path, required=True)
    ap.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto")
    ap.add_argument("--wvd-batch", type=int, default=4)
    args = ap.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    fatal = args.out_dir / "R10_2025_ADN_SOURCE_PROTOCOL_FREEZE_CANARY_V1_FATAL.txt"
    if fatal.exists():
        fatal.unlink()

    t0 = time.perf_counter()
    try:
        hp, wp, sp, windows, split = load_inputs(args.cache_dir)
        census = fold_census(windows, split)

        bad = census[
            census["split_role"].isin(["INNER_TRAIN", "INNER_VAL"])
            & (~census["enough_for_frozen_balanced_budget"])
        ]
        req(len(bad) == 0,
            "At least one fold lacks enough samples for frozen balanced budget:\n"
            + bad.to_string(index=False))

        dev = choose_device(args.device)
        if dev.type == "cuda":
            torch.backends.cudnn.benchmark = True
            if hasattr(torch.backends.cuda.matmul, "allow_tf32"):
                torch.backends.cuda.matmul.allow_tf32 = False
            if hasattr(torch.backends.cudnn, "allow_tf32"):
                torch.backends.cudnn.allow_tf32 = False
        torch.set_float32_matmul_precision("highest")

        model = ADN18(num_classes=2).to(dev)
        nparam = sum(p.numel() for p in model.parameters())
        req(nparam == EXPECTED_PARAMETER_COUNT,
            f"ADN parameter count drift {nparam} != {EXPECTED_PARAMETER_COUNT}")

        print("=" * 124)
        print("R10 2025 — ADN SOURCE/PROTOCOL FREEZE + WVD/NETWORK CANARY V1")
        print("=" * 124)
        print("device =", dev)
        if dev.type == "cuda":
            print("GPU    =", torch.cuda.get_device_name(dev))
        print("parameters =", f"{nparam:,}")
        print("cache =", hp)
        print("split =", sp)
        print("network = source-faithful ADN18 + SimAM")
        print("WVD = frozen MTDSP discrete complex-IQ reconstruction")
        print("future TRAIN/VAL per fold =", TRAIN_TOTAL, "/", VAL_TOTAL)
        print("future epochs =", EPOCHS, "(MTDSP adaptation; source paper omits epoch count)")
        print("\nLOAO census:")
        print(census.to_string(index=False))

        with h5py.File(hp, "r") as h5:
            seq_np, lab_np, sample_meta = choose_canary_examples(
                h5, windows, split, ACQS[0], SEED_BASE
            )

        iq = torch.from_numpy(seq_np).to(dev)

        # WVD throughput and repeatability.
        maps = []
        wt0 = time.perf_counter()
        for a in range(0, len(iq), args.wvd_batch):
            b = min(len(iq), a + args.wvd_batch)
            maps.append(wvd_base_map(iq[a:b]))
        base1 = torch.cat(maps, dim=0)
        wvd_seconds = time.perf_counter() - wt0

        maps = []
        for a in range(0, len(iq), args.wvd_batch):
            b = min(len(iq), a + args.wvd_batch)
            maps.append(wvd_base_map(iq[a:b]))
        base2 = torch.cat(maps, dim=0)

        diff = torch.abs(base1 - base2)
        rep_max = float(diff.max().item())
        rep_mean = float(diff.mean().item())
        req(rep_max <= 1e-6,
            f"WVD repeatability max_abs={rep_max} > 1e-6")

        x = map_to_adn_input(base1)
        req(x.shape == (16, 3, SOURCE_INPUT_HW, SOURCE_INPUT_HW),
            f"ADN input shape {tuple(x.shape)}")

        y = torch.from_numpy(lab_np).to(dev)

        model.train()
        opt = torch.optim.Adam(
            model.parameters(), lr=LR,
            betas=ADAM_BETAS, weight_decay=WEIGHT_DECAY
        )
        opt.zero_grad(set_to_none=True)
        ft0 = time.perf_counter()
        logits = model(x)
        loss = F.cross_entropy(logits, y)
        req(torch.isfinite(loss).item(), "nonfinite canary loss")
        loss.backward()

        grad_sq = 0.0
        for p in model.parameters():
            if p.grad is not None:
                grad_sq += float((p.grad.detach().float() ** 2).sum().item())
        grad_norm = math.sqrt(grad_sq)
        req(np.isfinite(grad_norm) and grad_norm > 0,
            f"invalid gradient norm {grad_norm}")
        opt.step()
        forward_backward_seconds = time.perf_counter() - ft0

        # One inference pass after update only to verify finite output.
        model.eval()
        with torch.inference_mode():
            q = torch.softmax(model(x), dim=1)
        req(torch.isfinite(q).all().item(), "nonfinite post-step probabilities")

        wvd_obs_per_sec = len(iq) / max(wvd_seconds, 1e-12)

        census_p = args.out_dir / "r10_adn_loao_sampler_capacity_census_v1.csv"
        census.to_csv(census_p, index=False)

        contract = {
            "version": VERSION,
            "status": "PASS_ADN_SOURCE_PROTOCOL_FREEZE_CANARY_V1__READY_FOR_BALANCED_LOAO_WVD_CACHE_TRAINING",
            "paper": PAPER,
            "scientific_class": (
                "OFFICIAL_NETWORK_SOURCE_FAITHFUL_PLUS_"
                "PAPER_TEXT_WVD_PLUS_PREDECLARED_MTDSP_ADAPTATION"
            ),
            "network": {
                "architecture": "ADN18",
                "resnet_layers": [2, 2, 2, 2],
                "input": [3, 224, 224],
                "classes": 2,
                "ACB_first_conv_each_block": "3x3 + 3x1 + 1x3 parallel, BN each, sum",
                "second_conv": "3x3",
                "attention": "SimAM after second conv and before BN",
                "simam_lambda": SIMAM_LAMBDA,
                "parameter_count": nparam,
                "pretrained": False,
            },
            "wvd_adapter": {
                "observation_pulses": M,
                "cross_frame": False,
                "input": "complex IQ",
                "discrete_rule": "x[t+k] * conj(x[t-k]), FFT over k",
                "display": "abs(real(WVD)) -> 10log10 -> peak-reference -> clip",
                "clip_db": [-WVD_CLIP_DB, 0.0],
                "cache_hw": [WVD_CACHE_HW, WVD_CACHE_HW],
                "network_hw": [SOURCE_INPUT_HW, SOURCE_INPUT_HW],
                "rgb": "repeat normalized single WVD luminance to 3 channels",
                "arbitrary_colormap": False,
                "source_under_specified": True,
            },
            "frozen_sampler": {
                "split": "existing LOAO frame split",
                "balanced_unique": True,
                "train_total": TRAIN_TOTAL,
                "train_positive": TRAIN_PER_CLASS,
                "train_negative": TRAIN_PER_CLASS,
                "val_total": VAL_TOTAL,
                "val_positive": VAL_PER_CLASS,
                "val_negative": VAL_PER_CLASS,
                "reason": (
                    "match already-frozen FSST+SimAM discriminative-TF baseline "
                    "sample budget for controlled MTDSP comparison"
                ),
            },
            "frozen_training": {
                "epochs": EPOCHS,
                "epochs_source_status": "NOT_STATED_IN_PAPER__MTDSP_ADAPTATION",
                "batch_size": BATCH,
                "optimizer": "Adam",
                "lr": LR,
                "betas": list(ADAM_BETAS),
                "scheduler": "StepLR",
                "lr_step_epochs": LR_STEP,
                "lr_gamma": LR_GAMMA,
                "loss": "unweighted CrossEntropyLoss",
                "weight_decay": WEIGHT_DECAY,
                "checkpoint": "FINAL_EPOCH_ONLY",
                "inner_val": "DESCRIPTIVE_ONLY",
                "augmentation": None,
            },
            "future_low_far": {
                "primary_H0": "two frozen 2022 target-absent VV files",
                "requested_pfa": [1e-5, 1e-6],
                "source_train_clutter_threshold": (
                    "diagnostic only; insufficient finite tail at balanced "
                    "training budget for 1e-5/1e-6"
                ),
                "decision": "target_softmax_score > frozen H0 threshold",
                "H1_threshold_refit": False,
            },
            "canary": {
                "samples": 16,
                "positive": 8,
                "negative": 8,
                "sample_meta": [
                    {"native_window_index": a, "range_bin_0based": b, "y": c}
                    for a, b, c in sample_meta
                ],
                "wvd_batch": args.wvd_batch,
                "wvd_runtime_seconds": wvd_seconds,
                "wvd_observations_per_second": wvd_obs_per_sec,
                "wvd_repeatability_max_abs": rep_max,
                "wvd_repeatability_mean_abs": rep_mean,
                "forward_backward_seconds": forward_backward_seconds,
                "loss": float(loss.detach().cpu().item()),
                "gradient_norm": grad_norm,
                "probability_min": float(q.min().item()),
                "probability_max": float(q.max().item()),
            },
            "inputs": {
                "cache_h5": str(hp),
                "cache_h5_sha256": sha256_file(hp),
                "windows_csv": str(wp),
                "windows_csv_sha256": sha256_file(wp),
                "split_manifest": str(sp),
                "split_manifest_sha256": sha256_file(sp),
            },
            "firewall": {
                "full_training": False,
                "H0_scored": False,
                "H1_scored": False,
                "threshold_fit": False,
            },
            "runtime_minutes": (time.perf_counter() - t0) / 60.0,
        }

        contract_p = args.out_dir / "r10_adn_source_protocol_freeze_canary_contract_v1.json"
        dump_json(contract, contract_p)

        summary_p = args.out_dir / "R10_2025_ADN_SOURCE_PROTOCOL_FREEZE_CANARY_V1_SUMMARY.txt"
        summary = f"""R10 2025 — ADN SOURCE/PROTOCOL FREEZE + WVD/NETWORK CANARY V1
====================================================================================================

STATUS
{contract['status']}

SOURCE
paper = Qu et al., IEEE Sensors Journal 2023
DOI = 10.1109/JSEN.2023.3259953
official repo = https://github.com/quqizhe-whu/ADN

NETWORK
ADN18 = source-faithful
parameters = {nparam:,}
ACB = 3x3 + 3x1 + 1x3
SimAM lambda = {SIMAM_LAMBDA:g}
input = 224x224x3

MTDSP WVD ADAPTER
IQ pulses = {M}
cross-frame = NO
base WVD cache = {WVD_CACHE_HW}x{WVD_CACHE_HW}
network image = 224x224x3
display = abs(real(WVD)) -> 10log10 -> peak reference -> clip [-{WVD_CLIP_DB:g},0] dB
RGB = grayscale repeat x3 (paper colormap is under-specified)

FROZEN SAMPLER / TRAINING
TRAIN = {TRAIN_TOTAL:,} unique balanced observations/fold
VAL   = {VAL_TOTAL:,} unique balanced observations/fold
epochs = {EPOCHS} [MTDSP adaptation; source paper does not state epoch count]
batch = {BATCH}
Adam lr = {LR:g}, beta = {ADAM_BETAS}
StepLR = x{LR_GAMMA} every {LR_STEP} epochs
checkpoint = FINAL EPOCH ONLY
INNER_VAL = descriptive only
H0/H1 = NOT SEEN

CANARY
samples = 16 (8 target + 8 clutter)
WVD runtime = {wvd_seconds:.4f} s
WVD throughput = {wvd_obs_per_sec:.2f} obs/s
WVD repeatability max_abs = {rep_max:.3e}
WVD repeatability mean_abs = {rep_mean:.3e}
forward+backward = {forward_backward_seconds:.4f} s
loss = {float(loss.detach().cpu().item()):.6f}
gradient norm = {grad_norm:.6f}

NEXT
Build deterministic 7-fold balanced plans -> cache WVD maps -> train all 7 final-epoch ADN checkpoints.
This next stage is GPU/disk heavy and should be treated as hours-scale until measured from cache throughput.
"""
        summary_p.write_text(summary, encoding="utf-8")

        print("\n" + summary)
        print("contract =", contract_p)
        print("census   =", census_p)
        print("summary  =", summary_p)
        return 0

    except Exception:
        tb = traceback.format_exc()
        fatal.write_text(tb, encoding="utf-8")
        print("\nFATAL\n" + tb)
        print("fatal log =", fatal)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
