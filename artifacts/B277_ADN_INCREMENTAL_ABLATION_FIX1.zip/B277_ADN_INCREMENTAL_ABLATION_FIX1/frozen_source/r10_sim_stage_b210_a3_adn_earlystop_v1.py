#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SIM-R10 Stage B2: original-source A3/ADN simulation training, not IQ-direct.

Input flow: IQ512 -> frozen source wvd_base_map (cached float32) ->
             frozen source map_to_adn_input -> original A3/ADN.
A3 loss is trainer.compose_loss with cfg wcsg=1,tfcg=1,hts=0;
ADN uses cross entropy. No pretrained weights or test/cal/audit scores.

Stages: cache | train | all. B2.10 only adds min-VAL-CE early stopping; frozen networks and A3 loss unchanged.
Checkpoint selection: smallest validation CE (TRAIN/VAL only).
All methods see identical balanced training index order and shared WVD cache.

This is a SIM development trainer and NOT the authors' published training
schedule. Never present B2 checkpoints as the old real-data LOAO checkpoints.
"""
from __future__ import annotations
import argparse
import gc
import hashlib
import importlib.util
import json
import math
import os
import random
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import h5py
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

VERSION = 'SIM_R10_STAGE_B210_A3_ADN_EARLYSTOP_TRAIN_V1'
PASS_CACHE = 'PASS_SIM_R10_STAGE_B2_WVD_CACHE__TRAIN_VAL_ONLY__FLOAT32__NO_H0_NO_H1TEST'
PASS_TRAIN = 'PASS_SIM_R10_STAGE_B2_A3_ADN_TRAIN__ORIGINAL_ARCH_AND_A3_LOSS__VAL_ONLY_SELECTION'
SOURCE_NAME = 'r10_2025_mtdsp_adn_source_protocol_freeze_canary_v1.py'
SOURCE_SHA = '0372818d8765520716407f97a0ec69df5a3bf42fb73d93a35739faa5bb71175e'
TRAINER_NAME = 'r10_2025_mtdsp_adn_proposed_wcsg_tfcg_hts_train_v1_FIX2.py'
TRAINER_SHA = '7354c3d64ca7e6f4745097f117afbf1f267091a97c79f0d5c99d081c9e2ffcc5'
CFG_A3 = {'wcsg': True, 'tfcg': True, 'hts': False}
PARAMS = {'A3': 14533299, 'ADN': 14330946}
H5_NAME = 'sim_r10_iq512_v1.h5'
CT_NAME = 'sim_r10_iq512_v1_contract.json'
CACHE_H5 = 'sim_r10_stage_b2_wvd_float32_train_val_v1.h5'
CACHE_CT = 'sim_r10_stage_b2_wvd_cache_contract_v1.json'


def req(cond, msg):
    if not bool(cond):
        raise RuntimeError(msg)


def sha256(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):
            h.update(b)
    return h.hexdigest()


def load_exact(p, expected, name):
    p = Path(p)
    req(p.is_file(), f'Missing frozen model source: {p}')
    actual = sha256(p)
    req(actual == expected, f'Frozen {p.name} SHA mismatch {actual} != {expected}')
    spec = importlib.util.spec_from_file_location(name, str(p))
    req(spec and spec.loader, f'Cannot import {p}')
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def bank_contract(bank_dir, preset):
    bp = bank_dir / CT_NAME
    hp = bank_dir / H5_NAME
    ap = bank_dir / 'sim_r10_iq512_audit_v1.json'
    req(bp.is_file() and hp.is_file() and ap.is_file(), f'Missing audited bank: {bank_dir}')
    b = json.loads(bp.read_text(encoding='utf-8'))
    a = json.loads(ap.read_text(encoding='utf-8'))
    req(b.get('version') == 'SIM_R10_IQ512_GENERATOR_V1', 'Bank generator version drift')
    req(b.get('preset') == preset, f'Bank preset must be {preset}, got {b.get("preset")}')
    req(int(b.get('n_pulses',-1)) == 512, 'Bank IQ length mismatch')
    req(str(b.get('status','')).startswith('PASS_SIM_R10_IQ512_BUILDER_V1__'), 'Bank builder not PASS')
    req(str(a.get('status','')).startswith('PASS_SIM_R10_IQ512_AUDIT_V1__'), 'Bank audit not PASS')
    req(a.get('bank_sha256') == b.get('file_sha256'), 'Audit references different bank')
    if not getattr(bank_contract, '_skip_large_sha', False):
        req(sha256(hp)==b.get('file_sha256'), 'Bank HDF5 SHA mismatch')
    return hp,b,a


def indices(y, epoch, batch, seed):
    """Balanced, no-replacement epoch sampler; same RNG across A3 and ADN."""
    y = np.asarray(y, dtype=np.int64)
    z = np.flatnonzero(y==0)
    o = np.flatnonzero(y==1)
    req(len(z)==len(o), 'Unbalanced train split')
    rng = np.random.default_rng(seed + 997*epoch)
    z=rng.permutation(z)
    o=rng.permutation(o)
    b2=batch//2
    for a in range(0,len(z),b2):
        zz=z[a:a+b2]
        oo=o[a:a+b2]
        idx=np.concatenate([zz,oo])
        yield rng.permutation(idx)


def h5_rows(ds, ix):
    ix=np.asarray(ix,np.int64)
    req(ix.size>0, 'Empty WVD fetch')
    req(len(np.unique(ix))==len(ix),'Repeated row in WVD batch')
    order=np.argsort(ix)
    return np.ascontiguousarray(ds[ix[order]][np.argsort(order)],dtype=np.float32)


def cache_source(src, hp, out_dir, args, bank):
    target=out_dir/CACHE_H5
    contract_path=out_dir/CACHE_CT
    req(not target.exists() and not contract_path.exists(),
        'WVD cache already exists; use --stage train, never overwrite an existing cache')
    temp=out_dir/('.'+CACHE_H5+'.tmp')
    req(not temp.exists(),'Incomplete cache temp already exists; inspect/delete manually if needed')
    print('[1/3] Cache WVD for TRAIN/VAL only, exact float32',flush=True)
    print('  H0 calibration and H1 dev/test not opened',flush=True)
    device=args.device_resolved
    with h5py.File(hp,'r') as h, h5py.File(temp,'w',libver='earliest') as wc:
        for split in ('train','val'):
            g=h[split]
            n=int(g['iq'].shape[0])
            req(g['iq'].shape==(n,512),f'{split} IQ shape incorrect')
            yy=g['label'][:]
            req(len(yy)==n and int(yy.sum())==n//2, f'{split} imbalance')
            wg=wc.create_group(split)
            wg.create_dataset('label', data=yy.astype(np.uint8))
            dest=None
            for start in range(0,n,args.wvd_batch):
                stop=min(n,start+args.wvd_batch)
                iq=np.ascontiguousarray(g['iq'][start:stop],dtype=np.complex64)
                with torch.no_grad():
                    x=torch.from_numpy(iq).to(device)
                    z=src.wvd_base_map(x)
                    req(torch.is_tensor(z) and z.shape[0]==len(iq), 'WVD output mismatch')
                    v=np.ascontiguousarray(z.detach().cpu().numpy().astype(np.float32))
                req(np.isfinite(v).all(),f'{split} nonfinite WVD at {start}')
                if dest is None:
                    shp=v.shape[1:]
                    req(len(shp) in (2,3),f'Unexpected WVD dims {shp}')
                    dest=wg.create_dataset('wvd',shape=(n,*shp),dtype='float32',
                                           chunks=(min(16,n),*shp),compression='lzf')
                    # Ensure cached output can be mapped by the exact frozen source.
                    with torch.no_grad():
                        inp=src.map_to_adn_input(torch.from_numpy(v).to(device))
                        req(inp.ndim==4 and inp.shape[0]==len(v),
                            f'{split} network mapping shape bad: {tuple(inp.shape)}')
                    print(f'  {split}: WVD base shape={shp}, ADN input shape={tuple(inp.shape[1:])}',flush=True)
                dest[start:stop]=v
                if stop==n or stop % 5000 < args.wvd_batch:
                    print(f'  {split}: {stop}/{n}',flush=True)
            wg.attrs['wvd_base_dtype']='float32'
        wc.flush()
    temp.rename(target)
    data=dict(version=VERSION,status=PASS_CACHE,scientific_role='SIM development cache',
              source_sha256=SOURCE_SHA,trainer_sha256=TRAINER_SHA,
              bank_sha256=bank['file_sha256'],bank_contract_sha256=sha256(args.bank_dir/CT_NAME),
              wvd_cache_sha256=sha256(target),cache_file=target.name,
              splits=['train','val'],h0_opened=False,dev_h1_opened=False,
              preprocessing='Frozen src.wvd_base_map, float32 WVD base cache, then src.map_to_adn_input')
    contract_path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    print(PASS_CACHE,flush=True)
    print('  cache =',target,flush=True)
    return target


def instantiate(src,trainer,method,device,seed):
    # Both start from identical RNG state for overlapping ADN layers.
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(seed)
    if method=='A3':
        req(hasattr(trainer,'ProposedWrapper') and hasattr(trainer,'compose_loss'),
            'Frozen original A3 interface absent')
        req(abs(float(trainer.LAMBDA_BG)-0.1)<1e-12,'A3 original L_bg weight drift')
        model=trainer.ProposedWrapper(src,dict(CFG_A3))
    else:
        model=src.ADN18(num_classes=2)
    count=sum(p.numel() for p in model.parameters())
    req(count==PARAMS[method],f'{method} parameters drift: {count}')
    return model.to(device)


def logits_score(model, x):
    l=model(x)
    req(l.ndim==2 and l.shape[1]==2,'Unexpected two-class logits')
    return l


@torch.inference_mode()
def evaluate(src,model,g,batch,device):
    model.eval()
    n=int(g['label'].shape[0]);hits=0;n0=0;n1=0;h0hit=0;h1hit=0;sum_ce=0.0
    for start in range(0,n,batch):
        end=min(n,start+batch)
        x=torch.from_numpy(np.ascontiguousarray(g['wvd'][start:end],dtype=np.float32)).to(device)
        y=torch.from_numpy(g['label'][start:end].astype(np.int64)).to(device)
        z=src.map_to_adn_input(x)
        logits=logits_score(model,z)
        req(torch.isfinite(logits).all().item(),'Nonfinite val logits')
        ce=F.cross_entropy(logits,y,reduction='sum')
        pred=logits.argmax(1)
        h0=(y==0);h1=(y==1)
        n0+=int(h0.sum().item());n1+=int(h1.sum().item())
        h0hit+=int(((pred==0)&h0).sum().item());h1hit+=int(((pred==1)&h1).sum().item())
        hits+=int((pred==y).sum().item())
        sum_ce+=float(ce.cpu())
    return dict(val_ce=sum_ce/n,val_accuracy=hits/n,
                val_acc_h0=h0hit/max(n0,1),val_acc_h1=h1hit/max(n1,1),n=n)


def train_model(src,trainer,method,h,output_dir,args,bank,cache_contract):
    dev=args.device_resolved
    model=instantiate(src,trainer,method,dev,args.seed)
    opt=torch.optim.Adam(model.parameters(),lr=args.lr,betas=(.9,.99))
    # No H0 threshold setting or SCNR test used in selecting model.
    ytrain=h['train']['label'][:].astype(np.int64)
    req(len(ytrain)==bank['counts']['train'],'TRAIN count drift')
    assert np.all((ytrain==0)|(ytrain==1))
    mdir=output_dir/method
    mdir.mkdir(exist_ok=False,parents=True)
    ckbest=mdir/'best_val_ce.pt';cklast=mdir/'last_epoch.pt'
    history=[];best=float('inf');best_epoch=-1
    print(f'[{method}] START epochs={args.epochs}, train={len(ytrain)}, val={len(h["val"]["label"])}',flush=True)
    for ep in range(1,args.epochs+1):
        model.train();total=0;ce_total=0;bg_total=0;n=0
        t0=time.perf_counter()
        for ix in indices(ytrain,ep,args.batch,args.seed):
            ww=h5_rows(h['train']['wvd'],ix)
            inp=torch.from_numpy(ww).to(dev)
            x=src.map_to_adn_input(inp)
            target=torch.from_numpy(ytrain[ix]).long().to(dev)
            opt.zero_grad(set_to_none=True)
            if method=='A3':
                logits, aux = model(x,return_aux=True)
                vals=trainer.compose_loss(logits,target,aux,dict(CFG_A3))
                req(len(vals)>=4,'Original loss return changed')
                loss,ce,bg,hts=vals[:4]
                req(torch.isfinite(bg).item() and abs(float(hts.detach().cpu()))<1e-10,
                    'A3 background/HTS loss failed')
            else:
                logits=model(x)
                ce=F.cross_entropy(logits,target)
                loss=ce
                bg=ce.new_zeros(())
            req(torch.isfinite(loss).item(),'Nonfinite train loss')
            loss.backward()
            req(all(torch.isfinite(p.grad).all().item() for p in model.parameters()
                    if p.grad is not None),'Nonfinite gradient')
            grad_norm=torch.nn.utils.clip_grad_norm_(model.parameters(),max_norm=args.clip_norm)
            req(torch.isfinite(grad_norm).item(),'Invalid gradient norm')
            opt.step()
            bs=len(ix);n+=bs
            total+=float(loss.detach().cpu())*bs
            ce_total+=float(ce.detach().cpu())*bs
            bg_total+=float(bg.detach().cpu())*bs
            del inp,x,target,loss,ce,bg,logits
        va=evaluate(src,model,h['val'],args.batch,dev)
        row=dict(method=method,epoch=ep,train_total=total/n,train_ce=ce_total/n,
                 train_bg=bg_total/n,**va,elapsed_s=time.perf_counter()-t0)
        history.append(row)
        # Validation CE only, deterministic earliest-epoch tie rule.
        if va['val_ce']<best:
            best=float(va['val_ce']);best_epoch=ep
            torch.save(dict(version=VERSION,method=method,state_dict=model.state_dict(),
                            seed=args.seed,selected_by='min VAL cross entropy, earliest tie',
                            epoch=ep,val_metrics=va,source_sha256=SOURCE_SHA,
                            trainer_sha256=TRAINER_SHA,bank_sha256=bank['file_sha256'],
                            wvd_cache_sha256=cache_contract['wvd_cache_sha256'],
                            cfg=CFG_A3 if method=='A3' else None),ckbest)
        print(f'  {method} ep={ep:02d}/{args.epochs} '
              f'train={row["train_total"]:.4f} valCE={va["val_ce"]:.4f} '
              f'valAcc={va["val_accuracy"]:.3f} '
              f'H0Acc={va["val_acc_h0"]:.3f} H1Acc={va["val_acc_h1"]:.3f} '
              f'best={best_epoch:02d} time={row["elapsed_s"]:.1f}s',flush=True)
        # Only validation CE is used; A3 and ADN apply identical stopping policy.
        # Minimum epochs permits a short recovery interval; best checkpoint is
        # selected across ALL evaluated epochs, regardless of when we stop.
        if (args.early_stop_patience > 0 and ep >= args.min_epochs
                and ep - best_epoch >= args.early_stop_patience):
            print(f'  {method}: EARLY STOP at epoch={ep} '
                  f'(best={best_epoch}, patience={args.early_stop_patience})',flush=True)
            break
    torch.save(dict(version=VERSION,method=method,state_dict=model.state_dict(),
                    epoch=ep,seed=args.seed,selection='last executed epoch',
                    bank_sha256=bank['file_sha256'],wvd_cache_sha256=cache_contract['wvd_cache_sha256']),cklast)
    pd.DataFrame(history).to_csv(mdir/'train_val_history.csv',index=False)
    summary=dict(version=VERSION,status=PASS_TRAIN,method=method,
                 architecture='Original A3 WCSG+TFCG' if method=='A3' else 'Original ADN18',
                 preprocessing='Frozen IQ512 -> WVD float32 cache -> ADN image mapper',
                 loss='original CE + 0.1 L_bg' if method=='A3' else 'CE',
                 checkpoint_selected_by='VAL CE only, no H0 calibration or H1 development',
                 best_epoch=best_epoch,best_val_ce=best,epochs=args.epochs,
                 epochs_executed=ep,early_stop_patience=args.early_stop_patience,
                 min_epochs=args.min_epochs,
                 batch=args.batch,
                 lr=args.lr,clip_norm=args.clip_norm,seed=args.seed,model_params=PARAMS[method],
                 bank_sha256=bank['file_sha256'],wvd_cache_sha256=cache_contract['wvd_cache_sha256'],
                 source_sha256=SOURCE_SHA,trainer_sha256=TRAINER_SHA,
                 h0_accessed=False,dev_h1_accessed=False,ood_test_accessed=False,
                 figures_emitted=False,pd_pfa_claim=False,
                 outputs={'best':{'name':ckbest.name,'sha256':sha256(ckbest)},
                          'last':{'name':cklast.name,'sha256':sha256(cklast)}})
    (mdir/'training_contract.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(f'  {method}: PASS best epoch={best_epoch}; best VAL CE={best:.5f}',flush=True)
    del opt,model
    gc.collect()
    if dev.type=='cuda':torch.cuda.empty_cache()
    return summary


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=Path,required=True)
    ap.add_argument('--bank-dir',type=Path,required=True)
    ap.add_argument('--out-dir',type=Path,required=True)
    ap.add_argument('--stage',choices=['cache','train','all'],default='all')
    ap.add_argument('--preset',choices=['pilot','full'],required=True)
    ap.add_argument('--methods',choices=['A3','ADN','both'],default='both')
    ap.add_argument('--device',choices=['cuda','cpu','auto'],default='auto')
    ap.add_argument('--wvd-batch',type=int,default=64)
    ap.add_argument('--batch',type=int,default=32)
    ap.add_argument('--epochs',type=int,default=15)
    ap.add_argument('--early-stop-patience',type=int,default=4,
                    help='Stop after N consecutive epochs without a strictly lower VAL CE; 0 disables')
    ap.add_argument('--min-epochs',type=int,default=6,
                    help='Train at least this many epochs before applying patience')
    ap.add_argument('--lr',type=float,default=1e-4)
    ap.add_argument('--clip-norm',type=float,default=5.0)
    ap.add_argument('--seed',type=int,default=20261008)
    ap.add_argument('--skip-bank-sha',action='store_true',help='Only if separately audited full bank; still validates contracts')
    args=ap.parse_args()
    for name in ('root','bank_dir','out_dir'):
        setattr(args,name,getattr(args,name).resolve())
    req(args.root.is_dir() and args.bank_dir.is_dir(),'root/bank directory missing')
    req(args.batch>0 and args.batch%2==0 and args.wvd_batch>0,'Batches must be valid')
    req(args.epochs>=1 and math.isfinite(args.lr) and args.lr>0,'Epochs/LR invalid')
    req(1<=args.min_epochs<=args.epochs and args.early_stop_patience>=0,
        'Early stopping parameters invalid')
    req(args.clip_norm>0 and np.isfinite(args.clip_norm),'Clip norm invalid')
    dev=torch.device('cuda' if args.device=='auto' and torch.cuda.is_available() else
                     'cpu' if args.device=='auto' else args.device)
    req(dev.type!='cuda' or torch.cuda.is_available(),'CUDA requested but unavailable')
    args.device_resolved=dev
    bank_contract._skip_large_sha=args.skip_bank_sha
    hp,bank,audit=bank_contract(args.bank_dir,args.preset)
    args.out_dir.mkdir(parents=True,exist_ok=True)
    src=load_exact(args.root/SOURCE_NAME,SOURCE_SHA,'simr10_b2_src')
    trainer=load_exact(args.root/TRAINER_NAME,TRAINER_SHA,'simr10_b2_trainer')
    req(all(hasattr(src,z) for z in ('wvd_base_map','map_to_adn_input','ADN18')),
        'Missing original ADN interfaces')
    print('SIM-R10 Stage B2 — A3/ADN SIM TRAINING',flush=True)
    print(f'  stage={args.stage} preset={args.preset} methods={args.methods} device={dev}',flush=True)
    print('  Raw IQ stored = YES | Raw IQ fed to A3/ADN CNN directly = NO',flush=True)
    print('  source = IQ512 -> frozen WVD -> frozen 224x224 ADN mapper -> network',flush=True)
    print('  Only TRAIN and VAL opened, no H0 CAL/AUDIT or DEV H1/OOD',flush=True)
    print('  No measured 2025 targets or FINAL data, no pretrained checkpoints',flush=True)
    if args.stage in ('cache','all'):
        cache_source(src,hp,args.out_dir,args,bank)
    if args.stage in ('train','all'):
        ccpath=args.out_dir/CACHE_CT;chpath=args.out_dir/CACHE_H5
        req(ccpath.is_file() and chpath.is_file(),'Missing cached WVD; run --stage cache first')
        cc=json.loads(ccpath.read_text(encoding='utf-8'))
        req(cc['status']==PASS_CACHE and cc['bank_sha256']==bank['file_sha256'],
            'Cache contract mismatch')
        req(sha256(chpath)==cc['wvd_cache_sha256'],'Cached WVD file SHA mismatch')
        methods=['A3','ADN'] if args.methods=='both' else [args.methods]
        with h5py.File(chpath,'r') as h:
            for m in methods:
                req(not (args.out_dir/m).exists(),
                    f'{m} output already exists; do not overwrite checkpoints')
                train_model(src,trainer,m,h,args.out_dir,args,bank,cc)
        print('\n'+PASS_TRAIN,flush=True)
        print('  Checkpoints are SIM-trained, NOT measured LOAO; training is not Pfa/Pd audit.',flush=True)


if __name__=='__main__':
    main()
