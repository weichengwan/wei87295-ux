"""Strict B274 source/checkpoint and paired score-cache verification."""
import csv
from pathlib import Path
import numpy as np
import torch
from b271_data import digest_file,fingerprint,load_checkpoint,need,read_json
from b271_score import SCENE_KEYS
from b273_statistics import metrics_for
from b274_model import SingleBranch
from b274_train import PASS as SOURCE_PASS


def metadata(run_dir,context,device,selection,original=None):
    run_dir=Path(run_dir).resolve();run=read_json(run_dir/'run_manifest.json');cfg=run['run_config']
    contract=read_json(run_dir/'training_contract.json');checkpoint=run_dir/'best.pt'
    need(run['run_fingerprint']==fingerprint(cfg)==contract['run_fingerprint'] and contract['status']==SOURCE_PASS,'B274 training identity differs')
    need(cfg['code_sha256']==read_json(Path(__file__).parent/'b274_release_sources.json'),'B274 source differs from verified release')
    need(cfg['bank_sha256']==context['bc']['file_sha256'] and Path(run['bank_dir']).resolve()==context['bank_dir'] and cfg['selected_rows']==selection,'B274 bank/TRAIN/VAL selection differs')
    need(digest_file(checkpoint)==contract['checkpoint_sha256'],'B274 checkpoint changed')
    folder=run_dir/'pd_scr_medium';p=read_json(folder/'protocol_frozen.json');progress=read_json(folder/'progress.json')
    need(p['version']=='B274_SINGLE_SPWVD_RESNET18_SCORE_V1' and p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==progress['fingerprint'],'B274 score protocol differs')
    need(p['nominal_pfas']==[1e-4] and p['h0_cal_n']==500000 and p['h0_audit_n']==200000 and p['h1_scenes_n']==1024 and p['scr_grid_db']==list(range(-24,13)),'Require completed medium B274')
    need(progress['completed']==dict(h0_cal=500000,h0_audit=200000,h1=37) and p['labels'][0]=='SINGLE','B274 scoring incomplete')
    need(p['checkpoint']['sha256']==contract['checkpoint_sha256'] and p['training_run_fingerprint']==run['run_fingerprint'] and p['code_sha256']==cfg['code_sha256'],'B274 scoring/training source mismatch')
    need(p['batch']==32 and p['device']==device.type and p['tf32'] is False and p['score_definition']=='float64(float32 logit1 - float32 logit0)','B274 numerical settings differ')
    if original is not None:
        scene={k:original[k] for k in SCENE_KEYS};scene.update(h0_cal_n=500000,h0_audit_n=200000)
        need(all(p[k]==v for k,v in scene.items()) and p['scene_fingerprint']==fingerprint(scene),'B274 paired scenes differ')
    for f in ('h0_cal_scores.npy','h0_audit_scores.npy','dev_h1_scores.npy','b274_curves.csv','b274_metrics.csv'):need((folder/f).is_file(),'Missing B274 source: '+str(folder/f))
    return dict(run_dir=run_dir,folder=folder,config=cfg,contract=contract,checkpoint=checkpoint,p=p,
                protocol_sha256=digest_file(folder/'protocol_frozen.json'))


def teacher(info,device):
    state=load_checkpoint(info['checkpoint']);cfg=info['config'];contract=info['contract']
    need(state['run_config']==cfg and state['run_fingerprint']==contract['run_fingerprint'] and state['epoch']==contract['best_epoch'],'B274 checkpoint internal identity differs')
    model=SingleBranch(cfg['backend'],cfg['scale']);model.load_state_dict(state['state_dict'],strict=True)
    model.to(device).eval()
    # Exact old script selection alone does not establish its TF axis/grid.
    # Confirm the source actually uses the estimator supported by this ARS.
    import legacy_tf_recovered
    with torch.inference_mode():
        t=torch.arange(512,device=device,dtype=torch.float32)
        probe=torch.stack((torch.exp(2j*torch.pi*.125*t),
            (1+.3*torch.sin(t/31))*torch.exp(2j*torch.pi*(.037*t+.00031*t.square())))).to(torch.complex64)
        actual=model.frontend.images(probe);expected=legacy_tf_recovered.tf_image(probe,cfg['scale'])
        need(torch.allclose(actual,expected,atol=5e-5,rtol=2e-5),
             'B274 frontend uses a different TF grid/normalization; preserve it and inspect before applying the current phase alignment')
    return model


def arrays(info):
    folder=info['folder'];p=info['p'];n=len(p['labels']);cache={};hashes={}
    for key,name,shape in [('h0_cal','h0_cal_scores.npy',(500000,n)),('h0_audit','h0_audit_scores.npy',(200000,n)),('h1','dev_h1_scores.npy',(37,1024,n))]:
        x=np.load(folder/name,mmap_mode='r',allow_pickle=False)
        need(x.shape==shape and x.dtype==np.dtype('float64') and np.isfinite(x).all(),'Malformed B274 score array')
        cache[key]=x;hashes[name]=digest_file(folder/name)
    with (folder/'b274_metrics.csv').open(encoding='utf-8-sig',newline='') as f:old=list(csv.DictReader(f))
    with (folder/'b274_curves.csv').open(encoding='utf-8-sig',newline='') as f:curves=list(csv.DictReader(f))
    for j,label in enumerate(p['labels']):
        name=p['names'][label];c,m=metrics_for(name,cache['h0_cal'][:,j],cache['h0_audit'][:,j],cache['h1'][:,:,j],p)
        previous=[v for v in old if v['method']==name and float(v['nominal_pfa'])==1e-4]
        need(len(previous)==1 and float(previous[0]['threshold'])==m[0]['threshold'] and int(previous[0]['audit_false_alarms'])==m[0]['audit_false_alarms'],'B274 own-threshold/H0 count replay differs')
        for row in c:
            match=[v for v in curves if v['method']==name and float(v['nominal_pfa'])==1e-4 and float(v['scr_db'])==row['scr_db']]
            need(len(match)==1 and int(match[0]['hits'])==row['hits'] and int(match[0]['n_h1'])==row['n_h1'],'B274 paired H1 hits differ')
    return cache,dict(protocol_sha256=info['protocol_sha256'],array_sha256=hashes,
        own_threshold_false_alarms_all37_hits_replayed=True,additional_baseline_GPU_forwards=0)
