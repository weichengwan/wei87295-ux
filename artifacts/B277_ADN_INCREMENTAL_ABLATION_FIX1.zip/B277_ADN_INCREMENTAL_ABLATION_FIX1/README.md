# B277 FIX1：ADN → SPWVD ADN/WCSG/TFCG 消融补齐

只训练两个缺失中间组。原始ADN和已经完成的B276完整组读取旧评分，按同一medium评价协议重算表格；不重复训练它们，不重写旧目录。

|表中行|输入|WCSG|注意力|本轮操作|
|---|---|---|---|---|
|A0 原始ADN历史参考|WVD|无|SimAM|读取B222原始分数，重新按500k CAL估计阈值|
|A1|SPWVD|无|原始SimAM|新训练|
|A2|SPWVD|居中WCSG|原始SimAM|新训练|
|A3 B276完整组|SPWVD|居中WCSG|TFCG替换SimAM|只读复用B276分数|

A1/A2均保留ADN的8个ACB和8个真实SimAM，没有把SimAM静默绕过；不含TFCG、不含ARS。A3的TFCG是替换SimAM，不是叠加在其上。


## 本次修复

V1 的 `references()` 调用 B274 来源检查函数时，误把旧协议传给 device、把 device 传给 selection，因此即使数据一致也报 `B274 bank/TRAIN/VAL selection differs`。FIX1 使用具名参数传递 device、selection、original；实际数据行、银行哈希、模型来源和预算检查仍全部保留，不通过删除校验来放行。

该日志出现在预检阶段，尚未开始两个新增组的训练。本包使用独立 FIX1 目录，不覆盖 B274、B276 或旧 B277；不用重新训练已经完成的 B276 完整模型。

新增入口回归测试先在未修复代码上复现了用户的同一错误，再通过真实来源检查链验证修复。另用少量生成 IQ 样本执行真实网络训练、权重重载和预测；不把这些功能测试当成真实海杂波指标。

## TFCG 的独立对照已经包含

- A1→A2：固定 SPWVD、ADN 和原始 SimAM，检查居中 WCSG 的增量。
- A2→A3：固定 SPWVD、ADN 和居中 WCSG，用 TFCG 替换 SimAM，检查注意力替换的增量。
- A1→A3：检查 WCSG 与 TFCG 作为整体改进的增量。

本轮只新增训练 A1、A2 两组；A3 读取已经完成的 B276 分数。因此不需要另加一组内容重复的“无 TFCG”。这里“无 TFCG”仍保留原 ADN 的 SimAM，并非删除所有注意力。报告不会预设某一组最好。

## SPWVD 名称与论文贡献

Wang 等 Remote Sensing 2024 论文的 **2.3 节、公式（4）**就称其为 smoothed pseudo-Wigner–Ville distribution（SPWVD，平滑伪 Wigner–Ville 分布）。这是已有变换，可作为本方法的输入表征；直接改名不产生原创算法。

当前前端是固定窗口的 SPWVD 及已有显示/尺度处理，没有新增可学习平滑核，不能描述成“原创自适应 SPWVD”。可以给完整检测网络取统一名称，注明采用 SPWVD，并按实际实现说明 WCSG、TFCG 的位置、来源和改进。是否能将这套任务适配作为论文贡献，取决于独立模块增益、对照预算、机理和泛化实验；本包不预先保证创新性或录用。

## 直接运行

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
unzip -n B277_ADN_INCREMENTAL_ABLATION_FIX1.zip
nohup /root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  bash B277_ADN_INCREMENTAL_ABLATION_FIX1/run_b277.sh --wait-for-gpu \
  > codex_b277_ablation_fix1.log 2>&1 < /dev/null &
tail -F codex_b277_ablation_fix1.log
```

B275若仍在运行，程序每分钟显示等待，共用同一个GPU锁，待前一任务结束后启动。默认仅TRAIN16000/VAL3000，每个新增组额外4epoch、batch32、CE。原权重LR1e-5、新参数LR1e-4；Adam、weight decay1e-4，VAL CE选权重并包含本组epoch0。全部CNN与BN可训练，没有原L1-Tail尾部损失。

训练完只推理这两个新模型：CAL500k、CHECK200k、H1每SCR1024条、37点，Pfa1e-4。每个模型独立用CAL估计严格score>threshold阈值，再用CHECK计算实际Pfa与置信区间。SPWVD每批共用一次，不新建大时频缓存，不自动跑全量。旧ADN和B276的额外GPU推理次数为0。

`--stage preflight`只检查来源元数据；`--stage train`只训练；`--stage score`使用已完成权重评分；`--stage report`重生成表图。重跑同一命令可从最后完整epoch恢复；更改科学配置请使用新的`--out-dir`。GPU耗时尚未在3080Ti实测，以epoch耗时与评分ETA为准。

## 原始ADN究竟在哪里

源码已包含：`frozen_source/r10_2025_mtdsp_adn_source_protocol_freeze_canary_v1.py`，SHA0372818d8765520716407f97a0ec69df5a3bf42fb73d93a35739faa5bb71175e，其中ADN18/ADNBasicBlock/SimAM是历史结构。

已知旧评分目录：`output_sim_r10_b222_gpu_dualpfa_v1/seed_20261022`。所需文件为protocol_frozen.json、h0_cal_scores.npy、h0_audit_scores.npy、dev_h1_scores_37.npy。第0列Original ADN，原权重SHA9d43c99ec95c5a465b3584940b71aeccb7f8be56be84e7b7059d792a76d11a44。

程序核对已知协议SHA、模型身份、场景指纹、数组形状与有效数值，取500k/200k前缀及同一37×1024 H1，重新估计medium阈值。不会直接复制旧3M阈值曲线。仅重新评价这些既有场景时，不需要找回原始权重。以后若换独立场景，仍需要权重或重新训练。

若旧文件缺失，A0会显示missing且指标留空，不会填0冒充结果，也不会自动重训ADN；两个中间组照常运行。若已有旧文件身份或数据校验失败，会报告错误，不能强行拼表。

## 其他必需旧文件

- 冻结SIM-R10 IQ银行、原B213场景协议。
- `output_b274_single_spwvd_resnet18_v1`的训练manifest/contract、best.pt和原前端文件。A1/A2与A3使用同一B274预训练权重、同一TRAIN/VAL行和同一额外预算。
- `output_b276_spwvd_adn_phase_v1/adn`的best.pt和training_contract.json，及`pd_scr_medium`的协议、progress、完整原始npy、b276_curves/metrics.csv。

原B276代码SHA要匹配发布版本，且数据、seed、epoch、学习率、初始化和本轮设置一致；复用评分的阈值、全部H0虚警数及所有37点H1检出数均重放核对，错误则拒绝。旧训练契约和指纹不改写。

## 输出

目录：`output_b277_adn_incremental_ablation_fix1/pd_scr_medium`。

- b277_ablation_table.csv（UTF8 BOM，可在Excel打开）、.md、.pdf、.png：四行表，含结构开关、参数量、Pd@0、D50/D80/D90、实际Pfa与预算标记。
- b277_metrics.csv、b277_comparisons.csv、b277_report.json：包括完整源记录和历史行范围说明。
- figures/b277_pd_scr_pfa_1e-04.pdf/.png/.svg：四组Pd图，完整组黑色虚线空心倒三角，轴为SCR(dB)、Pd，原值不平滑不移点。
- 其余B276参考方法的原始曲线也保存在b277_curves.csv供后续重画。

## 论文解释边界

A0是历史训练参考，旧推理batch16；A1-A3推理batch32，并具有相同B274源权重与额外训练预算。A0训练数据用量、训练策略、初始化与新组不同。因此A0→A1不能单独证明“只换WVD为SPWVD就带来X dB”。若需要严格的纯前端消融，应另外按共同初始化和预算训练WVD/SPWVD对照。

A1/A2保留非线性SimAM，初始输出本来就会不同于无SimAM的B274；程序如实记录差异，不把它绕过成恒等。A1与A2的共同初始骨干及WCSG初始恒等已检查；A3则沿用原B276的TFCG恒等初始化。不能把共同预训练权重误写为所有结构初始函数完全相同。

当前是单种子、已多次查看的DEV实验。表格用于判断模块增量，不预设完整组必须最好，也不把生成数据上的CPU测试当成真实雷达检测改进。借鉴来源需正常引用：ADN DOI10.1109/JSEN.2023.3259953；SPWVD时频分支启发 DOI10.3390/rs16244662；WCSG/TFCG沿用用户已有实现。
