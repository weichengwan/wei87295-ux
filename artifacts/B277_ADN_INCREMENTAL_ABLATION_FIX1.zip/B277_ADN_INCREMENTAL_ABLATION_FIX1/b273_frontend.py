"""SPWVD from Wang2024 Eq4 with an explicit signed-spectrum residual adaptation.

SPWVD is prior art. Hann9 time/Hann129 lag windows are declared engineering
choices, not claimed to be author-released code or the user's lost Wang run.
"""
from __future__ import annotations
import math
import torch
from torch import nn
import torch.nn.functional as F


class ResidualSPWVD(nn.Module):
    def __init__(self,mode='residual',time_length=9,lag_half=64,alpha_max=.75,
                 initial_alpha=.25,component_batch=8):
        super().__init__()
        if mode not in ('residual','plain'):raise ValueError('Unknown frontend mode')
        if not (time_length>=1 and time_length%2==1 and 1<=lag_half<256 and component_batch>=1):
            raise ValueError('Invalid SPWVD smoothing geometry')
        if not 0<initial_alpha<alpha_max<1:raise ValueError('Require0<initial_alpha<alpha_max<1')
        self.mode=mode;self.alpha_max=float(alpha_max);self.component_batch=int(component_batch)
        g=torch.ones(1) if time_length==1 else torch.hann_window(time_length,periodic=False)
        self.register_buffer('time_kernel',g/g.sum())
        h=torch.zeros(512);h[256-lag_half:256+lag_half+1]=torch.hann_window(2*lag_half+1,periodic=False)
        self.register_buffer('lag_kernel',h)
        self.mix_logit=nn.Parameter(torch.tensor(math.log(initial_alpha/(alpha_max-initial_alpha))),requires_grad=mode=='residual')
        self.register_buffer('blend_progress',torch.tensor(0. if mode=='residual' else 1.))
        t=torch.arange(512)[:,None];k=torch.arange(-256,256)[None]
        ip,im=t+k,t-k
        self.register_buffer('index_plus',ip.clamp(0,511),persistent=False)
        self.register_buffer('index_minus',im.clamp(0,511),persistent=False)
        self.register_buffer('valid',((ip>=0)&(ip<512)&(im>=0)&(im<512)),persistent=False)

    def set_epoch(self,epoch,warmup_epochs=2):
        if warmup_epochs<1:raise ValueError('Invalid warmup length')
        self.blend_progress.fill_(min(1.,max(0.,epoch/warmup_epochs)) if self.mode=='residual' else 1.)

    def alpha(self):
        if self.mode=='plain':return self.blend_progress.new_tensor(1.)
        return self.alpha_max*torch.sigmoid(self.mix_logit)*self.blend_progress

    @staticmethod
    def spectrum(products):
        return torch.fft.fftshift(torch.fft.fft(torch.fft.ifftshift(products,dim=-1),dim=-1),dim=-1).real

    @torch.no_grad()
    def components(self,iq):
        # no_grad, not inference_mode: these tensors must support gradient
        # propagation through the learned mix coefficient during training.
        if iq.ndim!=2 or iq.shape[1]!=512 or not torch.is_complex(iq):raise ValueError('Expected complex IQ[N,512]')
        if iq.dtype!=torch.complex64:raise ValueError('Require complex64 IQ')
        wvd,spwvd=[],[]
        weight=self.time_kernel[None,None,:,None].repeat(2,1,1,1)
        for start in range(0,len(iq),self.component_batch):
            x=iq[start:start+self.component_batch]
            products=x[:,self.index_plus]*x[:,self.index_minus].conj()*self.valid
            original=self.spectrum(products)
            ri=torch.view_as_real(products).permute(0,3,1,2).contiguous()
            smooth=F.conv2d(ri,weight,padding=(len(self.time_kernel)//2,0),groups=2)
            smooth=torch.view_as_complex(smooth.permute(0,2,3,1).contiguous())*self.lag_kernel[None,None]
            wvd.append(original);spwvd.append(self.spectrum(smooth))
        return torch.cat(wvd),torch.cat(spwvd)

    @staticmethod
    def display(signed):
        # Identical order, epsilon,60dB clipping, resize and q=2f(mod1) grid
        # to frozen ADN/L1. Mixing occurs BEFORE absolute value/log display.
        amplitude=signed.abs().float();db=10*torch.log10(amplitude+1e-12)
        db=db-db.amax((1,2),keepdim=True);z=(db.clamp(-60,0)+60)/60
        z=F.interpolate(z[:,None],size=(128,128),mode='bilinear',align_corners=False)[:,0]
        return z

    def maps(self,components):
        wvd,spwvd=components
        signed=spwvd if self.mode=='plain' else wvd+self.alpha()*(spwvd-wvd)
        return self.display(signed)

    def diagnostics(self):
        return dict(alpha=float(self.alpha().detach()),blend_progress=float(self.blend_progress),
                    alpha_max=self.alpha_max,mode=self.mode,coefficient_is_global_not_sample_adaptive=True)
