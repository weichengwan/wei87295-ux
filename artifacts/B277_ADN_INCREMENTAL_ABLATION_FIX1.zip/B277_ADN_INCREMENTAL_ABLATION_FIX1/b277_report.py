"""A four-row incremental table, with the historical row explicitly qualified."""
from pathlib import Path
import csv,shutil
import numpy as np
from b271_data import fingerprint,need,read_json,write_json
from b273_statistics import metrics_for,save_csv
from b277_model import NAMES
from paper_plots import generate as paper_plot


def table_rows(p,lookup):
    rows=[]
    plans=[('A0','HIST_ADN','WVD',False,False,'SimAM'),('A1','spwvd_adn','SPWVD',False,False,'SimAM'),
           ('A2','spwvd_wcsg','SPWVD',True,False,'SimAM'),('A3','REF_adn','SPWVD',True,True,'TFCG')]
    count={v['arm']:v['trainable_parameters'] for v in p['checkpoints']}
    budget=p.get('training_budget',dict(train_n=16000,val_n=3000,epochs=4))
    for order,label,front,wcsg,tfcg,attention in plans:
        m=lookup.get(label,{});historical=label=='HIST_ADN'
        row=dict(row=order,method=p['names'].get(label,NAMES['ORIGINAL']),frontend=front,ADN_ACB=True,WCSG=wcsg,
            SimAM=not tfcg,TFCG=tfcg,attention=attention,phase_ARS=False,
            parameters=14330946 if historical else p['reused_full_checkpoint']['trainable_parameters'] if label=='REF_adn' else count[label],
            nominal_pfa=1e-4,actual_pfa=m.get('actual_pfa'),audit_false_alarms=m.get('audit_false_alarms'),audit_n=m.get('audit_n'),
            pd_at_0=m.get('pd_at_0'),D50_db=m.get('D50_db'),D80_db=m.get('D80_db'),D90_db=m.get('D90_db'),
            result_status='available' if m else 'missing; not filled',matched_extra_training_budget=not historical,
            initialization='historical WVD ADN' if historical else 'same frozen B274 SPWVD ResNet18',
            initial_function_same_as_B274=False if label in ('spwvd_adn','spwvd_wcsg') else True if label=='REF_adn' else None,
            training_note='Historical training and batch16 scoring; paired scenes only' if historical else
                          f'same TRAIN{budget["train_n"]}/VAL{budget["val_n"]}, CE, extra{budget["epochs"]}epoch, seed and parameter-group LR as B276')
        rows.append(row)
    return rows


def export_table(out,rows):
    # BOM permits Excel/Word to read the table without corrupting symbols.
    with (out/'b277_ablation_table.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    fmt=lambda v:'—' if v is None else f'{v:.3f}'
    mark=lambda v:'✓' if v else '—'
    text='|Row|TF|WCSG|SimAM|TFCG|D80/dB|D90/dB|Pd@0|Actual Pfa|\n|---|---|---|---|---|---|---|---|---|\n'
    for r in rows:
        text+='|'+ '|'.join([r['row'],r['frontend'],mark(r['WCSG']),mark(r['SimAM']),mark(r['TFCG']),fmt(r['D80_db']),fmt(r['D90_db']),fmt(r['pd_at_0']),
                              '—' if r['actual_pfa'] is None else f'{r["actual_pfa"]:.2e}'])+'|\n'
    text+='\nA0 is a historical reference with different training/initialization and inference batch. A1–A3 share the SPWVD source and extra training budget. TFCG REPLACES SimAM. Previously exposed DEV; not independent FINAL. No claim of isolated WVD→SPWVD causal gain from A0→A1.\n'
    (out/'b277_ablation_table.md').write_text(text)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(10,2.8));ax.axis('off')
    content=[[r['row'],r['frontend'],'Y' if r['WCSG'] else '-',r['attention'],fmt(r['D80_db']),fmt(r['D90_db']),
              'missing' if r['actual_pfa'] is None else f'{r["actual_pfa"]:.2e}'] for r in rows]
    table=ax.table(cellText=content,colLabels=['Row','TF','WCSG','Attention','D80 /dB','D90 /dB','Actual Pfa'],loc='center',cellLoc='center')
    table.auto_set_font_size(False);table.set_fontsize(9);table.scale(1,1.5)
    ax.set_title('ADN incremental ablation | nominal Pfa=1e-4')
    fig.text(.03,.04,'A0: historical training reference. A1-A3: matched additional SPWVD training budget. Exposed DEV.',fontsize=8)
    fig.tight_layout(rect=(0,.1,1,1))
    for ext in ('pdf','png'):fig.savefig(out/f'b277_ablation_table.{ext}',dpi=300,bbox_inches='tight')
    plt.close(fig)


def generate(out):
    out=Path(out);p=read_json(out/'protocol_frozen.json');progress=read_json(out/'progress.json')
    need(p['version']=='B277_ADN_INCREMENTAL_ABLATION_SCORE_V1' and p['nominal_pfas']==[1e-4] and
         fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==p['fingerprint']==progress['fingerprint'],'B277 protocol differs')
    need(progress['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=len(p['scr_grid_db'])),'B277 scoring incomplete')
    n=len(p['labels']);values=[]
    for name,shape in [('h0_cal_scores.npy',(p['h0_cal_n'],n)),('h0_audit_scores.npy',(p['h0_audit_n'],n)),('dev_h1_scores.npy',(len(p['scr_grid_db']),p['h1_scenes_n'],n))]:
        x=np.load(out/name,mmap_mode='r',allow_pickle=False);need(x.shape==shape and x.dtype==np.dtype('float64'),'Malformed B277 score arrays');values.append(x)
    cal,audit,h1=values;curves=[];metrics=[];lookup={}
    for j,label in enumerate(p['labels']):
        cv,mt=metrics_for(p['names'][label],cal[:,j],audit[:,j],h1[:,:,j],p);curves+=cv;metrics+=mt;lookup[label]=mt[0]
    comparisons=[]
    for left,right,matched in [('spwvd_adn','HIST_ADN',False),('spwvd_wcsg','spwvd_adn',True),('REF_adn','spwvd_wcsg',True),('REF_adn','spwvd_adn',True)]:
        if left not in lookup or right not in lookup:continue
        x,y=lookup[left],lookup[right]
        delta=lambda key:x[key]-y[key] if x[key] is not None and y[key] is not None else None
        comparisons.append(dict(candidate=x['method'],reference=y['method'],delta_D80_db=delta('D80_db'),delta_D90_db=delta('D90_db'),
            pd_at_0_gain_pp=100*delta('pd_at_0'),candidate_false_alarms=x['audit_false_alarms'],reference_false_alarms=y['audit_false_alarms'],
            paired_scenes=True,matched_extra_training_budget=matched,negative_delta_means_left=True,isolated_frontend_gain_established=False))
    save_csv(out/'b277_curves.csv',curves);save_csv(out/'b277_metrics.csv',metrics);save_csv(out/'b277_comparisons.csv',comparisons)
    rows=table_rows(p,lookup);export_table(out,rows)
    report=dict(status='PASS_B277_MEDIUM_INCREMENTAL_ABLATION_REPORT',metrics=metrics,comparisons=comparisons,ablation_table=rows,
        scope=p['scope'],source_reuse=p['reused_baselines'],independent_final=False,automatic_promotion=False,
        original_ADN_retrained=False,full_B276_retrained=False,equal_actual_pfa_established=False,
        isolated_WVD_to_SPWVD_gain_established=False)
    write_json(out/'b277_report.json',report)
    ablation_curves=[r for row in rows if row['result_status']=='available' for r in curves if r['method']==row['method']]
    save_csv(out/'b277_ablation_curves.csv',ablation_curves)
    paper_plot(out/'b277_ablation_curves.csv',out/'figures',ours=p['names']['REF_adn'],nominal=1e-4,metrics=out/'b277_metrics.csv')
    for ext in ('png','pdf','svg'):shutil.copyfile(out/'figures'/f'b277_ablation_curves_paper_pd_pfa_1e-04.{ext}',out/'figures'/f'b277_pd_scr_pfa_1e-04.{ext}')
    for r in rows:print(f"{r['row']} {r['method']}: D90={r['D90_db']} Pfa={r['actual_pfa']} status={r['result_status']}",flush=True)
    print('B277 stopped after medium evaluation; table='+str(out/'b277_ablation_table.csv'),flush=True);return report
