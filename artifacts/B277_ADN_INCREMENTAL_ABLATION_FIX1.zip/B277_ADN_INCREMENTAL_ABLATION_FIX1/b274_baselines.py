"""Verify and reuse completed B273 scores, without another baseline GPU pass."""
from __future__ import annotations
import csv
from pathlib import Path
import numpy as np
from b271_data import digest_file, fingerprint, need, read_json
from b271_score import SCENE_KEYS
from b273_report import NAMES
from b273_statistics import metrics_for


def metadata(folder,context,original,device,selection=None):
    folder=Path(folder).resolve();p=read_json(folder/'protocol_frozen.json')
    progress=read_json(folder/'progress.json');run=read_json(folder.parent/'run_manifest.json')
    need(p['version']=='B273_RESIDUAL_SPWVD_SCORE_V1' and p['nominal_pfas']==[1e-4], 'Require completed B273 medium baseline scores')
    need(fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==p['fingerprint']==progress['fingerprint'],'B273 protocol fingerprint differs')
    scene={k:original[k] for k in SCENE_KEYS};scene.update(h0_cal_n=500000,h0_audit_n=200000)
    need(all(p[k]==v for k,v in scene.items()) and p['scene_fingerprint']==fingerprint(scene),'Baseline scene identities differ')
    need(progress['completed']==dict(h0_cal=500000,h0_audit=200000,h1=37),'B273 scoring unfinished')
    need(Path(run['bank_dir']).resolve()==context['bank_dir'] and p['generator_sha']==context['bc']['generator_sha256'],'Baseline IQ bank/generator differs')
    need(p['batch']==32 and p['device']==device.type and p['tf32'] is False and
         p['score_definition']=='float64(float32 logit1 - float32 logit0)','Baseline numerical settings differ')
    need(p['code_sha256']==read_json(Path(__file__).parent/'b273_release_sources.json'),'B273 implementation differs from the verified original release')
    need(len(set(p['labels']))==len(p['labels']) and set(p['labels'])<=set(NAMES) and 'B271_CONTROL' in p['labels'] and 'L1_TAIL' in p['labels'],'Unknown/incomplete baseline labels')
    if selection is not None:need(run['selected_rows']==selection,'TRAIN/VAL row selection differs from B273')
    for identity in p['checkpoints']:
        directory=folder.parent/identity['arm'];c=read_json(directory/'training_contract.json')
        need(digest_file(directory/'best.pt')==c['checkpoint_sha256']==identity['sha256'] and c['arm']==identity['arm'], 'B273 baseline checkpoint changed')
    for name in ('h0_cal_scores.npy','h0_audit_scores.npy','dev_h1_scores.npy','b273_curves.csv','b273_metrics.csv'):
        need((folder/name).is_file(),'Missing cached B273 result: '+str(folder/name))
    return dict(folder=folder,p=p,protocol_sha256=digest_file(folder/'protocol_frozen.json'),names={k:NAMES[k] for k in p['labels']})


def arrays(info):
    p=info['p'];folder=info['folder'];n=len(p['labels']);cached={};hashes={}
    for key,name,shape in [('h0_cal','h0_cal_scores.npy',(500000,n)),('h0_audit','h0_audit_scores.npy',(200000,n)),('h1','dev_h1_scores.npy',(37,1024,n))]:
        x=np.load(folder/name,mmap_mode='r',allow_pickle=False)
        need(x.shape==shape and x.dtype==np.dtype('float64') and np.isfinite(x).all(),'Malformed B273 score array: '+name)
        cached[key]=x;hashes[name]=digest_file(folder/name)
    with (folder/'b273_metrics.csv').open(newline='',encoding='utf-8-sig') as f:old_metrics=list(csv.DictReader(f))
    with (folder/'b273_curves.csv').open(newline='',encoding='utf-8-sig') as f:old_curves=list(csv.DictReader(f))
    for j,label in enumerate(p['labels']):
        name=info['names'][label]
        curves,metrics=metrics_for(name,cached['h0_cal'][:,j],cached['h0_audit'][:,j],cached['h1'][:,:,j],p)
        previous=[r for r in old_metrics if r['method']==name and float(r['nominal_pfa'])==1e-4]
        need(len(previous)==1 and metrics[0]['threshold']==float(previous[0]['threshold']) and
             metrics[0]['audit_false_alarms']==int(previous[0]['audit_false_alarms']),'Baseline threshold/H0 replay differs: '+name)
        for row in curves:
            match=[r for r in old_curves if r['method']==name and float(r['nominal_pfa'])==1e-4 and float(r['scr_db'])==row['scr_db']]
            need(len(match)==1 and int(match[0]['hits'])==row['hits'] and int(match[0]['n_h1'])==row['n_h1'],'Baseline hit-count replay differs: '+name)
    return cached,dict(protocol_sha256=info['protocol_sha256'],array_sha256=hashes,
        baseline_thresholds_false_alarms_all37_hits_replayed=True,additional_baseline_GPU_forwards=0)
