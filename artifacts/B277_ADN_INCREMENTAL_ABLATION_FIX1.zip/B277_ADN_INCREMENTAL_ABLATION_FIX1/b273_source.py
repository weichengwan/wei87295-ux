"""Validate the actual completed B271 checkpoint and its TRAIN-only H0 pool."""
from __future__ import annotations
from pathlib import Path
import h5py
import numpy as np
import torch
from b271_data import digest_file,fingerprint,load_checkpoint,need,read_json
from b271_model import B271Net


def verify_source(run_dir,context,l1_checkpoint,l1_sha):
    run_dir=Path(run_dir).resolve()
    run=read_json(run_dir/"run_manifest.json")
    contract=read_json(run_dir/"guided/training_contract.json")
    path=run_dir/"guided/best.pt";sha=digest_file(path);state=load_checkpoint(path)
    need(run["variants"]==["guided"] and run["initialization_sha256"]==l1_sha,"Not the original guided B271 run")
    need(Path(run["bank_dir"]).resolve()==context["bank_dir"] and
         Path(run["cache_dir"]).resolve()==context["cache_dir"],"B271 source data directories differ")
    need(contract["status"]=="PASS_B271_FROZEN_L1__TRAIN_VAL_ONLY" and
         contract["variant"]=="guided" and contract["checkpoint_sha256"]==sha,"B271 training incomplete or checksum differs")
    config=state["run_config"]
    need(state["run_fingerprint"]==contract["run_fingerprint"]==fingerprint(config),"B271 source run identity differs")
    need(state["epoch"]==contract["best_epoch"] and state["model_config"]==contract["model_config"],"B271 selected epoch/config differs")
    need(config["bank_sha"]==context["bc"]["file_sha256"] and
         config["cache_sha"]==context["cc"]["wvd_cache_sha256"] and
         config["initialization_sha"]==l1_sha==contract["initialization_sha256"],"B271 data/checkpoint lineage differs")
    expected=read_json(Path(__file__).parent/"b271_original_sources.json")
    need(config["code_sha"]==expected,"Source was not produced by the bundled verified B271 implementation")
    for name,digest in expected.items():
        need(digest_file(Path(__file__).parent/name)==digest,"Bundled B271 source changed: "+name)
    model=B271Net(**state["model_config"])
    model.load_state_dict(state["state_dict"],strict=True)
    for key,value in l1_checkpoint["state_dict"].items():
        need(torch.equal(model.state_dict()[key].cpu(),value.cpu()),"B271 original backbone/BN changed: "+key)
    return dict(run_dir=run_dir,run=run,contract=contract,state=state,checkpoint=path,
                sha256=sha,original_l1_sha256=l1_sha)


def verify_pool(source,context):
    directory=source["run_dir"]/"train_h0_pool"
    path=directory/"pool.h5";contract=read_json(directory/"contract.json")
    config=contract["config"];sha=digest_file(path)
    need(contract["fingerprint"]==fingerprint(config) and contract["pool_sha256"]==sha,
         "Original training H0 pool fingerprint/checksum differs")
    need(config["split"]=="b271_training_h0_v1" and config["bank_sha"]==context["bc"]["file_sha256"] and
         config["generator_sha"]==context["bc"]["generator_sha256"] and
         config["baseline_checkpoint_sha"]==source["original_l1_sha256"],"Training H0 pool source differs")
    need(contract["original_cal_audit_dev_opened"] is False and
         config["n_proposals"]==source["run"]["proposal_count"],"Pool must be the declared TRAIN-only pool")
    need(source["state"]["run_config"]["pool_sha"]==sha,"B271 trained with a different retained pool")
    with h5py.File(path,"r") as h:
        n=len(h["iq"])
        need(n==contract["retained"] and h["iq"].shape==(n,512) and h["iq"].dtype==np.dtype("complex64") and
             h["wvd"].shape==(n,128,128) and h["wvd"].dtype==np.dtype("float32"),"Retained pool shape/dtype differs")
    return path,dict(path=str(path),sha256=sha,retained=contract["retained"],
                     proposal_count=config["n_proposals"],new_proposals_generated=0)
