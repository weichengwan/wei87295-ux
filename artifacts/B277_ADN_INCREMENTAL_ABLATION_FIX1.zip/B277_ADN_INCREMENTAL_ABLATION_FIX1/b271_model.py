"""Frozen original ADN/L1 with phase-conditioned, bounded adaptive resampling.

ARS concept: Chen et al., Spatial Frequency Modulation for Semantic Segmentation,
TPAMI 2025, DOI 10.1109/TPAMI.2025.3592621. Independently implemented adaptation;
not the original SFM model or its upsampling/demodulation framework.
"""
from __future__ import annotations

import torch
from torch import nn
import torch.nn.functional as F

from source_loader import load_frozen_sources


class PhaseEvidence(nn.Module):
    """Evidence from eight disjoint 64-pulse blocks, with WVD alias alignment.

    Second phase differences allow constant quadratic phase, instead of assuming
    a constant Doppler. Colored clutter can also be coherent: this is a feature,
    never an oracle target map. No labels, target components, or SCR are inputs.
    """
    def __init__(self):
        super().__init__()
        self.register_buffer("window", torch.hann_window(64))

    def forward(self, iq):
        if iq.ndim != 2 or iq.shape[1] != 512 or not torch.is_complex(iq):
            raise ValueError("Expected complex IQ [N,512]")
        x = iq.to(torch.complex64)
        power = x.abs().square().mean(1, keepdim=True)
        x = x / power.clamp_min(1e-20).sqrt()
        z = torch.fft.fftshift(torch.fft.fft(x.reshape(-1, 8, 64) * self.window, dim=-1), dim=-1)
        p = z.abs().square()
        unit = z / z.abs().clamp_min(1e-7)
        curvature = unit[:, 2:] * unit[:, :-2] * unit[:, 1:-1].conj().square()
        # Weight phase evidence by the weakest of the three spectral magnitudes.
        reliability = torch.minimum(torch.minimum(p[:, 2:], p[:, :-2]), p[:, 1:-1]).sqrt()
        def local_average(v):
            return F.avg_pool2d(v[:, None], (3, 1), stride=1, padding=(1, 0),
                                count_include_pad=False)[:, 0]
        real = local_average(curvature.real * reliability)
        imag = local_average(curvature.imag * reliability)
        c = torch.sqrt(real.square() + imag.square() + 1e-20) / local_average(reliability).clamp_min(1e-7)
        c = F.pad(c.clamp(0, 1), (0, 0, 1, 1))
        # Discrete original WVD is x[t+k]conj(x[t-k]), hence q=2*f (mod 1).
        # Both physical aliases f and f+0.5 contribute, with power weighting.
        # Original WVD512 ->128 bilinear align_corners=False samples FFT
        # coordinates 4*k+1.5, rather than the integer coordinate 4*k.
        q = (torch.arange(128, device=x.device, dtype=torch.float32) - 64) / 128 + 1.5/512
        j = (q / 2 + 0.5) * 64
        j0 = j.floor().long() % 64
        fraction = (j - j.floor())[None, None]
        def sample(v, shift):
            left, right = (j0 + shift) % 64, (j0 + shift + 1) % 64
            return v.index_select(-1, left) * (1 - fraction) + v.index_select(-1, right) * fraction
        p1, p2 = sample(p, 0), sample(p, 32)
        c1p, c2p = sample(c * p, 0), sample(c * p, 32)
        folded_power = p1 + p2
        folded_c = (c1p + c2p) / folded_power.clamp_min(1e-7)
        db = 10 * torch.log10(folded_power.clamp_min(1e-10))
        energy = ((db - db.amax((1, 2), keepdim=True)).clamp(-40, 0) + 40) / 40
        valid = (power > 1e-20).to(energy.dtype)[:, :, None]
        guide = torch.stack((energy * valid, folded_c.clamp(0, 1) * valid), dim=1)
        # Time coordinates are block centers; border replication is explicit.
        return F.interpolate(guide, size=(128, 128), mode="bilinear", align_corners=False)


class BoundedResampler(nn.Module):
    def __init__(self, channels, maximum_offset=0.75):
        super().__init__()
        self.maximum_offset = float(maximum_offset)
        self.encoder = nn.Sequential(nn.Conv2d(channels, 8, 1, bias=False),
                                     nn.GroupNorm(2, 8), nn.SiLU())
        self.offset = nn.Sequential(nn.Conv2d(10, 12, 3, padding=1, bias=False),
                                    nn.GroupNorm(3, 12), nn.SiLU(), nn.Conv2d(12, 2, 1))
        nn.init.zeros_(self.offset[-1].weight)
        nn.init.zeros_(self.offset[-1].bias)

    def forward(self, x, guide, return_info=False):
        h, w = x.shape[-2:]
        g = F.interpolate(guide, (h, w), mode="bilinear", align_corners=False)
        pixels = self.maximum_offset * torch.tanh(self.offset(torch.cat((self.encoder(x), g), 1)))
        yy = (torch.arange(h, device=x.device, dtype=x.dtype) + 0.5) * (2 / h) - 1
        xx = (torch.arange(w, device=x.device, dtype=x.dtype) + 0.5) * (2 / w) - 1
        gy, gx = torch.meshgrid(yy, xx, indexing="ij")
        grid = torch.stack((gx, gy), -1)[None].expand(x.shape[0], -1, -1, -1)
        displacement = pixels.permute(0, 2, 3, 1) * x.new_tensor((2 / w, 2 / h))
        warped = F.grid_sample(x, grid + displacement, mode="bilinear",
                               padding_mode="border", align_corners=False)
        origin = F.grid_sample(x, grid, mode="bilinear",
                               padding_mode="border", align_corners=False)
        # Two identical samples cancel at initialization, even when a nominal
        # grid_sample identity grid has floating-point interpolation error.
        result = x + (warped - origin)
        if not return_info:
            return result
        dx = pixels[:, :, :-1, 1:] - pixels[:, :, :-1, :-1]
        dy = pixels[:, :, 1:, :-1] - pixels[:, :, :-1, :-1]
        jacobian = (1 + dx[:, 0]) * (1 + dy[:, 1]) - dx[:, 1] * dy[:, 0]
        penalty = dx.square().mean() + dy.square().mean() + F.relu(0.1-jacobian).square().mean()
        stats = dict(saturation=float((pixels.detach().abs() >= .99*self.maximum_offset).float().mean()),
                     negative_jacobian=float((jacobian.detach()<0).float().mean()),
                     outside_grid=float(((grid+displacement).detach().abs()>1).any(-1).float().mean()))
        return result, penalty, stats


class B271Net(nn.Module):
    def __init__(self, variant="guided", maximum_offset=0.75, correction_bound=3.0):
        super().__init__()
        if variant not in ("guided", "no_phase", "head_control"):
            raise ValueError("Unknown model variant")
        if not 0 < maximum_offset <= 1 or not 0 < correction_bound <= 5:
            raise ValueError("Invalid resampling/correction bound")
        source, trainer, reference = load_frozen_sources()
        original = trainer.ProposedWrapper(source, dict(reference.CFG))
        self.detector, self.suppressor = original.detector, original.suppressor
        self.cfg, self.variant = dict(reference.CFG), variant
        for p in self.parameters():
            p.requires_grad_(False)
        self.phase = PhaseEvidence()
        self.resample1 = BoundedResampler(64, maximum_offset)
        self.resample3 = BoundedResampler(128, maximum_offset)
        self.phase_encoder = nn.Sequential(
            nn.Conv2d(2, 8, 3, stride=2, padding=1, bias=False), nn.GroupNorm(2, 8), nn.SiLU(),
            nn.Conv2d(8, 8, 3, stride=2, padding=1, groups=8, bias=False),
            nn.GroupNorm(2, 8), nn.SiLU())
        self.image_projection = nn.Sequential(nn.LayerNorm(512), nn.Linear(512, 16), nn.SiLU())
        self.correction = nn.Sequential(nn.Linear(33, 16), nn.SiLU(), nn.Linear(16, 1))
        nn.init.zeros_(self.correction[-1].weight)
        nn.init.zeros_(self.correction[-1].bias)
        self.correction_bound = float(correction_bound)
        self.model_config = dict(variant=variant, maximum_offset=maximum_offset,
                                 correction_bound=correction_bound)
        if variant == "head_control":
            for module in (self.resample1, self.resample3, self.phase_encoder):
                for p in module.parameters():
                    p.requires_grad_(False)
        elif variant == "no_phase":
            for p in self.phase_encoder.parameters():
                p.requires_grad_(False)
        self.train()

    def train(self, mode=True):
        super().train(mode)
        self.detector.eval()
        self.suppressor.eval()
        return self

    def load_l1_checkpoint(self, checkpoint):
        source, trainer, reference = load_frozen_sources()
        if checkpoint.get("method") != "L1_TAIL" or checkpoint.get("cfg") != self.cfg:
            raise ValueError("Not the original L1-Tail checkpoint")
        if checkpoint.get("source_sha256") != trainer.EXPECTED_SOURCE_SHA:
            raise ValueError("Original source identity mismatch")
        if checkpoint.get("trainer_sha256") != "7354c3d64ca7e6f4745097f117afbf1f267091a97c79f0d5c99d081c9e2ffcc5":
            raise ValueError("Original trainer identity mismatch")
        expected = {k for k in self.state_dict() if k.startswith(("detector.", "suppressor."))}
        if set(checkpoint["state_dict"]) != expected:
            raise ValueError("Original L1 architecture/keys differ")
        self.load_state_dict(checkpoint["state_dict"], strict=False)

    def forward(self, images, iq, return_aux=False):
        if images.ndim != 4 or images.shape[1:] != (3, 224, 224) or iq.shape != (len(images), 512):
            raise ValueError("Expected mapped WVD images and paired IQ512")
        if self.variant == "guided":
            guide = self.phase(iq)
        else:
            guide = images.new_zeros((len(images), 2, 128, 128))
        x, aux = self.suppressor(images)
        penalties, diagnostics = [], []
        d = self.detector
        x = d.relu(d.bn1(d.conv1(x)))
        if self.variant != "head_control":
            if return_aux:
                x, penalty, stats = self.resample1(x, guide, return_info=True)
                penalties.append(penalty);diagnostics.append(stats)
            else:
                x = self.resample1(x, guide)
        x = d.layer1(d.maxpool(x))
        x = d.layer2(x)
        if self.variant != "head_control":
            if return_aux:
                x, penalty, stats = self.resample3(x, guide, return_info=True)
                penalties.append(penalty);diagnostics.append(stats)
            else:
                x = self.resample3(x, guide)
        x = d.layer4(d.layer3(x))
        feature = torch.flatten(d.avgpool(x), 1)
        logits = d.fc(feature)
        image_feature = self.image_projection(feature)
        if self.variant == "guided":
            phase = self.phase_encoder(F.avg_pool2d(guide, 2))
            phase_feature = torch.cat((phase.mean((2, 3)), phase.amax((2, 3))), 1)
        else:
            phase_feature = images.new_zeros((len(images), 16))
        margin = (logits[:, 1] - logits[:, 0]).detach().clamp(-15, 15)[:, None]
        correction = self.correction(torch.cat((image_feature, phase_feature, margin), 1))[:, 0]
        correction = self.correction_bound * torch.tanh(correction / self.correction_bound)
        result = logits + torch.stack((-0.5 * correction, 0.5 * correction), 1)
        if return_aux:
            aux["offset_regularizer"] = sum(penalties, result.new_zeros(()))
            aux["offset_diagnostics"] = diagnostics
        return (result, aux) if return_aux else result
