"""Raw paired curves, own-CAL cutoffs and independent H0 check counts."""
from pathlib import Path
import shutil
import numpy as np
from b271_data import fingerprint,need,read_json,write_json
from b273_statistics import metrics_for,save_csv
from paper_plots import generate as paper_plot


def generate(out):
    out=Path(out);p=read_json(out/'protocol_frozen.json');progress=read_json(out/'progress.json')
    need(p['version'] in ('B276_SPWVD_ADN_PHASE_SCORE_V1','B275_ADSCM_STAGE2_SCORE_V1') and p['nominal_pfas']==[1e-4] and
         fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==p['fingerprint']==progress['fingerprint'],'Score protocol changed')
    need(progress['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=len(p['scr_grid_db'])),'Scoring incomplete')
    columns=len(p['labels']);values=[]
    for name,shape in [('h0_cal_scores.npy',(p['h0_cal_n'],columns)),('h0_audit_scores.npy',(p['h0_audit_n'],columns)),('dev_h1_scores.npy',(len(p['scr_grid_db']),p['h1_scenes_n'],columns))]:
        x=np.load(out/name,mmap_mode='r',allow_pickle=False);need(x.shape==shape and x.dtype==np.dtype('float64'),'Malformed score bank');values.append(x)
    cal,audit,h1=values;curves=[];metrics=[];lookup={}
    # The five B273 references retain their previous order/colors.
    old=[v for v in p['labels'] if v.startswith('BASE_') and v not in ('BASE_SINGLE','BASE_POWER')]
    order=old+(['BASE_SINGLE'] if 'BASE_SINGLE' in p['labels'] else [])+(['BASE_POWER'] if 'BASE_POWER' in p['labels'] else [])+p['candidate_labels']
    need(set(order)==set(p['labels']) and len(order)==len(p['labels']),'Unknown report label')
    for label in order:
        j=p['labels'].index(label);c,m=metrics_for(p['names'][label],cal[:,j],audit[:,j],h1[:,:,j],p)
        curves.extend(c);metrics.extend(m);lookup[label]=m[0]
    comparisons=[]
    for arm in p['candidate_labels']:
        candidate=lookup[arm]
        for label,reference in lookup.items():
            if label==arm:continue
            delta=lambda k:candidate[k]-reference[k] if candidate[k] is not None and reference[k] is not None else None
            comparisons.append(dict(candidate=candidate['method'],reference=reference['method'],nominal_pfa=1e-4,
                delta_D80_db=delta('D80_db'),delta_D90_db=delta('D90_db'),pd_at_0_gain_pp=100*delta('pd_at_0'),
                candidate_false_alarms=candidate['audit_false_alarms'],reference_false_alarms=reference['audit_false_alarms'],
                paired_scenes=True,negative_delta_means_left=True))
    prefix='b275' if p['version'].startswith('B275') else 'b276'
    save_csv(out/(prefix+'_curves.csv'),curves);save_csv(out/(prefix+'_metrics.csv'),metrics);save_csv(out/(prefix+'_comparisons.csv'),comparisons)
    report=dict(status='PASS_'+prefix.upper()+'_MEDIUM_DEV_REPORT',metrics=metrics,comparisons=comparisons,checkpoints=p['checkpoints'],
        scope=p['scope'],baseline_reuse=p['reused_baselines'],independent_final=False,automatic_promotion=False,
        equal_actual_pfa_established=False,positive_detection_gain_claimed=False)
    write_json(out/(prefix+'_report.json'),report)
    paper_plot(out/(prefix+'_curves.csv'),out/'figures',ours=p['names'][p['ours_label']],nominal=1e-4,metrics=out/(prefix+'_metrics.csv'))
    for ext in ('png','pdf','svg'):shutil.copyfile(out/'figures'/f'{prefix}_curves_paper_pd_pfa_1e-04.{ext}',out/'figures'/f'{prefix}_pd_scr_pfa_1e-04.{ext}')
    for row in comparisons:
        if row['reference'] in (p['names'].get('BASE_SINGLE'),p['names'].get('BASE_L1_TAIL')):
            print(f"{row['candidate']} vs {row['reference']}: delta_D90={row['delta_D90_db']}; H0 FP={row['candidate_false_alarms']} vs {row['reference_false_alarms']}",flush=True)
    print(f'Stopped after medium DEV: {out/(prefix+"_metrics.csv")}',flush=True);return report
