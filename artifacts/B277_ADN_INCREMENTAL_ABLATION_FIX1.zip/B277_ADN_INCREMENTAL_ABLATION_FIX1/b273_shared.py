"""Verified data/subset/loss helpers reused from the tested B271 staged runner."""
from __future__ import annotations
import hashlib
from pathlib import Path
import h5py
import numpy as np
import torch
import torch.nn.functional as F
from b271_data import digest_file, load_checkpoint, need
from source_loader import load_frozen_file


def rows(dataset, indices):
    indices = np.asarray(indices, dtype=np.int64)
    unique, inverse = np.unique(indices, return_inverse=True)
    return np.ascontiguousarray(dataset[unique][inverse])

def atomic_save(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(value, temporary)
    temporary.replace(path)

def selected_checkpoint(path, expected_sha, run_fingerprint, model_config, epoch, proxy):
    need(path.is_file() and digest_file(path) == expected_sha,
         "Selected checkpoint missing or differs from committed epoch; preserve files and use a new output directory")
    state = load_checkpoint(path)
    need(state.get("run_fingerprint") == run_fingerprint and
         state.get("model_config") == model_config and state.get("epoch") == epoch and
         abs(state["val_metrics"]["pauc01"]-proxy) < 1e-12,
         "Selected checkpoint internal identity differs from committed training state")
    return state

def setup(threads):
    torch.set_num_threads(threads)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

def reference_forward(model, images):
    x, _ = model.suppressor(images)
    return model.detector(x)

def pauc(scores, labels, limit=0.01):
    """Exact empirical ROC area over [0,limit], divided by limit; ties grouped."""
    scores, labels = np.asarray(scores, float), np.asarray(labels)
    n0, n1 = int((labels == 0).sum()), int((labels == 1).sum())
    need(n0 and n1, "Validation requires both classes")
    order = np.argsort(-scores, kind="stable")
    s, y = scores[order], labels[order]
    ends = np.r_[np.flatnonzero(s[:-1] != s[1:]), len(s)-1]
    fp = np.r_[0., np.cumsum(y == 0)[ends] / n0]
    tp = np.r_[0., np.cumsum(y == 1)[ends] / n1]
    # Preserve every ROC vertex at the boundary. Collapsing duplicate FPRs
    # through np.interp can incorrectly give a boundary vertical jump area.
    included = fp <= limit
    x, z = fp[included], tp[included]
    if x[-1] < limit:
        right = int(np.searchsorted(fp, limit, side="left"))
        left = right-1
        endpoint = tp[left]+(tp[right]-tp[left])*(limit-fp[left])/(fp[right]-fp[left])
        x, z = np.r_[x, limit], np.r_[z, endpoint]
    integrate = np.trapezoid if hasattr(np, "trapezoid") else np.trapz
    return float(integrate(z, x) / limit)

def subset_indices(labels, families, limit, seed):
    """Deterministic equal-label, proportional-family subset of frozen rows."""
    labels = np.asarray(labels)
    need(np.isin(labels, (0,1)).all(), "Invalid subset labels")
    if not limit or limit >= len(labels):
        return np.arange(len(labels), dtype="int64")
    need(limit >= 2 and limit % 2 == 0, "Subset size must be even and at least two")
    families = np.zeros(len(labels), dtype="int64") if families is None else np.asarray(families)
    need(families.shape == labels.shape, "Subset family shape differs")
    selected=[]
    for label in (0,1):
        available=np.flatnonzero(labels==label);count=limit//2
        need(len(available)>=count, "Insufficient rows for balanced subset")
        values=np.unique(families[available])
        groups=[available[families[available]==v] for v in values]
        desired=count*np.array([len(g) for g in groups],dtype=float)/len(available)
        quota=np.floor(desired).astype(int)
        remainder=count-int(quota.sum())
        quota[np.argsort(-(desired-quota),kind="stable")[:remainder]]+=1
        for j,(group,n) in enumerate(zip(groups,quota)):
            rng=np.random.default_rng(seed+1000*label+j)
            selected.extend(rng.permutation(group)[:n])
    return np.sort(np.asarray(selected,dtype="int64"))

class Data:
    def __init__(self, context, train_limit=0, val_limit=0, seed=20261022):
        self.context = context
        self.maps = h5py.File(context["cache"], "r")
        self.iq = h5py.File(context["bank_dir"] / context["b210"].H5_NAME, "r")
        self.selected = {}
        self.selection = {}
        for split,limit,offset in (("train",train_limit,27101),("val",val_limit,27102)):
            need(np.array_equal(self.maps[split]["label"][:], self.iq[split]["label"][:]),
                 "Original IQ/cache label ordering differs")
            labels=self.maps[split]["label"][:].astype("int64")
            families=self.iq[split]["family_index"][:] if "family_index" in self.iq[split] else None
            chosen=subset_indices(labels,families,limit,seed+offset)
            self.selected[split]=chosen
            self.selection[split]=dict(count=len(chosen),original_count=len(labels),
                row_indices_sha256=hashlib.sha256(chosen.astype("<i8").tobytes()).hexdigest(),
                counts_by_label={str(v):int((labels[chosen]==v).sum()) for v in (0,1)},
                family_stratified=families is not None)
        self.labels = rows(self.maps["train"]["label"],self.selected["train"]).astype("int64")

    def original_rows(self, split, indices):
        return self.selected[split][np.asarray(indices,dtype="int64")]

    def fetch(self, split, indices):
        indices=self.original_rows(split,indices)
        maps = rows(self.maps[split]["wvd"], indices).astype("float32")
        iq = rows(self.iq[split]["iq"], indices).astype("complex64")
        labels = rows(self.iq[split]["label"], indices).astype("int64")
        return maps, iq, labels

    def close(self):
        self.maps.close()
        self.iq.close()

def tensors(context, maps, iq):
    device = context["device"]
    images = context["source"].map_to_adn_input(torch.from_numpy(maps).to(device))
    return images, torch.from_numpy(iq).to(device)

@torch.inference_mode()
def validation(model, data, context, batch, reference_only=False):
    model.eval()
    score, labels, loss, correct = [], [], 0., 0
    n = len(data.selected["val"])
    for start in range(0, n, batch):
        indices = np.arange(start, min(start+batch, n))
        maps, iq, y = data.fetch("val", indices)
        images, iq = tensors(context, maps, iq)
        logits = reference_forward(model,images) if reference_only else model(images, iq)
        target = torch.from_numpy(y).to(context["device"])
        loss += float(F.cross_entropy(logits, target, reduction="sum"))
        correct += int((logits.argmax(1) == target).sum())
        score.append((logits[:, 1]-logits[:, 0]).double().cpu().numpy())
        labels.append(y)
    score, labels = np.concatenate(score), np.concatenate(labels)
    original = load_frozen_file("r10_sim_stage_b214_ablation_train_v1.py")
    return dict(val_ce=loss/n, val_acc=correct/n, auc=original.auc(score, labels),
                pauc01=pauc(score, labels), n_val=n, n_h0=int((labels == 0).sum()),
                n_h1=int((labels == 1).sum()), proxy_fpr_limit=0.01,
                proxy_is_not_pfa_1e5_validation=True)

@torch.inference_mode()
def hard_order(model, data, context, pool, batch):
    model.eval()
    indices = np.flatnonzero(data.labels == 0)
    values = []
    for start in range(0, len(indices), batch):
        maps, iq, _ = data.fetch("train", indices[start:start+batch])
        images, iq = tensors(context, maps, iq)
        logits = model(images, iq)
        values.extend((logits[:, 1]-logits[:, 0]).cpu().tolist())
    source = np.zeros(len(indices), dtype="int64")
    if pool is not None:
        extra_scores = []
        for start in range(0, len(pool["iq"]), batch):
            maps = np.asarray(pool["wvd"][start:start+batch], dtype="float32")
            iq = np.asarray(pool["iq"][start:start+batch], dtype="complex64")
            images, iq = tensors(context, maps, iq)
            logits = model(images, iq)
            extra_scores.extend((logits[:, 1]-logits[:, 0]).cpu().tolist())
        source = np.r_[source, np.ones(len(extra_scores), dtype="int64")]
        indices = np.r_[indices, np.arange(len(extra_scores))]
        values.extend(extra_scores)
    selected = np.argsort(np.asarray(values), kind="stable")[-min(256, len(values)):]
    return np.stack((source[selected], indices[selected]), 1)

def fetch_hard(selection, data, pool):
    maps, iq = [], []
    for is_pool, index in selection:
        index=int(index) if is_pool else int(data.original_rows("train",[index])[0])
        group = pool if is_pool else data.maps["train"]
        maps.append(group["wvd"][int(index)])
        iq.append((pool["iq"] if is_pool else data.iq["train"]["iq"])[int(index)])
    return np.asarray(maps, dtype="float32"), np.asarray(iq, dtype="complex64")
