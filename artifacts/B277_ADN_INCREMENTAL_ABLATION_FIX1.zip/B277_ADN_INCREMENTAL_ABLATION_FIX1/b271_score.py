#!/usr/bin/env python3
"""Complete resumable original SIM-R10 DEV scoring for B271 and frozen L1."""
from __future__ import annotations
import argparse
import time
from pathlib import Path
import numpy as np
import torch

from b271_data import device_for, digest_file, fingerprint, find_files, load_checkpoint, need, read_json, resolve_data, verify_l1_checkpoint, write_json
from b271_model import B271Net
from b271_train import PASS as TRAIN_PASS, reference_forward, setup
from source_loader import load_frozen_file, load_frozen_sources

VERSION="B271_PHASE_ARS_SCORE_V1"
SCENE_KEYS=("master_seed","generator_sha","h0_cal_n","h0_audit_n","h1_scenes_n","scr_grid_db",
            "h0_cal_split","h0_audit_split","h1_split","family_names","scr_definition")


def original_protocol(root, context, explicit=None):
    candidates=[Path(explicit)/"protocol_frozen.json"] if explicit else find_files(root,"protocol_frozen.json")
    valid=[]
    for path in candidates:
        p=read_json(path)
        if p.get("version")=="SIM_R10_B213_SCOREBANK_V1" and p.get("training_bank_sha")==context["bc"]["file_sha256"]:
            valid.append(path)
    need(valid,"Original B213 protocol missing; provide --b213-dir")
    need(len({read_json(p).get("scene_fingerprint") for p in valid})==1,"Several B213 scene identities; provide --b213-dir")
    path=valid[0];p=read_json(path)
    need(fingerprint({k:p[k] for k in SCENE_KEYS})==p["scene_fingerprint"],"B213 scene fingerprint differs")
    need(fingerprint({k:v for k,v in p.items() if k!="fingerprint"})==p["fingerprint"],"B213 protocol fingerprint differs")
    need((p["h0_cal_n"],p["h0_audit_n"],p["h1_scenes_n"])==(3000000,1000000,1024)
         and p["scr_grid_db"]==list(range(-24,13)),"Require full original 3M/1M/1024,37-point protocol")
    generator=load_frozen_file("r10_sim_iq512_builder_v1_EARLIEST_HDF5.py")
    need(digest_file(generator.__file__)==p["generator_sha"]==context["bc"]["generator_sha256"],"Generator differs")
    need(p["master_seed"]==context["bc"]["seed"] and tuple(p["family_names"])==generator.TRAIN_FAMILIES,"Original seed/family identity differs")
    progress=read_json(path.with_name("progress.json"))
    need(progress["fingerprint"]==p["fingerprint"] and progress["completed"]==
         dict(h0_cal=p["h0_cal_n"],h0_audit=p["h0_audit_n"],h1=37),"Original B213 incomplete")
    return path,p,generator


@torch.inference_mode()
def predictions(models, source, iq, device, batch):
    need(iq.dtype==np.complex64 and iq.ndim==2 and iq.shape[1]==512,"Require complex64 IQ512")
    result=np.empty((len(iq),len(models)+1),dtype="float64")
    for start in range(0,len(iq),batch):
        stop=min(start+batch,len(iq))
        x=torch.from_numpy(np.ascontiguousarray(iq[start:stop])).to(device)
        images=source.map_to_adn_input(source.wvd_base_map(x))
        for j,model in enumerate(models):
            z=model(images,x)
            result[start:stop,j]=(z[:,1]-z[:,0]).double().cpu().numpy()
        z=reference_forward(models[0],images)
        result[start:stop,-1]=(z[:,1]-z[:,0]).double().cpu().numpy()
    need(np.isfinite(result).all(),"Nonfinite score")
    return result


def stream(a,protocol,generator,models,source,device):
    original=load_frozen_file("r10_sim_stage_b216_pdscr_score_v1.py")
    progress=original.init(a,protocol)
    columns=len(protocol["labels"])
    # A committed prefix cannot be reconstructed as zeros when its array was
    # removed. Check all three splits before creating or extending any array.
    for split,filename,total in (("h0_cal","h0_cal_scores.npy",protocol["h0_cal_n"]),
                                 ("h0_audit","h0_audit_scores.npy",protocol["h0_audit_n"]),
                                 ("h1","dev_h1_scores.npy",len(protocol["scr_grid_db"]))):
        completed=int(progress["completed"][split])
        need(0<=completed<=total,"Invalid score progress: "+split)
        need(completed==0 or (a.out_dir/filename).is_file(),
             "Score array missing despite committed progress: "+filename+
             "; restore the original array or use a new scoring output directory")
    for split in ("h0_cal","h0_audit"):
        total=protocol[split+"_n"]
        path=a.out_dir/(split+"_scores.npy")
        array=original.new_array(path,(total,columns),path.exists())
        first=int(progress["completed"][split])
        need(0<=first<=total,"Invalid score progress")
        started=time.perf_counter()
        for start in range(first,total,a.chunk):
            stop=min(start+a.chunk,total)
            samples=[generator.make_one(protocol["master_seed"],split,i,-30,10) for i in range(start,stop)]
            need(all(s["label"]==0 and not np.any(s["target"]) for s in samples),"Unexpected H0 target")
            iq=np.stack([s["base"] for s in samples]).astype("complex64")
            array[start:stop]=predictions(models,source,iq,device,a.batch)
            array.flush();progress["completed"][split]=stop
            write_json(a.out_dir/"progress.json",progress)
            if stop==total or stop%10000<a.chunk:
                rate=(stop-first)/max(time.perf_counter()-started,1e-6)
                print(f"[{split}] {stop:,}/{total:,}; {rate:.1f}/s; remaining~{(total-stop)/max(rate,1e-6)/60:.1f}min",flush=True)
        del array
    ns=protocol["h1_scenes_n"];levels=protocol["scr_grid_db"]
    path=a.out_dir/"dev_h1_scores.npy"
    array=original.new_array(path,(len(levels),ns,columns),path.exists())
    samples=[generator.make_one(protocol["master_seed"],"dev_h1",i,-30,10) for i in range(ns)]
    base=np.stack([s["base"] for s in samples]).astype("complex64")
    unit=np.stack([s["unit"] for s in samples]).astype("complex64")
    power=np.array([s["cp"] for s in samples],dtype="float64")
    need(np.isfinite(power).all() and (power>0).all(),"Invalid H1 clutter power")
    first=int(progress["completed"]["h1"])
    need(0<=first<=len(levels),"Invalid H1 progress")
    for j in range(first,len(levels)):
        scr=levels[j]
        for start in range(0,ns,a.chunk):
            stop=min(start+a.chunk,ns)
            amplitude=np.sqrt(power[start:stop]*10**(scr/10))
            iq=(base[start:stop].astype("complex128")+unit[start:stop].astype("complex128")*amplitude[:,None]).astype("complex64")
            array[j,start:stop]=predictions(models,source,iq,device,a.batch)
        array.flush();progress["completed"]["h1"]=j+1
        write_json(a.out_dir/"progress.json",progress)
        print(f"[dev_h1] SCR={scr:+d} dB {j+1}/{len(levels)}",flush=True)
    del array


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root",type=Path,default=Path(__file__).resolve().parent.parent)
    p.add_argument("--run-dir",type=Path)
    p.add_argument("--out-dir",type=Path)
    p.add_argument("--b213-dir",type=Path)
    p.add_argument("--batch",type=int,default=32)
    p.add_argument("--chunk",type=int,default=512)
    p.add_argument("--device",choices=("cuda","cpu"),default="cuda")
    p.add_argument("--cpu-threads",type=int,default=4)
    p.add_argument("--stage",choices=("all","score","report"),default="all")
    a=p.parse_args(argv)
    need(a.batch>0 and a.chunk>=a.batch and a.chunk%a.batch==0,"Invalid scoring batches")
    a.root=a.root.resolve()
    a.run_dir=(a.run_dir or a.root/"output_b271_phase_ars_v1").resolve()
    a.out_dir=(a.out_dir or a.run_dir/"pd_scr").resolve()
    setup(a.cpu_threads)
    if a.stage=="report":
        from b271_report import generate
        generate(a.out_dir,a.root)
        return
    run=read_json(a.run_dir/"run_manifest.json")
    context=resolve_data(a.root,run["bank_dir"],run["cache_dir"])
    ck,sha=verify_l1_checkpoint(run["l1_checkpoint"],context,run["seed"])
    need(sha==run["initialization_sha256"],"Original checkpoint changed")
    proto_path,original,generator=original_protocol(a.root,context,a.b213_dir)
    device=device_for(a.device)
    models,identities=[],[]
    for variant in run["variants"]:
        directory=a.run_dir/variant
        contract=read_json(directory/"training_contract.json")
        path=directory/"best.pt"
        need(contract["status"]==TRAIN_PASS and contract["variant"]==variant
             and contract["initialization_sha256"]==sha,"Incomplete/mismatched training")
        need(digest_file(path)==contract["checkpoint_sha256"],"New checkpoint checksum differs")
        state=load_checkpoint(path)
        need(state["run_fingerprint"]==contract["run_fingerprint"],"Checkpoint internal identity differs")
        need(state["run_config"]["bank_sha"]==context["bc"]["file_sha256"] and
             state["run_config"]["cache_sha"]==context["cc"]["wvd_cache_sha256"],"Training data identity differs")
        model=B271Net(**state["model_config"])
        model.load_state_dict(state["state_dict"],strict=True)
        for key,value in ck["state_dict"].items():
            need(torch.equal(model.state_dict()[key].cpu(),value.cpu()),"Original backbone changed")
        model.to(device).eval()
        for parameter in model.parameters():parameter.requires_grad_(False)
        models.append(model)
        identities.append(dict(variant=variant,path=str(path),sha256=contract["checkpoint_sha256"],
                               selected_epoch=state["epoch"]))
    protocol=dict(version=VERSION,**{k:original[k] for k in SCENE_KEYS},
                  scene_fingerprint=original["scene_fingerprint"],seed=run["seed"],
                  labels=run["variants"]+["L1_TAIL"],checkpoints=identities,
                  original_checkpoint_sha256=sha,b213_protocol_sha256=digest_file(proto_path),
                  bank_sha256=context["bc"]["file_sha256"],batch=a.batch,device=device.type,tf32=False,
                  score_definition="float64(float32 logit1 - float32 logit0)",
                  strict_decision="score > own H0 CAL threshold",
                  code_sha256={p.name:digest_file(p) for p in sorted(Path(__file__).parent.glob("*.py"))},
                  exploratory=True,independent_final=False)
    protocol["fingerprint"]=fingerprint(protocol)
    print(f"B271 full DEV scoring: {protocol['labels']}",flush=True)
    stream(a,protocol,generator,models,load_frozen_sources()[0],device)
    if a.stage=="all":
        from b271_report import generate
        generate(a.out_dir,a.root)
    print("PASS_B271_FULL_DEV_SCORING",flush=True)


if __name__=="__main__":
    main()
