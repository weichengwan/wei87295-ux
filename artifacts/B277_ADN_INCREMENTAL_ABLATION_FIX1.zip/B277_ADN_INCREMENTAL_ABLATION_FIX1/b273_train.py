#!/usr/bin/env python3
"""B271 with plain versus residual SPWVD; TRAIN/VAL only, medium by default."""
from __future__ import annotations
import argparse,gc,math,time
from pathlib import Path
import h5py
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from b271_data import digest_file,fingerprint,load_checkpoint,need,prepare_training,read_json,verify_l1_checkpoint,write_json
from b271_model import B271Net
from b273_model import B273Net
from b273_source import verify_source,verify_pool
from b273_cache import metadata as cache_metadata
from b273_shared import Data,atomic_save,selected_checkpoint,setup,validation,hard_order,fetch_hard,rows,tensors
from source_loader import load_frozen_sources

VERSION='B273_RESIDUAL_SPWVD_TRAIN_V1'
PASS='PASS_B273_FROZEN_ADN_L1__TRAIN_VAL_ONLY'


def code_hashes():
    return {p.name:digest_file(p) for p in sorted(Path(__file__).parent.glob('*.py'))}


@torch.inference_mode()
def evaluate(model,data,context,batch):
    result=validation(model,data,context,batch)
    result['frontend']=model.frontend.diagnostics()
    return result


def better(metrics,best,reference_ce):
    eligible=metrics['val_ce']<=reference_ce+.03
    old=best['val_ce']<=reference_ce+.03
    if eligible!=old:return eligible
    return metrics['pauc01']>best['pauc01']+1e-6 if eligible else metrics['val_ce']<best['val_ce']-1e-6


def train_one(a,context,data,source,l1,pool_path,arm,reference):
    out=a.out_dir/arm
    original_config=source['state']['run_config']
    losses={k:original_config[k] for k in ('hard_weight','consistency_weight','warp_weight')}
    config=dict(version=VERSION,seed=a.seed,arm=arm,epochs=a.epochs,batch=a.batch,
        selected_rows=data.selection,base_lr=a.base_lr,frontend_lr=a.frontend_lr,weight_decay=.001,warmup_epochs=a.warmup_epochs,
        source_b271_sha256=source['sha256'],pool_sha256=digest_file(pool_path),losses=losses,
        bank_sha256=context['bc']['file_sha256'],cache_sha256=context['cc']['wvd_cache_sha256'],
        frontend_config=a.frontend_config,code_sha256=code_hashes())
    fp=fingerprint(config);contract_path=out/'training_contract.json';latest=out/'last_epoch.pt'
    model_config=dict(arm=arm,b271_config=source['state']['model_config'],frontend_config=a.frontend_config)
    if contract_path.exists():
        contract=read_json(contract_path)
        need(contract['run_fingerprint']==fp and digest_file(out/'best.pt')==contract['checkpoint_sha256'],
             'Completed B273 configuration/checkpoint differs; use a new output directory')
        state=load_checkpoint(out/'best.pt')
        need(state['run_fingerprint']==fp and state['epoch']==contract['best_epoch'],'Completed checkpoint identity differs')
        print(f'[{arm}] already complete and verified',flush=True);return contract
    if out.exists() and any(out.iterdir()):
        need(a.resume and latest.is_file(),'Incomplete B273 output; --resume requires last_epoch.pt')
    out.mkdir(exist_ok=True)
    torch.manual_seed(a.seed)
    model=B273Net(**model_config);model.initialize_b271(source['state']);model.to(context['device'])
    optimizer=torch.optim.AdamW(model.parameter_groups(a.base_lr,a.frontend_lr))
    initial=evaluate(model,data,context,a.batch)
    if arm=='residual':
        need(abs(initial['val_ce']-reference['val_ce'])<1e-6 and
             abs(initial['pauc01']-reference['pauc01'])<1e-9,'Zero-progress residual model does not replay the exact B271 VAL subset')
    def snapshot(epoch,metrics):
        return dict(version=VERSION,state_dict=model.state_dict(),model_config=model_config,epoch=epoch,
            val_metrics=metrics,run_config=config,run_fingerprint=fp,
            validation_eligible=metrics['val_ce']<=reference['val_ce']+.03)
    history=[];start=1;best_epoch=0;best_metrics=initial
    if latest.exists():
        state=load_checkpoint(latest)
        need(state['run_fingerprint']==fp and state['model_config']==model_config,'Resume configuration changed')
        best_epoch=state['best_epoch'];best_metrics=state['best_metrics'];best_sha=state['best_checkpoint_sha256']
        selected_checkpoint(out/'best.pt',best_sha,fp,model_config,best_epoch,best_metrics['pauc01'])
        model.load_state_dict(state['state_dict'],strict=True);optimizer.load_state_dict(state['optimizer'])
        history=state['history'];start=state['epoch']+1
        torch.set_rng_state(state['torch_rng'])
        if context['device'].type=='cuda':torch.cuda.set_rng_state_all(state['cuda_rng'])
    else:
        atomic_save(out/'best.pt',snapshot(0,initial));best_sha=digest_file(out/'best.pt')
        write_json(out/'initial_validation.json',initial)
    reference_loss=load_frozen_sources()[2]
    with h5py.File(pool_path,'r') as pool:
        for epoch in range(start,a.epochs+1):
            started=time.perf_counter()
            model.frontend.set_epoch(epoch,a.warmup_epochs)
            bank=hard_order(model,data,context,pool,a.batch) if losses['hard_weight'] else None
            model.train();totals=np.zeros(5);seen=0
            for step,indices in enumerate(context['b210'].indices(data.labels,epoch,a.batch,a.seed)):
                maps,iq,labels=data.fetch('train',indices);n=len(indices)
                if bank is not None:
                    chosen=bank[(np.arange(16)+16*step)%len(bank)]
                    extra_maps,extra_iq=fetch_hard(chosen,data,pool)
                    maps=np.concatenate((maps,extra_maps));iq=np.concatenate((iq,extra_iq))
                images,iq_tensor=tensors(context,maps,iq);y=torch.from_numpy(labels).to(context['device'])
                optimizer.zero_grad(set_to_none=True)
                logits,aux=model(images,iq_tensor,return_aux=True)
                aux={k:v[:n] if torch.is_tensor(v) and v.ndim and len(v)==len(images) else v for k,v in aux.items()}
                original,_,_,_=reference_loss.compute_loss('L1_TAIL',logits[:n],y,aux)
                positive=torch.nonzero(y==1,as_tuple=False).flatten();hard=logits.new_zeros(())
                if bank is not None:
                    margin=logits[:,1]-logits[:,0]
                    hard=F.softplus(.5+margin[n:,None]-margin[positive][None]).mean()
                consistency=logits.new_zeros(())
                if losses['consistency_weight'] and positive.numel():
                    chosen=positive[:4];local=chosen.cpu().numpy()
                    raw_rows=data.original_rows('train',np.asarray(indices)[local])
                    target=rows(data.iq['train']['target_iq'],raw_rows).astype('complex64')
                    stronger=iq[local]+np.float32(10**(3/20)-1)*target
                    stronger_iq=torch.from_numpy(stronger).to(context['device'])
                    z=model(None,stronger_iq)
                    consistency=F.relu((logits[chosen,1]-logits[chosen,0]).detach()-(z[:,1]-z[:,0])).mean()
                warp=aux['offset_regularizer']
                loss=original+losses['hard_weight']*hard+losses['consistency_weight']*consistency+losses['warp_weight']*warp
                need(torch.isfinite(loss).item(),'Nonfinite objective')
                loss.backward();norm=torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],1.)
                need(torch.isfinite(norm).item(),'Nonfinite trainable-module gradient');optimizer.step()
                totals+=np.array([float(v.detach()) for v in (loss,original,hard,consistency,warp)])*n;seen+=n
            metrics=evaluate(model,data,context,a.batch)
            if better(metrics,best_metrics,reference['val_ce']):
                best_epoch=epoch;best_metrics=metrics
                atomic_save(out/'best.pt',snapshot(epoch,metrics));best_sha=digest_file(out/'best.pt')
            row=dict(epoch=epoch,train_loss=float(totals[0]/seen),original_loss=float(totals[1]/seen),
                hard_rank_loss=float(totals[2]/seen),consistency_loss=float(totals[3]/seen),offset_penalty=float(totals[4]/seen),
                **metrics,ce_guard_pass=metrics['val_ce']<=reference['val_ce']+.03,best_epoch=best_epoch,
                elapsed_s=time.perf_counter()-started)
            history.append(row);state=snapshot(epoch,metrics)
            state.update(optimizer=optimizer.state_dict(),history=history,best_epoch=best_epoch,best_metrics=best_metrics,
                best_checkpoint_sha256=best_sha,torch_rng=torch.get_rng_state(),
                cuda_rng=torch.cuda.get_rng_state_all() if context['device'].type=='cuda' else [])
            atomic_save(latest,state);pd.DataFrame(history).to_csv(out/'train_val_history.csv',index=False)
            print(f"[{arm}] {epoch}/{a.epochs} VAL_CE={metrics['val_ce']:.6f} pAUC01={metrics['pauc01']:.6f} "
                  f"best_epoch={best_epoch} alpha={metrics['frontend']['alpha']:.4f} time={row['elapsed_s']:.1f}s",flush=True)
    best=selected_checkpoint(out/'best.pt',best_sha,fp,model_config,best_epoch,best_metrics['pauc01'])
    model.load_state_dict(best['state_dict'],strict=True);restored=evaluate(model,data,context,a.batch)
    need(abs(restored['val_ce']-best_metrics['val_ce'])<1e-6 and
         abs(restored['pauc01']-best_metrics['pauc01'])<1e-9,'Selected VAL checkpoint replay differs')
    for key,value in l1['state_dict'].items():
        need(torch.equal(model.state_dict()[key].cpu(),value.cpu()),'Frozen original ADN/L1 tensor changed: '+key)
    contract=dict(version=VERSION,status=PASS,arm=arm,run_fingerprint=fp,run_config=config,model_config=model_config,
        source_b271_sha256=source['sha256'],best_epoch=best_epoch,epochs_executed=a.epochs,
        selected_validation=restored,reference_b271_validation=reference,checkpoint_sha256=best_sha,
        selected_passes_ce_guard=best['validation_eligible'],selected_frontend_trained=arm=='residual' and best_epoch>0,frontend=restored['frontend'],
        selection='VAL pAUC[0,.01], CE<=same-subset source B271+0.03; epoch0 eligible only if guard passes; otherwise best-CE diagnostic fallback',
        trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),
        original_weights_and_bn_unchanged=True,original_cal_audit_dev_used=False,one_db_gain_established=False)
    write_json(contract_path,contract)
    print(f"[{arm}] complete; selected epoch={best_epoch}; CE guard={best['validation_eligible']}",flush=True)
    del model,optimizer;gc.collect()
    if context['device'].type=='cuda':torch.cuda.empty_cache()
    return contract


def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    p.add_argument('--source-run',type=Path);p.add_argument('--out-dir',type=Path)
    p.add_argument('--arms',default='plain,residual')
    p.add_argument('--baseline-run',type=Path)
    p.add_argument('--train-limit',type=int,default=16000);p.add_argument('--val-limit',type=int,default=3000)
    p.add_argument('--epochs',type=int,default=4);p.add_argument('--batch',type=int,default=32)
    p.add_argument('--base-lr',type=float,default=3e-5);p.add_argument('--frontend-lr',type=float,default=1e-3)
    p.add_argument('--time-length',type=int,default=9);p.add_argument('--lag-half',type=int,default=64)
    p.add_argument('--alpha-max',type=float,default=.75);p.add_argument('--initial-alpha',type=float,default=.25)
    p.add_argument('--warmup-epochs',type=int,default=2);p.add_argument('--component-batch',type=int,default=8)
    p.add_argument('--seed',type=int,default=20261022);p.add_argument('--device',choices=('cuda','cpu'),default='cuda')
    p.add_argument('--cpu-threads',type=int,default=4);p.add_argument('--resume',action='store_true')
    a=p.parse_args(argv);a.root=a.root.resolve()
    a.source_run=(a.source_run or a.root/'output_b271_phase_ars_v1').resolve()
    a.out_dir=(a.out_dir or a.root/'output_b273_residual_spwvd_v1').resolve();a.arms=a.arms.split(',')
    a.baseline_run=(a.baseline_run or a.root/'output_b272_b271_ahpm_v1').resolve()
    need(len(a.arms)==len(set(a.arms)) and set(a.arms)<=set(('plain','residual')) and a.arms,'Invalid arms')
    need(a.batch>0 and a.batch%2==0 and a.epochs>0 and a.cpu_threads>0,'Invalid training budget')
    need(0<a.train_limit<=30000 and 0<a.val_limit<=5000 and a.train_limit%2==a.val_limit%2==0,'Invalid balanced subset')
    need(all(math.isfinite(v) and v>0 for v in (a.base_lr,a.frontend_lr)),'Invalid learning rate')
    need(a.warmup_epochs>=1 and a.component_batch>=1 and a.time_length>=1 and a.time_length%2==1 and 1<=a.lag_half<256 and
         0<a.initial_alpha<a.alpha_max<1,'Invalid SPWVD configuration')
    a.frontend_config=dict(time_length=a.time_length,lag_half=a.lag_half,alpha_max=a.alpha_max,initial_alpha=a.initial_alpha,component_batch=a.component_batch)
    need(a.out_dir!=a.source_run,'Choose a separate B273 output directory')
    return a



def main(argv=None):
    a=cli(argv);setup(a.cpu_threads)
    run=read_json(a.source_run/'run_manifest.json')
    context=prepare_training(a.root,bank_dir=run['bank_dir'],cache_dir=run['cache_dir'],device=a.device)
    l1,l1_sha=verify_l1_checkpoint(run['l1_checkpoint'],context,run['seed'])
    source=verify_source(a.source_run,context,l1,l1_sha);pool_path,pool_info=verify_pool(source,context)
    from b271_score import original_protocol
    _,original,_=original_protocol(a.root,context)  # JSON metadata only, no CAL/AUDIT/H1 arrays.
    data=Data(context,a.train_limit,a.val_limit,a.seed)
    try:
        cache=cache_metadata(a.baseline_run,source,context,original,a.batch,context['device'],training=a,selection=data.selection)
        print('Preflight: B272 matched-control metadata verified; CAL/AUDIT/H1 score arrays not opened for training',flush=True)
        reference_model=B271Net(**source['state']['model_config'])
        reference_model.load_state_dict(source['state']['state_dict'],strict=True)
        reference_model.to(context['device']).eval();reference=validation(reference_model,data,context,a.batch)
        del reference_model
        if context['device'].type=='cuda':torch.cuda.empty_cache()
        manifest=dict(version=VERSION,arms=a.arms,seed=a.seed,source_run=str(a.source_run),source_b271_sha256=source['sha256'],
            bank_dir=str(context['bank_dir']),cache_dir=str(context['cache_dir']),l1_checkpoint=run['l1_checkpoint'],
            original_l1_sha256=l1_sha,pool=pool_info,selected_rows=data.selection,reference_validation=reference,
            baseline_run=str(a.baseline_run),baseline_protocol_sha256=cache['source_protocol_sha256'],frontend_config=a.frontend_config,
            budget=dict(epochs=a.epochs,batch=a.batch,train_limit=a.train_limit,val_limit=a.val_limit))
        a.out_dir.mkdir(parents=True,exist_ok=True);path=a.out_dir/'run_manifest.json'
        if path.exists():need(read_json(path)==manifest,'Run manifest changed; use a separate output directory')
        else:
            need(not any(a.out_dir.iterdir()),'Nonempty output without run manifest');write_json(path,manifest)
        print(f'B273 SPWVD frontend: {a.arms}; TRAIN={len(data.labels)} VAL={len(data.selected["val"])}; '
              f'existing H0 retained={pool_info["retained"]}; new H0 proposals=0',flush=True)
        for arm in a.arms:train_one(a,context,data,source,l1,pool_path,arm,reference)
    finally:data.close()
    print(PASS,flush=True)


if __name__=='__main__':main()
