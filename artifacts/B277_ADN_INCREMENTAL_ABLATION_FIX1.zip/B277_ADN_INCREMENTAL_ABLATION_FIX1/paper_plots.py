#!/usr/bin/env python3
"""Standalone CSV-only paper plots. Does not import or modify fingerprinted training code."""
from __future__ import annotations
import argparse,csv,hashlib,json,math,os
from pathlib import Path

NAMES_B272={'B271 continued (control)':('#777777','--'),'B271 + AHPM3':('#d62728','-'),
    'B271 + AHPM2':('#9467bd','-'),'B271 frozen':('#1f77b4','-'),'L1-Tail':('#2ca02c',':')}


def require(condition,message):
    if not condition:raise ValueError(message)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_csv(path):
    with Path(path).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))


def save_csv(path,rows):
    if rows:
        with Path(path).open('w',encoding='utf-8',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def load_curves(path,nominal):
    rows=read_csv(path);selected=[]
    for r in rows:
        if not math.isclose(float(r['nominal_pfa']),nominal,rel_tol=1e-12):continue
        method=r['method'];x=float(r['scr_db']);pd=float(r['pd'])
        require(method and math.isfinite(x) and math.isfinite(pd) and 0<=pd<=1,'Invalid method/SCR/Pd')
        q=dict(method=method,scr_db=x,pd=pd)
        if r.get('hits','')!='' and r.get('n_h1','')!='':
            hits=int(r['hits']);n=int(r['n_h1'])
            require(n>0 and 0<=hits<=n and abs(hits/n-pd)<1e-12,'Pd differs from recorded hits/n_h1')
            q.update(hits=hits,n_h1=n)
        selected.append(q)
    methods=list(dict.fromkeys(r['method'] for r in selected));require(methods,'No curves for requested nominal Pfa')
    groups={m:sorted([r for r in selected if r['method']==m],key=lambda r:r['scr_db']) for m in methods}
    grid=None
    for m,rs in groups.items():
        x=[r['scr_db'] for r in rs]
        require(len(x)>=2 and len(set(x))==len(x),'Duplicate or insufficient SCR points: '+m)
        require(grid is None or x==grid,'Methods use different SCR grids');grid=x
    return methods,groups


def choose_ours(methods,explicit=None):
    if explicit:
        require(explicit in methods,'Requested method absent from CSV: '+explicit);return explicit
    # Fixed name defaults only; never select by the best DEV metric.
    for name in ('B271 + AHPM3','B271 + AHPM2','ADN/L1 + phase-ARS'):
        if name in methods:return name
    raise ValueError('Use --ours with the exact proposed-method CSV label')


def style_for(method,index,ours,b272,palette):
    color,linestyle=NAMES_B272.get(method,(palette[index%len(palette)],'-')) if b272 else (palette[index%len(palette)],'-')
    result=dict(color=color,linestyle=linestyle,marker='o',markersize=3,markevery=3)
    if method==ours:
        result.update(color='black',linestyle='--',marker='v',markersize=5,
            markerfacecolor='white',markeredgecolor='black',markeredgewidth=1.,markevery=2)
    return result


def precision_f1(pd,pfa,prevalence):
    require(0<=pd<=1 and 0<=pfa<=1 and 0<prevalence<1,'Invalid rates or target prevalence')
    tp=prevalence*pd;fp=(1-prevalence)*pfa;fn=prevalence*(1-pd)
    precision=tp/(tp+fp) if tp+fp else None
    return precision,2*tp/(2*tp+fp+fn)


def wilson(k,n):
    z=1.959963984540054;v=k/n;d=1+z*z/n
    center=(v+z*z/(2*n))/d
    radius=z*math.sqrt(v*(1-v)/n+z*z/(4*n*n))/d
    return max(0.,center-radius),min(1.,center+radius)


def load_false_alarms(path,methods,nominal):
    all_rows=read_csv(path);result={}
    for m in methods:
        matches=[r for r in all_rows if r['method']==m and math.isclose(float(r['nominal_pfa']),nominal,rel_tol=1e-12)]
        require(len(matches)==1,'Missing/duplicate false-alarm metrics: '+m)
        r=matches[0];fp=int(r['audit_false_alarms']);n=int(r['audit_n'])
        require(n>0 and 0<=fp<=n,'Invalid H0 false-alarm counts')
        p=fp/n;lo,hi=wilson(fp,n)
        require(abs(float(r['actual_pfa'])-p)<1e-12,'Actual Pfa differs from FP/N0')
        result[m]=dict(method=m,nominal_pfa=nominal,false_alarms=fp,n_h0=n,pfa_empty_cut=p,
            ci95_low=lo,ci95_high=hi,unit='one IQ512 CUT',same_h0_reused_across_scr=True)
    return result


def generate(curves,out,ours=None,nominal=1e-4,metrics=None,prevalence=None):
    curves=Path(curves).resolve();out=Path(out).resolve()
    require(metrics is not None or prevalence is None,'--prevalence also requires --metrics for measured H0 Pfa')
    if prevalence is not None:require(0<prevalence<1,'Target prevalence must be strictly between0 and1')
    methods,groups=load_curves(curves,nominal);ours=choose_ours(methods,ours)
    out.mkdir(parents=True,exist_ok=True)
    os.environ.setdefault('MPLCONFIGDIR',str(out/'.matplotlib_cache'))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    palette=plt.rcParams['axes.prop_cycle'].by_key()['color'];b272=any(m.startswith('B271 + AHPM') for m in methods)
    styles={m:style_for(m,i,ours,b272,palette) for i,m in enumerate(methods)}
    products=[];stem=curves.stem+'_paper';pfatag=f'{nominal:.0e}'
    def save_figure(fig,kind):
        fig.tight_layout()
        for ext in ('pdf','png','svg'):
            target=out/f'{stem}_{kind}_pfa_{pfatag}.{ext}'
            fig.savefig(target,dpi=300);products.append(target.name)
        plt.close(fig)
    def line_plot(kind,ylabel,values,title=None):
        fig,ax=plt.subplots(figsize=(8,5))
        for m in methods:
            x=[r['scr_db'] for r in groups[m]];y=values[m]
            ax.plot(x,[math.nan if v is None else v for v in y],label=m,**styles[m])
        grid=[r['scr_db'] for r in groups[methods[0]]]
        ax.set(xlabel='SCR (dB)',ylabel=ylabel,xlim=(min(grid),max(grid)),ylim=(0,1.02))
        if title:ax.set_title(title,fontsize=10)
        ax.grid(alpha=.25);ax.legend(fontsize=8);save_figure(fig,kind)
    line_plot('pd',r'$P_d$',{m:[r['pd'] for r in groups[m]] for m in methods})
    # Save the exact plotted values; sorting is the only numerical ordering change.
    raw=[dict(method=m,nominal_pfa=nominal,**{k:v for k,v in r.items() if k!='method'}) for m in methods for r in groups[m]]
    save_csv(out/f'{stem}_pd_source.csv',raw)
    false=None
    if metrics is not None:
        metrics=Path(metrics).resolve();false=load_false_alarms(metrics,methods,nominal)
        save_csv(out/f'{stem}_empty_pfa.csv',[false[m] for m in methods])
        fig,ax=plt.subplots(figsize=(9,5));positions=list(range(len(methods)))
        means=[false[m]['pfa_empty_cut'] for m in methods]
        lower=[means[i]-false[m]['ci95_low'] for i,m in enumerate(methods)]
        upper=[false[m]['ci95_high']-means[i] for i,m in enumerate(methods)]
        ax.bar(positions,means,color=[styles[m]['color'] for m in methods],alpha=.8)
        ax.errorbar(positions,means,yerr=[lower,upper],fmt='none',ecolor='black',capsize=4)
        ax.axhline(nominal,color='#555555',linestyle=':',label='Nominal Pfa')
        ax.set_xticks(positions,methods,rotation=15,ha='right',fontsize=8)
        ax.set_ylabel(r'$P_{fa}$');ax.set_ylim(bottom=0);ax.grid(axis='y',alpha=.25);ax.legend(fontsize=8)
        save_figure(fig,'empty_pfa_ci95')
    if prevalence is not None:
        precision={};f1={};extra=[]
        for m in methods:
            precision[m]=[];f1[m]=[]
            for r in groups[m]:
                p,f=precision_f1(r['pd'],false[m]['pfa_empty_cut'],prevalence)
                precision[m].append(p);f1[m].append(f)
                extra.append(dict(method=m,nominal_pfa=nominal,scr_db=r['scr_db'],assumed_target_prevalence=prevalence,
                    pd=r['pd'],pfa_empty_cut=false[m]['pfa_empty_cut'],precision='' if p is None else p,f1=f,
                    scope='Standardized assumed-prevalence scenario; not measured deployment precision'))
        tag=f'prior_{prevalence:g}'
        save_csv(out/f'{stem}_{tag}_precision_f1.csv',extra)
        title=f'Assumed target prevalence $\\pi$={prevalence:g}'
        line_plot(tag+'_precision','Precision',precision,title)
        line_plot(tag+'_f1','F1',f1,title)
    manifest=dict(version='PAPER_PLOTS_CSV_V1',curves_file=str(curves),curves_sha256=sha(curves),
        metrics_file=str(metrics) if metrics else None,metrics_sha256=sha(metrics) if metrics else None,
        ours=ours,nominal_pfa=nominal,styles=styles,products=products,
        source_values_unchanged=True,smoothing=False,curve_shifting=False,model_or_threshold_modified=False,
        assumed_target_prevalence=prevalence,precision_f1_is_scenario_analysis=prevalence is not None,
        empty_pfa_unit='CUT; not frame or pixel; H0 has no target SCR',
        scope='Development/source result retains its original evaluation status; styling does not create final-test evidence')
    (out/f'{stem}_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'Plotted {len(methods)} methods; proposed={ours}; source Pd unchanged',flush=True)
    print('Output: '+str(out),flush=True)
    return manifest


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--curves',required=True,type=Path);p.add_argument('--out-dir',type=Path)
    p.add_argument('--ours');p.add_argument('--pfa',type=float,default=1e-4)
    p.add_argument('--metrics',type=Path);p.add_argument('--prevalence',type=float)
    a=p.parse_args(argv);require(0<a.pfa<1,'Invalid nominal Pfa')
    out=a.out_dir or a.curves.resolve().parent/'paper_figures'
    generate(a.curves,out,a.ours,a.pfa,a.metrics,a.prevalence)


if __name__=='__main__':main()
