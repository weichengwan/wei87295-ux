"""Paired medium DEV, Pfa1e-4 only; infer only the newly trained single branch."""
from __future__ import annotations
import argparse
from pathlib import Path
import torch
from b271_data import device_for,digest_file,fingerprint,load_checkpoint,need,read_json
from b271_score import SCENE_KEYS,original_protocol
from b273_shared import setup
from b273_score import stream
from b274_data import resolve
from b274_model import SingleBranch,METHOD
from b274_train import PASS,code_hashes
from b274_baselines import metadata,arrays

VERSION='B274_SINGLE_SPWVD_RESNET18_SCORE_V1'


class AlreadyMapped:
    """The new frontend supplies its complete legacy TF image; do not remap it."""
    @staticmethod
    def map_to_adn_input(images):
        need(images.ndim==4 and images.shape[1:]==(3,224,224),'Expected complete SPWVD image')
        return images


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    p.add_argument('--run-dir',type=Path);p.add_argument('--out-dir',type=Path);p.add_argument('--b213-dir',type=Path);p.add_argument('--baseline-dir',type=Path)
    p.add_argument('--batch',type=int,default=32);p.add_argument('--chunk',type=int,default=512)
    p.add_argument('--device',choices=('cuda','cpu'),default='cuda');p.add_argument('--cpu-threads',type=int,default=4)
    p.add_argument('--stage',choices=('all','score','report'),default='all');a=p.parse_args(argv)
    a.root=a.root.resolve();a.run_dir=(a.run_dir or a.root/'output_b274_single_spwvd_resnet18_v1').resolve()
    a.out_dir=(a.out_dir or a.run_dir/'pd_scr_medium').resolve()
    need(a.batch==32 and a.chunk>=a.batch and a.chunk%a.batch==0 and a.cpu_threads>0,'Use batch32 for paired baseline numerical settings')
    setup(a.cpu_threads)
    if a.stage=='report':
        from b274_report import generate
        return generate(a.out_dir)
    run=read_json(a.run_dir/'run_manifest.json');config=run['run_config'];context=resolve(a.root,run['bank_dir'])
    need(context['bc']['file_sha256']==config['bank_sha256'] and run['run_fingerprint']==fingerprint(config),'Training bank/run changed')
    _,old,generator=original_protocol(a.root,context,a.b213_dir);device=device_for(a.device)
    baseline=a.baseline_dir or a.root/'output_b273_residual_spwvd_v1/pd_scr_medium'
    info=metadata(baseline,context,old,device,config['selected_rows']);cached,reuse=arrays(info)
    contract=read_json(a.run_dir/'training_contract.json');checkpoint=a.run_dir/'best.pt'
    need(contract['status']==PASS and digest_file(checkpoint)==contract['checkpoint_sha256'] and contract['run_fingerprint']==run['run_fingerprint'],'Training/checkpoint identity differs')
    state=load_checkpoint(checkpoint)
    need(state['run_config']==config and state['epoch']==contract['best_epoch'] and config['code_sha256']==code_hashes(),'Selected model/code changed')
    model=SingleBranch(config['backend'],config['scale']);model.load_state_dict(state['state_dict'],strict=True)
    model.to(device).eval()
    for parameter in model.parameters():parameter.requires_grad_(False)
    scene={k:old[k] for k in SCENE_KEYS};scene.update(h0_cal_n=500000,h0_audit_n=200000)
    protocol=dict(version=VERSION,**scene,scene_fingerprint=fingerprint(scene),nominal_pfas=[1e-4],
        labels=['SINGLE']+info['p']['labels'],names={'SINGLE':METHOD,**info['names']},backend=config['backend'],
        checkpoint=dict(sha256=contract['checkpoint_sha256'],selected_epoch=contract['best_epoch'],validation=contract['selected_validation']),
        training_run_fingerprint=run['run_fingerprint'],reused_baselines=reuse,batch=a.batch,device=device.type,tf32=False,
        code_sha256=code_hashes(),score_definition='float64(float32 logit1 - float32 logit0)',
        strict_decision='score > own H0 CAL threshold',scope='Paired medium exposed DEV, not independent FINAL; different training procedure from B271/B273; historical screenshot pairing unverified')
    protocol['fingerprint']=fingerprint(protocol)
    print(f'B274 CAL500000 CHECK200000 H1=1024x37; new model GPU forwards only; batch={a.batch}',flush=True)
    stream(a,protocol,generator,[model],AlreadyMapped(),device,cached)
    if a.stage=='all':
        from b274_report import generate
        generate(a.out_dir)
    print('PASS_B274_SINGLE_SPWVD_MEDIUM_DEV__STOP_NO_AUTO_FULL',flush=True)


if __name__=='__main__':main()
