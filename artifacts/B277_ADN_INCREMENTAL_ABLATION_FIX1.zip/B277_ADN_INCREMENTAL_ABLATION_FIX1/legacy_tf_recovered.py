"""Unmodified frontend functions recovered from the uploaded B266 descendant.
Not the missing original B233/B236 script; no MSDA/TFAM code is used here.
"""
import numpy as np

def spwvd_torch(iq, time_bins=128, nfft=128, lag_half=24, smooth_time=5):
    """Documented SPWVD-style discrete estimator: smoothed lag products + FFT.

    Implements a non-author-exact discretization of Eq.(4) of Wang et al.2024.
    IQ[N,512] complex64 -> real[N,128,128]. Zero boundary, Hann lag window,
    frequency smoothing via lag window and 5-step time-domain moving average.
    """
    import torch
    import torch.nn.functional as F
    assert iq.ndim==2 and iq.shape[1]==512 and iq.is_complex()
    B,N=iq.shape
    tc=torch.arange(time_bins,device=iq.device,dtype=torch.long)*4+2
    tau=torch.arange(-lag_half,lag_half+1,device=iq.device,dtype=torch.long)
    pos=tc[None,:]+tau[:,None]
    neg=tc[None,:]-tau[:,None]
    mask=(pos>=0)&(pos<N)&(neg>=0)&(neg<N)
    pos=pos.clamp(0,N-1);neg=neg.clamp(0,N-1)
    corr=iq[:,pos]*torch.conj(iq[:,neg])
    corr=corr*mask.to(iq.real.dtype)[None,:,:]
    lag_window=torch.hann_window(len(tau)+2,periodic=False,device=iq.device,dtype=iq.real.dtype)[1:-1]
    corr=corr*lag_window[None,:,None]
    # centered FFT representation, cropped to positive/negative 128-bin Doppler axis
    pad=torch.zeros((B,nfft,time_bins),device=iq.device,dtype=iq.dtype)
    pad[:,:lag_half+1,:]=corr[:,lag_half:,:]
    pad[:,-lag_half:,:]=corr[:,:lag_half,:]
    w=torch.fft.fftshift(torch.fft.fft(pad,n=nfft,dim=1),dim=1).real
    if smooth_time>1:
        w=F.avg_pool1d(w.reshape(B*nfft,1,time_bins),smooth_time,stride=1,padding=smooth_time//2).reshape(B,nfft,time_bins)
    return w

def tf_image(iq, scale):
    import torch
    import torch.nn.functional as F
    if isinstance(iq,np.ndarray):
        iq=torch.from_numpy(np.ascontiguousarray(iq.astype(np.complex64,copy=False)))
    sp=spwvd_torch(iq)
    feat=torch.log1p(torch.abs(sp))/float(scale)
    img=F.interpolate(feat[:,None],size=(224,224),mode='bilinear',align_corners=False)
    return img.repeat(1,3,1,1).float()
