"""SPWVD -> ADN/WCSG/TFCG -> aligned phase-ARS, initialized from B274.

This is an experimental migration, not a demonstrated novel detector. The
SPWVD estimator and ARS are attributed to their sources in README.md.
"""
from copy import deepcopy
import torch
from torch import nn
import torch.nn.functional as F
from b271_data import need
from b271_model import BoundedResampler
from b274_model import Frontend,SingleBranch
from source_loader import load_frozen_sources

ARMS=('continued','adn','phase')
NAMES={'continued':'SPWVD ResNet18 continued (control)',
       'adn':'SPWVD ADN/WCSG/TFCG',
       'phase':'SPWVD ADN/WCSG/TFCG + aligned phase-ARS'}


class SPWVDPhaseEvidence(nn.Module):
    """B271 phase-curvature features, aligned to the actual B274 SPWVD grid.

    x[t+k]conj(x[t-k]) has q=2*f modulo1. Here q bins are exact FFT128
    bins (no WVD512->128 resize offset), and time centers are4*j+2.
    Output axes are frequency,time, matching the recovered SPWVD image.
    """
    def __init__(self):
        super().__init__();self.register_buffer('window',torch.hann_window(64))

    def forward(self,iq):
        need(iq.ndim==2 and iq.shape[1]==512 and iq.is_complex(),'Expected complex IQ512')
        power=iq.abs().square().mean(1,keepdim=True)
        x=iq/power.clamp_min(1e-20).sqrt()
        z=torch.fft.fftshift(torch.fft.fft(x.reshape(-1,8,64)*self.window,dim=-1),dim=-1)
        p=z.abs().square();u=z/z.abs().clamp_min(1e-7)
        curvature=u[:,2:]*u[:,:-2]*u[:,1:-1].conj().square()
        reliability=torch.minimum(torch.minimum(p[:,2:],p[:,:-2]),p[:,1:-1]).sqrt()
        avg=lambda v:F.avg_pool2d(v[:,None],(3,1),stride=1,padding=(1,0),count_include_pad=False)[:,0]
        c=(avg(curvature.real*reliability).square()+avg(curvature.imag*reliability).square()+1e-20).sqrt()/avg(reliability).clamp_min(1e-7)
        c=F.pad(c.clamp(0,1),(0,0,1,1))
        q=(torch.arange(128,device=x.device,dtype=x.real.dtype)-64)/128
        j=(q/2+.5)*64;left=j.floor().long()%64;fraction=(j-j.floor())[None,None]
        sample=lambda v,shift:v.index_select(-1,(left+shift)%64)*(1-fraction)+v.index_select(-1,(left+shift+1)%64)*fraction
        folded=sample(p,0)+sample(p,32)
        coherence=(sample(c*p,0)+sample(c*p,32))/folded.clamp_min(1e-7)
        db=10*torch.log10(folded.clamp_min(1e-10))
        energy=((db-db.amax((1,2),keepdim=True)).clamp(-40,0)+40)/40
        valid=(power>1e-20).to(energy.dtype)[:,:,None]
        raw=torch.stack((energy*valid,coherence.clamp(0,1)*valid),1) # N,2,time8,freq128
        # Block j is centered at31.5+64*j; SPWVD center t is4*j+2.
        time=(4*torch.arange(128,device=x.device,dtype=x.real.dtype)+2+.5)*2/512-1
        freq=(torch.arange(128,device=x.device,dtype=x.real.dtype)+.5)*2/128-1
        gt,gf=torch.meshgrid(time,freq,indexing='ij')
        grid=torch.stack((gf,gt),-1)[None].expand(len(iq),-1,-1,-1)
        aligned=F.grid_sample(raw,grid,mode='bilinear',padding_mode='border',align_corners=False)
        return aligned.transpose(-1,-2).contiguous()


class CenteredWCSG(nn.Module):
    """Original WCSG with a constant initial gain divided out, not a new paper module."""
    def __init__(self,gate):
        super().__init__();self.gate=gate
        nn.init.zeros_(self.gate.out.weight)
        initial=self.gate.mask_floor+(1-self.gate.mask_floor)*torch.sigmoid(self.gate.out.bias.detach())
        self.register_buffer('initial_gain',initial.reshape(1,1,1,1).clone())
    def forward(self,x):
        y,aux=self.gate(x);return y/self.initial_gain,aux


class MigratedADN(nn.Module):
    def __init__(self,backend,scale,phase=True):
        super().__init__();self.frontend=Frontend(backend,scale)
        source,trainer,reference=load_frozen_sources()
        original=trainer.ProposedWrapper(source,dict(reference.CFG))
        self.detector=original.detector;self.suppressor=CenteredWCSG(original.suppressor)
        self.use_phase=bool(phase)
        if phase:
            self.phase=SPWVDPhaseEvidence()
            self.resample1=BoundedResampler(64,.75)
            self.resample3=BoundedResampler(128,.75)

    def prepared_forward(self,images,iq,return_aux=False):
        x,aux=self.suppressor(images);d=self.detector
        x=d.relu(d.bn1(d.conv1(x)));penalties=[];stats=[]
        guide=self.phase(iq) if self.use_phase else None
        if self.use_phase:
            if return_aux:x,p,s=self.resample1(x,guide,True);penalties.append(p);stats.append(s)
            else:x=self.resample1(x,guide)
        x=d.layer2(d.layer1(d.maxpool(x)))
        if self.use_phase:
            if return_aux:x,p,s=self.resample3(x,guide,True);penalties.append(p);stats.append(s)
            else:x=self.resample3(x,guide)
        x=d.layer4(d.layer3(x));logits=d.fc(torch.flatten(d.avgpool(x),1))
        if return_aux:
            aux.update(offset_regularizer=sum(penalties,logits.new_zeros(())),offset_diagnostics=stats)
            return logits,aux
        return logits
    def forward(self,iq,return_aux=False):return self.prepared_forward(self.frontend.images(iq),iq,return_aux)


def make_model(arm,backend,scale):
    need(arm in ARMS,'Unknown migration arm')
    return SingleBranch(backend,scale) if arm=='continued' else MigratedADN(backend,scale,arm=='phase')


def migrate(model,teacher,arm):
    """Copy every ResNet tensor; expand first conv to an ACB with zero side outputs.

    TFCG is identity by original zero expansion. WCSG is centered as above.
    ARS has original zero offsets. No WVD checkpoint is approximately loaded.
    """
    if arm=='continued':
        model.net.load_state_dict(teacher.net.state_dict(),strict=True)
        return {n for n,_ in model.named_parameters()}
    copied=set();src=teacher.net;dst=model.detector
    for name in ('conv1','bn1','fc'):
        getattr(dst,name).load_state_dict(getattr(src,name).state_dict(),strict=True)
        copied.update('detector.'+name+'.'+k for k,_ in getattr(dst,name).named_parameters())
    for stage in ('layer1','layer2','layer3','layer4'):
        need(len(getattr(src,stage))==2,'Expected standard ResNet18[2,2,2,2]')
        for i,(s,d) in enumerate(zip(getattr(src,stage),getattr(dst,stage))):
            prefix=f'detector.{stage}.{i}.'
            for old,new in [('conv1','conv3'),('bn1','bn3'),('conv2','conv2'),('bn2','bn2')]:
                getattr(d,new).load_state_dict(getattr(s,old).state_dict(),strict=True)
                copied.update(prefix+new+'.'+k for k,_ in getattr(d,new).named_parameters())
            need((d.downsample is None)==(s.downsample is None),'Shortcut topology differs')
            if d.downsample is not None:
                d.downsample.load_state_dict(s.downsample.state_dict(),strict=True)
                copied.update(prefix+'downsample.'+k for k,_ in d.downsample.named_parameters())
            for bn in (d.ver_bn,d.hor_bn):nn.init.zeros_(bn.weight);nn.init.zeros_(bn.bias)
    return copied


@torch.inference_mode()
def verify_initial(model,teacher,iq,tolerance=5e-5):
    model.eval();teacher.eval();images=teacher.frontend.images(iq)
    old=teacher.prepared_forward(images,iq);new=model.prepared_forward(images,iq)
    difference=float((old-new).abs().max())
    need(torch.allclose(new,old,atol=tolerance,rtol=2e-5),'Migration logits differ from B274: '+str(difference))
    return dict(maxabs_logit_difference=difference,atol=tolerance,rtol=2e-5,train_probe_n=len(iq),
                old_checkpoint_replaced=False,initial_function_preserved_within_tolerance=True)


def parameter_groups(model,copied,base_lr,new_lr):
    groups=[]
    for known,lr in ((True,base_lr),(False,new_lr)):
        parameters=[p for n,p in model.named_parameters() if (n in copied)==known]
        if parameters:groups.append(dict(params=parameters,lr=lr,weight_decay=1e-4))
    return groups


class PowerDiagnostic(nn.Module):
    """Cheap total-IQ-power reference; no trained parameters or extra frontend."""
    def __init__(self,frontend):super().__init__();self.frontend=frontend
    def prepared_forward(self,images,iq):
        score=iq.abs().square().mean(1)
        return torch.stack((torch.zeros_like(score),score),1)
