"""Three-arm B274->ADN migration, medium only, shared GPU lock."""
import argparse,fcntl,gc,shutil
from pathlib import Path
from b271_data import device_for,need
from b271_score import original_protocol
from b273_shared import setup
from b274_data import resolve,Data
from b276_source import metadata
from b276_model import ARMS
from b276_train import train_arm


def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    p.add_argument('--source-run',type=Path);p.add_argument('--out-dir',type=Path);p.add_argument('--bank-dir',type=Path);p.add_argument('--b213-dir',type=Path)
    p.add_argument('--stage',choices=('all','train','score','report'),default='all')
    p.add_argument('--arms',nargs='+',choices=ARMS,default=list(ARMS));p.add_argument('--epochs',type=int,default=4)
    p.add_argument('--train-limit',type=int,default=16000);p.add_argument('--val-limit',type=int,default=3000)
    p.add_argument('--batch',type=int,default=32);p.add_argument('--lr',type=float,default=1e-5);p.add_argument('--new-lr',type=float,default=1e-4)
    p.add_argument('--seed',type=int,default=20261022);p.add_argument('--device',choices=('cpu','cuda'),default='cuda');p.add_argument('--cpu-threads',type=int,default=4)
    a=p.parse_args(argv);a.root=a.root.resolve();a.source_run=(a.source_run or a.root/'output_b274_single_spwvd_resnet18_v1').resolve()
    a.out_dir=(a.out_dir or a.root/'output_b276_spwvd_adn_phase_v1').resolve()
    need(a.root.is_dir() and a.out_dir!=a.root and a.out_dir!=a.source_run and a.source_run not in a.out_dir.parents,'Use a separate new experiment directory')
    need(len(set(a.arms))==len(a.arms) and a.epochs>0 and a.batch==32 and a.lr>0 and a.new_lr>0 and a.cpu_threads>0,'Invalid migration budget')
    need(2<=a.train_limit<=30000 and 2<=a.val_limit<=5000 and a.train_limit%2==a.val_limit%2==0,'Invalid subset')
    a.device=device_for(a.device);return a


def main(argv=None):
    a=cli(argv);setup(a.cpu_threads)
    if a.stage=='report':
        from b276_report import generate
        return generate(a.out_dir/'pd_scr_medium')
    with (a.root/'codex_b271_night.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise SystemExit('Another radar job holds the shared GPU lock; no new job started')
        need(shutil.disk_usage(a.root).free>=2*1024**3,'Require2GiB free for independent model/optimizer checkpoints')
        context=resolve(a.root,a.bank_dir);data=Data(context,a.train_limit,a.val_limit,a.seed)
        _,old,_=original_protocol(a.root,context,a.b213_dir)
        info=metadata(a.source_run,context,a.device,data.selection,old)
        print(f'B276 source verified; TRAIN={a.train_limit} VAL={a.val_limit}; {a.epochs} extra epochs each; arms={a.arms}',flush=True)
        print('No CAL/AUDIT/H1 score arrays opened for training; source B274 checkpoint/result files unchanged.',flush=True)
        if a.stage in ('all','train'):
            for arm in a.arms:train_arm(a,context,data,info,arm)
        selection=data.selection;del data;gc.collect()
        if a.device.type=='cuda':
            import torch
            torch.cuda.empty_cache()
        if a.stage!='train':
            from b276_score import score
            return score(a,context,selection)


if __name__=='__main__':main()
