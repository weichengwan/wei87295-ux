"""Read-only validation/reuse of the user's completed B272 matched control scores."""
from __future__ import annotations
from pathlib import Path
import csv
import numpy as np
import torch
from b271_data import digest_file,fingerprint,load_checkpoint,need,read_json
from b271_score import SCENE_KEYS

BASELINE_NAMES=['B271 continued (control)','B271 + AHPM3','L1-Tail']
BASELINE_COLUMNS=[0,1,3]


def metadata(directory,source,context,original,batch,device,training=None,selection=None):
    directory=Path(directory).resolve();score_dir=directory/'pd_scr_medium'
    run=read_json(directory/'run_manifest.json');p=read_json(score_dir/'protocol_frozen.json')
    progress=read_json(score_dir/'progress.json')
    need(run['source_b271_sha256']==source['sha256'] and p['source_b271_sha256']==source['sha256'],
         'B272 was initialized from another B271')
    need(p['version']=='B272_B271_AHPM_SCORE_V1' and
         fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==p['fingerprint']==progress['fingerprint'],
         'B272 cached protocol fingerprint differs')
    need(progress['completed']==dict(h0_cal=500000,h0_audit=200000,h1=37) and
         p['labels']==['control','ahpm3','B271_frozen','L1_TAIL'],'Need the completed B272 medium experiment')
    scene={k:original[k] for k in SCENE_KEYS};scene.update(h0_cal_n=500000,h0_audit_n=200000)
    need(all(p[k]==v for k,v in scene.items()) and p['scene_fingerprint']==fingerprint(scene) and
         p['original_full_scene_fingerprint']==original['scene_fingerprint'],'B272 cached scenes differ')
    need(p['original_checkpoint_sha256']==source['original_l1_sha256'] and
         p['batch']==batch and p['device']==device.type and p['tf32'] is False and
         p['score_definition']=='float64(float32 logit1 - float32 logit0)',
         'Cached model/numeric settings differ; use the original32/cuda scoring settings')
    expected=read_json(Path(__file__).parent/'b272_original_sources.json')
    need(p['code_sha256']==expected,'B272 source implementation differs from the verified release')
    contracts={}
    for arm in ('control','ahpm3'):
        c=read_json(directory/arm/'training_contract.json');path=directory/arm/'best.pt'
        require=[v for v in p['checkpoints'] if v['arm']==arm]
        need(c['status']=='PASS_B272_FROZEN_ADN_L1__TRAIN_VAL_ONLY' and c['source_b271_sha256']==source['sha256'] and
             len(require)==1 and digest_file(path)==c['checkpoint_sha256']==require[0]['sha256'] and
             c['best_epoch']==require[0]['selected_epoch'],'B272 cached checkpoint changed: '+arm)
        need(c['run_config']['code_sha256']==expected and fingerprint(c['run_config'])==c['run_fingerprint'],
             'B272 training identity differs: '+arm)
        contracts[arm]=c
    control=contracts['control'];state=load_checkpoint(directory/'control/best.pt')
    need(state['run_fingerprint']==control['run_fingerprint'] and state['epoch']==control['best_epoch'],
         'B272 control checkpoint internal identity differs')
    # The actual uploaded B272 selected epoch0. Keep its measured trained-budget
    # result rather than rerunning four identical continuation epochs.
    need(control['best_epoch']==0 and set(state['state_dict'])==set(source['state']['state_dict']) and
         all(torch.equal(v.cpu(),source['state']['state_dict'][k].cpu()) for k,v in state['state_dict'].items()),
         'Expected the verified B272 epoch0 control identical to frozen B271')
    if training is not None:
        c=control['run_config']
        need(c['epochs']==training.epochs==control['epochs_executed'] and c['batch']==training.batch and
             c['seed']==training.seed and c['base_lr']==training.base_lr and c['weight_decay']==.001,
             'Requested training budget differs from the completed matched B272 control')
        need(c['selected_rows']==selection and c['pool_sha256']==source['state']['run_config']['pool_sha'] and
             c['losses']=={k:source['state']['run_config'][k] for k in ('hard_weight','consistency_weight','warp_weight')},
             'Matched-control data rows/pool/loss differ')
    for name in ('h0_cal_scores.npy','h0_audit_scores.npy','dev_h1_scores.npy','b272_curves.csv','b272_metrics.csv'):
        need((score_dir/name).is_file(),'Required B272 cache missing: '+str(score_dir/name))
    return dict(directory=directory,score_dir=score_dir,protocol=p,run=run,contracts=contracts,
        source_b271_sha256=source['sha256'],source_protocol_sha256=digest_file(score_dir/'protocol_frozen.json'),
        matched_continuation_epochs=control['epochs_executed'],matched_control_selected_epoch=0)


def arrays(info):
    folder=info['score_dir'];cached={};hashes={}
    for split,name,shape in (('h0_cal','h0_cal_scores.npy',(500000,4)),('h0_audit','h0_audit_scores.npy',(200000,4)),
                             ('h1','dev_h1_scores.npy',(37,1024,4))):
        path=folder/name;x=np.load(path,mmap_mode='r',allow_pickle=False)
        need(x.shape==shape and x.dtype==np.dtype('float64') and np.isfinite(x).all(),'Malformed B272 cache: '+name)
        need(np.array_equal(x[...,0],x[...,2]),'Epoch0 control does not replay the cached frozen B271 scores')
        cached[split]=np.ascontiguousarray(x[...,BASELINE_COLUMNS]);hashes[name]=digest_file(path)
    # Reproduce every baseline's original own-CAL threshold, H0 count and all37
    # H1 hit counts. No comparison result is used to select the new model.
    from source_loader import load_frozen_file
    statistics=load_frozen_file('r10_sim_stage_b216_pdscr_report_v1.py')
    with (folder/'b272_metrics.csv').open(encoding='utf-8-sig',newline='') as f:metrics=list(csv.DictReader(f))
    with (folder/'b272_curves.csv').open(encoding='utf-8-sig',newline='') as f:curves=list(csv.DictReader(f))
    for j,name in enumerate(BASELINE_NAMES):
        selected=[r for r in metrics if r['method']==name and float(r['nominal_pfa'])==1e-4]
        need(len(selected)==1,'B272 baseline metric missing: '+name);row=selected[0]
        threshold,_,_=statistics.cutoff(cached['h0_cal'][:,j],1e-4)
        need(threshold==float(row['threshold']) and
             int((cached['h0_audit'][:,j]>threshold).sum())==int(row['audit_false_alarms']),
             'B272 baseline threshold/false-alarm replay differs: '+name)
        for level,scr in enumerate(info['protocol']['scr_grid_db']):
            match=[r for r in curves if r['method']==name and float(r['nominal_pfa'])==1e-4 and float(r['scr_db'])==scr]
            need(len(match)==1 and int((cached['h1'][level,:,j]>threshold).sum())==int(match[0]['hits']),
                 'B272 baseline raw hits replay differs: '+name)
    details=dict(directory=str(folder),protocol_sha256=info['source_protocol_sha256'],array_sha256=hashes,
        labels=BASELINE_NAMES,columns=BASELINE_COLUMNS,all_baseline_thresholds_false_alarms_hits_replayed=True,
        matched_continuation_epochs=info['matched_continuation_epochs'],matched_control_selected_epoch=0,
        additional_baseline_gpu_forwards=0,thresholds_recomputed=True)
    return cached,details
