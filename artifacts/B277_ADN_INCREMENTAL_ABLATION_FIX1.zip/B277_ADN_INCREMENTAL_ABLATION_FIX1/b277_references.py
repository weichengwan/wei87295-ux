"""Read-only reuse of published B276 scores and historical B222 ADN scores."""
import csv
from pathlib import Path
import numpy as np
from b271_data import digest_file,fingerprint,load_checkpoint,need,read_json
from b271_score import SCENE_KEYS
from b273_statistics import metrics_for

B276_PASS='PASS_B276_SPWVD_ADN_MIGRATION_TRAIN_VAL_ONLY'
B222_SHA='f89991214c8fc9c5c8e1871d4ea43123dc86d1d5f5917c584d43b8a9354368af'
ADN_SHA='9d43c99ec95c5a465b3584940b71aeccb7f8be56be84e7b7059d792a76d11a44'


def full_metadata(folder,context,original,device,data_selection,source,a):
    folder=Path(folder).resolve();p=read_json(folder/'protocol_frozen.json');progress=read_json(folder/'progress.json')
    hashes=read_json(Path(__file__).parent/'b276_release_sources.json')
    need(p['version']=='B276_SPWVD_ADN_PHASE_SCORE_V1' and p['code_sha256']==hashes and
         p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==progress['fingerprint'],'B276 source protocol/code identity differs')
    scene={k:original[k] for k in SCENE_KEYS};scene.update(h0_cal_n=500000,h0_audit_n=200000)
    need(all(p[k]==v for k,v in scene.items()) and p['scene_fingerprint']==fingerprint(scene) and p['nominal_pfas']==[1e-4],'B276 paired scene identities differ')
    need(progress['completed']==dict(h0_cal=500000,h0_audit=200000,h1=37),'B276 scoring incomplete')
    need(p['batch']==32 and p['device']==device.type and p['tf32'] is False and p['score_definition']=='float64(float32 logit1 - float32 logit0)','B276 numerical settings differ')
    need('adn' in p['labels'] and len(set(p['labels']))==len(p['labels']),'B276 full ADN result absent')
    path=folder.parent/'adn/best.pt';c=read_json(path.with_name('training_contract.json'));cfg=c['run_config']
    need(c['status']==B276_PASS and cfg['code_sha256']==hashes and c['run_fingerprint']==fingerprint(cfg) and
         digest_file(path)==c['checkpoint_sha256'],'B276 full model training/source identity differs')
    need(cfg['initialization_sha256']==source['contract']['checkpoint_sha256'] and cfg['bank_sha256']==context['bc']['file_sha256'] and
         cfg['selected_rows']==data_selection and cfg['source_run']==str(source['run_dir']),'B276 initialization/data differs')
    expected={'arm':'adn','version':'B276_SPWVD_ADN_PHASE_TRAIN_V1','seed':a.seed,'epochs':a.epochs,'batch':32,
        'backbone_lr':a.lr,'new_parameters_lr':a.new_lr,'weight_decay':1e-4,'optimizer':'Adam','loss':'CE','phase_offset_regularizer':0.,
        'selection':'minimum VAL CE including epoch0; no DEV selection'}
    need(all(cfg[k]==v for k,v in expected.items()),'New ablation budget must match completed B276 ADN group')
    identity=[x for x in p['checkpoints'] if x['arm']=='adn']
    need(len(identity)==1 and identity[0]['sha256']==c['checkpoint_sha256'] and identity[0]['selected_epoch']==c['best_epoch'],'B276 score/selected model differ')
    for name in ('h0_cal_scores.npy','h0_audit_scores.npy','dev_h1_scores.npy','b276_curves.csv','b276_metrics.csv'):need((folder/name).is_file(),'Missing completed B276 cache: '+str(folder/name))
    return dict(folder=folder,p=p,contract=c,full_identity=identity[0],protocol_sha256=digest_file(folder/'protocol_frozen.json'))


def full_arrays(info):
    folder=info['folder'];p=info['p'];n=len(p['labels']);cache={};hashes={}
    for key,name,shape in [('h0_cal','h0_cal_scores.npy',(500000,n)),('h0_audit','h0_audit_scores.npy',(200000,n)),('h1','dev_h1_scores.npy',(37,1024,n))]:
        v=np.load(folder/name,mmap_mode='r',allow_pickle=False);need(v.shape==shape and v.dtype==np.dtype('float64') and np.isfinite(v).all(),'Malformed B276 score cache')
        cache[key]=v;hashes[name]=digest_file(folder/name)
    with (folder/'b276_metrics.csv').open(newline='',encoding='utf-8-sig') as f:old=list(csv.DictReader(f))
    with (folder/'b276_curves.csv').open(newline='',encoding='utf-8-sig') as f:curves=list(csv.DictReader(f))
    for j,label in enumerate(p['labels']):
        name=p['names'][label];cv,mt=metrics_for(name,cache['h0_cal'][:,j],cache['h0_audit'][:,j],cache['h1'][:,:,j],p)
        match=[r for r in old if r['method']==name and float(r['nominal_pfa'])==1e-4]
        need(len(match)==1 and float(match[0]['threshold'])==mt[0]['threshold'] and int(match[0]['audit_false_alarms'])==mt[0]['audit_false_alarms'],'B276 threshold/H0 count replay differs')
        for row in cv:
            found=[r for r in curves if r['method']==name and float(r['nominal_pfa'])==1e-4 and float(r['scr_db'])==row['scr_db']]
            need(len(found)==1 and int(found[0]['hits'])==row['hits'] and int(found[0]['n_h1'])==row['n_h1'],'B276 H1 hit replay differs')
    return cache,dict(protocol_sha256=info['protocol_sha256'],array_sha256=hashes,all_source_counts_replayed=True,additional_reference_GPU_forwards=0)


def historical_metadata(root,original):
    folder=Path(root)/'output_sim_r10_b222_gpu_dualpfa_v1/seed_20261022'
    names=('protocol_frozen.json','h0_cal_scores.npy','h0_audit_scores.npy','dev_h1_scores_37.npy')
    missing=[str(folder/n) for n in names if not (folder/n).is_file()]
    if missing:return dict(available=False,missing=missing,reason='Historical ADN scores missing; no automatic retraining')
    need(digest_file(folder/names[0])==B222_SHA,'Historical B222 protocol changed')
    p=read_json(folder/names[0])
    need(p['version']=='SIM_R10_B222_GPU_DUALPFA_V1' and p['methods'][0]=='Original ADN' and
         p['checkpoint_sha256']['Original ADN']==ADN_SHA and p['scene_fingerprint']==original['scene_fingerprint'],
         'Historical original ADN identity/scenes differ')
    return dict(available=True,folder=str(folder),protocol_sha256=B222_SHA,checkpoint_sha256=ADN_SHA,column=0,
        inference_batch=p['batch'],historical_training=True,matched_training_budget=False,original_weights_required_for_score_reuse=False)


def append_historical(info,cache):
    if not info['available']:return cache,info
    folder=Path(info['folder']);out={};hashes={}
    for key,name,shape,prefix in [('h0_cal','h0_cal_scores.npy',(3000000,4),500000),('h0_audit','h0_audit_scores.npy',(1000000,4),200000),('h1','dev_h1_scores_37.npy',(37,1024,4),None)]:
        raw=np.load(folder/name,mmap_mode='r',allow_pickle=False)
        need(raw.shape==shape and raw.dtype==np.dtype('float64'),'Historical ADN score shape differs')
        v=raw[...,0] if prefix is None else raw[:prefix,0]
        need(np.isfinite(v).all(),'Nonfinite historical ADN scores')
        out[key]=np.concatenate([cache[key],v[...,None]],axis=-1);hashes[name]=digest_file(folder/name)
    return out,{**info,'array_sha256':hashes,'new_cal_n':500000,'new_audit_n':200000,
        'historical_3M_cutoff_reused':False,'same_scenes':True,'additional_reference_GPU_forwards':0}
