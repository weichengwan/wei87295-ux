"""Independent single-branch TRAIN/VAL then paired medium scoring; shared GPU lock."""
import fcntl,gc,shutil
from datetime import datetime
from pathlib import Path
from b271_data import need
from b271_score import original_protocol
from b273_shared import setup
from b274_data import resolve,Data
from b274_model import select_backend
from b274_train import cli,train
from b274_baselines import metadata


def main(argv=None):
    a=cli(argv)
    with (a.root/'codex_b271_night.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise SystemExit('Another B271/B272/B273/B274 job holds the GPU lock; no job launched')
        print(datetime.now().astimezone().isoformat(),flush=True)
        print('B274 starting: single SPWVD+ResNet18; all CNN layers trained from scratch.',flush=True)
        setup(a.cpu_threads)
        free=shutil.disk_usage(a.root).free
        need(free>=1024**3,'Less than1GiB free: preserve data and free disposable caches before starting')
        context=resolve(a.root,a.bank_dir);data=Data(context,a.train_limit,a.val_limit,a.seed)
        _,original,_=original_protocol(a.root,context,a.b213_dir)
        baseline=a.baseline_dir or a.root/'output_b273_residual_spwvd_v1/pd_scr_medium'
        metadata(baseline,context,original,a.device,data.selection)
        backend=select_backend(a.root,a.backend,a.legacy_script)
        print(f'Preflight passed: paired B273 metadata; TRAIN={a.train_limit} VAL={a.val_limit} epochs={a.epochs}; '
              f'free={free/1024**3:.2f}GiB; no TF cache generated; backend={backend["kind"]}',flush=True)
        print('No CAL/AUDIT/H1 score arrays opened for training. Original WVD cache/weights are not training inputs.',flush=True)
        train(a,context,data,backend);del data;gc.collect()
        from b274_score import main as score
        args=['--root',str(a.root),'--run-dir',str(a.out_dir),'--baseline-dir',str(baseline),
              '--device',str(a.device),'--batch','32','--cpu-threads',str(a.cpu_threads)]
        if a.b213_dir:args+=['--b213-dir',str(a.b213_dir)]
        score(args)
        print(datetime.now().astimezone().isoformat(),flush=True)


if __name__=='__main__':main()
