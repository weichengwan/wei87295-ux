"""Frozen IQ TRAIN/VAL only; does not require any WVD cache or model weights."""
from __future__ import annotations
import hashlib
from pathlib import Path
import h5py
import numpy as np
import torch
from b271_data import digest_file, need, read_json
from b273_shared import subset_indices, rows
from source_loader import load_frozen_file


def resolve(root, bank_dir=None):
    root = Path(root).resolve()
    b210 = load_frozen_file('r10_sim_stage_b210_a3_adn_earlystop_v1.py')
    if bank_dir is None:
        manifest = root/'output_b271_phase_ars_v1/run_manifest.json'
        bank_dir = read_json(manifest)['bank_dir'] if manifest.is_file() else root/'SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1'
    directory = Path(bank_dir).resolve()
    path, contract, audit = b210.bank_contract(directory,'pilot')
    need(contract.get('counts',{}).get('train')==30000 and contract['counts'].get('val')==5000,
         'Expected frozen30K/5K IQ bank')
    generator = load_frozen_file('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
    need(digest_file(generator.__file__)==contract['generator_sha256'], 'Frozen IQ generator mismatch')
    return dict(root=root, bank_dir=directory, bank_path=path, bc=contract, b210=b210)


class Data:
    def __init__(self, context, train_limit, val_limit, seed):
        self.values, self.selection = {}, {}
        with h5py.File(context['bank_path'],'r') as bank:
            for split,limit,offset in [('train',train_limit,27101),('val',val_limit,27102)]:
                group=bank[split]
                need(group['iq'].shape==(len(group['label']),512) and group['iq'].dtype==np.dtype('complex64'), 'Malformed IQ bank')
                labels=group['label'][:].astype('int64')
                families=group['family_index'][:] if 'family_index' in group else None
                chosen=subset_indices(labels,families,limit,seed+offset)
                self.values[split]=(rows(group['iq'],chosen).astype('complex64'),labels[chosen])
                self.selection[split]=dict(count=len(chosen),original_count=len(labels),
                    row_indices_sha256=hashlib.sha256(chosen.astype('<i8').tobytes()).hexdigest(),
                    counts_by_label={str(v):int((labels[chosen]==v).sum()) for v in (0,1)},
                    family_stratified=families is not None)
    def fetch(self,split,index,device):
        iq,y=self.values[split]
        return torch.from_numpy(np.ascontiguousarray(iq[index])).to(device), torch.from_numpy(np.ascontiguousarray(y[index])).to(device)


def fit_scale(data,frontend,device,batch):
    values=[]
    # Same first256 TRAIN-row quantile convention as the recoverable descendant.
    count=min(256,len(data.values['train'][0]))
    for start in range(0,count,batch):
        x,_=data.fetch('train',slice(start,min(start+batch,count)),device)
        values.append(frontend.logmaps(x).cpu().numpy().ravel())
    scale=float(np.quantile(np.concatenate(values),.99))
    need(np.isfinite(scale) and scale>1e-4,'Degenerate TRAIN-only logabs scale')
    return scale
