"""Paired medium scoring of only the two newly trained missing ablations."""
from types import SimpleNamespace
import torch
from b271_data import digest_file,fingerprint,load_checkpoint,need
from b271_score import SCENE_KEYS
from b276_train import code_hashes
from b276_score import stream
from b277_model import ARMS,NAMES,factory
from b277_references import full_arrays,append_historical
from b277_run import references,PASS
from b271_data import read_json


def score(a,context,selection):
    source,full,history,old,generator=references(a,context,selection)
    cached,reuse=full_arrays(full);cached,historical=append_historical(history,cached)
    models=[];identities=[]
    for arm in ARMS:
        folder=a.out_dir/arm;c=read_json(folder/'training_contract.json');cfg=c['run_config'];path=folder/'best.pt'
        need(c['status']==PASS and c['run_fingerprint']==fingerprint(cfg) and cfg['code_sha256']==code_hashes() and
             digest_file(path)==c['checkpoint_sha256'],'New ablation checkpoint/code differs')
        need(cfg['initialization_sha256']==source['contract']['checkpoint_sha256'] and cfg['bank_sha256']==context['bc']['file_sha256'] and cfg['selected_rows']==selection,'New ablation source/data differs')
        state=load_checkpoint(path);need(state['run_config']==cfg and state['run_fingerprint']==c['run_fingerprint'] and state['epoch']==c['best_epoch'],'New ablation checkpoint internal identity differs')
        model=factory(arm,cfg['backend'],cfg['scale']);model.load_state_dict(state['state_dict'],strict=True);model.to(a.device).eval()
        models.append(model);identities.append(dict(arm=arm,sha256=c['checkpoint_sha256'],selected_epoch=c['best_epoch'],validation=c['selected_validation'],
            initialization=c['initialization'],module_diagnostics=c['module_diagnostics'],trainable_parameters=c['trainable_parameters']))
    labels=list(ARMS)+['REF_'+v for v in full['p']['labels']]
    names={**{k:NAMES[k] for k in ARMS},**{'REF_'+k:v for k,v in full['p']['names'].items()}}
    if historical['available']:labels.append('HIST_ADN');names['HIST_ADN']=NAMES['ORIGINAL']
    scene={k:old[k] for k in SCENE_KEYS};scene.update(h0_cal_n=500000,h0_audit_n=200000)
    p=dict(version='B277_ADN_INCREMENTAL_ABLATION_SCORE_V1',**scene,scene_fingerprint=fingerprint(scene),nominal_pfas=[1e-4],
        labels=labels,names=names,candidate_labels=list(ARMS),ours_label='REF_adn',checkpoints=identities,
        reused_full_checkpoint=full['full_identity'],reused_baselines={'B276':reuse,'historical_original_adn':historical},
        training_budget=dict(train_n=selection['train']['count'],val_n=selection['val']['count'],epochs=a.epochs,batch=32,seed=a.seed,
                             backbone_lr=a.lr,new_parameters_lr=a.new_lr),
        batch=32,device=a.device.type,tf32=False,code_sha256=code_hashes(),
        score_definition='float64(float32 logit1 - float32 logit0)',strict_decision='score > own H0 CAL threshold',
        scope='Matched SPWVD ablation additional budget; historical WVD ADN has different training/inference batch; exposed medium DEV, not FINAL')
    p['fingerprint']=fingerprint(p);args=SimpleNamespace(out_dir=a.out_dir/'pd_scr_medium',batch=32,chunk=512)
    print('B277 scores two NEW arms only; old ADN/full B276 GPU forwards=0; CAL500k CHECK200k H1=1024x37',flush=True)
    stream(args,p,generator,models,None,a.device,cached)
    from b277_report import generate
    return generate(args.out_dir)
