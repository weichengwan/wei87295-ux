"""Load the uploaded, unmodified L1-Tail reference with checksum verification."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from functools import lru_cache
from pathlib import Path


SOURCE_NAMES = (
    "r10_2025_mtdsp_adn_source_protocol_freeze_canary_v1.py",
    "r10_2025_mtdsp_adn_proposed_wcsg_tfcg_hts_train_v1_FIX2.py",
    "r10_sim_stage_b215_tpht_train_v1.py",
)


@lru_cache(maxsize=1)
def load_frozen_sources():
    root = Path(__file__).resolve().parent / "frozen_source"
    manifest = json.loads((root / "manifest.json").read_text())
    modules = []
    for index, filename in enumerate(SOURCE_NAMES):
        path = root / filename
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != manifest[filename]:
            raise RuntimeError(f"Frozen source checksum mismatch: {filename}")
        name = f"b270_frozen_reference_{index}"
        spec = importlib.util.spec_from_file_location(name, path)
        if spec is None or spec.loader is None:
            raise RuntimeError(f"Cannot load reference: {filename}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        modules.append(module)
    source, trainer, loss_reference = modules
    if manifest[SOURCE_NAMES[0]] != trainer.EXPECTED_SOURCE_SHA:
        raise RuntimeError("ADN source does not match the frozen trainer")
    if loss_reference.CFG != {"wcsg": True, "tfcg": True, "hts": False}:
        raise RuntimeError("Unexpected L1-Tail architecture configuration")
    return source, trainer, loss_reference


@lru_cache(maxsize=None)
def load_frozen_file(filename):
    root = Path(__file__).resolve().parent / "frozen_source"
    manifest = json.loads((root / "manifest.json").read_text())
    if filename not in manifest:
        raise RuntimeError(f"Source is not registered: {filename}")
    path = root / filename
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != manifest[filename]:
        raise RuntimeError(f"Frozen source checksum mismatch: {filename}")
    name = "b270_dependency_" + hashlib.sha256(filename.encode()).hexdigest()[:12]
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {filename}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module
