"""Single SPWVD -> standard ResNet18 -> two logits, with every CNN layer trained.

The recovered path uses the uploaded descendant's unmodified TF functions.
If the exact historical B236 script is found, its network/TF functions can be used.
Neither path adds WCSG, TFCG, ACB, phase resampling, or an IQ correction head.
"""
from __future__ import annotations
import ast, importlib.util, os, sys
from functools import lru_cache
from pathlib import Path
import numpy as np
import torch
from torch import nn
from b271_data import digest_file, need

LEGACY_SHA = '5177f9475fb38bf685714438842abb29ae65bd719d64d38caa8da5bde9841cfb'
API = ('network', 'spwvd_torch', 'tf_image')
METHOD = 'Wang2024 TF-only reconstruction (SPWVD+ResNet18)'


def select_backend(root, mode='auto', explicit=None):
    candidates = []
    if mode != 'recovered':
        if explicit:
            candidates = [Path(explicit).resolve()]
        else:
            for directory, dirs, files in os.walk(root, followlinks=False):
                depth = len(Path(directory).relative_to(root).parts)
                dirs[:] = [] if depth >= 3 else [d for d in dirs if not d.startswith('.') and d != '__pycache__']
                candidates.extend(Path(directory)/f for f in files if f.endswith('.py') and
                                  any(t in f.lower() for t in ('b233','b236','wang','tvfree')))
        for path in sorted(set(candidates)):
            if not path.is_file() or digest_file(path) != LEGACY_SHA:
                continue
            names = {n.name for n in ast.parse(path.read_text()).body if isinstance(n, ast.FunctionDef)}
            need(set(API) <= names, 'Verified historical script API differs; preserve it and use --backend recovered')
            return dict(kind='verified_b236_source', path=str(path), sha256=LEGACY_SHA,
                        original_training_protocol_replayed=False)
        need(not explicit and mode != 'legacy',
             'Exact historical B236 script not found. Use --backend recovered for the declared reconstruction.')
    path = Path(__file__).parent/'legacy_tf_recovered.py'
    return dict(kind='recovered_descendant_frontend', path=str(path.resolve()), sha256=digest_file(path),
                original_training_protocol_replayed=False)


@lru_cache(maxsize=None)
def imported_backend(path, expected):
    path = Path(path)
    need(path.is_file() and digest_file(path) == expected, 'TF source missing/changed: '+str(path))
    name = 'b274_tf_' + expected[:16]
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class BasicBlock(nn.Module):
    expansion = 1
    def __init__(self, cin, cout, stride=1):
        super().__init__()
        self.conv1 = nn.Conv2d(cin, cout, 3, stride, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(cout)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(cout, cout, 3, 1, 1, bias=False)
        self.bn2 = nn.BatchNorm2d(cout)
        self.downsample = nn.Sequential(nn.Conv2d(cin, cout, 1, stride, bias=False), nn.BatchNorm2d(cout)) if stride != 1 or cin != cout else None
        self.stride = stride
    def forward(self, x):
        identity = x if self.downsample is None else self.downsample(x)
        z = self.relu(self.bn1(self.conv1(x)))
        return self.relu(self.bn2(self.conv2(z)) + identity)


class ResNet18(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 64, 7, 2, 3, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(3, 2, 1)
        self.layer1 = nn.Sequential(BasicBlock(64,64), BasicBlock(64,64))
        self.layer2 = nn.Sequential(BasicBlock(64,128,2), BasicBlock(128,128))
        self.layer3 = nn.Sequential(BasicBlock(128,256,2), BasicBlock(256,256))
        self.layer4 = nn.Sequential(BasicBlock(256,512,2), BasicBlock(512,512))
        self.avgpool = nn.AdaptiveAvgPool2d((1,1))
        self.fc = nn.Linear(512,2)
        for m in self.modules():
            if isinstance(m, nn.Conv2d): nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm2d): nn.init.ones_(m.weight); nn.init.zeros_(m.bias)
    def forward(self,x):
        x = self.maxpool(self.relu(self.bn1(self.conv1(x))))
        x = self.layer4(self.layer3(self.layer2(self.layer1(x))))
        return self.fc(torch.flatten(self.avgpool(x),1))


class Frontend:
    def __init__(self, backend, scale):
        need(np.isfinite(scale) and scale > 1e-8, 'Invalid TRAIN-only frontend scale')
        self.backend, self.scale = dict(backend), float(scale)
        self.module = imported_backend(backend['path'],backend['sha256'])
    @torch.no_grad()
    def images(self, iq):
        images = self.module.tf_image(iq, self.scale)
        need(images.shape == (len(iq),3,224,224) and torch.isfinite(images).all().item(), 'Invalid TF image')
        return images
    @torch.no_grad()
    def logmaps(self, iq):
        return torch.log1p(self.module.spwvd_torch(iq).abs())
    # Interface for the unchanged, tested B273 streaming loop. The value
    # passed between these two methods is IQ itself, not a WVD spectrum.
    def components(self, iq):
        return iq
    def maps(self, iq):
        return self.images(iq)


class SingleBranch(nn.Module):
    def __init__(self, backend, scale):
        super().__init__()
        self.frontend = Frontend(backend, scale)
        self.net = self.frontend.module.network() if backend['kind'] == 'verified_b236_source' else ResNet18()
        need(isinstance(self.net, nn.Module), 'Historical network() did not return a module')
        for parameter in self.net.parameters(): parameter.requires_grad_(True)
    def forward(self, iq):
        return self.net(self.frontend.images(iq))
    def prepared_forward(self, images, iq):
        return self.net(images)
