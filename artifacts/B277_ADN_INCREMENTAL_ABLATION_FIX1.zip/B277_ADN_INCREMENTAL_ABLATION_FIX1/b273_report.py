"""B273 own-CAL metrics with exact reused baselines and the requested triangle style."""
from __future__ import annotations
from pathlib import Path
import shutil
import numpy as np
from b271_data import digest_file,fingerprint,need,read_json,write_json
from b273_statistics import metrics_for,save_csv
from paper_plots import generate as paper_plot

NAMES={'plain':'B271 + SPWVD','residual':'B271 + residual SPWVD',
       'B271_CONTROL':'B271 continued (control)','AHPM_REFERENCE':'B271 + AHPM3','L1_TAIL':'L1-Tail'}


def generate(out):
    out=Path(out);p=read_json(out/'protocol_frozen.json');progress=read_json(out/'progress.json')
    need(p['version']=='B273_RESIDUAL_SPWVD_SCORE_V1' and p['nominal_pfas']==[1e-4] and
         fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==p['fingerprint']==progress['fingerprint'],'Protocol changed')
    need(progress['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=len(p['scr_grid_db'])),'Scoring incomplete')
    cols=len(p['labels']);arrays=[]
    for name,shape in (('h0_cal_scores.npy',(p['h0_cal_n'],cols)),('h0_audit_scores.npy',(p['h0_audit_n'],cols)),
                       ('dev_h1_scores.npy',(len(p['scr_grid_db']),p['h1_scenes_n'],cols))):
        x=np.load(out/name,mmap_mode='r',allow_pickle=False)
        need(x.shape==shape and x.dtype==np.dtype('float64'),'Malformed score array');arrays.append(x)
    cal,audit,h1=arrays;curves=[];metrics=[];lookup={}
    for j,label in enumerate(p['labels']):
        c,m=metrics_for(NAMES[label],cal[:,j],audit[:,j],h1[:,:,j],p)
        curves.extend(c);metrics.extend(m);lookup[label]=m[0]
    comparisons=[]
    for candidate in ('plain','residual'):
        if candidate not in lookup:continue
        for reference in ('plain','B271_CONTROL','AHPM_REFERENCE','L1_TAIL'):
            if reference not in lookup or candidate==reference:continue
            a,b=lookup[candidate],lookup[reference]
            delta=lambda field:a[field]-b[field] if a[field] is not None and b[field] is not None else None
            comparisons.append(dict(candidate=candidate,reference=reference,nominal_pfa=1e-4,
                delta_D50_db=delta('D50_db'),delta_D80_db=delta('D80_db'),delta_D90_db=delta('D90_db'),
                pd_at_0_gain_pp=100*delta('pd_at_0'),candidate_false_alarms=a['audit_false_alarms'],
                reference_false_alarms=b['audit_false_alarms'],audit_n=p['h0_audit_n'],
                candidate_actual_pfa=a['actual_pfa'],reference_actual_pfa=b['actual_pfa'],
                negative_delta_means_left=True,scope='Medium exposed DEV descriptive; significance not established'))
    save_csv(out/'b273_curves.csv',curves);save_csv(out/'b273_metrics.csv',metrics)
    save_csv(out/'b273_comparisons.csv',comparisons)
    report=dict(status='PASS_B273_MEDIUM_DEV_REPORT',metrics=metrics,comparisons=comparisons,
        checkpoints=p['checkpoints'],training_budget=p['training_budget'],baseline_cache=p['reused_baselines'],
        evaluation=dict(cal=p['h0_cal_n'],audit=p['h0_audit_n'],h1_per_scr=p['h1_scenes_n'],scr=p['scr_grid_db'],nominal_pfas=[1e-4]),
        attribution='SPWVD from prior time-frequency analysis, used by Wang2024 DOI10.3390/rs16244662 Eq4; signed residual mix/bounded learned coefficient/progressive initialization are declared adaptations, not established novelty or measured improvement.',
        scope=p['scope'],automatic_promotion=False,independent_final=False,one_db_gain_established=False,
        uncertainty='50 CAL tail samples, about20 expected check false alarms; retain counts/intervals. Previously exposed DEV cannot serve as independent FINAL.',
        smoothing=False,coefficient_is_global_not_sample_adaptive=True)
    write_json(out/'b273_report.json',report)
    ours=NAMES['residual'] if 'residual' in lookup else NAMES['plain']
    figures=out/'figures'
    paper_plot(out/'b273_curves.csv',figures,ours=ours,nominal=1e-4,metrics=out/'b273_metrics.csv')
    for ext in ('pdf','png','svg'):
        shutil.copyfile(figures/f'b273_curves_paper_pd_pfa_1e-04.{ext}',figures/f'b273_pd_scr_pfa_1e-04.{ext}')
    for row in comparisons:
        print(f"{row['candidate']} vs {row['reference']}: delta_D90={row['delta_D90_db']}; "
              f"Pd@0 gain={row['pd_at_0_gain_pp']:+.3f}pp; H0FP={row['candidate_false_alarms']} vs {row['reference_false_alarms']}",flush=True)
    print('B273 medium complete. Stopped; no automatic full-size job.',flush=True)
    print(f"Report: {out/'b273_report.json'}",flush=True)
    return report
