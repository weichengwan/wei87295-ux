"""B271 with a source-attributed SPWVD front end; no AHPM or backbone replacement."""
from __future__ import annotations
import torch
from b271_model import B271Net
from b273_frontend import ResidualSPWVD
from source_loader import load_frozen_sources


class B273Net(B271Net):
    def __init__(self,arm='residual',b271_config=None,frontend_config=None):
        if arm not in ('plain','residual'):raise ValueError('Unknown B273 arm')
        config=dict(b271_config or dict(variant='guided',maximum_offset=.75,correction_bound=3.))
        if config.get('variant')!='guided':raise ValueError('Requires original guided B271')
        super().__init__(**config)
        frontend=dict(frontend_config or {})
        self.frontend=ResidualSPWVD(mode=arm,**frontend)
        self.arm=arm;self.model_config=dict(arm=arm,b271_config=config,frontend_config=frontend)
        self.train()

    def initialize_b271(self,state):
        old=state['state_dict'];expected={k for k in self.state_dict() if k.startswith('frontend.')}
        if set(self.state_dict())-set(old)!=expected or set(old)-set(self.state_dict()):
            raise ValueError('B271 source architecture differs')
        result=self.load_state_dict(old,strict=False)
        if set(result.missing_keys)!=expected or result.unexpected_keys:raise ValueError('Unexpected B271 transplant')

    def prepared_forward(self,images,iq,return_aux=False):
        return super().forward(images,iq,return_aux=return_aux)

    def forward(self,images,iq,return_aux=False):
        # Epoch0 residual candidate replays the actual frozen cache exactly.
        identity=self.arm=='residual' and float(self.frontend.blend_progress)==0.
        if not identity or images is None:
            components=self.frontend.components(iq)
            maps=self.frontend.display(components[0]) if identity else self.frontend.maps(components)
            images=load_frozen_sources()[0].map_to_adn_input(maps)
        return self.prepared_forward(images,iq,return_aux=return_aux)

    def parameter_groups(self,base_lr,frontend_lr,weight_decay=.001):
        base=[p for n,p in self.named_parameters() if p.requires_grad and not n.startswith('frontend.')]
        front=[p for n,p in self.named_parameters() if p.requires_grad and n.startswith('frontend.')]
        groups=[dict(params=base,lr=base_lr,weight_decay=weight_decay)]
        if front:groups.append(dict(params=front,lr=frontend_lr,weight_decay=0.))
        return groups
