"""Only Ours seed models execute; shared paired IQ and TFSE bank per batch."""
import time
import numpy as np
import torch
from b289_common import FILES,need,read_json,write_json,fingerprint,code_hashes
from tfse_frontend import smoothing_bank

def make_iq(generator,p,split,ix,j=None):
    scenes=[generator.make_one(p['master_seed'],p['h1_split'] if split=='h1' else p[split+'_split'],int(i),-30,10) for i in ix]
    if split!='h1':
        need(all(s['label']==0 and not np.any(s['target']) for s in scenes),'Target appeared in H0 split')
        return np.stack([s['base'] for s in scenes]).astype('complex64')
    need(all(s['label']==1 for s in scenes),'H1 label mismatch')
    base=np.stack([s['base'] for s in scenes]).astype('complex64').astype('complex128')
    unit=np.stack([s['unit'] for s in scenes]).astype('complex64').astype('complex128')
    cp=np.asarray([s['cp'] for s in scenes],dtype='float64');need((cp>0).all() and np.isfinite(cp).all(),'Invalid clutter power')
    amplitude=np.sqrt(cp*10**(p['scr_grid_db'][j]/10))
    return (base+unit*amplitude[:,None]).astype('complex64')


def protocol(a,info,models,contracts,profile,selection):
    need(profile in ('screen','full'),'Unknown score profile')
    p=dict(version='B290_OURS_SEEDS_SCORE_V1',**info['scene'])
    cal,audit,h1,pfas=(300000,200000,512,[1e-4]) if profile=='screen' else (3000000,1000000,1024,[1e-4,1e-5])
    p.update(profile=profile,h0_cal_n=cal,h0_audit_n=audit,h1_scenes_n=h1,
        scr_grid_db=list(range(-24,a.max_scr+1)),labels=list(models),
        names={k:'ADN + TFSE + DHiF (Ours); '+k for k in models},training_contracts=contracts,
        source_lineage=info['lineage'],source_files_sha256=info['protected_sources'],
        nominal_pfas=pfas,positive_prior=a.positive_prior,seed_selection=selection,
        code_sha256=code_hashes(),batch=a.batch,chunk=a.chunk,device=a.device.type,
        torch_version=str(torch.__version__),amp=False,tf32=False,
        score_definition='float64(float32 logit1-logit0)',strict_decision='score > own H0 CAL cutoff',
        only_method='ADN + TFSE + DHiF (Ours)',other_methods_executed=False,
        independent_final=False,scope='Fixed SIM-R10 DEV; seed winner selected only on full VAL before any H0/H1 screening')
    p['fingerprint']=fingerprint(p);return p


@torch.inference_mode()
def predict(models,labels,iq,device,batch):
    scales={m.scale for m in models.values()};need(len(scales)==1,'Ours seed TFSE scales differ')
    out=np.empty((len(iq),len(labels)),dtype='float64')
    for start in range(0,len(iq),batch):
        stop=min(start+batch,len(iq));x=torch.from_numpy(np.ascontiguousarray(iq[start:stop])).to(device)
        bank=smoothing_bank(x,next(iter(scales)))
        for col,label in enumerate(labels):
            z=models[label].prepared_forward(bank)
            need(z.shape==(len(x),2) and torch.isfinite(z).all(),'Invalid Ours seed logits')
            out[start:stop,col]=(z[:,1]-z[:,0]).double().cpu().numpy()
    need(np.isfinite(out).all(),'Nonfinite scores');return out


def stream(a,info,models,p,folder):
    folder.mkdir(exist_ok=True);pp=folder/'protocol_frozen.json';prp=folder/'progress.json'
    if pp.exists():need(read_json(pp)==p,'Scoring settings changed; preserve result')
    else:
        need(not any(folder.iterdir()),'Nonempty scoring folder without identity');write_json(pp,p)
    if prp.exists():pr=read_json(prp);need(pr['fingerprint']==p['fingerprint'],'Progress identity differs')
    else:
        need(not any((folder/f).exists() for f in FILES.values()),'Scores without commit metadata')
        pr=dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=0,h0_audit=0,h1=0));write_json(prp,pr)
    labels=p['labels'];levels=len(p['scr_grid_db'])
    for split,file in FILES.items():
        n=p['h1_scenes_n'] if split=='h1' else p[split+'_n'];done=pr['completed'][split]
        need(isinstance(done,int) and 0<=done<=(levels if split=='h1' else n),'Invalid score progress')
        path=folder/file;need(done==0 or path.is_file(),'Committed score file missing')
        shape=(levels,n,len(labels)) if split=='h1' else (n,len(labels))
        arr=np.lib.format.open_memmap(path,mode='r+' if path.exists() else 'w+',dtype='float64',shape=shape)
        need(arr.shape==shape and arr.dtype==np.float64,'Score shape/type differs')
        def block(start,stop,j=None):
            iq=make_iq(info['generator'],p,split,np.arange(start,stop),j)
            return predict(models,labels,iq,a.device,a.batch)
        if done:
            count=n if split=='h1' else done
            for j in sorted({0,done-1}) if split=='h1' else [None]:
                for start in sorted({0,max(0,((count-1)//a.batch)*a.batch)}):
                    stop=min(start+a.batch,count);actual=block(start,stop,j)
                    old=arr[j,start:stop] if split=='h1' else arr[start:stop]
                    need(np.allclose(actual,old,rtol=2e-5,atol=5e-5),'Committed own score replay differs')
        began=time.perf_counter()
        if split=='h1':
            for j in range(done,levels):
                for start in range(0,n,a.chunk):
                    stop=min(start+a.chunk,n);arr[j,start:stop]=block(start,stop,j)
                arr.flush();pr['completed'][split]=j+1;write_json(prp,pr)
                print(f'[{p["profile"]} dev_h1] SCR={p["scr_grid_db"][j]:+d} dB {j+1}/{levels}; Ours only',flush=True)
        else:
            for start in range(done,n,a.chunk):
                stop=min(start+a.chunk,n);arr[start:stop]=block(start,stop);arr.flush()
                pr['completed'][split]=stop;write_json(prp,pr)
                if stop==n or stop%10000<a.chunk:
                    rate=(stop-done)/max(time.perf_counter()-began,1e-6)
                    print(f'[{p["profile"]} {split}] {stop:,}/{n:,}; {rate:.1f}/s; remaining~{(n-stop)/max(rate,1e-6)/60:.1f}min',flush=True)
        del arr


