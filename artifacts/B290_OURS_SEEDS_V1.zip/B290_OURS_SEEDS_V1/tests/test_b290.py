"""Ours-only synthetic functional tests. No real AutoDL performance claims."""
import contextlib
import io
import json
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import numpy as np
import torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from b289_common import (ROOT,FILES,setup,generator,read_json,write_json,fingerprint,digest_file,
    atomic_save,snapshot,load_checkpoint,code_hashes)
from b289_model import TFSECore,Model,tensor_hash
from b289_source import load_sources,verify_protected
from b289_train import Prepared,evaluate,preflight,train_arm,load_selected
from b290_run import cli,seed_args,select_val
from b290_score import predict,stream
from b290_stats import classification_rates
from b290_history import cached_ours
from b290_report import generate


def fixture(root):
    setup(2,42)
    a=SimpleNamespace(root=root,b280_run=root/'old_B280',out_dir=root/'output_b290_ours_seeds_fixture',
        device=torch.device('cpu'),batch=2,chunk=4,seeds=[41,42],seed=41,cpu_threads=2,
        epochs=2,warmup_epochs=1,backbone_lr=1e-5,new_lr=3e-4,max_scr=24,positive_prior=.5)
    a.out_dir.mkdir(parents=True)
    context=dict(bc=dict(seed=20261009,file_sha256='synthetic-fixture-only',generator_sha256=digest_file(generator().__file__)))
    raw=SimpleNamespace(values={},selection={})
    for split,n in [('train',8),('val',4)]:
        scenes=[generator().make_one(20261009,split,j,-15,10) for j in range(n)]
        raw.values[split]=(np.stack([s['iq'] for s in scenes]),np.array([s['label'] for s in scenes],dtype='int64'))
        raw.selection[split]=dict(count=n,fixture_only=True)
    def fetch(split,index,device):
        iq,y=raw.values[split]
        return torch.from_numpy(np.ascontiguousarray(iq[index])).to(device),torch.from_numpy(np.ascontiguousarray(y[index])).to(device)
    raw.fetch=fetch
    model=TFSECore(1.).eval()
    with torch.no_grad():model.gate.head.weight.normal_(0,.02)
    cfg=dict(arm='A1',code_sha256=read_json(ROOT/'expected_source_code.json')['B280'],
        bank_sha256=context['bc']['file_sha256'],factor_A_joint_SPWVD=True,factor_B_TFCG_Tail=False,
        selected_rows=dict(train=dict(count=30000),val=dict(count=5000)),scale=1.)
    folder=a.b280_run/'A1';folder.mkdir(parents=True)
    state=dict(state_dict=snapshot(model),run_config=cfg,run_fingerprint=fingerprint(cfg),epoch=3)
    atomic_save(folder/'best.pt',state)
    ct=dict(status='PASS_B280_FULL_TRAIN_VAL_ONLY',run_config=cfg,run_fingerprint=fingerprint(cfg),best_epoch=3,
        checkpoint_sha256=digest_file(folder/'best.pt'),selected_validation=evaluate(model,Prepared(raw,True,1.),a.device,a.batch))
    write_json(folder/'training_contract.json',ct)
    scene=dict(master_seed=20261009,generator_sha=context['bc']['generator_sha256'],h0_cal_n=3000000,h0_audit_n=1000000,
        h1_scenes_n=1024,scr_grid_db=list(range(-24,13)),h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',
        family_names=list(generator().TRAIN_FAMILIES),scr_definition='synthetic-fixture-only')
    p=dict(version='B280_FULL_FACTORIAL_SCORE_V1',**scene,scene_fingerprint=fingerprint(scene),
        labels=['A0','A1','A2','A3'],checkpoints=[None,ct,None,None]);p['fingerprint']=fingerprint(p)
    folder=a.b280_run/'pd_scr_full';folder.mkdir()
    write_json(folder/'protocol_frozen.json',p)
    write_json(folder/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=3000000,h0_audit=1000000,h1=37)))
    return a,context,load_sources(a,context),raw


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):torch.set_num_threads(2)

    def test_only_A1_required_and_only_FULL_can_train(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            a,context,info,raw=fixture(Path(tmp))
            self.assertFalse((a.b280_run/'A0').exists());self.assertEqual(set(info['models']),{'A1'})
            self.assertEqual(len(info['protected_sources']),2)
            anchors,checks=preflight(a,info,raw)
            self.assertEqual(set(checks['candidate_checks']),{'FULL'})
            with self.assertRaisesRegex(RuntimeError,'Only ADN'):train_arm(a,context,info,raw,anchors['FULL'],'DHIF')
            self.assertFalse((a.out_dir/'DHIF').exists());self.assertTrue(verify_protected(info)['unchanged'])

    def test_train_resume_and_VAL_selection_before_H1(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            a,ctx,info,raw=fixture(Path(tmp)/'interrupted');anchor=info['contracts']['A1']['selected_validation']
            current=seed_args(a,41);current.out_dir.mkdir();hit=[]
            def interrupt(path,obj):
                atomic_save(path,obj)
                if Path(path).name=='last_epoch.pt' and obj['epoch']==1 and not hit:
                    hit.append(True);raise RuntimeError('synthetic interruption')
            with patch('b289_train.atomic_save',side_effect=interrupt):
                with self.assertRaisesRegex(RuntimeError,'interruption'):train_arm(current,ctx,info,raw,anchor,'FULL')
            train_arm(current,ctx,info,raw,anchor,'FULL')
            second=seed_args(a,42);second.out_dir.mkdir();train_arm(second,ctx,info,raw,anchor,'FULL')
            selected=select_val(a,info)
            self.assertFalse(selected['H0_CAL_AUDIT_H1_used']);self.assertFalse((a.out_dir/'pd_scr_screen').exists())
            rank=sorted(selected['candidates'],key=lambda r:(-r['val_pauc01'],r['val_ce'],r['seed']))
            self.assertEqual(selected['selected_seed'],rank[0]['seed'])
            score=a.out_dir/'pd_scr_screen';score.mkdir();(score/'fake_Pd.csv').write_text('not used for choosing a seed')
            self.assertEqual(select_val(a,info),selected)
            before=digest_file(current.out_dir/'FULL/best.pt');train_arm(current,ctx,info,raw,anchor,'FULL')
            self.assertEqual(digest_file(current.out_dir/'FULL/best.pt'),before)
            model,_=load_selected(current,info,'FULL');self.assertTrue(model.with_tfse)
            b,ctx2,info2,raw2=fixture(Path(tmp)/'continuous');other=seed_args(b,41);other.out_dir.mkdir()
            train_arm(other,ctx2,info2,raw2,info2['contracts']['A1']['selected_validation'],'FULL')
            left=load_checkpoint(current.out_dir/'FULL/best.pt')['state_dict']
            right=load_checkpoint(other.out_dir/'FULL/best.pt')['state_dict']
            self.assertTrue(all(torch.equal(v,right[k]) for k,v in left.items()))
            self.assertTrue(verify_protected(info)['unchanged'])

    def test_shared_TFSE_bank_and_multi_seed_score_resume(self):
        class Predictor:
            scale=1.
            def __init__(self,k):self.k=k
            def prepared_forward(self,x):
                y=x.flatten(1).mean(1)+self.k;return torch.stack((-y,y),1)
        models={'seed_1':Predictor(0),'seed_2':Predictor(1)}
        iq=np.ones((7,512),dtype='complex64');calls=[]
        def bank(x,s):calls.append(1);return x.real[:,None,:]
        with patch('b290_score.smoothing_bank',side_effect=bank):
            value=predict(models,list(models),iq,torch.device('cpu'),3)
        self.assertEqual(len(calls),3);self.assertTrue(np.all(value[:,0]==2));self.assertTrue(np.all(value[:,1]==4))
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            a=SimpleNamespace(device=torch.device('cpu'),batch=2,chunk=4)
            p=dict(profile='screen',h0_cal_n=9,h0_audit_n=7,h1_scenes_n=4,scr_grid_db=list(range(-24,25)),
                labels=list(models),fingerprint='synthetic-score-only')
            info=dict(generator=generator());seen=[]
            def make(g,p,split,indices,j=None):return np.full((len(indices),512),(j or 0)+1,dtype='complex64')
            native=predict
            def interrupted(*args,**kwargs):
                seen.append(1)
                if len(seen)==2:raise RuntimeError('score interruption')
                return native(*args,**kwargs)
            folder=Path(tmp)/'scores'
            with patch('b290_score.make_iq',side_effect=make),patch('b290_score.smoothing_bank',side_effect=bank),patch('b290_score.predict',side_effect=interrupted):
                with self.assertRaisesRegex(RuntimeError,'interruption'):stream(a,info,models,p,folder)
            old=np.load(folder/FILES['h0_cal'])[:4].copy()
            with patch('b290_score.make_iq',side_effect=make),patch('b290_score.smoothing_bank',side_effect=bank):stream(a,info,models,p,folder)
            self.assertTrue(np.array_equal(old,np.load(folder/FILES['h0_cal'])[:4]))
            self.assertEqual(np.load(folder/FILES['h1']).shape,(49,4,2))

    def test_cached_history_reads_FULL_column_only_never_loads_a_model(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);folder=root/'old/pd_scr_full';folder.mkdir(parents=True)
            cfg=dict(arm='FULL',TFSE=True,TFCG=False,Tail=False,source_lineage=dict(B280_A1='a1'),
                code_sha256=read_json(ROOT/'expected_ours_code.json'))
            ct=dict(run_config=cfg,run_fingerprint=fingerprint(cfg),checkpoint_sha256='old-ours')
            scene=dict(master_seed=42,generator_sha='fake',h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',family_names=['a'],scr_definition='fixture')
            old=dict(version='B289_DHIF_TWO_MODEL_FULL_SCORE_V2',**scene,h0_cal_n=64,h0_audit_n=64,h1_scenes_n=8,
                scr_grid_db=list(range(-24,13)),labels=['DHIF','FULL'],training_contracts=dict(FULL=ct),
                batch=32,device='cpu',torch_version=str(torch.__version__),amp=False,tf32=False)
            old['fingerprint']=fingerprint(old);write_json(folder/'protocol_frozen.json',old)
            write_json(folder/'progress.json',dict(fingerprint=old['fingerprint'],completed=dict(h0_cal=64,h0_audit=64,h1=37)))
            for split,file in FILES.items():
                shape=(37,8,2) if split=='h1' else (64,2)
                value=np.zeros(shape);value[...,0]=999;value[...,1]=22;np.save(folder/file,value)
            p=dict(old,h0_cal_n=32,h0_audit_n=32,h1_scenes_n=4,scr_grid_db=list(range(-24,25)),source_lineage=dict(B280_A1='a1'))
            before={f.name:digest_file(f) for f in folder.iterdir()}
            with patch('torch.load',side_effect=AssertionError('No archived model may be loaded')):
                hist,reason=cached_ours(root/'old',p)
            self.assertIsNone(reason);self.assertTrue(all(np.all(v==22) for v in hist['arrays'].values()))
            self.assertFalse(hist['record']['model_executed']);self.assertEqual(hist['arrays']['h1'].shape,(37,4))
            p['source_lineage']['B280_A1']='changed';self.assertIsNone(cached_ours(root/'old',p)[0])
            self.assertEqual(before,{f.name:digest_file(f) for f in folder.iterdir()})

    def test_declared_prior_precision_and_F1(self):
        rates=classification_rates(.5,.1,.5)
        self.assertAlmostEqual(rates['precision'],50/60);self.assertAlmostEqual(rates['F1'],100/160)
        self.assertLess(classification_rates(.5,.1,.01)['precision'],rates['precision'])
        self.assertEqual(classification_rates(0,0,.5)['precision'],0.)

    def test_two_Pfa_report_mean_std_and_common_range_history(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            folder=Path(tmp);n=1000000;nh=64
            selection=dict(selected_label='seed_1',selected_seed=1)
            p=dict(version='B290_OURS_SEEDS_SCORE_V1',profile='full',only_method='ADN + TFSE + DHiF (Ours)',
                labels=['seed_1','seed_2'],names=dict(seed_1='Ours seed1',seed_2='Ours seed2'),
                h0_cal_n=n,h0_audit_n=100000,h1_scenes_n=nh,scr_grid_db=list(range(-24,25)),nominal_pfas=[1e-4,1e-5],
                positive_prior=.5,source_lineage={},seed_selection=selection)
            p['fingerprint']=fingerprint(p);write_json(folder/'protocol_frozen.json',p)
            write_json(folder/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=n,h0_audit=100000,h1=49)))
            cal=np.tile(np.linspace(-3,3,n)[:,None],(1,2));audit=np.tile(np.linspace(-3,2.99,100000)[:,None],(1,2))
            values=np.stack([np.linspace(-2,2,nh)+(scr+24)/4 for scr in p['scr_grid_db']]);h1=np.repeat(values[:,:,None],2,axis=2)
            for split,value in dict(h0_cal=cal,h0_audit=audit,h1=h1).items():np.save(folder/FILES[split],value)
            history=dict(arrays=dict(h0_cal=cal[:,0],h0_audit=audit[:,0],h1=h1[:37,:,0]),scr_grid_db=list(range(-24,13)),record=dict(source_sha256={}))
            with patch('b290_report.cached_ours',return_value=(history,None)):result=generate(folder,folder/'no-model')
            self.assertEqual(len(result['metrics']),6);self.assertFalse(result['other_methods_executed'])
            self.assertTrue(all(r['common_scr_max']==12 for r in result['comparisons']))
            self.assertTrue((folder/'figures/b290_pd_scr_pfa_1e-05.pdf').is_file())
            self.assertTrue((folder/'figures/b290_F1_scr_pfa_1e-05.pdf').is_file())
            self.assertFalse(result['seed_choice_uses_H1'])

    def test_cli_protects_other_experiment_outputs(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(RuntimeError,'output_b290_ours_seeds_'):cli(['--root',tmp,'--out-dir',tmp+'/output_b280_full_ablation_v1','--device','cpu'])
            a=cli(['--root',tmp,'--device','cpu'])
            self.assertEqual(a.seeds,[20261023,20261024,20261025]);self.assertFalse(a.full_all)


if __name__=='__main__':unittest.main()
