"""Fixed native ADN and TFSE; only new models insert DHiF after Layer2."""
import copy
import hashlib
import numpy as np
import torch
from torch import nn
from b289_common import need, source
from tfse_frontend import JointTFGate
from dhif_module import DHiF


def tensor_hash(state):
    h = hashlib.sha256()
    for name, value in sorted(state.items()):
        value = value.detach().cpu().contiguous()
        h.update(name.encode()); h.update(str(value.dtype).encode())
        h.update(np.asarray(value.shape, dtype='<i8').tobytes()); h.update(value.numpy().tobytes())
    return h.hexdigest()


class PlainADN(nn.Module):
    def __init__(self):
        super().__init__()
        self.detector = source().ADN18(num_classes=2)

    def prepared_forward(self, image):
        return self.detector(image)


class TFSECore(PlainADN):
    def __init__(self, scale):
        super().__init__()
        need(np.isfinite(scale) and scale > 0, 'Invalid frozen TFSE scale')
        self.scale = float(scale)
        self.gate = JointTFGate()

    def prepared_forward(self, bank):
        image, _ = self.gate(bank)
        return self.detector(image)


class Model(nn.Module):
    def __init__(self, reference, with_tfse):
        super().__init__()
        self.with_tfse = with_tfse
        self.net = copy.deepcopy(reference)
        self.net.requires_grad_(True)
        self.scale = reference.scale if with_tfse else None
        self.refiner = DHiF(128).initialize_identity()
        if with_tfse:
            self.net.gate.requires_grad_(False)
        for m in self.net.detector.modules():
            if isinstance(m, nn.modules.batchnorm._BatchNorm):
                m.requires_grad_(False)
        self.train(False)

    def train(self, mode=True):
        super().train(mode)
        if self.with_tfse:
            self.net.gate.eval()
        for m in self.net.detector.modules():
            if isinstance(m, nn.modules.batchnorm._BatchNorm):
                m.eval()
        return self

    def prepared_forward(self, value, return_aux=False):
        if self.with_tfse:
            with torch.no_grad():
                image, _ = self.net.gate(value)
        else:
            image = value
        d = self.net.detector
        x = d.maxpool(d.relu(d.bn1(d.conv1(image))))
        x = d.layer2(d.layer1(x))
        refined = self.refiner(x)
        aux = dict(mean_abs_feature_change=(refined - x).abs().mean())
        x = d.layer4(d.layer3(refined))
        z = d.fc(torch.flatten(d.avgpool(x), 1))
        return (z, aux) if return_aux else z


@torch.inference_mode()
def initial_check(model, reference, value):
    model.eval(); reference.eval()
    error = float((model.prepared_forward(value) - reference.prepared_forward(value)).abs().max())
    need(error <= 1e-6, 'Identity DHiF did not preserve source logits')
    shared = tensor_hash(model.net.state_dict())
    need(shared == tensor_hash(reference.state_dict()), 'Source tensors changed during candidate construction')
    count = sum(type(m).__name__ == 'SimAM' for m in model.net.detector.modules())
    need(count == 8, 'Retain every original ADN SimAM')
    return dict(initial_maxabs_logit_difference=error, shared_source_tensor_sha256=shared,
        original_SimAM_count=count, extra_parameters=sum(p.numel() for p in model.refiner.parameters()),
        DHiF_position='after complete native Layer2, before Layer3', feature_shape=[128, 28, 28],
        TFSE=model.with_tfse, LCBR=False, CGCR=False, TFCG=False, Tail=False,
        initialization='Dirac base kernel; zero dynamic operator, no outer residual gate')
