"""DHiF Eqs(5)-(8), Li et al., TCSVT2026; independent equation implementation.

The authors' model/basic.py is the numerical reference, not bundled here.
Same native 3x3, unit-stride module; no additional gating, attention or loss.
"""
import math
import torch
from torch import nn
from torch.nn import functional as F


class DHiF(nn.Module):
    def __init__(self, channels=128):
        super().__init__()
        self.channels = channels
        self.operator_conv = nn.Sequential(nn.Linear(9, 81), nn.Tanh())
        # Retain the author's input-channel/output-channel kernel layout.
        self.weight = nn.Parameter(torch.empty(channels, channels, 3, 3))
        self.bias = nn.Parameter(torch.empty(channels))
        nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))
        bound = 1 / math.sqrt(channels * 9)
        nn.init.uniform_(self.bias, -bound, bound)

    @torch.no_grad()
    def initialize_identity(self):
        # Warm-start adaptation only: a Dirac base kernel and a zero dynamic
        # operator yield the unchanged reference function. Both paths receive
        # gradients; there is no zero residual multiplier or output projection.
        self.weight.zero_()
        ix = torch.arange(self.channels, device=self.weight.device)
        self.weight[ix, ix, 1, 1] = 1
        self.bias.zero_()
        self.operator_conv[0].weight.zero_()
        self.operator_conv[0].bias.zero_()
        return self

    def forward(self, x):
        b, c, h, w = x.shape
        if c != self.channels:
            raise ValueError('DHiF channel interface differs')
        patches = F.unfold(x, kernel_size=3, padding=1).reshape(b, c, 9, h, w).permute(0, 1, 3, 4, 2)
        # The author's normalization is channel L2 norm, not unit-vector
        # normalization, spatial softmax or subtracting the local mean.
        descriptor = torch.norm(patches, p=2, dim=1)
        operators = self.operator_conv(descriptor).reshape(b, h, w, 9, 9)
        filtered = torch.einsum('bchwi,bhwij->bchwj', patches, operators)
        kernels = self.weight.reshape(c, c, 9).permute(1, 0, 2)
        output = torch.einsum('bchwk,ock->bohw', patches + filtered, kernels)
        return (output + self.bias[None, :, None, None]).contiguous()
