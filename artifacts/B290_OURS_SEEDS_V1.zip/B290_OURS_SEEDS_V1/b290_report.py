"""Ours seeds only, optional old-Ours cached overlay; no model execution."""
import numpy as np
from b289_common import FILES,need,read_json,write_json,save_csv,fingerprint,digest_file
from b290_stats import cutoff,wilson,crossing,classification_rates
from b290_history import cached_ours


def generate(folder,old_run):
    p=read_json(folder/'protocol_frozen.json');pr=read_json(folder/'progress.json')
    need(p['version']=='B290_OURS_SEEDS_SCORE_V1' and p['only_method']=='ADN + TFSE + DHiF (Ours)','Wrong Ours-only report')
    need(p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==pr['fingerprint'],'Score identity differs')
    need(pr['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=len(p['scr_grid_db'])),'Scoring incomplete')
    columns={label:{} for label in p['labels']}
    for split,file in FILES.items():
        n=p['h1_scenes_n'] if split=='h1' else p[split+'_n']
        shape=(len(p['scr_grid_db']),n,len(columns)) if split=='h1' else (n,len(columns))
        arr=np.load(folder/file,mmap_mode='r',allow_pickle=False)
        need(arr.shape==shape and arr.dtype==np.float64 and np.isfinite(arr).all(),'Malformed scores '+file)
        for j,label in enumerate(p['labels']):columns[label][split]=arr[...,j]
    history,reason=cached_ours(old_run,p)
    labels=list(p['labels']);names=dict(p['names']);grids={label:p['scr_grid_db'] for label in labels}
    if history is not None:
        columns['old_ours']=history['arrays'];labels.append('old_ours');grids['old_ours']=history['scr_grid_db']
        names['old_ours']='B289 Ours (cached scores)'
    curves=[];metrics=[];by_label={}
    for label in labels:
        data=columns[label];x=grids[label]
        for nominal in p['nominal_pfas']:
            th,k,cfp=cutoff(data['h0_cal'],nominal);n0=len(data['h0_audit'])
            fp=int((data['h0_audit']>th).sum());fpr=fp/n0;flo,fhi=wilson(fp,n0)
            hits=(data['h1']>th).sum(1);pd=hits/data['h1'].shape[1]
            peak=float(pd.max());m=dict(run=label,method=names[label],nominal_pfa=nominal,
                actual_pfa=fpr,audit_false_alarms=fp,audit_n=n0,actual_pfa_ci95_low=flo,actual_pfa_ci95_high=fhi,
                threshold=th,cal_n=len(data['h0_cal']),cal_tail_support=k,cal_exceedances=cfp,
                D50_db=crossing(x,pd,.5),D80_db=crossing(x,pd,.8),D90_db=crossing(x,pd,.9),
                max_pd=peak,max_pd_scr_db=';'.join(str(s) for s,q in zip(x,pd) if q==peak),
                first_observed_scr_pd_ge_0_9=next((s for s,q in zip(x,pd) if q>=.9),None),
                actual_scr_points=len(x),last_scr_db=x[-1],pd_at_last_scr=float(pd[-1]))
            metrics.append(m);by_label[label,nominal]=m
            for scr,count,value in zip(x,hits,pd):
                lo,hi=wilson(int(count),data['h1'].shape[1])
                curves.append(dict(run=label,method=names[label],nominal_pfa=nominal,scr_db=scr,hits=int(count),
                    n_h1=data['h1'].shape[1],pd=float(value),pd_ci95_low=lo,pd_ci95_high=hi,
                    actual_pfa=fpr,**classification_rates(float(value),fpr,p['positive_prior'])))
    comparisons=[]
    if history is not None:
        common=grids['old_ours'];last=len(common)
        for label in p['labels']:
            for nominal in p['nominal_pfas']:
                ref=by_label['old_ours',nominal]
                own=[r['pd'] for r in curves if r['run']==label and r['nominal_pfa']==nominal][:last]
                d80,d90=crossing(common,own,.8),crossing(common,own,.9)
                comparisons.append(dict(run=label,reference='old_ours',nominal_pfa=nominal,
                    common_scr_min=common[0],common_scr_max=common[-1],
                    delta_D80_db=None if d80 is None or ref['D80_db'] is None else d80-ref['D80_db'],
                    delta_D90_db=None if d90 is None or ref['D90_db'] is None else d90-ref['D90_db'],
                    own_audit_pfa=by_label[label,nominal]['actual_pfa'],reference_audit_pfa=ref['actual_pfa'],
                    negative_delta_means_left=True,scope='DEV descriptive, common SCR only'))
    save_csv(folder/'b290_curves.csv',curves);save_csv(folder/'b290_metrics.csv',metrics)
    if comparisons:save_csv(folder/'b290_comparisons.csv',comparisons)
    summaries=[]
    for nominal in p['nominal_pfas']:
        for scr in p['scr_grid_db']:
            values=[r['pd'] for r in curves if r['run'] in p['labels'] and r['nominal_pfa']==nominal and r['scr_db']==scr]
            summaries.append(dict(nominal_pfa=nominal,scr_db=scr,n_new_seeds=len(values),mean_pd=float(np.mean(values)),
                sample_std_pd=float(np.std(values,ddof=1)) if len(values)>1 else None))
    save_csv(folder/'b290_seed_mean_std.csv',summaries)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    figures=folder/'figures';figures.mkdir(exist_ok=True)
    colors=['#1f77b4','#2ca02c','#9467bd'];winner=p['seed_selection']['selected_label']
    for nominal in p['nominal_pfas']:
        for key,ylabel in [('pd',r'$P_d$'),('precision','Precision'),('F1','F1')]:
            fig,ax=plt.subplots(figsize=(8,5))
            for j,label in enumerate(labels):
                rows=[r for r in curves if r['run']==label and r['nominal_pfa']==nominal]
                color='gray' if label=='old_ours' else 'black' if label==winner else colors[j%len(colors)]
                ax.plot([r['scr_db'] for r in rows],[r[key] for r in rows],label=names[label],color=color,
                    linestyle='-',marker='v',markerfacecolor='white',markevery=3,markersize=5,linewidth=1.7)
            exponent=int(round(np.log10(nominal)))
            title=r'$P_{\mathrm{fa}}=10^{'+str(exponent)+'}$'
            if key!='pd':title+=f'; positive prior={p["positive_prior"]:g}'
            ax.set(xlabel='SCR (dB)',ylabel=ylabel,xlim=(p['scr_grid_db'][0],p['scr_grid_db'][-1]),ylim=(0,1.02),title=title)
            ax.grid(alpha=.25);ax.legend(fontsize=7);fig.tight_layout()
            for ext in ('pdf','png'):fig.savefig(figures/f'b290_{key}_scr_pfa_{nominal:.0e}.{ext}',dpi=250)
            plt.close(fig)
    if history is not None:
        need(all(digest_file(path)==sha for path,sha in history['record']['source_sha256'].items()),'Archived Ours inputs changed')
    result=dict(status='PASS_B290_OURS_SEEDS_REPORT',profile=p['profile'],executed_runs=p['labels'],only_method=p['only_method'],
        seed_selection=p['seed_selection'],metrics=metrics,comparisons=comparisons,
        source_lineage=p['source_lineage'],raw_score_sha256={f:digest_file(folder/f) for f in FILES.values()},
        archived_Ours_reused=history is not None,archived_Ours=history['record'] if history is not None else None,
        archived_Ours_unavailable_reason=reason,other_methods_executed=False,
        positive_prior=p['positive_prior'],Precision_F1_note='Derived from Pd and independent audited FPR at a fixed declared prior; not deployment precision unless prior is representative.',
        independent_final=False,source_Pd_unchanged=True,smoothing=False,curve_shifting=False,
        seed_choice_uses_H1=False,all_screened_seed_results_retained=True)
    write_json(folder/'b290_report.json',result)
    for row in metrics:
        print(f'{p["profile"]} {row["run"]} Pfa={row["nominal_pfa"]:.0e}: MAX Pd={row["max_pd"]:.4%} '
            f'at SCR={row["max_pd_scr_db"]}; D90={row["D90_db"]}; H0 FP={row["audit_false_alarms"]}/{row["audit_n"]}',flush=True)
    return result
