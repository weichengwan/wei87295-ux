"""Joint SPWVD display correction and WCSG context: shared learned controls."""
import torch
from torch import nn
import torch.nn.functional as F
from b289_common import need
from b289_common import frozen
spwvd_torch=frozen("legacy_tf_recovered.py").spwvd_torch

SETTINGS=dict(time_windows=[1,5,9],lag_half=24,nfft=128,coherence_window=9,
              consistency_relative_floor=1e-3,
              context_pools=[3,7,15],hidden=8,correction_bound=.25,gain_bound=.20,
              scale='first256 full TRAIN rows q99 logabs',heads='zero-initialized 3-channel shared head',
              baseline='window5 initial display; no second CNN; CE or CE+Tail depends on factor B')


def time_average(x,window):
    need(window%2==1 and x.ndim==3,'Expected odd time window and B,F,T map')
    b,f,t=x.shape
    return F.avg_pool1d(x.reshape(b*f,1,t),window,stride=1,padding=window//2).reshape(b,f,t)


@torch.no_grad()
def smoothing_bank(iq,scale):
    need(iq.ndim==2 and iq.shape[1]==512 and iq.dtype==torch.complex64,'Require complex64 IQ512')
    # One lag-product/FFT calculation. Other scales use inexpensive pooling.
    s1=spwvd_torch(iq,smooth_time=1);s5=time_average(s1,5);s9=time_average(s1,9)
    denominator=time_average(s1.abs(),9)
    # Pure-tone FFT bins near numerical zero must not become arbitrary
    # 0/1 consistency features under harmless complex64 phase roundoff.
    floor=(SETTINGS['consistency_relative_floor']*denominator.amax((1,2),keepdim=True)).clamp_min(1e-12)
    consistency=(s9.abs()/(denominator+floor)).clamp(0,1)
    return torch.stack((torch.log1p(s1.abs())/scale,torch.log1p(s5.abs())/scale,
                        torch.log1p(s9.abs())/scale,consistency),1)


class JointTFGate(nn.Module):
    def __init__(self):
        super().__init__();hidden=SETTINGS['hidden']
        self.pre=nn.Sequential(nn.Conv2d(5,hidden,3,padding=1,bias=False),nn.BatchNorm2d(hidden),nn.GELU(),
            nn.Conv2d(hidden,hidden,5,padding=2,groups=hidden,bias=False),nn.BatchNorm2d(hidden),nn.GELU())
        self.head=nn.Conv2d(hidden,3,1,bias=True)
        nn.init.zeros_(self.head.weight);nn.init.zeros_(self.head.bias)

    def forward(self,bank):
        need(bank.ndim==4 and bank.shape[1:]==(4,128,128),'Joint gate expects B,4,128,128 scale/consistency bank')
        z1,z5,z9,c=(bank[:,j:j+1] for j in range(4))
        context=torch.cat([z5]+[F.avg_pool2d(z5,k,stride=1,padding=k//2) for k in SETTINGS['context_pools']]+[c],1)
        controls=self.head(self.pre(context))
        a1=SETTINGS['correction_bound']*torch.tanh(controls[:,:1])
        a9=SETTINGS['correction_bound']*torch.tanh(controls[:,1:2])
        gain=1+SETTINGS['gain_bound']*torch.tanh(controls[:,2:3])
        # Bounded signed residuals: NOT a convex kernel or new exact SPWVD.
        corrected=(z5+a1*(z1-z5)+a9*(z9-z5)).clamp_min(0)
        output_gray=F.interpolate(corrected*gain,size=(224,224),mode='bilinear',align_corners=False)
        base=F.interpolate(z5,size=(224,224),mode='bilinear',align_corners=False)
        return output_gray.repeat(1,3,1,1),dict(input_gray=base,output_gray=output_gray,
            gain=gain,correction_short=a1,correction_long=a9,consistency=c,
            native_base=z5,native_corrected=corrected)

