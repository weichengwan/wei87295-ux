"""Only ADN+TFSE+DHiF: three fixed seed reruns, screen, VAL-selected full score."""
import argparse
import copy
import fcntl
import gc
import shutil
import time
from pathlib import Path
import torch
from b289_common import (ROOT,TRAIN_PASS,need,read_json,write_json,fingerprint,digest_file,
    code_hashes,validate_sources,setup)
from b289_source import load_sources,verify_protected
from b289_data import resolve,Data
from b289_train import preflight,train_arm,load_selected
from b290_score import protocol,stream


def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=ROOT.parent)
    for key in ('bank-dir','b280-run','old-ours-run','out-dir'):p.add_argument('--'+key,type=Path)
    p.add_argument('--seeds',type=int,nargs='+',default=[20261023,20261024,20261025])
    p.add_argument('--epochs',type=int,default=15);p.add_argument('--warmup-epochs',type=int,default=3)
    p.add_argument('--backbone-lr',type=float,default=1e-5);p.add_argument('--new-lr',type=float,default=3e-4)
    p.add_argument('--batch',type=int,default=32);p.add_argument('--chunk',type=int,default=512)
    p.add_argument('--cpu-threads',type=int,default=4);p.add_argument('--device',choices=('cuda','cpu'),default='cuda')
    p.add_argument('--max-scr',type=int,default=24)
    p.add_argument('--positive-prior',type=float,default=.5)
    p.add_argument('--full-all',action='store_true',help='Full-score all new seeds instead of only the VAL winner')
    p.add_argument('--stage',choices=('all','train','screen','full','report'),default='all')
    p.add_argument('--wait-for-gpu',action='store_true')
    a=p.parse_args(argv);a.root=a.root.resolve()
    for key,default in [('b280_run','output_b280_full_ablation_v1'),('old_ours_run','output_b289_dhif_two_full_v2'),
        ('out_dir','output_b290_ours_seeds_v1')]:setattr(a,key,(getattr(a,key) or a.root/default).resolve())
    need(a.root.is_dir() and a.out_dir.parent==a.root and a.out_dir.name.startswith('output_b290_ours_seeds_'),
         'Use a fresh direct output_b290_ours_seeds_* output only')
    for old in (a.b280_run,a.old_ours_run):
        need(old!=a.out_dir and old not in a.out_dir.parents and a.out_dir not in old.parents,'Do not overlap old runs')
    need(len(a.seeds) in (2,3) and len(set(a.seeds))==len(a.seeds) and all(0<=s<2**32 for s in a.seeds),'Use two or three distinct nonnegative training seeds')
    need(a.epochs>0 and 0<=a.warmup_epochs<=a.epochs and a.batch==32 and a.chunk>=32 and a.chunk%32==0,'Invalid epochs or fixed batch32 settings')
    need(a.cpu_threads>0 and a.backbone_lr>0 and a.new_lr>0 and 12<=a.max_scr<=40 and 0<a.positive_prior<1,'Invalid runtime or reporting settings')
    if a.out_dir.exists() and any(a.out_dir.iterdir()):
        need((a.out_dir/'run_manifest.json').is_file(),'Nonempty output has no Ours-seed identity')
        need(not any(f.is_symlink() for f in a.out_dir.rglob('*')),'Output contains symlinks; preserve it')
    if a.device=='cuda' and a.stage!='report':need(torch.cuda.is_available(),'CUDA unavailable')
    a.device=torch.device(a.device);a.seed=a.seeds[0]
    return a


def seed_args(a,seed):
    value=copy.copy(a);value.seed=seed;value.out_dir=a.out_dir/('seed_'+str(seed))
    return value


def select_val(a,info):
    rows=[]
    for seed in a.seeds:
        folder=seed_args(a,seed).out_dir/'FULL';ct=read_json(folder/'training_contract.json');cfg=ct['run_config']
        need(ct['status']==TRAIN_PASS and cfg['arm']=='FULL' and cfg['seed']==seed and
             cfg['source_lineage']==info['lineage'] and cfg['code_sha256']==code_hashes(),'Wrong Ours seed candidate')
        need(ct['run_fingerprint']==fingerprint(cfg) and digest_file(folder/'best.pt')==ct['checkpoint_sha256'],'Seed checkpoint/contract changed')
        v=ct['selected_validation']
        rows.append(dict(seed=seed,label='seed_'+str(seed),val_pauc01=v['val_pauc01'],val_ce=v['val_ce'],
            best_epoch=ct['best_epoch'],checkpoint_sha256=ct['checkpoint_sha256'],run_fingerprint=ct['run_fingerprint']))
    winner=sorted(rows,key=lambda r:(-r['val_pauc01'],r['val_ce'],r['seed']))[0]
    value=dict(version='B290_VAL_ONLY_SEED_SELECTION_V1',candidates=rows,selected_seed=winner['seed'],
        selected_label=winner['label'],selection_rule='max full VAL pAUC01, then min VAL CE, then lowest seed',
        H0_CAL_AUDIT_H1_used=False,committed_before_screening=True)
    value['fingerprint']=fingerprint(value);path=a.out_dir/'val_seed_selection.json'
    if path.exists():need(read_json(path)==value,'Committed VAL-only seed selection changed')
    else:write_json(path,value)
    return value


def acquire(lock,wait):
    while True:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);return
        except BlockingIOError:
            need(wait,'Another radar experiment holds the shared GPU lock')
            print('Waiting for current GPU experiment; no other task will be interrupted.',flush=True);time.sleep(30)


def main(argv=None):
    a=cli(argv);validate_sources()
    if a.stage=='report':
        torch.set_num_threads(a.cpu_threads)
        from b290_report import generate
        for profile in ('screen','full','full_all'):
            folder=a.out_dir/('pd_scr_'+profile)
            if folder.is_dir():generate(folder,a.old_ours_run)
        return
    setup(a.cpu_threads,a.seed)
    print('B290 ONLY ADN + TFSE + DHiF (Ours). Seeds='+str(a.seeds),flush=True)
    with (a.root/'codex_b271_night.lock').open('a') as lock:
        acquire(lock,a.wait_for_gpu);context=resolve(a);info=load_sources(a,context)
        a.out_dir.mkdir(exist_ok=True)
        identity=dict(version='B290_OURS_SEEDS_V1',only_method='ADN + TFSE + DHiF (Ours)',
            other_methods_executed=False,seeds=a.seeds,epochs=a.epochs,warmup_epochs=a.warmup_epochs,
            train=30000,val=5000,batch=a.batch,chunk=a.chunk,cpu_threads=a.cpu_threads,backbone_lr=a.backbone_lr,
            new_lr=a.new_lr,max_scr=a.max_scr,positive_prior=a.positive_prior,
            source_lineage=info['lineage'],code_sha256=code_hashes(),device=a.device.type,torch_version=str(torch.__version__))
        path=a.out_dir/'run_manifest.json'
        if path.exists():need(read_json(path)==identity,'Run settings changed; preserve output and choose another Ours-seed directory')
        else:
            need(not any(a.out_dir.iterdir()),'Nonempty output before identity');write_json(path,identity)
        if a.stage in ('all','train'):
            missing=sum(not (seed_args(a,s).out_dir/'FULL/training_contract.json').is_file() for s in a.seeds)
            need(shutil.disk_usage(a.out_dir).free>=max(512*1024**2,missing*1024**3),'Insufficient space for new seed checkpoints; no files deleted')
            raw=Data(context,30000,a.seed);pf=a.out_dir/'preflight.json';fp=fingerprint(identity)
            if pf.exists():
                v=read_json(pf);need(v['run_fingerprint']==fp,'Preflight differs');anchors=v['anchors']
            else:
                anchors,result=preflight(a,info,raw);write_json(pf,dict(run_fingerprint=fp,anchors=anchors,result=result))
            for seed in a.seeds:
                current=seed_args(a,seed);current.out_dir.mkdir(exist_ok=True)
                train_arm(current,context,info,raw,anchors['FULL'],'FULL')
            del raw;gc.collect();verify_protected(info)
            if a.device.type=='cuda':torch.cuda.empty_cache()
            if a.stage=='train':return
        selection=select_val(a,info)
        print('VAL-only chosen seed='+str(selection['selected_seed'])+'; choice frozen before Pd screening.',flush=True)
        for profile in ('screen','full'):
            if a.stage not in ('all',profile):continue
            seeds=a.seeds if profile=='screen' or a.full_all else [selection['selected_seed']]
            models={};contracts={}
            for seed in seeds:
                label='seed_'+str(seed);models[label],contracts[label]=load_selected(seed_args(a,seed),info,'FULL')
            p=protocol(a,info,models,contracts,profile,selection)
            folder_key='full_all' if profile=='full' and a.full_all else profile
            folder=a.out_dir/('pd_scr_'+folder_key)
            print(f'{profile}: {len(models)} Ours runs; CAL{p["h0_cal_n"]:,}, AUDIT{p["h0_audit_n"]:,}, H1={p["h1_scenes_n"]}x{len(p["scr_grid_db"])}',flush=True)
            need(shutil.disk_usage(a.out_dir).free>=256*1024**2,'Need256MiB for scores and figures')
            stream(a,info,models,p,folder)
            del models;gc.collect()
            if a.device.type=='cuda':torch.cuda.empty_cache()
            from b290_report import generate
            generate(folder,a.old_ours_run)
        write_json(a.out_dir/'protected_sources_after_run.json',verify_protected(info))
        print('PASS_B290_OURS_ONLY_SEEDS_COMPLETE: '+str(a.out_dir),flush=True)


if __name__=='__main__':main()
