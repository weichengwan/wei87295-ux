"""Read ONLY the archived B289 FULL score column; no model loading or execution."""
from pathlib import Path
import numpy as np
import torch
from b289_common import ROOT,FILES,need,read_json,fingerprint,digest_file


def cached_ours(directory,p):
    folder=directory/'pd_scr_full'
    try:
        pp=folder/'protocol_frozen.json';prp=folder/'progress.json'
        if not pp.is_file() or not prp.is_file():return None,'No completed archived Ours score metadata'
        old,pr=read_json(pp),read_json(prp)
        need(old['version']=='B289_DHIF_TWO_MODEL_FULL_SCORE_V2' and old['labels']==['DHIF','FULL'],'Unexpected archived release')
        need(old['fingerprint']==fingerprint({k:v for k,v in old.items() if k!='fingerprint'})==pr['fingerprint'],'Archived scoring identity differs')
        need(pr['completed']==dict(h0_cal=old['h0_cal_n'],h0_audit=old['h0_audit_n'],h1=len(old['scr_grid_db'])),'Archived scoring incomplete')
        for key in ('master_seed','generator_sha','h0_cal_split','h0_audit_split','h1_split','family_names','scr_definition'):
            need(old[key]==p[key],'Archived scene differs: '+key)
        need(old['scr_grid_db']==p['scr_grid_db'][:len(old['scr_grid_db'])],'Archived SCR is not the same prefix')
        for key in ('batch','device','torch_version','amp','tf32'):need(old.get(key)==p.get(key),'Archived inference setting differs: '+key)
        ct=old['training_contracts']['FULL'];cfg=ct['run_config']
        need(cfg['arm']=='FULL' and cfg['TFSE'] and not cfg['TFCG'] and not cfg['Tail'],'Wrong archived method')
        need(cfg['source_lineage']['B280_A1']==p['source_lineage']['B280_A1'],'Archived Ours has another initial A1')
        need(cfg['code_sha256']==read_json(ROOT/'expected_ours_code.json'),'Archived model release differs')
        need(ct['run_fingerprint']==fingerprint(cfg),'Archived training identity differs')
        arrays={};hashes={}
        for split,file in FILES.items():
            path=folder/file;n=p['h1_scenes_n'] if split=='h1' else p[split+'_n']
            oldn=old['h1_scenes_n'] if split=='h1' else old[split+'_n']
            need(oldn>=n,'Archived score prefix too short: '+split)
            value=np.load(path,mmap_mode='r',allow_pickle=False)
            shape=(len(old['scr_grid_db']),oldn,2) if split=='h1' else (oldn,2)
            need(value.shape==shape and value.dtype==np.float64,'Archived score shape/type differs')
            column=value[:,:n,1] if split=='h1' else value[:n,1]
            need(np.isfinite(column).all(),'Nonfinite archived Ours scores')
            arrays[split]=column;hashes[str(path)]=digest_file(path)
        rp=folder/'b289_report.json'
        if rp.is_file():
            reported=read_json(rp)
            for file in FILES.values():need(reported['raw_score_sha256'][file]==hashes[str(folder/file)],'Archived raw scores changed')
        hashes[str(pp)]=digest_file(pp);hashes[str(prp)]=digest_file(prp)
        return dict(arrays=arrays,scr_grid_db=old['scr_grid_db'],record=dict(folder=str(folder),column='FULL',
            column_index=1,checkpoint_sha256=ct['checkpoint_sha256'],training_contract=ct,
            source_sha256=hashes,model_loaded=False,model_executed=False,
            matching_prefix_calibration=(p['h0_cal_n']!=old['h0_cal_n']),original_score_files_unchanged=True)),None
    except (OSError,ValueError,RuntimeError,KeyError,TypeError) as error:return None,str(error)
