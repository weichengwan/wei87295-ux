"""Train ONLY the FULL Ours model on30k/5k. No standalone model optimization."""
import gc
import time
import numpy as np
import torch
import torch.nn.functional as F
from b289_common import (need, read_json, write_json, fingerprint, code_hashes, digest_file,
    save_csv, atomic_save, load_checkpoint, snapshot, setup, roc_metrics, TRAIN_PASS, source)
from b289_model import Model, initial_check
from b289_source import verify_protected
from tfse_frontend import smoothing_bank


class Prepared:
    def __init__(self, raw, with_tfse, scale=None):
        self.raw=raw;self.values=raw.values;self.selection=raw.selection
        self.with_tfse=with_tfse;self.scale=scale

    def fetch(self,split,index,device):
        iq,y=self.raw.fetch(split,index,device)
        if self.with_tfse:
            x=smoothing_bank(iq,self.scale)
        else:
            # Original frozen WVD, computed online: no multi-GiB feature cache.
            # Interpolation runs outside inference_mode; clone if a future
            # source change returns an inference tensor unsuitable for training.
            x=source().map_to_adn_input(source().wvd_base_map(iq))
            if torch.is_inference(x):x=x.clone()
        return x,y


@torch.inference_mode()
def evaluate(model,data,device,batch):
    model.eval();n=len(data.values['val'][1]);loss=0.;scores=[];labels=[]
    for start in range(0,n,batch):
        x,y=data.fetch('val',slice(start,min(start+batch,n)),device)
        z=model.prepared_forward(x)
        need(z.shape==(len(y),2) and torch.isfinite(z).all(),'Invalid VAL output')
        loss+=float(F.cross_entropy(z,y,reduction='sum'))
        scores.append((z[:,1]-z[:,0]).double().cpu().numpy());labels.append(y.cpu().numpy())
    return dict(val_ce=loss/n,n_val=n,**roc_metrics(np.concatenate(scores),np.concatenate(labels)))


def optimizer_for(model,a):
    params=[p for p in model.net.detector.parameters() if p.requires_grad]
    return torch.optim.Adam([dict(params=params,lr=a.backbone_lr),
        dict(params=model.refiner.parameters(),lr=a.new_lr)],weight_decay=1e-4)


def set_phase(model,warmup):
    for p in model.net.detector.parameters():p.requires_grad_(not warmup)
    for m in model.net.detector.modules():
        if isinstance(m,torch.nn.modules.batchnorm._BatchNorm):m.requires_grad_(False)
    if model.with_tfse:model.net.gate.requires_grad_(False)


@torch.inference_mode()
def diagnostics(model,x):
    model.eval();_,aux=model.prepared_forward(x,True)
    return dict(mean_abs_feature_change=float(aux['mean_abs_feature_change']),
        dynamic_linear_weight_abs_mean=float(model.refiner.operator_conv[0].weight.abs().mean()),
        base_kernel_abs_mean=float(model.refiner.weight.abs().mean()),
        module_parameters=sum(p.numel() for p in model.refiner.parameters()))


def preflight(a,info,raw):
    anchors={};checks={}
    for arm,key in [('FULL','A1')]:
        reference=info['models'][key]
        data=Prepared(raw,arm=='FULL',info['models']['A1'].scale)
        # Historical source VAL is read-only metadata. No full baseline VAL replay.
        anchor=dict(info['contracts'][key]['selected_validation'])
        historical=anchor['val_ce'];anchors[arm]=anchor
        setup(a.cpu_threads,a.seed)
        model=Model(reference,arm=='FULL').to(a.device)
        x,y=data.fetch('train',slice(0,a.batch),a.device)
        initial=initial_check(model,reference,x)
        optimizer=optimizer_for(model,a)
        if a.device.type=='cuda':torch.cuda.reset_peak_memory_stats(a.device)
        before_kernel=model.refiner.weight.detach().clone()
        before_operator=model.refiner.operator_conv[0].weight.detach().clone()
        gradient_checks=[]
        # Probe the more memory-demanding joint phase, then discard this model.
        for step in range(3):
            model.train();optimizer.zero_grad(set_to_none=True)
            loss=F.cross_entropy(model.prepared_forward(x),y)
            need(torch.isfinite(loss),'Nonfinite DHiF optimizer canary')
            loss.backward()
            kg=float(model.refiner.weight.grad.abs().sum())
            og=float(model.refiner.operator_conv[0].weight.grad.abs().sum())
            need(kg>0 and og>0,'DHiF base kernel or dynamic operator has no gradient')
            gradient_checks.append(dict(step=step+1,kernel_grad_abs_sum=kg,operator_grad_abs_sum=og,CE=float(loss.detach())))
            optimizer.step()
        need(not torch.equal(before_kernel,model.refiner.weight) and
             not torch.equal(before_operator,model.refiner.operator_conv[0].weight),'DHiF did not update')
        checks[arm]=dict(anchor=anchor,historical_VAL_CE=historical,source_full_VAL_recomputed=False,
            initialization=initial,gradient_checks=gradient_checks,discarded_optimizer_steps=True,
            module_after_probe=diagnostics(model,x),
            peak_allocated_GiB=torch.cuda.max_memory_allocated(a.device)/1024**3 if a.device.type=='cuda' else None)
        del model,optimizer,x,y,loss,before_kernel,before_operator;gc.collect()
        if a.device.type=='cuda':torch.cuda.empty_cache()
        print(f'PASS_B290_{arm}_IDENTITY_AND_BOTH_DHIF_PATHS_LEARN',flush=True)
    return anchors,dict(candidate_checks=checks,fixed_TFSE_experiment_executed=False,protected=verify_protected(info))


def config(a,context,info,data,arm):
    key='A1'
    return dict(version='B290_OURS_SEED_TRAIN_V1',arm=arm,seed=a.seed,epochs=a.epochs,
        module_only_warmup_epochs=a.warmup_epochs,batch=a.batch,cpu_threads=a.cpu_threads,
        selected_rows=data.selection,bank_sha256=context['bc']['file_sha256'],source_lineage=info['lineage'],
        initial_checkpoint=info['contracts'][key]['checkpoint_sha256'],
        backbone_lr=a.backbone_lr,new_module_lr=a.new_lr,optimizer='Adam',weight_decay=1e-4,loss='CE only',
        schedule='constant learning rates;3 module-only epochs then joint adaptation by default',
        TFSE=arm=='FULL',LCBR=False,CGCR=False,TFCG=False,Tail=False,
        frontend_frozen=True,native_BN_affine_and_running_frozen=True,
        position='after complete native Layer2 before Layer3',
        selection='maximum full VAL pAUC01 among trained epochs; CE tie-break; epoch0 diagnostic only',
        original_CE_plus_0_01_guard_used=False,selection_uses_CAL_AUDIT_H1=False,
        code_sha256=code_hashes(),device=a.device.type,torch_version=str(torch.__version__),amp=False,tf32=False,
        fixed_control_continuation_budget_matched=False)


def better(value,best):
    return best is None or value['val_pauc01']>best['val_pauc01']+1e-12 or (
        abs(value['val_pauc01']-best['val_pauc01'])<=1e-12 and value['val_ce']<best['val_ce'])


def train_arm(a,context,info,raw,anchor,arm):
    need(arm=='FULL','Only ADN + TFSE + DHiF (Ours) is allowed')
    folder=a.out_dir/arm;folder.mkdir(exist_ok=True)
    reference=info['models']['A1']
    data=Prepared(raw,arm=='FULL',info['models']['A1'].scale)
    cfg=config(a,context,info,data,arm);fp=fingerprint(cfg)
    manifest=folder/'run_manifest.json';ct_path=folder/'training_contract.json'
    best_path=folder/'best.pt';last=folder/'last_epoch.pt'
    identity=dict(run_config=cfg,run_fingerprint=fp)
    if manifest.exists():need(read_json(manifest)==identity,'Training settings changed; use another independent output')
    else:
        need(not any(folder.iterdir()),'Nonempty candidate folder without manifest');write_json(manifest,identity)
    if ct_path.exists():
        ct=read_json(ct_path)
        need(ct['status']==TRAIN_PASS and ct['run_fingerprint']==fp and digest_file(best_path)==ct['checkpoint_sha256'],'Completed candidate changed')
        print(arm+' completed; verified and skipped retraining',flush=True);return ct
    setup(a.cpu_threads,a.seed);model=Model(reference,arm=='FULL').to(a.device)
    x,y=data.fetch('train',slice(0,a.batch),a.device);initial=initial_check(model,reference,x)
    optimizer=optimizer_for(model,a);history=[];start=1
    def state(epoch,metrics):return dict(state_dict=snapshot(model),epoch=epoch,val_metrics=metrics,run_config=cfg,run_fingerprint=fp)
    def commit(epoch,best):
        value=state(epoch,history[-1]);value.update(best_checkpoint=best,history=history,optimizer=optimizer.state_dict(),
            initialization=initial,anchor=anchor,torch_rng=torch.get_rng_state(),
            cuda_rng=torch.cuda.get_rng_state_all() if a.device.type=='cuda' else [])
        atomic_save(last,value)
        if best is not None:atomic_save(best_path,best)
        save_csv(folder/'train_val_history.csv',history)
    if last.exists():
        saved=load_checkpoint(last);need(saved['run_config']==cfg and saved['run_fingerprint']==fp and saved['anchor']==anchor,'Resume identity differs')
        model.load_state_dict(saved['state_dict'],strict=True);optimizer.load_state_dict(saved['optimizer'])
        best=saved['best_checkpoint'];history=saved['history'];initial=saved['initialization'];start=saved['epoch']+1
        torch.set_rng_state(saved['torch_rng'])
        if a.device.type=='cuda':torch.cuda.set_rng_state_all(saved['cuda_rng'])
        del saved
    else:
        value=evaluate(model,data,a.device,a.batch)
        need(abs(value['val_ce']-anchor['val_ce'])<=2e-4,'Initial candidate full VAL differs from historical source; preserve old files')
        best=None;history=[dict(epoch=0,train_ce=None,**value,best_epoch=None,phase='source_identity',elapsed_s=0.)]
        commit(0,best)
    for epoch in range(start,a.epochs+1):
        began=time.perf_counter();warmup=epoch<=a.warmup_epochs
        set_phase(model,warmup);model.train();total=seen=0
        n=len(data.values['train'][1]);order=np.random.default_rng(a.seed+997*epoch).permutation(n)
        for offset in range(0,n,a.batch):
            value,y=data.fetch('train',order[offset:offset+a.batch],a.device)
            optimizer.zero_grad(set_to_none=True);loss=F.cross_entropy(model.prepared_forward(value),y)
            need(torch.isfinite(loss),'Nonfinite TRAIN CE');loss.backward();optimizer.step()
            total+=float(loss.detach())*len(y);seen+=len(y)
            if seen==n or seen%6400<a.batch:print(f'[{arm}] epoch {epoch}/{a.epochs} TRAIN {seen:,}/{n:,}',flush=True)
        v=evaluate(model,data,a.device,a.batch)
        if better(v,None if best is None else best['val_metrics']):best=state(epoch,v)
        elapsed=time.perf_counter()-began
        history.append(dict(epoch=epoch,train_ce=total/seen,**v,best_epoch=best['epoch'],
            phase='DHiF_only' if warmup else 'CNN_and_DHiF',elapsed_s=elapsed))
        commit(epoch,best)
        print(f'[{arm}] {epoch}/{a.epochs} VAL_CE={v["val_ce"]:.6f} pAUC01={v["val_pauc01"]:.6f} '
              f'best={best["epoch"]} phase={history[-1]["phase"]} time={elapsed:.1f}s; '
              f'current-arm remaining~{elapsed*(a.epochs-epoch)/60:.1f}min',flush=True)
    need(best is not None and best['epoch']>0,'No trained candidate selected')
    model.load_state_dict(best['state_dict'],strict=True)
    replay=evaluate(model,data,a.device,a.batch)
    need(abs(replay['val_ce']-best['val_metrics']['val_ce'])<1e-6,'Selected candidate VAL replay differs')
    diag=diagnostics(model,x)
    need(diag['mean_abs_feature_change']>0,'Selected DHiF remained the unchanged source function')
    ct=dict(status=TRAIN_PASS,run_config=cfg,run_fingerprint=fp,checkpoint_sha256=digest_file(best_path),
        best_epoch=best['epoch'],initialization=initial,anchor_validation=anchor,selected_validation=replay,
        module_diagnostics=diag,CAL_AUDIT_H1_used_for_training=False,pure_ADN_trained=False,
        fixed_TFSE_trained=False,protected_sources=verify_protected(info))
    write_json(ct_path,ct);del model,optimizer,best,x,y;gc.collect()
    if a.device.type=='cuda':torch.cuda.empty_cache()
    print(f'{TRAIN_PASS}; {arm}; selected epoch={ct["best_epoch"]}',flush=True);return ct


def load_selected(a,info,arm):
    need(arm=='FULL','Only Ours may be loaded')
    folder=a.out_dir/arm;ct=read_json(folder/'training_contract.json');cfg=ct['run_config'];path=folder/'best.pt'
    need(ct['status']==TRAIN_PASS and cfg['arm']==arm and cfg['source_lineage']==info['lineage'] and cfg['code_sha256']==code_hashes(),'Selected candidate identity differs')
    need(digest_file(path)==ct['checkpoint_sha256'],'Selected checkpoint SHA differs')
    state=load_checkpoint(path)
    need(state['run_config']==cfg and state['run_fingerprint']==ct['run_fingerprint']==fingerprint(cfg) and state['epoch']==ct['best_epoch'],'Selected checkpoint internal identity differs')
    model=Model(info['models']['A1'],arm=='FULL')
    model.load_state_dict(state['state_dict'],strict=True)
    return model.to(a.device).eval().requires_grad_(False),ct
