# B290：只重复 ADN＋TFSE＋DHiF（Ours），三个新训练种子

本包只训练、推理同一个方法 **ADN＋TFSE＋DHiF（Ours）**。
不训练或评分原始ADN、ADN＋DHiF、TFSE单独对照或任何外部baseline。
B289模型、DHiF和TFSE前端代码逐字节保留，见 `MODEL_UNCHANGED.json`。
ADN骨干内部定义是Ours的一部分，不代表额外启动原始ADN实验。

## 本轮固定设置

- 新训练种子：20261023、20261024、20261025。
- 所有种子从同一个旧B280 A1检查点的副本初始化；不继续优化旧B289检查点。
- 同一冻结TRAIN30,000、VAL5,000；种子改变训练批次顺序，不改变IQ数据、VAL或H0/H1场景种子。
- 每次15epoch：前3epoch只更新DHiF，后12epoch更新CNN＋DHiF。
- CNN lr1e-5，DHiF lr3e-4，Adam，weight_decay1e-4，CE。
- TFSE前端和原生BN仿射参数、运行统计冻结，与B289一致。
- DHiF仍在完整Layer2后、Layer3前，保留全部8个SimAM；没有新增模块或损失。

这轮先只改变训练种子，便于区分随机波动；真实Pd是否提升由实验结果判断。

## 默认自动流程

1. 顺序完成三个种子的训练，保存各自所有训练记录和选中检查点。
2. 仅按完整VAL pAUC@FPR<=0.01最高、VAL CE最低、种子数值最小的顺序选出一个种子。
   写入 `val_seed_selection.json` 后才开始H0/H1评分。不会看Pd图后偷偷重选种子。
3. 对三个新种子做同场景中规模评分：CAL300,000、AUDIT200,000、每SCR512条H1，Pfa1e-4。
   中规模CAL不足以可靠支持1e-5，所以此阶段不画1e-5。
4. 默认只对VAL选中的一个种子做完整评分：CAL3,000,000、AUDIT1,000,000、每SCR1,024条H1，Pfa1e-4和1e-5。
5. 输出所有种子的中规模Pd、均值和样本标准差；保留全部结果。全量输出包含最高Pd、峰值SCR、D80/D90、实际虚警率。

SCR统一为 **-24到+24dB，1dB步长，共49点**，便于后续与B288完整结果对齐。
H0/H1生成器固定；所有新种子共享相同回波与每批TFSE表征计算。
VAL的pAUC01只是选择代理，5000VAL不能直接证明1e-4/1e-5的性能。
这些仍是已暴露的SIM-R10 DEV实验，不能写成独立最终测试。

如需三个新种子都进行完整双Pfa推理，添加 `--full-all`。
它保存到 `pd_scr_full_all/`，已完成的训练会校验后跳过，不重新训练。
参数不变时，也可在默认任务结束后用此选项补齐其他种子的全量评分。

## 旧 Ours 的参考曲线

只读取旧 `output_b289_dhif_two_full_v2/pd_scr_full/` 的FULL分数列，绝不执行旧网络。
不读取其中DHIF列作比较，也不加载原始ADN或外部baseline。
只有旧代码身份、A1血缘、场景、批次和运行设置一致时才使用缓存。

中规模比较将旧CAL/AUDIT/H1分数裁成相同前缀，再按相同CAL规模计算参考阈值；
因此这条中规模参考不是旧全量PDF的重命名，旧全量结果不会改变。
全量比较使用旧完整CAL和AUDIT；旧H1只到+12dB，参考曲线如实止于+12，
不会外推到+24，D80/D90差值只在双方共有SCR区间计算。
缺少兼容旧分数时只画新种子结果，不触发旧模型重新推理。

## Precision、F1 与合图

本包在CPU上由每点Pd和独立AUDIT虚警率计算样本级Precision、Recall、F1，无需额外神经网络推理。
默认正类先验0.5，即统一的正负1:1评估口径，并在图标题和CSV中注明。

```text
Precision = pi*Pd / (pi*Pd + (1-pi)*Pfa_actual)
F1 = 2*pi*Pd / (pi*(1+Pd) + (1-pi)*Pfa_actual)
```

没有预测为正的样本时Precision按0记录。不同方法必须使用同一pi；不能通过改变正负比例制造优势。
这与直接拼接100万H0和1024个H1得到的样本先验不同，不应混称部署Precision。
有旧Pd、实际审计Pfa和固定样本口径时，也可纯CPU计算其他方法的这些指标。

合并外部baseline的Pd图本身只需要CSV和CPU；要先确认场景生成器、划分、SCR定义和阈值协议。
协议不一致时需要固定权重重新评分；只缺高SCR点时仅补H1，不必重训。
本包按用户要求先只运行Ours，未启动任何外部baseline评分。

## AutoDL一键启动

解压到 `/root/autodl-tmp/MTDSP_NATIVE_LMDA_V1` 后运行：

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
bash B290_OURS_SEEDS_V1/start_on_autodl.sh
tail -F codex_b290_ours_seeds.log
```

使用conda run，无需conda activate。GPU被现有共享锁任务占用时自动等待。
nohup后台执行，SSH断线后继续；同一命令可恢复最近完整epoch和已提交评分块/SCR。
所有新结果写入 `output_b290_ours_seeds_v1/`，不覆盖旧结果。
前三个种子检查点及原子写入建议预留约3GiB；不生成额外时频图缓存。

三个种子全部完整评分：

```bash
bash B290_OURS_SEEDS_V1/start_on_autodl.sh --full-all
```

上述两个启动方式选择其一；已有任务运行时重复启动会识别PID，不启动第二个同名任务。

默认必需只读输入：

```text
SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1/
output_b280_full_ablation_v1/A1/{best.pt,training_contract.json}
output_b280_full_ablation_v1/pd_scr_full/{protocol_frozen.json,progress.json}
```

不需要A0检查点。缺文件时明确报路径，不自动训练其他模型补齐。

## 结果位置

```text
output_b290_ours_seeds_v1/
  seed_20261023/FULL/best.pt
  seed_20261024/FULL/best.pt
  seed_20261025/FULL/best.pt
  val_seed_selection.json
  pd_scr_screen/b290_metrics.csv
  pd_scr_screen/b290_seed_mean_std.csv
  pd_scr_full/b290_metrics.csv
  pd_scr_full/b290_comparisons.csv
  pd_scr_full/figures/b290_pd_scr_pfa_1e-04.pdf
  pd_scr_full/figures/b290_pd_scr_pfa_1e-05.pdf
```

`b290_curves.csv`逐点包含Pd、Precision、Recall、F1、实际Pfa、正类先验。
同一figures目录包含Precision和F1图。启用full-all时全量目录改为 `pd_scr_full_all/`。
选中种子用黑色实线空心倒三角，其他种子用不同颜色实线倒三角，旧Ours缓存用灰色实线。
图上方标Pfa，横轴SCR(dB)、纵轴Pd；不平移、不平滑、不强制单调。

只重新绘图、计算指标可用CPU：

```bash
/root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  python B290_OURS_SEEDS_V1/b290_run.py --stage report --device cpu
```

## 本地验证

```bash
python -m unittest discover -s tests -v
```

使用合成微型数据验证单方法限制、A0缺失时仍可运行、原始权重保护、
真实优化器和训练恢复、VAL选择先于H1、共享表征评分恢复、
旧FULL列只读、Precision/F1公式及报告。CPU测试不代表真实Pd提升。
