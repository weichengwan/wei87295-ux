"""Joint TSFEM/FFM/MobileNetV3 training: paper Adam, CE and StepLR."""
import gc
import time
import numpy as np
import torch
import torch.nn.functional as F
from b288_common import (need, read_json, write_json, fingerprint, digest_file, code_hashes,
    save_csv, atomic_save, load_checkpoint, snapshot, setup, roc_metrics, TRAIN_PASS)
from b288_model import TSDetectNet, architecture_audit


def config(a, context, data):
    return dict(version='B288_TSDETECTNET_FULL_TRAIN_V2', model='TS-DetectNet', pulses=512,
        training_size='full', epochs=a.epochs, batch=a.train_batch, seed=a.seed,
        validation_batch=a.batch, cpu_threads=a.cpu_threads,
        selected_rows=data.selection, bank_sha256=context['bc']['file_sha256'],
        optimizer='Adam', lr=.001, betas=[.9, .99], weight_decay=0.,
        loss='cross entropy; no auxiliary loss', schedule='StepLR(step_size=5,gamma=0.5), after each epoch',
        selection='minimum full VAL CE among trained epochs; no CAL/AUDIT/H1 selection',
        code_sha256=code_hashes(), device=a.device.type, torch_version=str(torch.__version__),
        amp=False, tf32=False, pretrained=False, input_normalization='none',
        shuffle='deterministic random permutation; no augmentation',
        ADN_trained=False, ours_trained=False, source_checkpoint_loaded=False)


@torch.inference_mode()
def evaluate(model, data, device, batch, return_scores=False):
    model.eval()
    n = len(data.values['val'][1])
    loss = correct = 0
    scores, labels = [], []
    for start in range(0, n, batch):
        x, y = data.fetch('val', slice(start, min(start + batch, n)), device)
        z = model(x)
        need(z.shape == (len(y), 2) and torch.isfinite(z).all(), 'Invalid VAL logits')
        loss += float(F.cross_entropy(z, y, reduction='sum'))
        correct += int((z.argmax(1) == y).sum())
        scores.append((z[:, 1] - z[:, 0]).double().cpu().numpy())
        labels.append(y.cpu().numpy())
    s, y = np.concatenate(scores), np.concatenate(labels)
    metrics = dict(val_ce=loss / n, val_acc=correct / n, n_val=n, **roc_metrics(s, y))
    return (metrics, s, y) if return_scores else metrics


def optimizer_canary(a, data):
    setup(a.cpu_threads, a.seed)
    model = TSDetectNet().to(a.device)
    optimizer = torch.optim.Adam(model.parameters(), lr=.001, betas=(.9, .99))
    labels = data.values['train'][1]
    # AutoDL uses the full requested training batch for the VRAM probe.
    # The CPU code test uses8 rows and does not claim a GPU memory check.
    n = a.train_batch if a.device.type == 'cuda' else min(8, a.train_batch)
    ix = np.r_[np.flatnonzero(labels == 0)[:n // 2], np.flatnonzero(labels == 1)[:n // 2]]
    need(len(ix) == n, 'Insufficient balanced TRAIN rows for optimizer probe')
    x, y = data.fetch('train', ix, a.device)
    if a.device.type == 'cuda':
        torch.cuda.reset_peak_memory_stats(a.device)
    before = {k: snapshot(model)[k] for k in (
        'frontend.real_conv.weight', 'frontend.imag_conv.weight', 'frontend.fusion.0.weight', 'detector.classifier.3.weight')}
    model.train()
    losses = []
    for _ in range(3):
        optimizer.zero_grad(set_to_none=True)
        loss = F.cross_entropy(model(x), y)
        need(torch.isfinite(loss), 'Nonfinite TRAIN optimizer probe')
        loss.backward()
        optimizer.step()
        losses.append(float(loss.detach()))
    after = model.state_dict()
    need(all(not torch.equal(v, after[k].cpu()) for k, v in before.items()), 'One of the original model stages did not update')
    model.eval()
    with torch.inference_mode():
        # Inference memory checked at requested batch on GPU, small batch on CPU.
        q = x.repeat((max(1, (a.batch + len(x) - 1) // len(x)), 1))[:a.batch] if a.device.type == 'cuda' else x
        z = model(q)
        need(z.shape == (len(q), 2) and torch.isfinite(z).all(), 'Inference probe failed')
    result = dict(three_optimizer_steps_discarded=True, actual_training_probe_batch=n,
        actual_inference_probe_batch=len(q), loss_values=losses,
        all_original_stages_updated=True, synthetic_data=False,
        peak_allocated_GiB=torch.cuda.max_memory_allocated(a.device) / 1024**3 if a.device.type == 'cuda' else None,
        architecture=architecture_audit(), ADN_loaded=False, ours_loaded=False)
    del model, optimizer, x, y, z, loss, after, before
    gc.collect()
    if a.device.type == 'cuda':
        torch.cuda.empty_cache()
    print('PASS_B288_TRAIN_OPTIMIZER_AND_INFERENCE_CANARY', flush=True)
    return result


def train(a, context, data):
    folder = a.train_dir
    cfg = config(a, context, data)
    fp = fingerprint(cfg)
    manifest, contract = folder / 'run_manifest.json', folder / 'training_contract.json'
    best_path, last_path = folder / 'best.pt', folder / 'last_epoch.pt'
    if manifest.exists():
        need(read_json(manifest) == dict(config=cfg, fingerprint=fp), 'Training settings changed; preserve run and choose another output')
    else:
        write_json(manifest, dict(config=cfg, fingerprint=fp))
    if contract.exists():
        ct = read_json(contract)
        need(ct['status'] == TRAIN_PASS and ct['run_fingerprint'] == fp, 'Completed training identity differs')
        need(digest_file(best_path) == ct['checkpoint_sha256'], 'Selected checkpoint changed')
        print('Completed TS-DetectNet training verified; skipped retraining', flush=True)
        return ct
    setup(a.cpu_threads, a.seed)
    model = TSDetectNet().to(a.device)
    optimizer = torch.optim.Adam(model.parameters(), lr=.001, betas=(.9, .99), weight_decay=0.)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=5, gamma=.5)
    history, start = [], 1

    def state(epoch, metrics):
        return dict(state_dict=snapshot(model), epoch=epoch, val_metrics=metrics, run_config=cfg, run_fingerprint=fp)

    def commit(epoch, best):
        value = state(epoch, {k: history[-1][k] for k in ('val_ce', 'val_acc', 'n_val', 'val_auc', 'val_pauc01')})
        value.update(best_checkpoint=best, history=history, optimizer=optimizer.state_dict(), scheduler=scheduler.state_dict(),
                     torch_rng=torch.get_rng_state(), cuda_rng=torch.cuda.get_rng_state_all() if a.device.type == 'cuda' else [])
        atomic_save(last_path, value)
        if best is not None:
            atomic_save(best_path, best)
        save_csv(folder / 'train_val_history.csv', history)

    if last_path.exists():
        saved = load_checkpoint(last_path)
        need(saved['run_config'] == cfg and saved['run_fingerprint'] == fp, 'Resume identity differs')
        model.load_state_dict(saved['state_dict'], strict=True)
        optimizer.load_state_dict(saved['optimizer'])
        scheduler.load_state_dict(saved['scheduler'])
        best, history, start = saved['best_checkpoint'], saved['history'], saved['epoch'] + 1
        torch.set_rng_state(saved['torch_rng'])
        if a.device.type == 'cuda':
            torch.cuda.set_rng_state_all(saved['cuda_rng'])
        del saved
    else:
        metrics = evaluate(model, data, a.device, a.batch)
        best = None
        history = [dict(epoch=0, train_ce=None, lr=None, **metrics, best_epoch=None, elapsed_s=0.)]
        commit(0, best)
    for epoch in range(start, a.epochs + 1):
        began = time.perf_counter()
        model.train()
        total = seen = 0
        n = len(data.values['train'][1])
        order = np.random.default_rng(a.seed + 997 * epoch).permutation(n)
        current_lr = optimizer.param_groups[0]['lr']
        for offset in range(0, n, a.train_batch):
            ix = order[offset:offset + a.train_batch]
            x, y = data.fetch('train', ix, a.device)
            optimizer.zero_grad(set_to_none=True)
            loss = F.cross_entropy(model(x), y)
            need(torch.isfinite(loss), 'Nonfinite training CE')
            loss.backward()
            optimizer.step()
            total += float(loss.detach()) * len(y)
            seen += len(y)
            if seen == n or seen % 4096 < a.train_batch:
                print(f'[TS-DetectNet] epoch {epoch}/{a.epochs} TRAIN {seen:,}/{n:,}', flush=True)
        metrics = evaluate(model, data, a.device, a.batch)
        if best is None or metrics['val_ce'] < best['val_metrics']['val_ce'] - 1e-8:
            best = state(epoch, metrics)
        elapsed = time.perf_counter() - began
        history.append(dict(epoch=epoch, train_ce=total / seen, lr=current_lr, **metrics,
                            best_epoch=best['epoch'], elapsed_s=elapsed))
        scheduler.step()
        commit(epoch, best)
        print(f'[TS-DetectNet] {epoch}/{a.epochs} VAL_CE={metrics["val_ce"]:.6f} '
              f'VAL_AUC={metrics["val_auc"]:.6f} best={best["epoch"]} time={elapsed:.1f}s; '
              f'train remaining~{elapsed * (a.epochs - epoch) / 60:.1f}min', flush=True)
    need(best is not None and best['epoch'] >= 1, 'No trained model selected')
    model.load_state_dict(best['state_dict'], strict=True)
    replay, scores, labels = evaluate(model, data, a.device, a.batch, return_scores=True)
    need(abs(replay['val_ce'] - best['val_metrics']['val_ce']) < 1e-6, 'Selected full VAL replay differs')
    save_csv(folder / 'b288_val_scores.csv', [dict(row=i, label=int(y), logit_margin=float(s)) for i, (s, y) in enumerate(zip(scores, labels))])
    ct = dict(status=TRAIN_PASS, run_config=cfg, run_fingerprint=fp,
        checkpoint_sha256=digest_file(best_path), best_epoch=best['epoch'], selected_validation=replay,
        CAL_AUDIT_H1_used_for_training=False, ADN_loaded=False, ADN_trained=False,
        ours_loaded=False, ours_trained=False, official_author_checkpoint=False)
    write_json(contract, ct)
    del model, optimizer, best
    gc.collect()
    if a.device.type == 'cuda':
        torch.cuda.empty_cache()
    print(f'{TRAIN_PASS}; selected epoch={ct["best_epoch"]}', flush=True)
    return ct


def load_selected(a, context):
    ct = read_json(a.train_dir / 'training_contract.json')
    path = a.train_dir / 'best.pt'
    cfg = ct['run_config']
    need(ct['status'] == TRAIN_PASS and cfg['bank_sha256'] == context['bc']['file_sha256'], 'Wrong selected training bank')
    need(cfg['code_sha256'] == code_hashes(), 'Implementation changed after training')
    need(digest_file(path) == ct['checkpoint_sha256'], 'Selected checkpoint checksum differs')
    state = load_checkpoint(path)
    need(state['run_config'] == cfg and state['run_fingerprint'] == ct['run_fingerprint'] == fingerprint(cfg), 'Checkpoint identity differs')
    need(state['epoch'] == ct['best_epoch'], 'Checkpoint epoch differs')
    model = TSDetectNet()
    model.load_state_dict(state['state_dict'], strict=True)
    return model.to(a.device).eval().requires_grad_(False), ct
