"""TS-DetectNet, Xu et al., IEEE Sensors Journal2025, Eqs(5)-(13)."""
import torch
from torch import nn
from vendor.mobilenet_v3 import mobilenet_v3_small


class TimeKernelFrontend(nn.Module):
    def __init__(self, pulses=512):
        super().__init__()
        if pulses not in (256, 512, 1024):
            raise ValueError('Use one of the pulse lengths evaluated in the paper')
        self.pulses = pulses
        kernels, width = pulses // 4, pulses // 8
        self.real_conv = nn.Conv1d(1, kernels, width, stride=2, bias=True)
        self.imag_conv = nn.Conv1d(1, kernels, width, stride=2, bias=True)
        self.fusion = nn.Sequential(
            nn.Conv2d(2, 3, kernel_size=3, stride=(1, 2), bias=True),
            nn.BatchNorm2d(3), nn.ReLU(inplace=True))

    def time_kernel(self, iq):
        if not iq.is_complex() or iq.ndim != 2 or iq.shape[1] != self.pulses:
            raise ValueError(f'Expected complex [B,{self.pulses}] IQ')
        real = self.real_conv(iq.real.float().unsqueeze(1))
        imag = self.imag_conv(iq.imag.float().unsqueeze(1))
        return torch.stack((real, imag), dim=1)

    def forward(self, iq):
        return self.fusion(self.time_kernel(iq))


class TSDetectNet(nn.Module):
    def __init__(self, pulses=512):
        super().__init__()
        self.frontend = TimeKernelFrontend(pulses)
        # Binary standard Small gives1,519,906 parameters, matching Table VI1.52M.
        # No resizing, pretrained weights, input adapter or additional attention.
        self.detector = mobilenet_v3_small(pretrained=False, num_classes=2)

    def forward(self, iq):
        return self.detector(self.frontend(iq))


def architecture_audit(pulses=512):
    model = TSDetectNet(pulses).eval()
    frontend_parameters = sum(p.numel() for p in model.frontend.parameters())
    detector_parameters = sum(p.numel() for p in model.detector.parameters())
    with torch.no_grad():
        x = torch.complex(torch.zeros(2, pulses), torch.zeros(2, pulses))
        tk = model.frontend.time_kernel(x)
        fused = model.frontend(x)
        logits = model.detector(fused)
    return dict(pulses=pulses, time_kernel_shape=list(tk.shape[1:]),
                fused_shape=list(fused.shape[1:]), logits_shape=list(logits.shape),
                frontend_parameters=frontend_parameters,
                detector_parameters=detector_parameters,
                total_parameters=frontend_parameters + detector_parameters)
