"""One unchanged TS-DetectNet; full H0 and honest adaptive SCR extension."""
import time
from pathlib import Path
import numpy as np
import torch
from b288_common import FILES,need,read_json,write_json,fingerprint,digest_file,code_hashes

def make_iq(generator,p,split,ix,j=None):
    scenes=[generator.make_one(p['master_seed'],p['h1_split'] if split=='h1' else p[split+'_split'],int(i),-30,10) for i in ix]
    if split!='h1':
        need(all(s['label']==0 and not np.any(s['target']) for s in scenes),'Target appeared in H0 split')
        return np.stack([s['base'] for s in scenes]).astype('complex64')
    need(all(s['label']==1 for s in scenes),'H1 label mismatch')
    base=np.stack([s['base'] for s in scenes]).astype('complex64').astype('complex128')
    unit=np.stack([s['unit'] for s in scenes]).astype('complex64').astype('complex128')
    cp=np.asarray([s['cp'] for s in scenes],dtype='float64');need((cp>0).all() and np.isfinite(cp).all(),'Invalid clutter power')
    amplitude=np.sqrt(cp*10**(p['scr_grid_db'][j]/10))
    return (base+unit*amplitude[:,None]).astype('complex64')

@torch.inference_mode()
def predict(model,iq,device,batch):
    output=[]
    for start in range(0,len(iq),batch):
        x=torch.from_numpy(np.ascontiguousarray(iq[start:start+batch])).to(device);z=model(x)
        need(z.shape==(len(x),2) and torch.isfinite(z).all(),'Invalid inference output')
        output.append((z[:,1]-z[:,0]).double().cpu().numpy())
    return np.concatenate(output)


def protocol(a,context,ct):
    p=dict(version='B288_TSDETECTNET_FULL_SCORE_V2',
        master_seed=context['bc']['seed'],generator_sha=context['bc']['generator_sha256'],
        training_bank_sha256=context['bc']['file_sha256'],h0_cal_n=3000000,h0_audit_n=1000000,
        h1_scenes_n=1024,scr_grid_db=list(range(-24,a.max_scr+1)),
        initial_max_scr=a.initial_max_scr,extend_step=a.extend_step,target_pd=a.target_pd,
        target_consecutive=a.target_consecutive,
        stop_rule='After initial range, check each extension block; both Pfa curves must meet target on the last consecutive SCR points; otherwise stop at cap honestly',
        h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',
        family_names=list(context['generator'].TRAIN_FAMILIES),
        scr_definition='pre-Doppler target/clutter mean IQ power; noise excluded from clutter denominator',
        training_contract=ct,nominal_pfas=[1e-4,1e-5],code_sha256=code_hashes(),
        batch=a.batch,chunk=a.chunk,device=a.device.type,torch_version=str(torch.__version__),amp=False,tf32=False,
        score_definition='float64(float32 logit1-logit0); monotonic to H1 softmax',
        strict_decision='score > own frozen H0 CAL cutoff; rank-based and tie-conservative',
        methods=['TS-DetectNet (Sensors2025; SIM512)'],ADN_loaded=False,ours_loaded=False,
        training_samples=30000,validation_samples=5000,full_scale_explicitly_requested=True,
        independent_final=False,scope='Exposed SIM-R10 DEV; adaptive high-SCR diagnostic, no checkpoint or threshold reselection')
    p['fingerprint']=fingerprint(p)
    return p


def stop_status(p,h1,done,thresholds):
    initial=p['scr_grid_db'].index(p['initial_max_scr'])+1
    maximum=len(p['scr_grid_db'])
    if done<initial:return None
    if done!=maximum and (done-initial)%p['extend_step']!=0:return None
    if done>=p['target_consecutive']:
        tail=h1[done-p['target_consecutive']:done]
        if all(np.all((tail>th).mean(1)>=p['target_pd']) for th in thresholds):return 'target_reached'
    if done==maximum:return 'scr_cap_reached'
    return None


def read_progress(folder,p):
    pr=read_json(folder/'progress.json')
    need(pr['fingerprint']==p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'}),'Scoring identity differs')
    for split,maximum in [('h0_cal',p['h0_cal_n']),('h0_audit',p['h0_audit_n']),('h1',len(p['scr_grid_db']))]:
        done=pr['completed'][split]
        need(isinstance(done,int) and 0<=done<=maximum,'Invalid score progress '+split)
    return pr


def completed_arrays(folder,p):
    folder=Path(folder);pr=read_progress(folder,p)
    need(pr.get('finished') is True and pr['completed']['h0_cal']==p['h0_cal_n'] and
         pr['completed']['h0_audit']==p['h0_audit_n'],'Scoring incomplete')
    arrays={}
    for split,file in FILES.items():
        shape=(len(p['scr_grid_db']),p['h1_scenes_n']) if split=='h1' else (p[split+'_n'],)
        value=np.load(folder/file,mmap_mode='r',allow_pickle=False)
        need(value.shape==shape and value.dtype==np.float64,'Malformed full score array '+file)
        if split=='h1':value=value[:pr['completed']['h1']]
        need(np.isfinite(value).all(),'Nonfinite completed score array '+file);arrays[split]=value
    return arrays


def freeze_thresholds(folder,p):
    from b288_report import cutoff
    values=np.load(folder/FILES['h0_cal'],mmap_mode='r',allow_pickle=False)
    need(values.shape==(p['h0_cal_n'],) and values.dtype==np.float64,'Wrong CAL scores')
    rows=[]
    for nominal in p['nominal_pfas']:
        th,k,fp=cutoff(values,nominal)
        rows.append(dict(nominal_pfa=nominal,threshold=th,cal_n=len(values),cal_tail_support=k,cal_exceedances=fp))
    frozen=dict(protocol_fingerprint=p['fingerprint'],cutoffs=rows)
    path=folder/'h0_cutoffs_frozen.json'
    if path.exists():need(read_json(path)==frozen,'Frozen H0 thresholds changed; preserve result')
    else:write_json(path,frozen)
    return rows


def verify_resume(a,p,model,generator):
    folder=a.score_dir
    if not (folder/'protocol_frozen.json').exists():return []
    need(read_json(folder/'protocol_frozen.json')==p,'Scoring settings changed; preserve full run')
    if not (folder/'progress.json').exists():
        need(not any((folder/f).exists() for f in FILES.values()),'Raw scores exist without commit metadata');return []
    pr=read_progress(folder,p);checks=[]
    for split,file in FILES.items():
        done=pr['completed'][split]
        if not done:continue
        raw=np.load(folder/file,mmap_mode='r',allow_pickle=False)
        n=p['h1_scenes_n'] if split=='h1' else p[split+'_n']
        shape=(len(p['scr_grid_db']),n) if split=='h1' else (n,)
        need(raw.shape==shape and raw.dtype==np.float64,'Resume array shape/type changed')
        count=n if split=='h1' else done;error=0.
        for j in sorted({0,done-1}) if split=='h1' else [None]:
            for start in sorted({0,max(0,((count-1)//a.batch)*a.batch)}):
                stop=min(start+a.batch,count)
                actual=predict(model,make_iq(generator,p,split,np.arange(start,stop),j),a.device,a.batch)
                expected=raw[j,start:stop] if split=='h1' else raw[start:stop]
                error=max(error,float(np.abs(actual-expected).max()))
                need(np.allclose(actual,expected,rtol=1e-5,atol=2e-5),'Resume score numerical replay differs')
        checks.append(dict(split=split,committed=done,maxabs_difference=error))
    return checks


def stream(a,p,model,generator):
    folder=a.score_dir;folder.mkdir(exist_ok=True)
    pp,prpath=folder/'protocol_frozen.json',folder/'progress.json'
    if pp.exists():need(read_json(pp)==p,'Scoring settings changed; use another output')
    else:
        need(not any(folder.iterdir()),'Nonempty scoring output without protocol');write_json(pp,p)
    if prpath.exists():pr=read_progress(folder,p)
    else:
        need(not any((folder/f).exists() for f in FILES.values()),'Raw scores have no commit metadata')
        pr=dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=0,h0_audit=0,h1=0),finished=False,stop_reason=None)
        write_json(prpath,pr)
    for split in ('h0_cal','h0_audit'):
        n=p[split+'_n'];done=pr['completed'][split];path=folder/FILES[split]
        need(done==0 or path.is_file(),'Committed H0 file missing')
        array=np.lib.format.open_memmap(path,mode='r+' if path.exists() else 'w+',dtype='float64',shape=(n,))
        need(array.shape==(n,) and array.dtype==np.float64,'H0 score shape/type differs')
        began=time.perf_counter()
        for start in range(done,n,a.chunk):
            stop=min(start+a.chunk,n)
            iq=make_iq(generator,p,split,np.arange(start,stop))
            array[start:stop]=predict(model,iq,a.device,a.batch);array.flush()
            pr['completed'][split]=stop;write_json(prpath,pr)
            if stop==n or stop%10000<a.chunk:
                rate=(stop-done)/max(time.perf_counter()-began,1e-6)
                print(f'[{split}] {stop:,}/{n:,}; {rate:.1f}/s; remaining~{(n-stop)/max(rate,1e-6)/60:.1f}min',flush=True)
        del array
    cutoffs=freeze_thresholds(folder,p);thresholds=[r['threshold'] for r in cutoffs]
    path=folder/FILES['h1'];done=pr['completed']['h1'];n=p['h1_scenes_n']
    need(done==0 or path.is_file(),'Committed H1 file missing')
    shape=(len(p['scr_grid_db']),n)
    array=np.lib.format.open_memmap(path,mode='r+' if path.exists() else 'w+',dtype='float64',shape=shape)
    need(array.shape==shape and array.dtype==np.float64,'H1 score shape/type differs')
    if pr.get('finished'):
        need(stop_status(p,array,done,thresholds)==pr['stop_reason'],'Stored stop reason disagrees with raw scores')
        print('Completed full inference verified; no new scores generated.',flush=True);return
    initial=p['scr_grid_db'].index(p['initial_max_scr'])+1
    while True:
        done=pr['completed']['h1'];reason=stop_status(p,array,done,thresholds)
        if reason is not None:
            pr.update(finished=True,stop_reason=reason);write_json(prpath,pr)
            print(f'High-SCR stop: {reason}; actual final SCR={p["scr_grid_db"][done-1]:+d} dB; {done} points',flush=True)
            break
        if done>=initial and (done-initial)%p['extend_step']==0:
            last=min(len(p['scr_grid_db'])-1,done+p['extend_step']-1)
            print(f'Both curves have not met the consecutive target; extending SCR=+{p["scr_grid_db"][done]}..+{p["scr_grid_db"][last]} dB; weights/cutoffs frozen.',flush=True)
        j=done;began=time.perf_counter()
        for start in range(0,n,a.chunk):
            stop=min(start+a.chunk,n);iq=make_iq(generator,p,'h1',np.arange(start,stop),j)
            array[j,start:stop]=predict(model,iq,a.device,a.batch)
        array.flush();pr['completed']['h1']=j+1;write_json(prpath,pr)
        detail='; '.join(f'Pfa={r["nominal_pfa"]:.0e} Pd={float((array[j]>r["threshold"]).mean()):.4f}' for r in cutoffs)
        print(f'[dev_h1] SCR={p["scr_grid_db"][j]:+d} dB; {detail}; {time.perf_counter()-began:.1f}s',flush=True)

