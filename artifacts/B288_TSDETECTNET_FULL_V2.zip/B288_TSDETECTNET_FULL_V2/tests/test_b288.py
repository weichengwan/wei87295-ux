import contextlib
import io
import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import h5py
import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from b288_common import (setup, generator, digest_file, fingerprint, read_json,
    write_json, load_checkpoint, atomic_save, balanced_subset, roc_metrics, NAME)
from b288_model import TSDetectNet, TimeKernelFrontend, architecture_audit
from b288_data import resolve, Data
from b288_train import train, optimizer_canary, load_selected
from b288_score import protocol, stream, verify_resume, completed_arrays, make_iq, freeze_thresholds, stop_status
from b288_report import cutoff, generate
from b288_run import cli


def fixture(root, epochs=2):
    setup(2, 71)
    a = SimpleNamespace(root=root, out_dir=root / 'output_b288_fixture', bank_dir=None,
        device=torch.device('cpu'), cpu_threads=2, seed=71, epochs=epochs,
        train_batch=8, batch=8, chunk=32, initial_max_scr=12,max_scr=14,extend_step=2,target_pd=.9,target_consecutive=3)
    a.train_dir = a.out_dir / 'train_full'
    a.score_dir = a.out_dir / 'pd_scr_full'
    a.train_dir.mkdir(parents=True)
    g = generator()
    c = dict(generator=g, bc=dict(seed=20261009, file_sha256='synthetic-unit-test-not-real-bank',
                                  generator_sha256=digest_file(g.__file__)))
    data = Data.__new__(Data)
    data.values, data.selection = {}, {}
    for split, n in [('train', 16), ('val', 8)]:
        scenes = [g.make_one(20261009, split, i, -15, 10) for i in range(n)]
        data.values[split] = (np.stack([s['iq'] for s in scenes]), np.array([s['label'] for s in scenes], dtype='int64'))
        data.selection[split] = dict(count=n, fixture_only=True)
    return a, c, data


class ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)

    def test_paper_equations_and_parameter_table(self):
        for n, shape, parameters in [(256, [3, 62, 56], 4287), (512, [3, 126, 112], 16703),
                                      (1024, [3, 254, 224], 66111)]:
            v = architecture_audit(n)
            self.assertEqual(v['fused_shape'], shape)
            self.assertEqual(v['frontend_parameters'], parameters)
            self.assertEqual(v['detector_parameters'], 1519906)
        f = TimeKernelFrontend(512).eval()
        iq = torch.complex(torch.randn(2, 512), torch.randn(2, 512))
        expected = torch.stack((F.conv1d(iq.real[:, None], f.real_conv.weight, f.real_conv.bias, stride=2),
                                F.conv1d(iq.imag[:, None], f.imag_conv.weight, f.imag_conv.bias, stride=2)), 1)
        self.assertTrue(torch.equal(expected, f.time_kernel(iq)))
        self.assertNotEqual(f.real_conv.weight.data_ptr(), f.imag_conv.weight.data_ptr())

    def test_input_contract_rejects_wrong_interfaces(self):
        f = TimeKernelFrontend()
        with self.assertRaises(ValueError):
            f(torch.zeros(2, 512))
        with self.assertRaises(ValueError):
            f(torch.zeros(2, 256, dtype=torch.complex64))

    def test_stratification_and_tied_roc(self):
        labels = np.tile([0, 1], 15000)
        family = np.arange(30000) % 5
        ix = balanced_subset(labels, family, 16000, 73)
        self.assertEqual(len(ix), 16000)
        self.assertEqual(int(labels[ix].sum()), 8000)
        self.assertEqual(len(np.unique(ix)), 16000)
        self.assertTrue(np.array_equal(ix, balanced_subset(labels, family, 16000, 73)))
        self.assertEqual(roc_metrics(np.ones(4), np.array([0, 1, 0, 1]))['val_auc'], .5)

    def test_only_new_output_namespace(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old = root / 'output_b280_full_ablation_v1'
            old.mkdir()
            sentinel = old / 'best.pt'
            sentinel.write_bytes(b'protected ADN checkpoint sentinel')
            sha = digest_file(sentinel)
            with self.assertRaisesRegex(RuntimeError, 'output_b288_'):
                cli(['--root', tmp, '--out-dir', str(old), '--device', 'cpu'])
            self.assertEqual(sha, digest_file(sentinel))
            v = cli(['--root', tmp, '--device', 'cpu'])
            self.assertEqual(v.epochs, 20)
            self.assertEqual(v.train_batch, 256)
            self.assertFalse(v.out_dir.exists())

    def test_bank_integrity_and_read_only_selection(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            directory = root / 'bank'
            directory.mkdir()
            path = directory / 'sim_r10_iq512_v1.h5'
            with h5py.File(path, 'w') as h:
                for split, n in [('train', 30000), ('val', 5000)]:
                    gr = h.create_group(split)
                    gr.create_dataset('iq', shape=(n, 512), dtype='complex64', chunks=(16, 512))
                    gr.create_dataset('label', data=np.arange(n) % 2)
                    gr.create_dataset('family_index', data=np.arange(n) % 5)
            sha = digest_file(path)
            bc = dict(version='SIM_R10_IQ512_GENERATOR_V1', n_pulses=512, seed=20261009,
                counts=dict(train=30000, val=5000), status='PASS_SIM_R10_IQ512_BUILDER_V1__TEST',
                file_sha256=sha, generator_sha256=digest_file(generator().__file__))
            write_json(directory / 'sim_r10_iq512_v1_contract.json', bc)
            write_json(directory / 'sim_r10_iq512_audit_v1.json',
                dict(status='PASS_SIM_R10_IQ512_AUDIT_V1__TEST', bank_sha256=sha))
            a = SimpleNamespace(root=root, bank_dir=directory)
            ctx = resolve(a)
            d = Data(ctx, 30000, 20261022)
            self.assertEqual(d.values['train'][0].shape, (30000, 512))
            self.assertEqual(d.values['val'][0].shape, (5000, 512))
            self.assertEqual(sha, digest_file(path))
            bc['file_sha256'] = 'changed'
            write_json(directory / 'sim_r10_iq512_v1_contract.json', bc)
            with self.assertRaisesRegex(RuntimeError, 'checksum'):
                resolve(a)

    def test_real_native_optimizer_probe_and_resume(self):
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()):
            a, ctx, data = fixture(Path(tmp) / 'first')
            result = optimizer_canary(a, data)
            self.assertTrue(result['all_original_stages_updated'])
            self.assertFalse(result['ADN_loaded'])
            calls = []

            def interrupt_after_commit(path, obj):
                atomic_save(path, obj)
                if Path(path).name == 'last_epoch.pt' and obj['epoch'] == 1 and not calls:
                    calls.append(True)
                    raise RuntimeError('simulated process interruption after committed epoch')

            with patch('b288_train.atomic_save', side_effect=interrupt_after_commit):
                with self.assertRaisesRegex(RuntimeError, 'simulated process interruption'):
                    train(a, ctx, data)
            self.assertFalse((a.train_dir / 'training_contract.json').exists())
            ct = train(a, ctx, data)
            model, _ = load_selected(a, ctx)
            self.assertEqual(model(data.fetch('val', slice(0, 2), a.device)[0]).shape, (2, 2))
            best_sha = digest_file(a.train_dir / 'best.pt')
            train(a, ctx, data)
            self.assertEqual(best_sha, digest_file(a.train_dir / 'best.pt'))
            b, c2, d2 = fixture(Path(tmp) / 'uninterrupted')
            ct2 = train(b, c2, d2)
            self.assertEqual(ct['best_epoch'], ct2['best_epoch'])
            selected = load_checkpoint(a.train_dir / 'best.pt')['state_dict']
            other = load_checkpoint(b.train_dir / 'best.pt')['state_dict']
            self.assertTrue(all(torch.equal(value, other[key]) for key, value in selected.items()))
            self.assertFalse(ct['ADN_trained'])
            self.assertFalse(ct['ours_trained'])

    def test_native_scoring_interruption_and_resume(self):
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()):
            a, ctx, data = fixture(Path(tmp))
            m = TSDetectNet().eval().requires_grad_(False)
            p = protocol(a, ctx, dict(checkpoint_sha256='test-model'))
            p.update(h0_cal_n=64, h0_audit_n=32, h1_scenes_n=2)
            p['fingerprint'] = fingerprint({k: v for k, v in p.items() if k != 'fingerprint'})
            native = make_iq
            count = []

            def interrupted(*args, **kwargs):
                count.append(1)
                if len(count) == 2:
                    raise RuntimeError('simulated scoring interruption')
                return native(*args, **kwargs)

            with patch('b288_score.make_iq', side_effect=interrupted), patch('b288_report.cutoff',return_value=(1e6,1,0)):
                with self.assertRaisesRegex(RuntimeError, 'simulated scoring interruption'):
                    stream(a, p, m, ctx['generator'])
            self.assertEqual(read_json(a.score_dir / 'progress.json')['completed']['h0_cal'], 32)
            check = verify_resume(a, p, m, ctx['generator'])
            self.assertLess(check[0]['maxabs_difference'], 2e-5)
            with patch('b288_report.cutoff',return_value=(1e6,1,0)):stream(a, p, m, ctx['generator'])
            arrays = completed_arrays(a.score_dir, p)
            self.assertEqual(arrays['h1'].shape, (39, 2))
            before = digest_file(a.score_dir / 'dev_h1_scores.npy')
            with patch('b288_report.cutoff',return_value=(1e6,1,0)):stream(a, p, m, ctx['generator'])
            self.assertEqual(before, digest_file(a.score_dir / 'dev_h1_scores.npy'))
            self.assertEqual(p['methods'], [NAME])

    def test_adaptive_scr_stop_requires_both_curves_and_honest_cap(self):
        p=dict(scr_grid_db=list(range(-24,21)),initial_max_scr=12,extend_step=4,target_pd=.9,target_consecutive=3)
        values=np.zeros((45,10));values[34:37]=.15
        self.assertIsNone(stop_status(p,values,37,[.1,.2]))
        values[38:41,:9]=.3
        self.assertIsNone(stop_status(p,values,40,[.1,.2]))
        self.assertEqual(stop_status(p,values,41,[.1,.2]),'target_reached')
        values[42:45]=.15
        self.assertEqual(stop_status(p,values,45,[.1,.2]),'scr_cap_reached')

    def test_target_block_interrupt_resume_does_not_rescore_H0_or_extra_SCR(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            a,ctx,_=fixture(Path(tmp));a.max_scr=20;a.extend_step=4
            a.score_dir.mkdir();p=protocol(a,ctx,dict(checkpoint_sha256='synthetic-target-fixture'))
            p.update(h0_cal_n=1000000,h0_audit_n=1000,h1_scenes_n=10)
            p['fingerprint']=fingerprint({k:v for k,v in p.items() if k!='fingerprint'})
            write_json(a.score_dir/'protocol_frozen.json',p)
            write_json(a.score_dir/'progress.json',dict(fingerprint=p['fingerprint'],
                completed=dict(h0_cal=1000000,h0_audit=1000,h1=0),finished=False,stop_reason=None))
            np.save(a.score_dir/'h0_cal_scores.npy',np.linspace(-1,1,1000000))
            np.save(a.score_dir/'h0_audit_scores.npy',np.linspace(-1,.99,1000))
            hashes={name:digest_file(a.score_dir/name) for name in ('h0_cal_scores.npy','h0_audit_scores.npy')}
            calls=[];interrupted=[]
            def iq(g,proto,split,indices,j=None):
                self.assertEqual(split,'h1') # Any H0 reinference fails this test.
                calls.append(proto['scr_grid_db'][j])
                return np.full((len(indices),512),proto['scr_grid_db'][j],dtype='complex64')
            def predictor(model,iq,device,batch):return (iq.real[:,0]>=14).astype('float64')*2
            def committed(path,obj):
                write_json(path,obj)
                if Path(path).name=='progress.json' and obj.get('completed',{}).get('h1')==41 and not obj.get('finished') and not interrupted:
                    interrupted.append(True);raise RuntimeError('interruption at target boundary')
            with patch('b288_score.make_iq',side_effect=iq),patch('b288_score.predict',side_effect=predictor),patch('b288_score.write_json',side_effect=committed):
                with self.assertRaisesRegex(RuntimeError,'target boundary'):stream(a,p,None,None)
            self.assertEqual(max(calls),16);calls.clear()
            with patch('b288_score.make_iq',side_effect=iq),patch('b288_score.predict',side_effect=predictor):stream(a,p,None,None)
            self.assertEqual(calls,[])
            self.assertEqual(read_json(a.score_dir/'progress.json')['stop_reason'],'target_reached')
            arrays=completed_arrays(a.score_dir,p);self.assertEqual(arrays['h1'].shape,(41,10))
            result=generate(a)
            self.assertTrue(result['both_curves_tail_target_met'])
            self.assertEqual(result['actual_scr_grid_db'][-1],16)
            self.assertTrue(all(abs(m['D90_db']-13.9)<1e-10 for m in result['metrics']))
            self.assertEqual(hashes,{name:digest_file(a.score_dir/name) for name in hashes})

    def test_calibration_audit_and_single_model_plot(self):
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()):
            a, ctx, _ = fixture(Path(tmp))
            a.score_dir.mkdir()
            p = protocol(a, ctx, dict(checkpoint_sha256='synthetic-score-plot-test'))
            p.update(h0_cal_n=1000000, h0_audit_n=100000, h1_scenes_n=512)
            p['fingerprint'] = fingerprint({k: v for k, v in p.items() if k != 'fingerprint'})
            write_json(a.score_dir / 'protocol_frozen.json', p)
            write_json(a.score_dir / 'progress.json', dict(fingerprint=p['fingerprint'], completed=dict(h0_cal=1000000, h0_audit=100000, h1=37),finished=True,stop_reason='target_reached'))
            # Artificial distributions test report arithmetic; they are never a measured Pd claim.
            cal = np.linspace(-3, 3, 1000000)
            audit = np.linspace(-3, 2.99, 100000)
            quantiles = np.linspace(-2, 2, 512)
            h1 = np.stack([quantiles + (s + 24) / 4 for s in p['scr_grid_db']])
            h1[37:]=-999. # Uncommitted reserved SCR points must never appear in figures.
            for name, value in [('h0_cal_scores.npy', cal), ('h0_audit_scores.npy', audit), ('dev_h1_scores.npy', h1)]:
                np.save(a.score_dir / name, value)
            th, k, fp = cutoff(cal, 1e-5)
            self.assertEqual((k, fp), (10, 10))
            old = a.root / 'output_b280_full_ablation_v1'
            old.mkdir()
            sentinel = old / 'best.pt'
            sentinel.write_bytes(b'original stays unchanged')
            sha = digest_file(sentinel)
            freeze_thresholds(a.score_dir,p)
            result = generate(a)
            self.assertEqual(result['models_trained_and_plotted'], ['TS-DetectNet'])
            self.assertEqual(result['metrics'][0]['audit_false_alarms'], int((audit > cutoff(cal,1e-4)[0]).sum()))
            self.assertTrue((a.score_dir / 'figures/b288_pd_scr_pfa_1e-04.pdf').is_file())
            self.assertEqual(sha, digest_file(sentinel))
            self.assertFalse(result['model_architecture_changed_from_medium'])
            self.assertEqual(result['actual_scr_grid_db'],list(range(-24,13)))
            self.assertTrue(result['both_curves_tail_target_met'])
            self.assertFalse(result['historical_scores_loaded'])


if __name__ == '__main__':
    unittest.main()
