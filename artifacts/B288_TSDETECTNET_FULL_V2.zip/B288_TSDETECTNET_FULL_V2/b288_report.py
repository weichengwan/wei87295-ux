"""Standalone TS-DetectNet curves only: no external references or relabeling."""
import math
import numpy as np
from b288_common import need, read_json, write_json, save_csv, digest_file, NAME, FILES
from b288_score import completed_arrays


def wilson(k, n):
    z = 1.959963984540054
    q = k / n
    den = 1 + z * z / n
    mid = (q + z * z / (2 * n)) / den
    rad = z * math.sqrt(q * (1 - q) / n + z * z / (4 * n * n)) / den
    return max(0., mid - rad), min(1., mid + rad)


def cutoff(scores, pfa):
    s = np.asarray(scores)
    need(s.ndim == 1 and np.isfinite(s).all(), 'Invalid H0 CAL scores')
    k = int(math.floor(len(s) * pfa))
    need(10 <= k < len(s), 'Insufficient calibration tail support')
    threshold = float(np.partition(s, len(s) - k - 1)[len(s) - k - 1])
    return threshold, k, int((s > threshold).sum())


def crossing(x, y, level):
    if y[0] >= level:
        return float(x[0])
    for i in range(1, len(x)):
        if y[i - 1] < level <= y[i]:
            return float(x[i - 1] + (level - y[i - 1]) * (x[i] - x[i - 1]) / (y[i] - y[i - 1]))
    return None


def generate(a):
    from b288_score import read_progress,stop_status
    folder=a.score_dir;p=read_json(folder/'protocol_frozen.json')
    need(p['version']=='B288_TSDETECTNET_FULL_SCORE_V2' and p['methods']==[NAME] and
         p['nominal_pfas']==[1e-4,1e-5],'Wrong full single-model protocol')
    arrays=completed_arrays(folder,p);pr=read_progress(folder,p)
    x=p['scr_grid_db'][:pr['completed']['h1']]
    frozen=read_json(folder/'h0_cutoffs_frozen.json')
    need(frozen['protocol_fingerprint']==p['fingerprint'],'Threshold identity differs')
    curves=[];metrics=[];summaries=[];sorted_audit=np.sort(arrays['h0_audit'])
    thresholds=[]
    for nominal in p['nominal_pfas']:
        th,k,calfp=cutoff(arrays['h0_cal'],nominal);thresholds.append(th)
        saved=next((r for r in frozen['cutoffs'] if r['nominal_pfa']==nominal),None)
        need(saved==dict(nominal_pfa=nominal,threshold=th,cal_n=len(arrays['h0_cal']),
            cal_tail_support=k,cal_exceedances=calfp),'Frozen threshold was changed')
        n0=len(arrays['h0_audit']);fp=int((arrays['h0_audit']>th).sum());lo,hi=wilson(fp,n0)
        hits=(arrays['h1']>th).sum(1);pd=hits/p['h1_scenes_n'];maximum=float(pd.max())
        peaks=[scr for scr,value in zip(x,pd) if value==maximum]
        n=p['target_consecutive']
        mt=dict(method=NAME,nominal_pfa=nominal,actual_pfa=fp/n0,audit_false_alarms=fp,audit_n=n0,
            actual_pfa_ci95_low=lo,actual_pfa_ci95_high=hi,threshold=th,cal_n=len(arrays['h0_cal']),
            cal_tail_support=k,cal_exceedances=calfp,D50_db=crossing(x,pd,.5),D80_db=crossing(x,pd,.8),
            D90_db=crossing(x,pd,.9),max_pd=maximum,max_pd_scr_db=';'.join(map(str,peaks)),
            first_observed_scr_pd_ge_0_8=next((scr for scr,value in zip(x,pd) if value>=.8),None),
            first_observed_scr_pd_ge_0_9=next((scr for scr,value in zip(x,pd) if value>=.9),None),
            pd_at_last_scr=float(pd[-1]),last_scr_db=x[-1],actual_scr_points=len(x),
            reached_0_9=bool(maximum>=.9),last_consecutive_target_met=bool(len(pd)>=n and (pd[-n:]>=p['target_pd']).all()),
            pd_downward_steps=int((np.diff(pd)<0).sum()),pd_downward_steps_gt_5pp=int((np.diff(pd)<-.05).sum()))
        metrics.append(mt)
        for j,(scr,count) in enumerate(zip(x,hits)):
            n1=p['h1_scenes_n'];low,high=wilson(int(count),n1)
            left=np.searchsorted(sorted_audit,arrays['h1'][j],side='left')
            right=np.searchsorted(sorted_audit,arrays['h1'][j],side='right')
            auc=float(np.mean((left+right)/(2*n0)))
            curves.append(dict(method=NAME,nominal_pfa=nominal,scr_db=scr,hits=int(count),n_h1=n1,
                pd=float(count/n1),pd_ci95_low=low,pd_ci95_high=high,diagnostic_auc_vs_H0_audit=auc))
    need(stop_status(p,arrays['h1'],len(x),thresholds)==pr['stop_reason'],'Stop reason differs from completed scores')
    for split,values in [('h0_cal',arrays['h0_cal']),('h0_audit',arrays['h0_audit'])]+[
        ('h1_scr_'+str(scr),arrays['h1'][j]) for j,scr in enumerate(x)]:
        q=np.quantile(values,[0,.01,.5,.99,.999,1])
        summaries.append(dict(split=split,n=int(values.size),mean=float(values.mean()),std=float(values.std()),
            minimum=float(q[0]),q01=float(q[1]),median=float(q[2]),q99=float(q[3]),q999=float(q[4]),maximum=float(q[5])))
    save_csv(folder/'b288_curves.csv',curves);save_csv(folder/'b288_metrics.csv',metrics)
    save_csv(folder/'b288_score_summary.csv',summaries)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    figdir=folder/'figures';figdir.mkdir(exist_ok=True)
    for nominal in p['nominal_pfas']:
        rows=[r for r in curves if r['nominal_pfa']==nominal]
        fig,ax=plt.subplots(figsize=(8,5))
        ax.plot(x,[r['pd'] for r in rows],color='tab:blue',marker='o',markerfacecolor='white',
            markersize=4,linewidth=1.7,linestyle='-',label=NAME,markevery=max(2,len(x)//30))
        ax.axhline(.9,color='gray',linestyle=':',linewidth=.8)
        exponent=int(round(np.log10(nominal)))
        ax.set(xlabel='SCR (dB)',ylabel=r'$P_d$',xlim=(x[0],x[-1]),ylim=(0,1.02),
            title=r'$P_{\mathrm{fa}}=10^{'+str(exponent)+'}$')
        ax.grid(alpha=.25);ax.legend(fontsize=9);fig.tight_layout()
        for ext in ('pdf','png','svg'):fig.savefig(figdir/f'b288_pd_scr_pfa_{nominal:.0e}.{ext}',dpi=250)
        plt.close(fig);save_csv(figdir/f'b288_pd_source_pfa_{nominal:.0e}.csv',rows)
    report=dict(status='PASS_B288_TSDETECTNET_FULL_REPORT',method=NAME,protocol_fingerprint=p['fingerprint'],
        training_contract=p['training_contract'],metrics=metrics,actual_scr_grid_db=x,
        stop_reason=pr['stop_reason'],target_pd=p['target_pd'],target_consecutive=p['target_consecutive'],
        both_curves_tail_target_met=all(m['last_consecutive_target_met'] for m in metrics),
        raw_score_sha256={f:digest_file(folder/f) for f in FILES.values()},
        model_architecture_changed_from_medium=False,models_trained_and_plotted=['TS-DetectNet'],
        ADN_loaded=False,ADN_trained=False,ours_loaded=False,ours_trained=False,historical_scores_loaded=False,
        official_author_code=False,paper_equations_reimplemented=True,
        real_IPIX_SDRDSP_performance_reproduced=False,independent_final=False,
        source_Pd_unchanged=True,smoothing=False,curve_shifting=False,thresholds_frozen_before_H1=True,
        scope='Full30k/5k SIM-R10 experiment. Adaptive high-SCR extension is diagnostic, not an independent final test.',
        warning_flags=[dict(nominal_pfa=m['nominal_pfa'],D90_unreached=m['D90_db'] is None,
            nominal_Pfa_outside_audit_95CI=not(m['actual_pfa_ci95_low']<=m['nominal_pfa']<=m['actual_pfa_ci95_high'])) for m in metrics])
    write_json(folder/'b288_report.json',report)
    for m in metrics:
        print(f'Pfa={m["nominal_pfa"]:.0e}: MAX Pd={m["max_pd"]:.4%} at SCR={m["max_pd_scr_db"]} dB; '
              f'D80={m["D80_db"]}; D90={m["D90_db"]}; Pd@{x[-1]}={m["pd_at_last_scr"]:.4%}; '
              f'H0 FP={m["audit_false_alarms"]}/{m["audit_n"]}',flush=True)
    if not report['both_curves_tail_target_met']:
        print('SCR cap reached without both curves meeting target. Raw results retained; no extrapolation or forced Pd.',flush=True)
    print('PASS_B288_TSDETECTNET_FULL_TRAIN_SCORE_REPORT_COMPLETE: '+str(folder),flush=True)
    return report


