"""Read ONLY the frozen IQ TRAIN/VAL bank. No existing model or score input."""
import hashlib
import h5py
import numpy as np
import torch
from b288_common import need, read_json, digest_file, generator, balanced_subset


def resolve(a):
    directory = (a.bank_dir or a.root / 'SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1').resolve()
    path = directory / 'sim_r10_iq512_v1.h5'
    bc = read_json(directory / 'sim_r10_iq512_v1_contract.json')
    audit = read_json(directory / 'sim_r10_iq512_audit_v1.json')
    need(bc.get('version') == 'SIM_R10_IQ512_GENERATOR_V1' and bc.get('n_pulses') == 512, 'Wrong IQ bank version/length')
    need(bc.get('counts', {}).get('train') == 30000 and bc['counts'].get('val') == 5000, 'Need existing30k/5k IQ bank')
    need(str(bc.get('status', '')).startswith('PASS_SIM_R10_IQ512_BUILDER_V1__') and
         str(audit.get('status', '')).startswith('PASS_SIM_R10_IQ512_AUDIT_V1__'), 'IQ bank/audit not passed')
    print('Verifying read-only TRAIN/VAL IQ bank SHA256', flush=True)
    need(digest_file(path) == bc['file_sha256'] == audit['bank_sha256'], 'IQ bank checksum differs')
    g = generator()
    need(digest_file(g.__file__) == bc['generator_sha256'], 'Bundled IQ generator differs from bank generator')
    return dict(path=path, bc=bc, generator=g)


class Data:
    def __init__(self, context, count, seed):
        self.values, self.selection = {}, {}
        # h5py mode='r'; no cache or data regeneration is performed here.
        with h5py.File(context['path'], 'r') as h:
            for split, original, n, offset in [('train', 30000, count, 27101), ('val', 5000, 5000, 27102)]:
                group = h[split]
                y = group['label'][:].astype('int64')
                need(group['iq'].shape == (original, 512) and group['iq'].dtype == np.complex64, 'Wrong IQ array shape/type')
                need(y.shape == (original,) and np.isin(y, (0, 1)).all() and y.sum() == original // 2, 'Malformed/unbalanced labels')
                need('family_index' in group, 'Frozen IQ bank has no family labels')
                family = group['family_index'][:]
                rows = balanced_subset(y, family, n, seed + offset)
                iq = group['iq'][rows].astype('complex64')
                need(np.isfinite(iq).all(), 'Nonfinite input IQ')
                self.values[split] = (iq, y[rows])
                self.selection[split] = dict(count=len(rows), original_count=original,
                    row_indices_sha256=hashlib.sha256(rows.astype('<i8').tobytes()).hexdigest(),
                    counts_by_label={str(k): int((y[rows] == k).sum()) for k in (0, 1)},
                    family_stratified=True, family_counts={str(int(k)): int((family[rows] == k).sum()) for k in np.unique(family[rows])})

    def fetch(self, split, index, device):
        iq, labels = self.values[split]
        return (torch.from_numpy(np.ascontiguousarray(iq[index])).to(device),
                torch.from_numpy(np.ascontiguousarray(labels[index])).to(device))
