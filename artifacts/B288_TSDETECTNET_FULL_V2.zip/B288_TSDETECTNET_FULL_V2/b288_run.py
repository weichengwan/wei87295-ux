"""Only TS-DetectNet2025; full TRAIN, H0 CAL/AUDIT and adaptively extended SCR DEV."""
import argparse
import fcntl
import gc
import shutil
import time
from pathlib import Path
import torch
from b288_common import ROOT, need, read_json, write_json, fingerprint, validate_sources, code_hashes, setup
from b288_model import architecture_audit
from b288_data import resolve, Data
from b288_train import optimizer_canary, train, load_selected, config
from b288_score import protocol, verify_resume, stream


def cli(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, default=ROOT.parent)
    p.add_argument('--bank-dir', type=Path)
    p.add_argument('--out-dir', type=Path)
    p.add_argument('--stage', choices=('all', 'preflight', 'train', 'score', 'report'), default='all')
    p.add_argument('--epochs', type=int, default=20)
    p.add_argument('--train-batch', type=int, choices=(32, 64, 128, 256), default=256)
    p.add_argument('--batch', type=int, choices=(32, 64, 128, 256), default=256)
    p.add_argument('--chunk', type=int, default=1024)
    p.add_argument('--device', choices=('cuda', 'cpu'), default='cuda')
    p.add_argument('--cpu-threads', type=int, default=4)
    p.add_argument('--seed', type=int, default=20261022)
    p.add_argument('--wait-for-gpu', action='store_true')
    p.add_argument('--initial-max-scr',type=int,default=24)
    p.add_argument('--max-scr',type=int,default=60)
    p.add_argument('--extend-step',type=int,default=4)
    p.add_argument('--target-pd',type=float,default=.9)
    p.add_argument('--target-consecutive',type=int,default=3)
    a = p.parse_args(argv)
    a.root = a.root.resolve()
    a.out_dir = (a.out_dir or a.root / 'output_b288_tsdetectnet_full_v2').resolve()
    # Exact new namespace; even --out-dir cannot target an existing ADN/ours run.
    need(a.root.is_dir() and a.out_dir.parent == a.root and a.out_dir.name.startswith('output_b288_tsdetectnet_full_'),
         'Output must be a direct child named output_b288_tsdetectnet_full_*; existing model directories are forbidden')
    need(a.out_dir != ROOT and a.epochs > 0 and a.cpu_threads > 0, 'Invalid run settings')
    need(a.chunk >= a.batch and a.chunk % a.batch == 0, 'Chunk must be a positive multiple of scoring batch')
    if a.out_dir.exists():
        need(a.out_dir.is_dir(), 'Output path is not a directory')
        if any(a.out_dir.iterdir()):
            need((a.out_dir / 'b288_identity.json').is_file(), 'Nonempty output has no B288 identity; preserve it')
    if a.device == 'cuda':
        need(torch.cuda.is_available(), 'CUDA unavailable; use AutoDL mpdnet-r10')
    need(12 <= a.initial_max_scr <= a.max_scr <= 80 and a.extend_step > 0 and
         0 < a.target_pd <= 1 and 1 <= a.target_consecutive <= 10,'Invalid SCR extension settings')
    a.device = torch.device(a.device)
    a.train_dir = a.out_dir / 'train_full'
    a.score_dir = a.out_dir / 'pd_scr_full'
    return a


def acquire(lock, wait):
    while True:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return
        except BlockingIOError:
            need(wait, 'Another radar job holds the shared GPU lock')
            print('Another radar job holds the shared GPU lock; waiting, no existing job is interrupted.', flush=True)
            time.sleep(30)


def main(argv=None):
    a = cli(argv)
    setup(a.cpu_threads, a.seed)
    validate_sources()
    if a.stage == 'report':
        from b288_report import generate
        return generate(a)
    print(f'B288 TS-DetectNet ONLY | stage={a.stage} | output={a.out_dir}', flush=True)
    print('Read-only IQ data; no ADN/ours weights or score inputs; no WVD/SPWVD/TFSE/CGCR modules.', flush=True)
    with (a.root / 'codex_b271_night.lock').open('a') as lock:
        acquire(lock, a.wait_for_gpu)
        context = resolve(a)
        a.out_dir.mkdir(exist_ok=True)
        identity = dict(version='B288_TSDETECTNET_ONLY_FULL_V2', code_sha256=code_hashes(),
            bank_sha256=context['bc']['file_sha256'], models=['TS-DetectNet'],
            ADN_loaded=False, ours_loaded=False, full_scale_explicitly_requested=True,
            inference_settings=dict(initial_max_scr=a.initial_max_scr,max_scr=a.max_scr,extend_step=a.extend_step,
                target_pd=a.target_pd,target_consecutive=a.target_consecutive))
        id_path = a.out_dir / 'b288_identity.json'
        if id_path.exists():
            need(read_json(id_path) == identity, 'B288 run code/bank identity changed')
        else:
            need(not any(a.out_dir.iterdir()), 'Output changed before run identity was written')
            write_json(id_path, identity)
        a.train_dir.mkdir(exist_ok=True)
        need(shutil.disk_usage(a.out_dir).free > 256 * 1024**2, 'Need256MiB for own checkpoints and full scores; no deletion performed')
        if a.stage in ('all', 'train', 'preflight'):
            data = Data(context, 30000, a.seed)
            preflight = a.train_dir / 'preflight.json'
            fp = fingerprint(config(a, context, data))
            if preflight.exists():
                need(read_json(preflight)['fingerprint'] == fp, 'Preflight training settings changed')
            else:
                audits = {str(n): architecture_audit(n) for n in (256, 512, 1024)}
                need(audits['1024']['frontend_parameters'] == 66111 and
                     audits['512']['detector_parameters'] == 1519906, 'Architecture does not match paper Table VI')
                checks = optimizer_canary(a, data)
                write_json(preflight, dict(fingerprint=fp, architecture=audits, optimizer_probe=checks))
            if a.stage == 'preflight':
                return
            train(a, context, data)
            del data
            if a.stage == 'train':
                return
        model, ct = load_selected(a, context)
        p = protocol(a, context, ct)
        print('FULL: CAL3,000,000; AUDIT1,000,000; H1=1024 per SCR; Pfa1e-4 and1e-5. Only TS-DetectNet executes.', flush=True)
        checks = verify_resume(a, p, model, context['generator'])
        write_json(a.train_dir / 'score_resume_probe.json', dict(protocol_fingerprint=p['fingerprint'], checks=checks))
        stream(a, p, model, context['generator'])
        del model
        gc.collect()
        if a.device.type == 'cuda':
            torch.cuda.empty_cache()
        from b288_report import generate
        return generate(a)


if __name__ == '__main__':
    main()
