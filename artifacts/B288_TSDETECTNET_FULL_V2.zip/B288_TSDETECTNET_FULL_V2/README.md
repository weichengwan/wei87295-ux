# B288 TS-DetectNet：最大规模版 V2

仅训练和评分原B288的TS-DetectNet，不加载ADN或我们的方法。
网络定义和MobileNetV3文件与中规模包逐字节相同；原文公式对应的结构不变。

原文：**CNN-Based Data Processing for Enhanced Detection of Small Targets in Sea Clutter**，
Xu et al.，IEEE Sensors Journal2025，DOI：10.1109/JSEN.2025.3596263。
这是原文机制在SIM512上的重实现，不是作者完整源码或原文实测数据结果复现。
MobileNetV3-Small的选择依据原文表VI参数数量，与此前B288一致。

```text
复数IQ512
  实部 → 原独立Conv1d ┐
  虚部 → 原独立Conv1d ┘ → stack → 原Conv2d、BN、ReLU
                               → 原MobileNetV3-Small → 两类输出
```

没有WVD、SPWVD、TFSE、CGCR、DHiF或其他附加模块。

## 默认最大规模

- 全部冻结TRAIN30,000、VAL5,000，不再抽取中规模16,000子集。
- TS-DetectNet从随机权重独立训练20epoch，Adam lr0.001、betas(0.9,0.99)、CE、batch256；每5epoch学习率乘0.5。
- 仅按完整VAL CE选择已训练epoch；H0 CAL、AUDIT和H1不参与训练、选epoch。
- 完整H0 CAL3,000,000、独立AUDIT1,000,000。
- 每个SCR1,024条H1，固定同一组回波场景ID，仅改变目标幅度。
- 两种虚警率明确为 **1e-4和1e-5**，即10的负四次方、负五次方。
- H0校准完成后先保存冻结阈值，再开始H1。扩展SCR时权重和阈值都不变化。

## SCR范围与停止规则

先按1dB步长推理 **-24到+24dB，共49点**。
若两种Pfa下最后连续3个SCR点均达到Pd>=0.9，则结束。
否则每次将上界增加4dB：+28、+32……，默认最多到+60dB。
每个扩展区间仍按1dB推理，不跳点。最大85点只预留空间，不冒充已完成的结果。

图的横轴自动延长到实际完成的最右端，显示所有已完成的点，保留0.9参考线。
输出最高Pd、所有峰值SCR、首次实测达到0.8/0.9的SCR以及插值得到的D80/D90。
不平滑、不平移、不强制单调，不通过降低阈值或选择其他epoch获得0.9。
达到+60dB仍不足0.9时停止并如实报告，未达到的D90留空。

这里延长高SCR范围是诊断，不改变原始TRAIN/VAL数据；不是独立最终测试。

## AutoDL启动

解压到 `/root/autodl-tmp/MTDSP_NATIVE_LMDA_V1` 后运行：

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
bash B288_TSDETECTNET_FULL_V2/start_on_autodl.sh
tail -F codex_b288_tsdetectnet_full_v2.log
```

默认使用GPU。若B289等实验持有共享GPU锁，本任务排队等待，不终止它们。
nohup后台运行，SSH断线后继续；服务器关机、进程被杀或磁盘满仍可能中断。
相同启动命令可恢复最近完整epoch、H0评分块和H1已提交SCR。
已完成的全量训练会校验后跳过，不重复训练。

只读数据来自：

```text
SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1/
  sim_r10_iq512_v1.h5
  sim_r10_iq512_v1_contract.json
  sim_r10_iq512_audit_v1.json
```

不依赖旧中规模权重或分数，不覆盖中规模B288结果，不生成时频图缓存。
本包输出一般小于256MiB；启动时检查至少256MiB可用空间。

## 结果

```text
output_b288_tsdetectnet_full_v2/
  train_full/best.pt
  train_full/training_contract.json
  pd_scr_full/b288_metrics.csv
  pd_scr_full/b288_curves.csv
  pd_scr_full/b288_report.json
  pd_scr_full/h0_cutoffs_frozen.json
  pd_scr_full/figures/b288_pd_scr_pfa_1e-04.pdf
  pd_scr_full/figures/b288_pd_scr_pfa_1e-05.pdf
```

图保留TS-DetectNet蓝色实线和空心圆形标记，横轴SCR(dB)、纵轴Pd，上方标Pfa。
每万条H0输出速度与剩余时间；H1逐点输出两种Pfa的Pd。
最后直接打印最高Pd及其SCR、D80、D90、末端Pd、实际审计虚警计数。

## 可选参数

例如预检前决定使用batch128或其他SCR上限：

```bash
bash B288_TSDETECTNET_FULL_V2/start_on_autodl.sh \
  --train-batch 128 --batch 128 \
  --out-dir /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1/output_b288_tsdetectnet_full_b128
```

默认batch256已在原B288本地CPU检查过；实际GPU会用真实TRAIN批次预检显存后才训练。
改动已有任务的配置会拒绝恢复，应保留旧结果。网络结构不随batch改变。

## 验证

```bash
python -m unittest discover -s tests -v
```

测试使用合成微型数据，不代表真实Pd增益；包括全量数据索引、原论文参数表、
原生复数IQ接口、真实优化器更新、训练和评分中断恢复、H0阈值锁定、
两种曲线都达标才停止、到上限仍未达标如实停止、图中不显示未计算的预留点。
