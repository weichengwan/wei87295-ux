# B293：现成 CVHSTNet VAL-best 中规模复评

只复评现有 **B241R 第7轮、VAL最优 CVHSTNet**，不训练、不更换结构、不加入 TFSE/SPWVD 或我们的模块，不运行 ADN、Ours、TS-DetectNet 或 FARC-CAT。

## 为什么值得先试这一次

你之前的低曲线是 B241 **第25轮最终权重**。保存的验证 CE 约1.02582，说明后期有过拟合风险；此前单独训练并仅按 VAL 选择的 B241R 权重，第7轮 CE约0.48977，之后第12轮开始明显变差。它是同一个 CVHSTNet 结构的既有权重，尚未发现其正式低虚警率评分。

这支持先复评它，**不能推断一定达到Pd0.8/0.9**。旧 VAL 探针在1%虚警代理阈值下能有高Pd，但不证明1e-4/1e-5性能。原论文在IPIX数据上报告的90%以上Pd对应1e-3，不能当作当前SIM、低虚警率的保证。

论文：*Overcoming Data Scarcity in Maritime Radar Target Detection via a Complex-Valued Hybrid Spatiotemporal Network*，IEEE GRSL2025，DOI `10.1109/LGRS.2025.3557817`。已有代码属于论文公式重建与SIM接口适配，未宣称作者原代码完全等价。原复杂CNN、CV-BiLSTM及复数FC逐字保留，模型源SHA为 `db857eb65f5c7e549e085650191a2e59bcdfef721468d6c1dd159c7b32b3afad`。

## 默认只跑中规模

- 原权重SHA `e25bdb185c3ac0f407e8bfda700f08cc8e5db18dcbfa4c37abfaeb7b50f9cbf2`，选择完全早于此次DEV评估。
- 启动先在CPU核对权重与contract，避免排队几小时后才发现缺文件。
- GPU空闲后，使用原5000条VAL重放CE，必须与0.48977记录一致，再评分。
- H0 CAL **300,000**，独立 H0 AUDIT **200,000**。
- H1每SCR **512**，SCR **-24…+24 dB，步长2 dB，25点**。
- 只评 **Pfa1e-4**，CAL尾部支持30点，报告真实AUDIT虚警及Wilson区间。
- 不套用B241旧权重的阈值。按当前第7轮权重自己的H0 CAL分布校准，阈值不按Pd或AUDIT调整。
- 画原始Pd，报告真实峰值及全部峰值SCR、D80、D90；不做平移、单调包络或插值美化。
- **完成中规模就停止，不自动升级到全量，不自动重训。**

## 上传、解压、启动

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
unzip -n B293_CVHST_VALBEST_MEDIUM_V1.zip
bash B293_CVHST_VALBEST_MEDIUM_V1/start_on_autodl.sh
tail -F codex_b293_cvhst_valbest.log
```

启动器是nohup＋conda run，使用 `mpdnet-r10`，默认CUDA。会排在B291等使用共享锁 `codex_b271_night.lock` 的任务后，不打断它们。普通SSH/热点断开不影响已启动后台进程；服务器停止/关机则会中断，重复相同命令可从已提交chunk或SCR恢复。CPU也可用 `--device cpu`，通常慢很多。

## 必要旧文件

```
output_sim_r10_b241r_valbest_train_v1/CVHSTNet_2025/seed_20261022/
  sim_r10_final.pt
  training_contract.json

SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1/
  sim_r10_iq512_v1.h5
```

路径移动可传 `--train-dir /实际训练根目录 --bank-dir /实际IQ目录`。不需要旧B241评分文件、旧RankMix、B222或任何ADN权重。缺文件时明确报错，不会自动训练。

## 输出

目录 `output_b293_cvhst_valbest_medium_v1`：

- `b293_pd_scr_pfa_1e-04.pdf/png`
- `b293_metrics.csv`：真实最大Pd/峰值SCR、实际Pfa、D80/D90、第7轮来源。
- `b293_curves.csv`：25点原始计数和区间。
- `b293_report.json`、`protocol_frozen.json`、`val_replay.json`、`progress.json`：来源、VAL重放与恢复证据。
- 三份原始NPY评分数组，供后续整图复用。

先看中规模是否达到用户希望的Pd0.8，以及AUDIT虚警是否合理。未达到时如实保留，不把阈值降低到超出既定虚警率。换论文也必须在同一协议下实测，不能预先保证0.8/0.9。

如中规模正常，之后**显式**加 `--full` 才会用同一冻结权重在新目录 `output_b293_cvhst_valbest_full_v1` 进行 CAL3M/AUDIT1M/H1 1024×49，Pfa1e-4和1e-5；不训练。当前任务默认不启动这一阶段。

## 替补候选核验

2025年的 *Radar Target Detection in Sea Clutter Based on Two-Stage Collaboration*，JMSE13(8),1556，DOI `10.3390/jmse13081556`。标题、日期、作者和海杂波雷达检测任务已通过Crossref原始元数据核验。具体输入、原生网络、作者代码与可复现性仍需原文审核；未声称在SIM达到Pd0.8/0.9，也未直接改写成我们的前端。详见 `research_decision.json`。

## 验证边界

见 `VALIDATION.json`。本地只做CPU合成功能测试，核对原生复数网络前向、权重冻结、5000条VAL聚合逻辑、原场景注入公式、断点恢复、中规模停止和报告。没有AutoDL实际权重，未测真实Pd或CUDA速度。测试中的VAL重放分数使用临时合成数据和mock，不是实际0.48977重放通过的声明。
