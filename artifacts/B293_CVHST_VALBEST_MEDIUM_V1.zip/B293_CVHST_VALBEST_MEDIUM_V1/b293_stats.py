"""CPU postprocessing: fixed cutoffs, descriptive crossings and declared-prior F1."""
import math
import numpy as np
from b293_common import need


def cutoff(scores,pfa):
    s=np.asarray(scores);k=int(math.floor(len(s)*pfa))
    need(s.ndim==1 and np.isfinite(s).all() and 10<=k<len(s),'Insufficient/invalid CAL tail support')
    threshold=float(np.partition(s,len(s)-k-1)[len(s)-k-1])
    return threshold,k,int((s>threshold).sum())


def wilson(k,n):
    z=1.959963984540054;q=k/n;den=1+z*z/n
    mid=(q+z*z/(2*n))/den;rad=z*math.sqrt(q*(1-q)/n+z*z/(4*n*n))/den
    return max(0.,mid-rad),min(1.,mid+rad)


def crossing(x,y,level):
    if y[0]>=level:return float(x[0])
    for j in range(1,len(x)):
        if y[j-1]<level<=y[j]:return float(x[j-1]+(level-y[j-1])*(x[j]-x[j-1])/(y[j]-y[j-1]))
    return None


def classification_rates(tpr,fpr,positive_prior):
    need(0<positive_prior<1 and 0<=tpr<=1 and 0<=fpr<=1,'Invalid class prior or rates')
    tp=positive_prior*tpr;fp=(1-positive_prior)*fpr;fn=positive_prior*(1-tpr)
    precision=tp/(tp+fp) if tp+fp else 0.
    f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.
    return dict(positive_prior=positive_prior,precision=precision,recall=tpr,F1=f1)
