"""CVHSTNet VAL-best: fixed checkpoint, unchanged architecture, medium first."""
import argparse
import copy
import fcntl
import time
from pathlib import Path
import h5py
import numpy as np
import torch
import torch.nn.functional as F
from b293_common import ROOT,NAME,need,readj,writej,readcsv,writecsv,sha,fp,frozen,validate
from b293_stats import cutoff,wilson,crossing

FILES=dict(h0_cal='h0_cal_scores.npy',h0_audit='h0_audit_scores.npy',h1='dev_h1_scores.npy')

def hashes():
    paths=list(ROOT.glob('*.py'))+list((ROOT/'frozen_source').glob('*.py'))+[ROOT/'expected_valbest_contract.json',ROOT/'frozen_sources.json']
    return {p.relative_to(ROOT).as_posix():sha(p) for p in sorted(paths)}

def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT.parent)
    p.add_argument('--train-dir',type=Path);p.add_argument('--bank-dir',type=Path);p.add_argument('--out-dir',type=Path)
    p.add_argument('--device',choices=('cuda','cpu'),default='cuda');p.add_argument('--batch',type=int,default=4)
    p.add_argument('--chunk',type=int,default=256);p.add_argument('--cpu-threads',type=int,default=2)
    p.add_argument('--wait-for-gpu',action='store_true');p.add_argument('--full',action='store_true')
    p.add_argument('--report-only',action='store_true')
    a=p.parse_args(argv);a.root=a.root.resolve();a.profile='full' if a.full else 'medium'
    for key,name in [('train_dir','output_sim_r10_b241r_valbest_train_v1'),('bank_dir','SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1'),
                     ('out_dir','output_b293_cvhst_valbest_'+a.profile+'_v1')]:setattr(a,key,(getattr(a,key) or a.root/name).resolve())
    need(a.root.is_dir() and a.out_dir.parent==a.root and a.out_dir.name.startswith('output_b293_cvhst_'),'Use fresh direct output_b293_cvhst_* directory')
    need(a.out_dir not in (a.train_dir,a.bank_dir),'Output must not overlap old source')
    need(1<=a.batch<=8 and a.chunk>=a.batch and a.chunk%a.batch==0 and 1<=a.cpu_threads<=4,'Invalid batch/chunk/threads')
    if a.out_dir.exists() and any(a.out_dir.iterdir()):
        need((a.out_dir/'protocol_frozen.json').exists(),'Unidentified output contents')
        need(not any(x.is_symlink() for x in a.out_dir.rglob('*')),'Output contains symlinks')
    if a.report_only:a.device='cpu'
    if a.device=='cuda':need(torch.cuda.is_available(),'CUDA unavailable; --device cpu is supported')
    a.device=torch.device(a.device);return a

def source(a):
    folder=a.train_dir/'CVHSTNet_2025/seed_20261022';ctpath=folder/'training_contract.json';ck=folder/'sim_r10_final.pt'
    need(ctpath.is_file() and ck.is_file(),'Existing B241R VAL-best weight/contract missing; no automatic retraining: '+str(folder))
    ct=readj(ctpath);need(ct==readj(ROOT/'expected_valbest_contract.json'),'Wrong CVHSTNet variant or VAL selection record')
    need(sha(ck)==ct['checkpoint_sha256'],'VAL-best checkpoint checksum differs')
    need(sha(ROOT/'frozen_source/cvhstnet_model.py')==ct['signature']['model_source_sha256'],'Original CVHSTNet architecture changed')
    try:state=torch.load(ck,map_location='cpu',weights_only=True)
    except TypeError:state=torch.load(ck,map_location='cpu')
    need(state['signature']==ct['signature'] and state['final_epoch']==ct['best_epoch'] and state['selected_by']=='TRAIN_VAL_MIN_CE_NO_DEV','Checkpoint selection identity differs')
    need(float(state['train_only_input_rms'])==ct['signature']['input_scale_train_only_rms'],'TRAIN scale differs')
    mm=frozen('cvhstnet_model.py');model=mm.CVHSTNet();model.load_state_dict(state['state_dict'],strict=True)
    model.to(a.device).eval().requires_grad_(False)
    protected={str(p):sha(p) for p in (ctpath,ck)}
    return dict(model=model,mm=mm,scale=float(state['train_only_input_rms']),contract=ct,protected=protected)

@torch.inference_mode()
def logits(a,info,iq):
    rows=[]
    for start in range(0,len(iq),a.batch):
        x=torch.from_numpy(np.ascontiguousarray(iq[start:start+a.batch])).to(a.device)
        z=info['model'](info['mm'].stft_iq512(x,info['scale']))
        need(z.shape==(len(x),2) and torch.isfinite(z).all(),'Invalid native CVHSTNet logits');rows.append(z.cpu())
    return torch.cat(rows)

def replay_val(a,info):
    path=a.bank_dir/'sim_r10_iq512_v1.h5';need(path.is_file(),'Frozen IQ bank missing for VAL replay')
    need(sha(path)==info['contract']['signature']['train_bank_sha256'],'VAL bank checksum differs')
    total=0.;count=0
    with h5py.File(path,'r') as h:
        need(h['val/iq'].shape==(5000,512),'Expected full original VAL')
        for start in range(0,5000,a.chunk):
            iq=h['val/iq'][start:start+a.chunk].astype('complex64');y=torch.from_numpy(h['val/label'][start:start+a.chunk].astype('int64'))
            z=logits(a,info,iq);total+=float(F.cross_entropy(z,y,reduction='sum'));count+=len(y)
    ce=total/count;reference=info['contract']['best_val_ce']
    need(abs(ce-reference)<=2e-4,'VAL-best original full VAL CE replay differs')
    print(f'Existing CVHSTNet VAL-best replay passed: epoch={info["contract"]["best_epoch"]}, CE={ce:.8f}; no training',flush=True)
    return dict(val_ce=ce,reference_val_ce=reference,n=count,training_executed=False)

def make_iq(g,p,split,ids,j=None):
    rows=[g.make_one(p['master_seed'],'dev_h1' if split=='h1' else split,int(i),-30,10) for i in ids]
    if split!='h1':
        need(all(r['label']==0 and not np.any(r['target']) for r in rows),'Target leaked into H0')
        return np.stack([r['base'] for r in rows]).astype('complex64')
    base=np.stack([r['base'] for r in rows]).astype('complex128');unit=np.stack([r['unit'] for r in rows]).astype('complex128')
    cp=np.asarray([r['cp'] for r in rows]);need(all(r['label']==1 for r in rows) and (cp>0).all(),'Invalid H1 scene')
    return (base+unit*np.sqrt(cp*10**(p['scr_grid_db'][j]/10))[:,None]).astype('complex64')

def stream(a,p,infer):
    prpath=a.out_dir/'progress.json'
    if prpath.exists():pr=readj(prpath);need(pr['fingerprint']==p['fingerprint'],'Score progress differs')
    else:pr=dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=0,h0_audit=0,h1=0));writej(prpath,pr)
    for split,name in FILES.items():
        n=p['h1_per_scr'] if split=='h1' else p[split+'_n'];levels=len(p['scr_grid_db']);done=pr['completed'][split]
        need(0<=done<=(levels if split=='h1' else n),'Invalid progress count');path=a.out_dir/name
        need(done==0 or path.exists(),'Committed scores missing')
        shape=(levels,n) if split=='h1' else (n,)
        values=np.lib.format.open_memmap(path,mode='r+' if path.exists() else 'w+',dtype='float64',shape=shape)
        need(values.shape==shape and values.dtype==np.float64,'Unexpected score geometry')
        if done:
            j=done-1 if split=='h1' else None;ids=np.arange(min(a.batch,n if split=='h1' else done))
            saved=values[j,ids] if split=='h1' else values[ids];current=infer(split,ids,j)
            need(np.allclose(saved,current,rtol=2e-5,atol=5e-5),'Committed score replay differs')
        began=time.perf_counter()
        if split=='h1':
            for j in range(done,levels):
                for start in range(0,n,a.chunk):
                    stop=min(start+a.chunk,n);values[j,start:stop]=infer(split,np.arange(start,stop),j)
                need(np.isfinite(values[j]).all(),'Nonfinite H1');values.flush();pr['completed'][split]=j+1;writej(prpath,pr)
                print(f'[{a.profile} H1] SCR={p["scr_grid_db"][j]:+d} dB {j+1}/{levels}',flush=True)
        else:
            for start in range(done,n,a.chunk):
                stop=min(start+a.chunk,n);values[start:stop]=infer(split,np.arange(start,stop),None)
                need(np.isfinite(values[start:stop]).all(),'Nonfinite H0');values.flush();pr['completed'][split]=stop;writej(prpath,pr)
                if stop==n or stop%10000<a.chunk:
                    rate=(stop-done)/max(time.perf_counter()-began,1e-6)
                    print(f'[{a.profile} {split}] {stop:,}/{n:,}; {rate:.1f}/s; remaining~{(n-stop)/max(rate,1e-6)/60:.1f}min',flush=True)

def report(a,p):
    pr=readj(a.out_dir/'progress.json');need(pr['fingerprint']==p['fingerprint'],'Report identity differs')
    need(pr['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=len(p['scr_grid_db'])),'Scoring incomplete')
    arr={k:np.load(a.out_dir/n,mmap_mode='r',allow_pickle=False) for k,n in FILES.items()}
    need(arr['h0_cal'].shape==(p['h0_cal_n'],) and arr['h0_audit'].shape==(p['h0_audit_n'],) and arr['h1'].shape==(len(p['scr_grid_db']),p['h1_per_scr']),'Report score shape differs')
    need(all(np.isfinite(v).all() for v in arr.values()),'Nonfinite scores')
    metrics=[];curves=[]
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    for nominal in p['nominal_pfas']:
        threshold,k,chits=cutoff(arr['h0_cal'],nominal);fp0=int((arr['h0_audit']>threshold).sum());n0=len(arr['h0_audit']);flo,fhi=wilson(fp0,n0)
        hits=(arr['h1']>threshold).sum(1);pd=hits/p['h1_per_scr'];grid=p['scr_grid_db'];peak=float(pd.max())
        m=dict(method='CVHSTNet VAL-best SIM-adapt',profile=p['profile'],nominal_pfa=nominal,threshold=threshold,cal_tail_support=k,
            actual_pfa=fp0/n0,audit_false_alarms=fp0,audit_n=n0,actual_pfa_ci95_low=flo,actual_pfa_ci95_high=fhi,
            max_pd=peak,max_pd_scr_db=';'.join(str(s) for s,q in zip(grid,pd) if q==peak),
            reached_pd_0_8=bool(peak>=.8),reached_pd_0_9=bool(peak>=.9),D80_db=crossing(grid,pd,.8),D90_db=crossing(grid,pd,.9),
            selected_epoch=p['training_contract']['best_epoch'])
        metrics.append(m)
        for scr,count,prob in zip(grid,hits,pd):
            lo,hi=wilson(int(count),p['h1_per_scr']);curves.append(dict(method=m['method'],nominal_pfa=nominal,scr_db=scr,hits=int(count),n_h1=p['h1_per_scr'],pd=float(prob),pd_ci95_low=lo,pd_ci95_high=hi))
        fig,ax=plt.subplots(figsize=(8,5));ax.plot(grid,pd,color='tab:orange',marker='o',markevery=2,markersize=4,label=m['method'])
        ax.set(xlabel='SCR (dB)',ylabel=r'$P_d$',xlim=(grid[0],grid[-1]),ylim=(0,1.02),title=r'$P_{\mathrm{fa}}=10^{'+str(int(round(np.log10(nominal))))+'}$')
        ax.grid(alpha=.25);ax.legend(fontsize=8);fig.tight_layout()
        for ext in ('pdf','png'):fig.savefig(a.out_dir/f'b293_pd_scr_pfa_{nominal:.0e}.{ext}',dpi=250)
        plt.close(fig)
        print(f'CVHSTNet VAL-best Pfa={nominal:.0e}: MAX Pd={peak:.4%} at SCR={m["max_pd_scr_db"]}; D80={m["D80_db"]}; D90={m["D90_db"]}; actual Pfa={fp0/n0:g}',flush=True)
    writecsv(a.out_dir/'b293_metrics.csv',metrics);writecsv(a.out_dir/'b293_curves.csv',curves)
    result=dict(status='PASS_B293_CVHST_VALBEST_EVALUATED',metrics=metrics,training_executed=False,architecture_changed=False,
        other_models_executed=False,thresholds_calibrated_on_own_checkpoint=True,medium_does_not_trigger_full=True,
        protected_sources_unchanged=all(sha(path)==h for path,h in p['protected_sources'].items()),
        score_sha256={k:sha(a.out_dir/name) for k,name in FILES.items()},independent_final=False,
        scope='Fixed VAL-selected historical checkpoint re-evaluation; exposed SIM-R10 DEV, not a guarantee of Pd>=.8',protocol=p)
    need(result['protected_sources_unchanged'],'An old checkpoint changed');writej(a.out_dir/'b293_report.json',result);return result

def main(argv=None):
    a=cli(argv);validate();torch.set_num_threads(a.cpu_threads);torch.manual_seed(20261022)
    torch.backends.cudnn.benchmark=False;torch.backends.cudnn.allow_tf32=False;torch.backends.cuda.matmul.allow_tf32=False
    if a.report_only:
        p=readj(a.out_dir/'protocol_frozen.json');need(p['fingerprint']==fp({k:v for k,v in p.items() if k!='fingerprint'}),'Invalid protocol')
        report(a,p);return
    # Check the existing weight before waiting hours for another GPU job.
    # Construct on CPU first so this inspection does not occupy its GPU.
    pre_args=copy.copy(a);pre_args.device=torch.device('cpu');info=source(pre_args)
    if not (a.out_dir/'val_replay.json').exists():
        need((a.bank_dir/'sim_r10_iq512_v1.h5').is_file(),'Frozen VAL IQ bank missing; no run started')
    print(f'Found fixed CVHSTNet VAL-best checkpoint, epoch={info["contract"]["best_epoch"]}; no retraining.',flush=True)
    lock=a.root/('codex_b271_night.lock' if a.device.type=='cuda' else 'codex_b293_cvhst_cpu.lock')
    with lock.open('a') as f:
        while True:
            try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);break
            except BlockingIOError:
                need(a.wait_for_gpu,'Another radar job is active');print('Waiting for current GPU experiment; no training or other models started.',flush=True);time.sleep(30)
        info['model'].to(a.device);g=frozen('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
        cal,audit,h1,grid,pfas=(3000000,1000000,1024,list(range(-24,25)),[1e-4,1e-5]) if a.full else (300000,200000,512,list(range(-24,25,2)),[1e-4])
        p=dict(version='B293_CVHST_VALBEST_SCORE_V1',profile=a.profile,training_contract=info['contract'],protected_sources=info['protected'],
            master_seed=20261009,generator_sha256=sha(g.__file__),h0_cal_n=cal,h0_audit_n=audit,h1_per_scr=h1,scr_grid_db=grid,nominal_pfas=pfas,
            batch=a.batch,chunk=a.chunk,cpu_threads=a.cpu_threads,device=a.device.type,torch_version=str(torch.__version__),code_sha256=hashes(),amp=False,tf32=False,
            architecture_changed=False,training_executed=False,other_models_executed=False,checkpoint_selected_before_DEV=True)
        p['fingerprint']=fp(p);a.out_dir.mkdir(exist_ok=True);pp=a.out_dir/'protocol_frozen.json'
        if pp.exists():need(readj(pp)==p,'Run settings changed; use fresh output_b293_cvhst_*')
        else:
            need(not any(a.out_dir.iterdir()),'Unidentified output');writej(pp,p)
        vp=a.out_dir/'val_replay.json'
        if vp.exists():need(readj(vp)['protocol_fingerprint']==p['fingerprint'],'VAL replay identity differs')
        else:writej(vp,dict(protocol_fingerprint=p['fingerprint'],**replay_val(a,info)))
        def infer(split,ids,j):
            z=logits(a,info,make_iq(g,p,split,ids,j));return (z[:,1]-z[:,0]).numpy().astype('float64')
        print(f'B293 ONLY existing CVHSTNet VAL-best: {a.profile}; CAL{cal:,}/AUDIT{audit:,}; H1 {h1}x{len(grid)}; no training',flush=True)
        stream(a,p,infer);report(a,p);print('B293 complete; stops here, no automatic full-scale run: '+str(a.out_dir),flush=True)

if __name__=='__main__':main()
