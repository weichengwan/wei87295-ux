"""Synthetic CPU checks; no real baseline Pd or CUDA measurement."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import h5py
import numpy as np
import torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from b293_common import ROOT,readj,writej,sha,fp,frozen
from b293_evaluate import source,logits,replay_val,make_iq,stream,report,cli,FILES,main

def fixture(root):
    root.mkdir(parents=True,exist_ok=True)
    a=SimpleNamespace(root=root,train_dir=root/'old_valbest',bank_dir=root/'bank',out_dir=root/'output_b293_cvhst_fixture',
        device=torch.device('cpu'),batch=2,chunk=4,cpu_threads=2,profile='medium',full=False)
    a.bank_dir.mkdir();a.out_dir.mkdir();train=a.train_dir/'CVHSTNet_2025/seed_20261022';train.mkdir(parents=True)
    with h5py.File(a.bank_dir/'sim_r10_iq512_v1.h5','w') as h:
        h.create_dataset('val/iq',shape=(5000,512),dtype='complex64',chunks=(64,512),fillvalue=np.complex64(0))
        h.create_dataset('val/label',data=np.tile(np.array([0,1],dtype='uint8'),2500))
    ct=readj(ROOT/'expected_valbest_contract.json');ct['signature']['train_bank_sha256']=sha(a.bank_dir/'sim_r10_iq512_v1.h5')
    ct['best_val_ce']=float(np.log(2.))
    model=frozen('cvhstnet_model.py').CVHSTNet()
    torch.save(dict(signature=ct['signature'],final_epoch=ct['best_epoch'],selected_by='TRAIN_VAL_MIN_CE_NO_DEV',
        train_only_input_rms=ct['signature']['input_scale_train_only_rms'],state_dict=model.state_dict()),train/'sim_r10_final.pt')
    ct['checkpoint_sha256']=sha(train/'sim_r10_final.pt');writej(train/'training_contract.json',ct)
    expected=root/'expected';(expected/'frozen_source').mkdir(parents=True)
    (expected/'frozen_source/cvhstnet_model.py').write_bytes((ROOT/'frozen_source/cvhstnet_model.py').read_bytes())
    writej(expected/'expected_valbest_contract.json',ct)
    with patch('b293_evaluate.ROOT',expected):info=source(a)
    return a,info,expected

class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):torch.set_num_threads(2)

    def test_fixed_VAL_best_source_native_forward_and_VAL_replay(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            a,info,expected=fixture(Path(tmp));g=frozen('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
            iq=np.stack([g.make_one(20261009,'val',j,-30,10)['iq'] for j in range(2)])
            z=logits(a,info,iq);self.assertEqual(tuple(z.shape),(2,2));self.assertTrue(torch.isfinite(z).all())
            self.assertFalse(any(x.requires_grad for x in info['model'].parameters()))
            a.chunk=256
            with patch('b293_evaluate.logits',side_effect=lambda a,info,iq:torch.zeros(len(iq),2)):
                value=replay_val(a,info);self.assertEqual(value['n'],5000);self.assertLess(abs(value['val_ce']-np.log(2)),1e-6)
            self.assertTrue(all(sha(p)==s for p,s in info['protected'].items()))

    def test_generator_h0_h1_and_exact_original_injection(self):
        g=frozen('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py');p=dict(master_seed=20261009,scr_grid_db=[-24,0,24])
        ids=np.array([0,1,5]);h0=make_iq(g,p,'h0_cal',ids)
        np.testing.assert_array_equal(h0,np.stack([g.make_one(20261009,'h0_cal',int(i),-30,10)['base'] for i in ids]))
        h1=make_iq(g,p,'h1',ids,2);self.assertEqual(h1.dtype,np.complex64)
        row=g.make_one(20261009,'dev_h1',0,-30,10)
        expected=(row['base'].astype('complex128')+row['unit'].astype('complex128')*np.sqrt(row['cp']*10**2.4)).astype('complex64')
        np.testing.assert_array_equal(h1[0],expected)

    def test_score_stream_interruption_and_resume(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            folder=Path(tmp);a=SimpleNamespace(out_dir=folder,batch=2,chunk=4,profile='fixture')
            p=dict(h0_cal_n=9,h0_audit_n=7,h1_per_scr=8,scr_grid_db=[-24,0,24]);p['fingerprint']=fp(p)
            def infer(split,ids,j):return np.asarray(ids,dtype='float64')+(0 if j is None else j)
            done=[]
            def stop(split,ids,j):
                if split=='h0_cal' and ids[0]==4 and not done:done.append(True);raise RuntimeError('synthetic interruption')
                return infer(split,ids,j)
            with self.assertRaisesRegex(RuntimeError,'interruption'):stream(a,p,stop)
            self.assertEqual(readj(folder/'progress.json')['completed']['h0_cal'],4)
            stream(a,p,infer);before={n:sha(folder/n) for n in FILES.values()};stream(a,p,infer)
            self.assertEqual(before,{n:sha(folder/n) for n in FILES.values()})

    def test_report_real_tail_support_and_both_Pd_targets(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            a,info,_=fixture(Path(tmp))
            p=dict(profile='medium',h0_cal_n=300000,h0_audit_n=200000,h1_per_scr=8,scr_grid_db=[-24,0,24],nominal_pfas=[1e-4],
                training_contract=info['contract'],protected_sources=info['protected']);p['fingerprint']=fp(p)
            np.save(a.out_dir/FILES['h0_cal'],np.linspace(-1,1,300000))
            np.save(a.out_dir/FILES['h0_audit'],np.linspace(-1,1,200000))
            np.save(a.out_dir/FILES['h1'],np.array([np.full(8,-2.),np.r_[-2.,-2.,np.full(6,2.)],np.full(8,2.)]))
            writej(a.out_dir/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=300000,h0_audit=200000,h1=3)))
            result=report(a,p);m=result['metrics'][0]
            self.assertTrue(m['reached_pd_0_8'] and m['reached_pd_0_9']);self.assertEqual(m['cal_tail_support'],30)
            self.assertFalse(result['training_executed']);self.assertFalse(result['architecture_changed'])
            self.assertTrue((a.out_dir/'b293_pd_scr_pfa_1e-04.pdf').is_file())

    def test_medium_main_stops_without_full_or_training_and_full_is_explicit(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            a,info,_=fixture(Path(tmp));captured=[]
            argv=['--root',tmp,'--device','cpu','--out-dir',str(a.out_dir),'--bank-dir',str(a.bank_dir)]
            with patch('b293_evaluate.source',return_value=info),patch('b293_evaluate.replay_val',return_value=dict(n=5000,val_ce=.49)),\
                 patch('b293_evaluate.stream',side_effect=lambda a,p,i:captured.append(p)),patch('b293_evaluate.report',return_value={}):
                main(argv)
            self.assertEqual(len(captured),1);p=captured[0]
            self.assertEqual((p['h0_cal_n'],p['h0_audit_n'],p['h1_per_scr']),(300000,200000,512))
            self.assertEqual(p['nominal_pfas'],[1e-4]);self.assertFalse(p['training_executed'] or p['other_models_executed'])
            self.assertEqual(cli(['--root',tmp,'--device','cpu','--full']).profile,'full')

if __name__=='__main__':unittest.main()
