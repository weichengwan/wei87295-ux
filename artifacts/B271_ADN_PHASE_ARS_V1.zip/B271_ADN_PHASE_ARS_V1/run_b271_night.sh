#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -ne 0 ]; then
  printf '此脚本采用预设配置。自定义参数请使用 run_b271_train.sh / run_b271_score.sh。\n' >&2
  exit 64
fi
b271_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$b271_dir"
exec 9>../codex_b271_night.lock
flock -n 9 || { printf '已有 B271 任务运行。\n' >&2; exit 1; }
date -Is
bash run_b271_train.sh --variants guided --epochs 12 --batch 32 --device cuda --resume
date -Is
bash run_b271_score.sh --batch 32 --chunk 512 --device cuda
date -Is
