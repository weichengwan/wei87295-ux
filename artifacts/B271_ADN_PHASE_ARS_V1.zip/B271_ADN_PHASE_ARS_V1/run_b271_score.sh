#!/usr/bin/env bash
set -euo pipefail
b271_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
export OMP_NUM_THREADS=4
export MKL_NUM_THREADS=4
exec python -u "$b271_dir/b271_score.py" "$@"
