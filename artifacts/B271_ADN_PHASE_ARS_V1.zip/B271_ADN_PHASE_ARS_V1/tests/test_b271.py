"""CPU functional tests with artificial inputs; not radar detection results."""
from __future__ import annotations
import copy
import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import h5py
import numpy as np
import torch
import torch.nn.functional as F

ROOT=Path(__file__).resolve().parents[1]
PACKAGE=ROOT/"package" if (ROOT/"package").is_dir() else ROOT
sys.path.insert(0,str(PACKAGE))
from b271_model import B271Net,PhaseEvidence,BoundedResampler
from b271_data import digest_file,write_json,read_json,load_checkpoint
from source_loader import load_frozen_sources,load_frozen_file
import b271_train as train
import b271_score as score
import b271_report as report


def fixture(root):
    source,trainer,original=load_frozen_sources()
    b210=load_frozen_file("r10_sim_stage_b210_a3_adn_earlystop_v1.py")
    generator=load_frozen_file("r10_sim_iq512_builder_v1_EARLIEST_HDF5.py")
    bank=root/"bank";bank.mkdir()
    cache=root/"cache.h5"
    with h5py.File(bank/b210.H5_NAME,"w") as raw,h5py.File(cache,"w") as maps:
        for split in ("train","val"):
            scenes=[generator.make_one(20261009,split,i,-30,10) for i in range(4)]
            iq=np.stack([x["iq"] for x in scenes]).astype("complex64")
            target=np.stack([x["target"] for x in scenes]).astype("complex64")
            labels=np.array([x["label"] for x in scenes],dtype="uint8")
            g=raw.create_group(split);g.create_dataset("iq",data=iq)
            g.create_dataset("target_iq",data=target);g.create_dataset("label",data=labels)
            h=maps.create_group(split);h.create_dataset("label",data=labels)
            h.create_dataset("wvd",data=source.wvd_base_map(torch.from_numpy(iq)).numpy())
    context=dict(root=root,bank_dir=bank,cache=cache,b210=b210,source=source,
                 device=torch.device("cpu"),bc=dict(file_sha256=digest_file(bank/b210.H5_NAME),
                 generator_sha256=digest_file(generator.__file__)),cc=dict(wvd_cache_sha256=digest_file(cache)))
    torch.manual_seed(3)
    model=trainer.ProposedWrapper(source,dict(original.CFG))
    initialization=dict(method="L1_TAIL",seed=20261022,epoch=1,cfg=original.CFG,
                        state_dict=model.state_dict(),source_sha256=b210.SOURCE_SHA,
                        trainer_sha256=b210.TRAINER_SHA)
    data=train.Data(context)
    candidate=train.make_model(dict(variant="guided"),initialization,context["device"])
    initialization["val_metrics"]=train.validation(candidate,data,context,2)
    return context,data,initialization


class ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        train.setup(2)

    def test_zero_initialization_and_checkpoint_for_all_variants(self):
        source,trainer,original=load_frozen_sources()
        torch.manual_seed(4)
        baseline=trainer.ProposedWrapper(source,dict(original.CFG)).eval()
        images=torch.rand(2,3,224,224);iq=torch.randn(2,512,dtype=torch.complex64)
        checkpoint=dict(method="L1_TAIL",cfg=original.CFG,state_dict=baseline.state_dict(),
                        source_sha256=trainer.EXPECTED_SOURCE_SHA,
                        trainer_sha256="7354c3d64ca7e6f4745097f117afbf1f267091a97c79f0d5c99d081c9e2ffcc5")
        with torch.no_grad():expected=baseline(images)
        for variant in ("guided","no_phase","head_control"):
            model=train.make_model(dict(variant=variant),checkpoint,torch.device("cpu")).eval()
            with torch.no_grad():actual=model(images,iq)
            torch.testing.assert_close(actual,expected,rtol=0,atol=0)
            restored=B271Net(**model.model_config).eval()
            restored.load_state_dict(model.state_dict())
            with torch.no_grad():torch.testing.assert_close(restored(images,iq),actual,rtol=0,atol=0)
        bad=copy.deepcopy(checkpoint);bad["state_dict"].pop(next(iter(bad["state_dict"])))
        with self.assertRaises(ValueError):model.load_l1_checkpoint(bad)

    def test_phase_global_phase_power_and_batch_invariance(self):
        phase=PhaseEvidence()
        torch.manual_seed(8)
        iq=torch.randn(5,512,dtype=torch.complex64)
        original=phase(iq)
        torch.testing.assert_close(phase(iq*torch.exp(torch.tensor(.72j))),original,atol=2e-5,rtol=2e-5)
        torch.testing.assert_close(phase(iq*7.3),original,atol=2e-5,rtol=2e-5)
        torch.testing.assert_close(torch.cat([phase(iq[i:i+1]) for i in range(5)]),original,atol=2e-6,rtol=2e-6)
        order=torch.tensor([3,1,4,0,2])
        torch.testing.assert_close(phase(iq[order]),original[order],atol=2e-6,rtol=2e-6)
        zero=phase(torch.zeros(2,512,dtype=torch.complex64))
        self.assertTrue(torch.isfinite(zero).all() and torch.count_nonzero(zero)==0)

    def test_wvd_frequency_alias_alignment_and_disjoint_noise_diagnostic(self):
        phase=PhaseEvidence()
        t=torch.arange(512,dtype=torch.float32)
        for f in (-.28,-.25,-.1,0.,.1,.25,.28):
            tone=torch.exp(2j*torch.pi*f*t)[None]
            guide=phase(tone)
            peak=int(guide[0,0].mean(0).argmax())
            expected=((2*f+.5)%1)*128
            distance=min(abs(peak-expected),128-abs(peak-expected))
            self.assertLessEqual(distance,3.,(f,peak,expected))
        torch.manual_seed(12)
        noise=torch.randn(48,512,dtype=torch.complex64)
        noise_c=float(phase(noise)[:,1,32:96].mean())
        tone=torch.exp(2j*torch.pi*.125*t)[None]
        coherent=float(phase(tone)[0,1,32:96,96].mean())
        self.assertGreater(coherent,noise_c+.15)
        self.assertLess(noise_c,.85)
        # These are a finite artificial sanity check, not evidence that actual
        # sea clutter is always less coherent than a target.

    def test_second_step_gradients_and_frozen_original_bn(self):
        model=B271Net()
        model.train()
        self.assertFalse(model.detector.training or model.suppressor.training)
        old={k:v.detach().clone() for k,v in model.state_dict().items()
             if k.startswith(("detector.","suppressor."))}
        images=torch.rand(2,3,224,224);iq=torch.randn(2,512,dtype=torch.complex64)
        optimizer=torch.optim.Adam([p for p in model.parameters() if p.requires_grad],lr=1e-3)
        for _ in range(2):
            optimizer.zero_grad()
            loss=F.cross_entropy(model(images,iq),torch.tensor([0,1]))
            loss.backward();optimizer.step()
        self.assertGreater(float(model.resample1.encoder[0].weight.grad.abs().sum()),0)
        self.assertGreater(float(model.phase_encoder[0].weight.grad.abs().sum()),0)
        for key,value in old.items():self.assertTrue(torch.equal(model.state_dict()[key],value),key)
        self.assertLess(sum(p.numel() for p in model.parameters() if p.requires_grad),20000)


class PipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):train.setup(2)

    def test_actual_training_pool_resume_and_weight_freeze(self):
        with tempfile.TemporaryDirectory(prefix="b271_artificial_training_") as tmp:
            root=Path(tmp)
            context,data,ck=fixture(root)
            args=train.cli(["--root",str(root),"--epochs","2","--min-epochs","1","--patience","0",
                            "--batch","2","--device","cpu","--train-h0-proposals","16","--pool-size","4"])
            args.out_dir.mkdir()
            candidate=train.make_model(dict(variant="head_control"),ck,context["device"])
            pool=train.extra_h0_pool(args,context,candidate,"artificial-checkpoint-sha")
            self.assertEqual(train.extra_h0_pool(args,context,candidate,"artificial-checkpoint-sha"),pool)
            one=train.train_one(args,context,data,ck,"artificial-checkpoint-sha",pool,"guided")
            last=load_checkpoint(args.out_dir/"guided/last_epoch.pt")
            self.assertTrue(one["original_weights_and_bn_unchanged"])
            self.assertEqual(one["epochs_executed"],2)
            self.assertEqual(train.train_one(args,context,data,ck,"artificial-checkpoint-sha",pool,"guided"),one)
            interrupted=copy.copy(args);interrupted.out_dir=root/"interrupted";interrupted.out_dir.mkdir()
            original_save=train.atomic_save
            def stop_after_first(path,state):
                original_save(path,state)
                if Path(path).name=="last_epoch.pt" and state["epoch"]==1:
                    raise InterruptedError("artificial test interruption")
            with patch.object(train,"atomic_save",stop_after_first):
                with self.assertRaises(InterruptedError):
                    train.train_one(interrupted,context,data,ck,"artificial-checkpoint-sha",pool,"guided")
            interrupted.resume=True
            restored=train.train_one(interrupted,context,data,ck,"artificial-checkpoint-sha",pool,"guided")
            actual=load_checkpoint(interrupted.out_dir/"guided/last_epoch.pt")
            for key,value in last["state_dict"].items():
                torch.testing.assert_close(actual["state_dict"][key],value,rtol=0,atol=0)
            self.assertEqual(restored["best_epoch"],one["best_epoch"])
            changed=copy.copy(args);changed.lr*=2
            with self.assertRaises(RuntimeError):train.train_one(changed,context,data,ck,"artificial-checkpoint-sha",pool,"guided")
            data.close()

    def test_partial_auc_ties_and_perfect_ranking(self):
        self.assertAlmostEqual(train.pauc([0,0,1,1],[0,0,1,1]),1.)
        self.assertAlmostEqual(train.pauc([1,1,0,0],[0,0,1,1]),0.)
        self.assertAlmostEqual(train.pauc([0,0,0,0],[0,0,1,1]),.005)

    def test_selected_checkpoint_binding_rejects_replaced_or_mismatched_best(self):
        with tempfile.TemporaryDirectory(prefix="b271_selected_checkpoint_") as tmp:
            path=Path(tmp)/"best.pt"
            state=dict(run_fingerprint="fixture-run",model_config=dict(variant="guided"),
                       epoch=2,val_metrics=dict(pauc01=.1))
            train.atomic_save(path,state)
            sha=digest_file(path)
            self.assertEqual(train.selected_checkpoint(path,sha,"fixture-run",state["model_config"],2,.1),state)
            for changes in (dict(run_fingerprint="other-run"),dict(model_config=dict(variant="no_phase")),
                            dict(epoch=3),dict(val_metrics=dict(pauc01=.2))):
                bad={**state,**changes};train.atomic_save(path,bad)
                with self.assertRaises(RuntimeError):
                    train.selected_checkpoint(path,digest_file(path),"fixture-run",state["model_config"],2,.1)
            with self.assertRaises(RuntimeError):
                train.selected_checkpoint(path,sha,"fixture-run",state["model_config"],2,.1)
            path.unlink()
            with self.assertRaises(RuntimeError):
                train.selected_checkpoint(path,sha,"fixture-run",state["model_config"],2,.1)

    def test_partial_auc_boundary_vertical_segment_has_no_area(self):
        self.assertAlmostEqual(train.pauc([4,3,2,1],[0,1,0,1],limit=.5),0.)
        # 2500 H0 puts the actual selection boundary exactly at rank25.
        labels=np.r_[np.zeros(25),np.ones(3),np.zeros(2475),np.ones(2)]
        scores=np.arange(len(labels),0,-1,dtype=float)
        self.assertAlmostEqual(train.pauc(scores,labels,limit=.01),0.)

    def test_actual_scoring_stream_resume_and_margin_precision(self):
        with tempfile.TemporaryDirectory(prefix="b271_artificial_scoring_") as tmp:
            root=Path(tmp)
            generator=load_frozen_file("r10_sim_iq512_builder_v1_EARLIEST_HDF5.py")
            source=load_frozen_sources()[0];model=B271Net().eval()
            p=dict(version=score.VERSION,master_seed=20261009,h0_cal_n=8,h0_audit_n=4,
                   h1_scenes_n=4,scr_grid_db=[-24,0,12],labels=["guided","L1_TAIL"])
            p["fingerprint"]=train.fingerprint(p)
            args=SimpleNamespace(out_dir=root/"scores",batch=2,chunk=4)
            score.stream(args,p,generator,[model],source,torch.device("cpu"))
            first=np.load(args.out_dir/"dev_h1_scores.npy").copy()
            np.testing.assert_array_equal(first[:,:,0],first[:,:,1])
            progress=read_json(args.out_dir/"progress.json")
            progress["completed"]["h0_cal"]=4;progress["completed"]["h1"]=2
            write_json(args.out_dir/"progress.json",progress)
            corrupt=np.load(args.out_dir/"dev_h1_scores.npy",mmap_mode="r+")
            corrupt[2]=-999;corrupt.flush();del corrupt
            score.stream(args,p,generator,[model],source,torch.device("cpu"))
            np.testing.assert_array_equal(np.load(args.out_dir/"dev_h1_scores.npy"),first)
            # Every array is mandatory once its prefix is committed. A missing
            # CAL/AUDIT/H1 file must not be silently recreated as finite zeros.
            for filename in ("h0_cal_scores.npy","h0_audit_scores.npy","dev_h1_scores.npy"):
                path=args.out_dir/filename;backup=path.with_suffix(".bak")
                path.rename(backup)
                with self.assertRaisesRegex(RuntimeError,"array missing"):
                    score.stream(args,p,generator,[model],source,torch.device("cpu"))
                self.assertFalse(path.exists())
                backup.rename(path)

    def test_full_count_report_reference_replay_and_known_shift(self):
        # Deliberately constructed mathematical scores. Any shift here is a
        # report test oracle, never a trained detector's performance.
        with tempfile.TemporaryDirectory(prefix="b271_analytic_report_") as tmp:
            root=Path(tmp);out=root/"current";out.mkdir()
            p=dict(version=score.VERSION,scene_fingerprint="artificial-scene-id",seed=20261022,
                   labels=["guided","L1_TAIL"],h0_cal_n=3000000,h0_audit_n=1000000,
                   h1_scenes_n=1024,scr_grid_db=list(range(-24,13)),
                   original_checkpoint_sha256="artificial-l1-id")
            p["fingerprint"]=train.fingerprint(p)
            write_json(out/"protocol_frozen.json",p)
            write_json(out/"progress.json",dict(fingerprint=p["fingerprint"],
                       completed=dict(h0_cal=3000000,h0_audit=1000000,h1=37)))
            b222=root/"output_sim_r10_b222_gpu_dualpfa_v1/seed_20261022"
            lmda=root/"output_sim_r10_b223_external_baselines_v1/dl/LMDA_PF/seed_20261022"
            old=root/"output_sim_r10_b227_score_fusion_exploratory_v1/seed_20261022"
            for d in (b222,lmda,old):d.mkdir(parents=True)
            a=dict(scene_fingerprint=p["scene_fingerprint"],fingerprint="artificial-a",
                   checkpoint_sha256={"L1-Tail":p["original_checkpoint_sha256"]},
                   methods=["Original ADN","L1-Tail","Original M2","FT-KD-Order"],
                   scr_grid_db=p["scr_grid_db"],h1_per_scr=1024)
            b=dict(b213_scene_fingerprint=p["scene_fingerprint"],fingerprint="artificial-b",
                   method="LMDA-PF",scr_db=p["scr_grid_db"],h1_per_scr=1024)
            for d,c in ((b222,a),(lmda,b)):
                write_json(d/"protocol_frozen.json",c)
                write_json(d/"progress.json",dict(fingerprint=c["fingerprint"],h0_cal=3000000,
                           h0_audit=1000000,h1_scr=37))
            write_json(old/"b227_provenance.json",dict(scene_fingerprint=p["scene_fingerprint"],
                       source_protocol_sha256=dict(B222=digest_file(b222/"protocol_frozen.json"),
                                                   LMDA=digest_file(lmda/"protocol_frozen.json"))))
            base_h1=np.array([1+scr*.01+np.linspace(-.1,.1,1024) for scr in p["scr_grid_db"]])
            own={}
            for name,count in (("h0_cal_scores.npy",3000000),("h0_audit_scores.npy",1000000)):
                values=np.arange(count,dtype="float64")/count
                for d,cols in ((b222,4),(lmda,1),(out,2)):
                    m=np.lib.format.open_memmap(d/name,mode="w+",dtype="float64",shape=(count,cols))
                    m[:]=values[:,None];m.flush();del m
                own[name]=np.load(out/name,mmap_mode="r")
            for d,cols in ((b222,4),(lmda,1),(out,2)):
                name="dev_h1_scores.npy" if d==out else "dev_h1_scores_37.npy"
                m=np.lib.format.open_memmap(d/name,mode="w+",dtype="float64",shape=(37,1024,cols))
                m[:]=base_h1[:,:,None]
                if d==out:m[:,:,0]+=.02
                m.flush();del m
            # Independent literal original B227 arithmetic as the replay oracle.
            cal=np.arange(3000000,dtype="float64")/3000000
            aud=np.arange(1000000,dtype="float64")/1000000
            def original_mix(x):
                q=np.searchsorted(cal,x,side="left").astype("float64")/len(cal)
                return .75*q+.25*q
            c,m=report.metrics_for("Rank mix LMDA75/L125",original_mix(cal),original_mix(aud),
                                   original_mix(base_h1),p)
            report.save_csv(old/"b227_curves.csv",c)
            report.save_csv(old/"b227_pfa.csv",[dict(method=r["method"],nominal_pfa=r["nominal_pfa"],
                            false_alarms=r["audit_false_alarms"]) for r in m])
            result=report.generate(out,root)
            self.assertTrue(result["rankmix_reference"]["rankmix_all_74_hits_replayed"])
            self.assertEqual(len(result["internal_targets"]),2)
            for target in result["internal_targets"]:
                self.assertLess(target["delta_D90_db"],-1.9)
                self.assertTrue(target["one_db_D90_met"])
            self.assertTrue((out/"figures/b271_pd_scr_pfa_1e-05.pdf").is_file())
            with (old/"b227_curves.csv").open() as f:bad=list(csv.DictReader(f))
            bad[0]["hits"]=int(bad[0]["hits"])+1
            report.save_csv(old/"b227_curves.csv",bad)
            with self.assertRaisesRegex(RuntimeError,"hit replay failed"):
                report.frozen_comparators(root,p)


if __name__=="__main__":
    unittest.main()
