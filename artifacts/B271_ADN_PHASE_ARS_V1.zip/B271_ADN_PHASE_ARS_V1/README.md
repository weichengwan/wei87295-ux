# B271：ADN/L1 + 相位条件重采样，完整训练与评分

这是可在原 AutoDL 环境运行的候选方法，包含实际训练、训练专用 H0 难例
筛选、断点恢复、完整 3M/1M/1024 评分及 PDF/PNG 曲线。不是仅含接口的包。
本地完成的是人工输入上的 CPU 功能验证；尚未验证真实 AutoDL 检测提升。

本包只处理SIM-R10纯仿真Pd–SCR：单距离单元512脉冲，输入SCR为纯目标/纯杂波
平均IQ功率比。原L1仅输入WVD图；本候选额外读取同一条原始IQ，需披露输入
表征变化。它不使用RD图，不能将结果写成实测海况验证。2025实测LOAO模型、
203帧残差缩放Δ曲线及1015次/点的模板SCNR注入是其他协议，不能合并或共用横轴。

## 方法与来源

基座是你现有的 L1-Tail：ADN18 + WCSG + TFCG + 原 B215 L1-Tail 目标。
新增结构不使用 LMDA 网络或权重。参考的是：

Linwei Chen, Ying Fu, Lin Gu, Dezhi Zheng, Jifeng Dai.
**Spatial Frequency Modulation for Semantic Segmentation**.
IEEE TPAMI, 47(11), 9767–9784, 2025.
DOI: [10.1109/TPAMI.2025.3592621](https://doi.org/10.1109/TPAMI.2025.3592621).
[作者官方源码](https://github.com/Linwei-Chen/SFM).

已核对作者仓库中题名、期刊、年份、DOI及ARS机制，并固定仓库提交
b08e63ee49a5e5d4e304ada368142a9f5972113a。出版社/arXiv接口受网络限制，
未完成独立全文审读。它是2025年的相关顶刊候选，不宣称是截至2026年的最新论文。

本实现借鉴“下采样前自适应重采样”的机制，独立实现有界采样器；未复制原
SFM代码，也未复现语义分割网络及上采样解调部分。引入以下领域适配：

1. 512点复数IQ分成8个**不重叠**的64点Hann窗块，计算局部二阶相位差
   的圆集中度。二阶差允许常加速度相位；这只是证据特征，海杂波也可能相干。
2. 按原离散WVD的 **q=2f mod 1** 关系对齐相位图。两个物理别名分支使用
   功率加权聚合，并校正原WVD512→128像素中心的1.5/512偏移；时间按块
   中心插值，显式保留边界近似。
3. 在原maxpool之前及layer3之前加入两个小采样器，预测偏移每轴最多0.75像素。
   使用 x + grid(x,offset) - grid(x,0)，使零偏移时严格恢复原输出。
4. 小型相位证据头融合相位图和512维图像特征，对原分类margin给出有界修正。
   输出层零初始化，margin修正最多±3。

**仅训练新增13,869个参数。原主干权重、WCSG、TFCG、BN状态都冻结。**
冻结主干没有包在no_grad里，插入模块仍可通过后续冻结层获得梯度。
空间偏移有平滑/Jacobian正则，并记录偏移饱和及负Jacobian比例。
没有声称已证明“抗混叠”“目标专属相干性”或新颖性；这些需要专门实验。

## 训练数据与目标：明确发生了哪些改变

- 原TRAIN=30000、VAL=5000 IQ及WVD缓存继续使用，均校验来源与SHA。
- 默认额外生成**200000条训练专用H0候选**，使用原生成器的独立阶段名
  b271_training_h0_v1。只保留冻结L1最高分1024条和最多256条随机候选，
  不存20万条完整WVD，增加的缓存通常约几十至一百MiB。
- 额外H0筛选只调用冻结L1，所有消融使用同一提案规则；不会读原H0-CAL、
  H0-AUDIT、DEV-H1或其分数来训练/选点。候选总数是**额外训练曝光预算**，
  不能声称训练数据预算与原L1完全相同。
- 每轮用当前候选对原训练H0和保留池重新评分，取全局高分256条，分批加入
  排序目标；这些难例在损失中重新前向，分数有梯度，不用过期缓存logit。
- 保留原B215的L1-Tail损失；默认增加0.05×跨batch难H0排序。
- 从训练H1的已保存target_iq构造同背景+3dB配对，增加0.05×单调性惩罚，
  不把target_iq或SCR作为推理输入。此监督依赖仿真纯目标分量，不能直接
  照搬到无法分离真实目标分量的实测训练。
- 0.001×偏移平滑/Jacobian惩罚；AdamW lr=2e-4、weight_decay=1e-3、梯度裁剪1。
- 最多12epoch；至少4轮、patience=3。按**VAL pAUC[0,0.01]**选择，并要求
  VAL CE不高于初始值+0.03；初始epoch0可以入选。
  2500条VAL H0只能提供代理选择指标，不能证明Pfa=1e-5性能。
  若选中epoch0，应报告训练未获得符合选择标准的改进。

额外样本及额外优化也可能带来收益。论文需要同数据/目标的控制实验，不能把
全部增益归给新模块。不要使用AUDIT或已暴露DEV来调权重、挑epoch或门限。

## 运行

将本包解压到原项目下，使目录为：

    /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1/B271_ADN_PHASE_ARS_V1

激活原环境后：

~~~bash
source /root/miniconda3/etc/profile.d/conda.sh
conda activate mpdnet-r10
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1/B271_ADN_PHASE_ARS_V1
bash run_b271_night.sh
~~~

它依次执行训练专用H0筛选→新模块训练→完整评分与绘图，失败即停止。
推荐用nohup后台运行。请只启动一次；脚本使用flock避免重复任务。
模型、数据和旧B270结果不被覆盖。

默认输出 ../output_b271_phase_ars_v1：

    run_manifest.json
    train_h0_pool/contract.json
    train_h0_pool/pool.h5
    guided/best.pt
    guided/last_epoch.pt
    guided/train_val_history.csv
    guided/training_contract.json
    pd_scr/b271_metrics.csv
    pd_scr/b271_curves.csv
    pd_scr/b271_report.json
    pd_scr/figures/*.pdf
    pd_scr/figures/*.png
    pd_scr/diagnostics/b271_vs_rankmix_1db.csv

训练和评分可分别运行，支持命令行参数：

~~~bash
# 只校验数据、加载和完整VAL初始重放，不更新参数
bash run_b271_train.sh --preflight

# 自定义完整训练及评分
bash run_b271_train.sh --epochs 12 --batch 32 --resume
bash run_b271_score.sh --batch 32 --chunk 512

# 只重新生成报告
bash run_b271_score.sh --stage report
~~~

默认自动使用已恢复的 output_sim_r10_b270_wvd_rebuilt_v1，不再复制/重建这份缓存。
run_manifest、配置、代码和缓存来源变化会拒绝续跑；更改配置请使用新out-dir。
断点位于epoch边界，未提交的epoch重新执行；推理按H0分块/H1-SCR边界恢复。
已提交epoch绑定best.pt的SHA及内部配置/轮次。若best保存后、epoch提交前中断
导致两者不一致，会停止；已有评分进度而数组丢失时也停止，不会补零冒充结果。
提案筛选也逐块保存进度。若在写保留池HDF5过程中断且遗留.tmp，先保留现场
检查，脚本会停止而不擅自删除文件。

## 消融

三个变体：guided完整相位引导；no_phase同重采样器但无相位证据；
head_control仅图像小头，原图像主干固定。使用相同额外H0预算。
准确地说，no_phase同时移除STFT能量与相干两个通道以及直接IQ证据头；
head_control也不保留IQ证据头。这三臂是组合控制，不能分别证明相位相对功率、
重采样相对直接证据头各自的独立贡献。若候选有效，还需补齐这些单因素控制。

~~~bash
bash run_b271_train.sh --variants guided,no_phase,head_control \
  --out-dir ../output_b271_architecture_ablation
bash run_b271_score.sh --run-dir ../output_b271_architecture_ablation

# 关闭跨batch难例库和额外H0曝光，隔离训练采样效果
bash run_b271_train.sh --hard-weight 0 --train-h0-proposals 0 \
  --out-dir ../output_b271_without_hard_bank
bash run_b271_score.sh --run-dir ../output_b271_without_hard_bank
~~~

还应独立关闭一致性损失做控制。消融结果不能预先写成贡献已成立。

## 评估与强融合目标

原B213生成器与场景指纹、3M CAL、1M AUDIT、37个SCR(-24..12)、每点1024
H1保持不变。分数为float32 logit差转换float64，TF32关闭，不使用AMP。
门限只从CAL独立拟合，判决严格score>threshold；AUDIT只报告实测虚警及区间。
原始37点曲线不平滑，D50/D80/D90首次交点插值，不外推。

主图绘制新候选、原L1和可用的原ADN冻结scorebank。若原B222/B223/B227
缓存仍在，会在**内部诊断目录**重算固定75/25排名融合，先核验全部74个
命中数与AUDIT计数，再给出1dB目标达成情况。新模型不加载LMDA。
原来的rankmix使用固定H0-CAL left ECDF并独立校准融合门限；
此参考只用于事先明确的性能目标，不能把它或新结果说成独立FINAL。
历史ADN冻结分数是回顾性参考，不代表已重新完成同种子或多种子公平比较；
此前存在事后极值选种子，论文主结论仍需匹配训练设置与输入/数据预算。

原L1新推理与历史scorebank的浮点实现可能不同，之前已有4个SCR各差1个命中。
本包分别保留各自的原CAL阈值，不宣称位级等价。场景协议可核对，但无逐场景
ID重新哈希，不作未经核实的配对显著性声明。

主要目标仍是Pfa=1e-5下D90约<=1.557dB，并检查实际AUDIT虚警。
单个D90满足不等于整条曲线左移，创新性、真实数据有效性与跨seed稳定性
均需额外验证。本包不保证达到目标。

## 本地验证

CPU测试包括严格初始输出、两步梯度、主干/BN冻结、相位/功率/
batch不变性、WVD别名对齐、不重叠噪声诊断、实际训练/难例池/精确续跑、
真实原生成器的缩小评分续跑、全计数报告与原融合重放。

~~~bash
python -m unittest discover -s tests -v
~~~

测试使用人工输入与数学fixture，构造的左移仅测试报告逻辑，绝不是模型实验结果。
未在此运行AutoDL真实训练、CUDA耗时或真实完整Pd/SCR实验。
