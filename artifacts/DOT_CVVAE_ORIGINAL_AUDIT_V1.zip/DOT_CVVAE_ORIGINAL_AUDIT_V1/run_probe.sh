#!/usr/bin/env bash
set -euo pipefail
DOT_PACKAGE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DOT_PROJECT_ROOT="${1:-$(dirname -- "$DOT_PACKAGE_DIR")}"
exec 9>"$DOT_PROJECT_ROOT/dot_original_audit.lock"
if ! flock -n 9; then
  echo 'A DoT diagnostic is already active or queued; no second task started.'
  exit 0
fi
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2
exec /root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  python -u "$DOT_PACKAGE_DIR/dot_probe.py" --root "$DOT_PROJECT_ROOT" --device cuda --wait-for-gpu
