#!/usr/bin/env bash
set -euo pipefail
DOT_PACKAGE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DOT_PROJECT_ROOT="${1:-$(dirname -- "$DOT_PACKAGE_DIR")}"
DOT_LOG="$DOT_PROJECT_ROOT/codex_dot_original_audit.log"
nohup bash "$DOT_PACKAGE_DIR/run_probe.sh" "$DOT_PROJECT_ROOT" >> "$DOT_LOG" 2>&1 < /dev/null &
printf '后台 PID：%s\n日志：%s\n' "$!" "$DOT_LOG"
