"""Read-only checkpoint/VAL diagnosis. No fitting, threshold tuning or DEV scoring."""
from __future__ import annotations
import argparse,csv,fcntl,hashlib,importlib.util,json,math,os,time
from datetime import datetime,timezone
from pathlib import Path
import h5py,numpy as np,torch

SOURCE='r10_2025_mtdsp_dotcvvae_native_source_v1_FIX1_FAST.py'
SOURCE_SHA='9dc539bef5fa56852d38beffda0b99b660ea23392cf8ddb5a62a5f54250608c4'
BANK='SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1'
MODEL='output_sim_r10_b225_real_four_dl_train_v1/DoT_CVVAE/seed_20261022'
MODES=('native16_fixed_block','legacy_max32','diagnostic_mean32')

def need(test,message):
    if not bool(test):raise RuntimeError(message)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for piece in iter(lambda:f.read(8*1024**2),b''):h.update(piece)
    return h.hexdigest()
def readj(path):return json.loads(Path(path).read_text())
def savej(path,data):
    temp=Path(str(path)+'.tmp');temp.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n');temp.replace(path)
def load_source():
    path=Path(__file__).resolve().parent/'frozen_source'/SOURCE
    need(sha(path)==SOURCE_SHA,'Frozen native model source SHA changed')
    spec=importlib.util.spec_from_file_location('dot_native_probe',path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

def context(root):
    folder=root/MODEL;meta=readj(folder/'training_contract.json');path=folder/'sim_r10_final.pt'
    need(meta['version']=='SIM_R10_B225_FOUR_DL_TRAIN_V1' and meta['method']=='DoT-CVVAE','Not the expected B225 DoT checkpoint')
    need(meta['original_source_sha256']==SOURCE_SHA and not meta['h0_cal_used_for_training'] and not meta['dev_h1_used_for_training'],'Source/training scope mismatch')
    need(meta['checkpoint_sha256']==sha(path),'Model checkpoint differs from training contract')
    contract=readj(root/BANK/'sim_r10_iq512_v1_contract.json');bank=root/BANK/'sim_r10_iq512_v1.h5'
    need(meta['training_bank_sha256']==contract['file_sha256'],'Model and VAL belong to different banks')
    need(bank.is_file() and sha(bank)==contract['file_sha256'],'Actual frozen IQ bank SHA differs')
    with h5py.File(bank,'r') as h:
        need(h['val']['iq'].shape==(5000,512),'Expected full frozen VAL5000 IQ512')
        y=np.asarray(h['val']['label'][:]);need(set(np.unique(y))=={0,1} and y.sum()==2500,'VAL label census differs')
    try:state=torch.load(path,map_location='cpu',weights_only=True)
    except TypeError:state=torch.load(path,map_location='cpu')
    need(state['version']==meta['version'] and state['method']=='DoT-CVVAE' and state['original_source_sha256']==SOURCE_SHA,'Checkpoint internal identity differs')
    rms=float(state['h0_train_rms'])
    need(math.isfinite(rms) and rms>0 and rms==float(meta['h0_train_rms']),'TRAIN-H0 RMS differs')
    source=load_source();model=source.DoTCVVAE();model.load_state_dict(state['state_dict'],strict=True);model.eval().requires_grad_(False)
    return source,model,rms,bank,meta

def auc(y,score):
    """Mann-Whitney AUC with average tied ranks, used only for descriptive VAL diagnosis."""
    order=np.argsort(score,kind='stable');ranks=np.empty(len(score),dtype='float64');s=score[order];start=0
    for stop in range(1,len(score)+1):
        if stop==len(score) or s[stop]!=s[start]:
            ranks[order[start:stop]]=(start+1+stop)/2;start=stop
    n1=int(y.sum());n0=len(y)-n1
    need(n1>0 and n0>0,'Both VAL labels required')
    return float((ranks[y==1].sum()-n1*(n1+1)/2)/(n1*n0))
def summary(values):
    v=np.asarray(values,dtype='float64');need(v.size and np.isfinite(v).all(),'Empty/nonfinite values')
    q=np.quantile(v,[.5,.9,.99])
    return dict(n=int(v.size),mean=float(v.mean()),median=float(q[0]),q90=float(q[1]),q99=float(q[2]),maximum=float(v.max()))

@torch.inference_mode()
def infer(source,model,iq,rms,device,native_batch):
    need(iq.dtype==np.complex64 and iq.ndim==2 and iq.shape[1]==512,'Expected complex64 IQ512')
    # The same division, IQ16 segmentation and statistic as the old B225 adapter.
    flat=(torch.from_numpy(np.ascontiguousarray(iq)).to(device)/rms).reshape(-1,16)
    keys=('T','T_time','T_amp','T_dop');parts={k:[] for k in keys}
    rec=[];mu=[];lv=[]
    for start in range(0,len(flat),native_batch):
        result=source.detection_statistic(model,flat[start:start+native_batch])
        need(torch.allclose(result['T'],result['T_time']+result['T_amp']+result['T_dop'],rtol=1e-6,atol=1e-6),'Statistic components do not sum')
        for k in keys:parts[k].append(result[k].double().cpu().numpy())
        rec.append(result['xhat'].abs().square().mean(1).double().cpu().numpy())
        mu.append(result['mu'].abs().square().mean(1).double().cpu().numpy())
        lv.append(result['logvar'].mean(1).double().cpu().numpy())
    parts={k:np.concatenate(v).reshape(len(iq),32) for k,v in parts.items()}
    scores=np.stack([parts['T'][:,16],parts['T'].max(1),parts['T'].mean(1)],axis=1)
    details={k:parts[k].mean(1) for k in keys}
    details.update(reconstruction_power=np.concatenate(rec).reshape(len(iq),32).mean(1),
                   posterior_mean_power=np.concatenate(mu).reshape(len(iq),32).mean(1),
                   posterior_logvar=np.concatenate(lv).reshape(len(iq),32).mean(1),
                   input_power=np.mean(np.abs(iq.astype('complex128')/rms)**2,axis=1))
    return scores,details

def run(a):
    source,model,rms,bank,meta=context(a.root)
    print('PASS_DOT_OLD_CHECKPOINT_AND_FULL_VAL_BANK_SHA; no training',flush=True)
    if a.stage=='preflight':return
    device=torch.device(a.device);need(device.type!='cuda' or torch.cuda.is_available(),'CUDA not available')
    with (a.root/'codex_b271_night.lock').open('a') as lock:
        while True:
            try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);break
            except BlockingIOError:
                need(a.wait_for_gpu,'Another radar job holds GPU lock; use --wait-for-gpu')
                print('Waiting for radar GPU lock; no GPU memory allocated',flush=True);time.sleep(15)
        model=model.to(device)
        out=a.root/'output_dot_original_audit_v1'/datetime.now(timezone.utc).strftime('val_probe_%Y%m%dT%H%M%S_%fZ')
        out.mkdir(parents=True,exist_ok=False);all_scores=[];all_details={};began=time.monotonic()
        with h5py.File(bank,'r') as h:
            group=h['val'];y=np.asarray(group['label'][:],dtype=np.int64)
            need('family_index' in group,'VAL family_index absent');families=np.asarray(group['family_index'][:])
            for start in range(0,5000,a.scene_batch):
                stop=min(5000,start+a.scene_batch);iq=np.asarray(group['iq'][start:stop],dtype=np.complex64)
                scores,detail=infer(source,model,iq,rms,device,a.native_batch);all_scores.append(scores)
                for k,v in detail.items():all_details.setdefault(k,[]).append(v)
                if stop==5000 or stop//1000!=start//1000:print(f'VAL {stop}/5000; elapsed={time.monotonic()-began:.1f}s',flush=True)
        scores=np.concatenate(all_scores);details={k:np.concatenate(v) for k,v in all_details.items()}
        need(np.isfinite(scores).all(),'Nonfinite score');rows=[]
        for label in (0,1):
            for family in (-1,0,1,2,3,4):
                mask=(y==label)&((families==family) if family>=0 else True)
                if not mask.any():continue
                for col,name in enumerate(MODES):rows.append(dict(label=label,family=family,mode=name,**summary(scores[mask,col])))
        with (out/'dot_val_score_summary.csv').open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
        with (out/'dot_val_scores.csv').open('w',newline='') as f:
            fields=['val_index','label','family']+list(MODES)+list(details);writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
            for i in range(len(y)):writer.writerow(dict(val_index=i,label=int(y[i]),family=int(families[i]),**dict(zip(MODES,scores[i])),**{k:v[i] for k,v in details.items()}))
        report=dict(status='PASS_DOT_ORIGINAL_VAL_DIAGNOSIS',stage='VAL only; descriptive, not independent test',
          checkpoint_sha256=meta['checkpoint_sha256'],bank_sha256=meta['training_bank_sha256'],source_sha256=SOURCE_SHA,
          train_epochs=meta['train_epochs'],paper_epochs=50,train_h0_rms=rms,n_val=5000,
          scope=dict(trained=False,weights_modified=False,thresholds_calibrated=False,DEV_or_CAL_or_AUDIT_opened=False,
            automatic_baseline_selection=False,low_Pfa_Pd_estimated=False),
          units=dict(native16_fixed_block='IQ[256:272], short-observation diagnosis only',legacy_max32='Old IQ512 max32 score, unchanged',
            diagnostic_mean32='New aggregation diagnostic only, not original-paper detector'),
          auc_on_val={name:auc(y,scores[:,i]) for i,name in enumerate(MODES)},
          components={str(label):{k:summary(v[y==label]) for k,v in details.items()} for label in (0,1)},
          elapsed_seconds=time.monotonic()-began,
          limits=['VAL5000 does not support reliable Pfa1e-4/1e-5 tail estimation','Native IQ16 and full IQ512 scores use different observation lengths',
                  'No model/aggregation is automatically selected by these VAL descriptive results','Posterior mean reconstruction is the existing adapter choice, under-specified by original paper'])
        savej(out/'dot_probe_report.json',report)
        print('VAL descriptive AUC:',report['auc_on_val'],flush=True)
        print('PASS_DOT_ORIGINAL_VAL_DIAGNOSIS:',out,flush=True)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    p.add_argument('--stage',choices=('preflight','probe'),default='probe');p.add_argument('--device',choices=('cpu','cuda'),default='cuda')
    p.add_argument('--scene-batch',type=int,default=64);p.add_argument('--native-batch',type=int,default=1024);p.add_argument('--wait-for-gpu',action='store_true')
    a=p.parse_args();a.root=a.root.resolve();need(a.root.is_dir() and a.scene_batch>0 and a.native_batch>0,'Invalid root or batch')
    torch.set_num_threads(2)
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    torch.backends.cudnn.benchmark=False
    run(a)
if __name__=='__main__':main()
