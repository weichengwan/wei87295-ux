import argparse,hashlib,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np,torch,h5py
import dot_probe as p

class ProbeTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2);cls.src=p.load_source()
    def test_auc_ties_and_orientation(self):
        y=np.array([0,0,1,1]);self.assertEqual(p.auc(y,np.ones(4)),.5)
        self.assertEqual(p.auc(y,np.array([0,1,2,3.])),1.)
        self.assertEqual(p.auc(y,np.array([3,2,1,0.])),0.)
    def test_original_component_formula(self):
        rng=np.random.default_rng(2);x=torch.from_numpy((rng.normal(size=(7,16))+1j*rng.normal(size=(7,16))).astype('complex64'))
        xhat=x*complex(.3,.2)
        class Fixed:
            def __call__(self,xx,deterministic=False):return xhat,torch.zeros(7,4,dtype=torch.complex64),torch.zeros(7,4)
        r=self.src.detection_statistic(Fixed(),x)
        expected=.5*(x-xhat).abs().square().mean(1)+(x.abs()-xhat.abs()).square().mean(1)
        sx=torch.fft.fft(x,norm='ortho').abs();sh=torch.fft.fft(xhat,norm='ortho').abs()
        ks=sx.argmax(1);k=torch.arange(16)[None,:];d=(k-ks[:,None]).abs();d=torch.minimum(d,16-d)
        w=1+1.7*torch.exp(-d.square()/ (2*1.6**2))
        expected+=(w*(sx-sh).square()).mean(1)
        torch.testing.assert_close(r['T'],expected)
    def test_old_max_and_probe_no_extra_normalization(self):
        torch.manual_seed(8);net=self.src.DoTCVVAE().eval().requires_grad_(False)
        rng=np.random.default_rng(3);iq=(rng.normal(size=(4,512))+1j*rng.normal(size=(4,512))).astype('complex64');rms=1.6450551209312119
        score,detail=p.infer(self.src,net,iq,rms,torch.device('cpu'),64)
        with torch.inference_mode():
            native=self.src.detection_statistic(net,(torch.from_numpy(iq)/rms).reshape(-1,16))['T'].double().numpy().reshape(4,32)
        np.testing.assert_allclose(score[:,0],native[:,16],rtol=2e-5,atol=2e-5)
        np.testing.assert_allclose(score[:,1],native.max(1),rtol=2e-5,atol=2e-5)
        np.testing.assert_allclose(score[:,2],native.mean(1),rtol=2e-5,atol=2e-5)
        np.testing.assert_allclose(detail['T'],detail['T_time']+detail['T_amp']+detail['T_dop'],rtol=1e-6)
    def make_fixture(self,root):
        dest=root/p.MODEL;dest.mkdir(parents=True);b=root/p.BANK;b.mkdir()
        with h5py.File(b/'sim_r10_iq512_v1.h5','w') as h:
            g=h.create_group('val');g.create_dataset('iq',data=np.ones((5000,512),dtype='complex64'))
            g.create_dataset('label',data=np.arange(5000)%2);g.create_dataset('family_index',data=np.arange(5000)%5)
        bank=p.sha(b/'sim_r10_iq512_v1.h5');(b/'sim_r10_iq512_v1_contract.json').write_text(json.dumps({'file_sha256':bank}))
        state=dict(version='SIM_R10_B225_FOUR_DL_TRAIN_V1',method='DoT-CVVAE',original_source_sha256=p.SOURCE_SHA,
                   h0_train_rms=1.,state_dict=self.src.DoTCVVAE().state_dict())
        torch.save(state,dest/'sim_r10_final.pt')
        meta=dict(version=state['version'],method=state['method'],original_source_sha256=p.SOURCE_SHA,h0_cal_used_for_training=False,
                  dev_h1_used_for_training=False,checkpoint_sha256=p.sha(dest/'sim_r10_final.pt'),training_bank_sha256=bank,h0_train_rms=1.,train_epochs=25)
        (dest/'training_contract.json').write_text(json.dumps(meta));return b
    def test_wrong_weight_hash_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);self.make_fixture(root)
            with (root/p.MODEL/'sim_r10_final.pt').open('ab') as f:f.write(b'changed')
            with self.assertRaisesRegex(RuntimeError,'checkpoint differs'):p.context(root)
    def test_preflight_and_report_keep_checkpoint_read_only(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);self.make_fixture(root);checkpoint=root/p.MODEL/'sim_r10_final.pt';before=p.sha(checkpoint)
            a=argparse.Namespace(root=root,stage='preflight',device='cpu',wait_for_gpu=False,scene_batch=64,native_batch=1024)
            p.run(a);self.assertFalse((root/'output_dot_original_audit_v1').exists())
            def fake_infer(source,model,iq,rms,device,native_batch):
                v=np.arange(len(iq),dtype=float);return np.stack((v,v+1,v+2),axis=1),{'T':v,'T_time':v*.5,'T_amp':v*.3,'T_dop':v*.2}
            a.stage='probe'
            with patch.object(p,'infer',fake_infer):p.run(a)
            reports=list((root/'output_dot_original_audit_v1').glob('*/dot_probe_report.json'));self.assertEqual(len(reports),1)
            report=json.loads(reports[0].read_text());self.assertFalse(report['scope']['low_Pfa_Pd_estimated'])
            self.assertFalse(report['scope']['trained']);self.assertFalse(report['scope']['automatic_baseline_selection'])
            self.assertEqual(before,p.sha(checkpoint));self.assertEqual(len(report['auc_on_val']),3)

if __name__=='__main__':unittest.main()
