#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
R10 2025 — DoT-CVVAE NATIVE SOURCE V1 FIX1 FAST
======================================

Paper-text-faithful reconstruction of:
T. Bai, J. Tang, N. Sun, Y. Xu,
"Radar target detection in sea clutter via a detection-oriented complex-valued VAE",
Signal Processing 249 (2026) 110758.

SOURCE-SPECIFIED:
  L=16, K=4, channels=32, 4 encoder / 4 decoder complex TCN blocks,
  encoder dilation 1,2,4,8; decoder 8,4,2,1; kernel=3; modReLU;
  proper complex-Gaussian latent posterior; Student-t likelihood nu=5;
  lambda_amp=lambda_peak=1; alpha_w=1.7; rho=1.6;
  Adam lr=1e-4, batch=256, 50 epochs;
  T(x)=T_time+T_amp+T_dop;
  clutter-only quantile threshold, fixed at test time.

PAPER-UNDERSPECIFIED IMPLEMENTATION CHOICES FROZEN HERE:
  1) Complex Conv1d implemented by the standard real/imag decomposition.
  2) Symmetric "same-length" dilated padding, not causal padding.
     The paper does not state a causal requirement; radar dwell processing is offline.
  3) First encoder block uses a complex 1x1 residual projection from 1 -> 32 channels.
  4) Decoder latent projection is a complex linear K -> channels*L.
  5) log-variance head consumes concatenated real/imag pooled features.
  6) Validation/test reconstruction is deterministic using posterior mean z=mu.
     Training uses one proper-complex reparameterized sample per input.
  7) A single fold-global RMS scale, estimated from TRAIN clutter only, is applied
     to all inputs for that fold. In normalized coordinates sigma_x^2=1.
     This is an MTDSP numerical-scale adaptation because the paper does not report
     an absolute sigma_x^2 or input normalization convention.
  8) FFT uses norm="ortho" to implement the paper's unitary DFT.
  9) logvar is clamped to [-16, 12] only at exp/sampling sites for numerical safety.

These choices MUST NOT be tuned on H0/H1 performance.

FIX1 FAST COMPUTATIONAL BACKEND
-------------------------------
Complex Conv1d and Complex Linear use a fused 2x2 real block-matrix form.
This is algebraically the same complex multiplication as V1 and preserves
all trainable parameter tensors/state_dict names.  The purpose is only to
reduce the very large number of tiny CUDA kernel launches for L=16.
No scientific hyperparameter, sampler, loss, normalization, or detector
statistic is changed.
"""

from __future__ import annotations

import math
from typing import Dict, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

VERSION = "R10_2025_MTDSP_DOTCVVAE_NATIVE_SOURCE_V1_FIX1_FAST"

L = 16
LATENT_K = 4
CHANNELS = 32
ENC_DILATIONS = (1, 2, 4, 8)
DEC_DILATIONS = (8, 4, 2, 1)
KERNEL = 3
NU = 5.0
LAMBDA_AMP = 1.0
LAMBDA_PEAK = 1.0
ALPHA_W = 1.7
RHO = 1.6
SIGMA_X2_NORMALIZED = 1.0


class ComplexConv1d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size,
                 dilation=1, padding=0, bias=True):
        super().__init__()
        self.in_channels = int(in_channels)
        self.out_channels = int(out_channels)
        self.kernel_size = int(kernel_size)
        self.dilation = int(dilation)
        self.padding = int(padding)

        shape = (self.out_channels, self.in_channels, self.kernel_size)
        self.weight_r = nn.Parameter(torch.empty(shape))
        self.weight_i = nn.Parameter(torch.empty(shape))
        if bias:
            self.bias_r = nn.Parameter(torch.zeros(self.out_channels))
            self.bias_i = nn.Parameter(torch.zeros(self.out_channels))
        else:
            self.register_parameter("bias_r", None)
            self.register_parameter("bias_i", None)
        self.reset_parameters()

    def reset_parameters(self):
        # Complex analogue of Kaiming uniform: each real/imag part scaled by 1/sqrt(2).
        nn.init.kaiming_uniform_(self.weight_r, a=math.sqrt(5))
        nn.init.kaiming_uniform_(self.weight_i, a=math.sqrt(5))
        with torch.no_grad():
            self.weight_r.mul_(1.0 / math.sqrt(2.0))
            self.weight_i.mul_(1.0 / math.sqrt(2.0))

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        """
        Algebraically identical fused implementation of
            yr = conv(xr,Wr) - conv(xi,Wi)
            yi = conv(xr,Wi) + conv(xi,Wr)
        using ONE real Conv1d call instead of four small Conv1d calls.

        Parameter tensors and state_dict names are unchanged.
        """
        if not torch.is_complex(z):
            raise TypeError("ComplexConv1d expects complex tensor")
        xr, xi = z.real, z.imag
        x2 = torch.cat((xr, xi), dim=1)
        top = torch.cat((self.weight_r, -self.weight_i), dim=1)
        bot = torch.cat((self.weight_i,  self.weight_r), dim=1)
        w2 = torch.cat((top, bot), dim=0)
        b2 = None
        if self.bias_r is not None:
            b2 = torch.cat((self.bias_r, self.bias_i), dim=0)
        y2 = F.conv1d(
            x2, w2, b2,
            padding=self.padding,
            dilation=self.dilation,
        )
        yr, yi = torch.split(y2, self.out_channels, dim=1)
        return torch.complex(yr, yi)


class ComplexLinear(nn.Module):
    def __init__(self, in_features, out_features, bias=True):
        super().__init__()
        self.in_features = int(in_features)
        self.out_features = int(out_features)
        self.weight_r = nn.Parameter(torch.empty(out_features, in_features))
        self.weight_i = nn.Parameter(torch.empty(out_features, in_features))
        if bias:
            self.bias_r = nn.Parameter(torch.zeros(out_features))
            self.bias_i = nn.Parameter(torch.zeros(out_features))
        else:
            self.register_parameter("bias_r", None)
            self.register_parameter("bias_i", None)
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.kaiming_uniform_(self.weight_r, a=math.sqrt(5))
        nn.init.kaiming_uniform_(self.weight_i, a=math.sqrt(5))
        with torch.no_grad():
            self.weight_r.mul_(1.0 / math.sqrt(2.0))
            self.weight_i.mul_(1.0 / math.sqrt(2.0))

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        """
        Algebraically identical fused real Linear implementation.
        Parameter tensors and state_dict names are unchanged.
        """
        if not torch.is_complex(z):
            raise TypeError("ComplexLinear expects complex tensor")
        xr, xi = z.real, z.imag
        x2 = torch.cat((xr, xi), dim=-1)
        top = torch.cat((self.weight_r, -self.weight_i), dim=1)
        bot = torch.cat((self.weight_i,  self.weight_r), dim=1)
        w2 = torch.cat((top, bot), dim=0)
        b2 = None
        if self.bias_r is not None:
            b2 = torch.cat((self.bias_r, self.bias_i), dim=0)
        y2 = F.linear(x2, w2, b2)
        yr, yi = torch.split(y2, self.out_features, dim=-1)
        return torch.complex(yr, yi)


class ModReLU(nn.Module):
    def __init__(self, channels: int, eps: float = 1e-8):
        super().__init__()
        self.bias = nn.Parameter(torch.zeros(int(channels)))
        self.eps = float(eps)

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        mag = torch.abs(z)
        b = self.bias[None, :, None]
        scale = F.relu(mag + b) / (mag + self.eps)
        return z * scale


class ComplexTCNBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, dilation: int):
        super().__init__()
        pad = int(dilation) * (KERNEL - 1) // 2
        self.conv1 = ComplexConv1d(
            in_channels, out_channels, KERNEL,
            dilation=dilation, padding=pad, bias=True)
        self.act1 = ModReLU(out_channels)
        self.conv2 = ComplexConv1d(
            out_channels, out_channels, KERNEL,
            dilation=dilation, padding=pad, bias=True)
        self.act2 = ModReLU(out_channels)
        self.skip = (
            ComplexConv1d(in_channels, out_channels, 1, dilation=1, padding=0)
            if in_channels != out_channels else nn.Identity()
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        r = self.skip(x)
        y = self.act1(self.conv1(x))
        y = self.act2(self.conv2(y))
        return y + r


class DoTCVVAE(nn.Module):
    def __init__(self):
        super().__init__()
        enc = []
        cin = 1
        for d in ENC_DILATIONS:
            enc.append(ComplexTCNBlock(cin, CHANNELS, d))
            cin = CHANNELS
        self.encoder = nn.ModuleList(enc)

        self.mu_head = ComplexLinear(CHANNELS, LATENT_K)
        self.logvar_head = nn.Linear(2 * CHANNELS, LATENT_K)

        self.dec_proj = ComplexLinear(LATENT_K, CHANNELS * L)
        self.decoder = nn.ModuleList([
            ComplexTCNBlock(CHANNELS, CHANNELS, d)
            for d in DEC_DILATIONS
        ])
        self.out_conv = ComplexConv1d(CHANNELS, 1, 1, padding=0)

    def encode(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        # x [B,L] complex
        if x.ndim != 2 or x.shape[-1] != L:
            raise ValueError(f"Expected [B,{L}] complex input, got {tuple(x.shape)}")
        h = x[:, None, :]
        for block in self.encoder:
            h = block(h)
        pooled = h.mean(dim=-1)  # [B,C] complex
        mu = self.mu_head(pooled)
        feat = torch.cat([pooled.real, pooled.imag], dim=1)
        logvar = self.logvar_head(feat)
        return mu, logvar

    def reparameterize(self, mu: torch.Tensor, logvar: torch.Tensor,
                       deterministic: bool = False) -> torch.Tensor:
        if deterministic:
            return mu
        lv = logvar.clamp(-16.0, 12.0)
        sigma = torch.exp(0.5 * lv)
        er = torch.randn_like(sigma)
        ei = torch.randn_like(sigma)
        eps = torch.complex(er, ei) / math.sqrt(2.0)
        return mu + sigma * eps

    def decode(self, z: torch.Tensor) -> torch.Tensor:
        h = self.dec_proj(z).reshape(z.shape[0], CHANNELS, L)
        for block in self.decoder:
            h = block(h)
        y = self.out_conv(h)[:, 0, :]
        return y

    def forward(self, x: torch.Tensor, deterministic: bool = False):
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar, deterministic=deterministic)
        xhat = self.decode(z)
        return xhat, mu, logvar


def kl_complex_standard(mu: torch.Tensor, logvar: torch.Tensor) -> torch.Tensor:
    # Eq.(6) journal: sum[-log sigma^2 + sigma^2 + |mu|^2 - 1]
    lv = logvar.clamp(-16.0, 12.0)
    var = torch.exp(lv)
    return (-lv + var + torch.abs(mu).square() - 1.0).sum(dim=1)


def student_t_nll(x: torch.Tensor, xhat: torch.Tensor,
                  nu: float = NU, sigma_x2: float = SIGMA_X2_NORMALIZED) -> torch.Tensor:
    # Negative Eq.(9), dropping constants independent of model parameters.
    err2 = torch.abs(x - xhat).square().sum(dim=1)
    return (nu + L) * torch.log1p(err2 / (nu * sigma_x2))


def amplitude_loss(x: torch.Tensor, xhat: torch.Tensor) -> torch.Tensor:
    # Eq.(15)
    return (torch.abs(x) - torch.abs(xhat)).square().mean(dim=1)


def peak_weights_from_input(x: torch.Tensor,
                            alpha_w: float = ALPHA_W,
                            rho: float = RHO) -> torch.Tensor:
    # x [B,L], unitary DFT per paper.
    s = torch.abs(torch.fft.fft(x, dim=1, norm="ortho"))
    # torch.argmax returns first maximizer.
    kstar = torch.argmax(s, dim=1)
    k = torch.arange(L, device=x.device)[None, :]
    diff = torch.abs(k - kstar[:, None])
    d = torch.minimum(diff, L - diff).to(s.dtype)
    w = 1.0 + alpha_w * torch.exp(-(d.square()) / (2.0 * rho * rho))
    return w


def spectral_peak_loss(x: torch.Tensor, xhat: torch.Tensor) -> torch.Tensor:
    # Eqs.(12)-(19)
    sx = torch.abs(torch.fft.fft(x, dim=1, norm="ortho"))
    sh = torch.abs(torch.fft.fft(xhat, dim=1, norm="ortho"))
    w = peak_weights_from_input(x)
    return (w * (sx - sh).square()).mean(dim=1)


def training_loss_components(model: DoTCVVAE, x: torch.Tensor) -> Dict[str, torch.Tensor]:
    xhat, mu, logvar = model(x, deterministic=False)
    nll = student_t_nll(x, xhat)
    kl = kl_complex_standard(mu, logvar)
    lamp = amplitude_loss(x, xhat)
    lpeak = spectral_peak_loss(x, xhat)
    total = nll + kl + LAMBDA_AMP * lamp + LAMBDA_PEAK * lpeak
    return {
        "total": total,
        "student_t_nll": nll,
        "kl": kl,
        "amp": lamp,
        "peak": lpeak,
        "xhat": xhat,
    }


@torch.inference_mode()
def detection_statistic(model: DoTCVVAE, x: torch.Tensor) -> Dict[str, torch.Tensor]:
    # Frozen MTDSP choice: deterministic posterior-mean reconstruction.
    xhat, mu, logvar = model(x, deterministic=True)
    # Eqs.(22)-(24)
    t_time = 0.5 * torch.abs(x - xhat).square().mean(dim=1)
    t_amp = amplitude_loss(x, xhat)
    t_dop = spectral_peak_loss(x, xhat)
    total = t_time + t_amp + t_dop
    return {
        "T": total,
        "T_time": t_time,
        "T_amp": t_amp,
        "T_dop": t_dop,
        "xhat": xhat,
        "mu": mu,
        "logvar": logvar,
    }


def parameter_count(model: nn.Module) -> int:
    return int(sum(p.numel() for p in model.parameters()))
