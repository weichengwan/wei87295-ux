"""Exactly the B280 A1 frontend/CNN; LCBR after native layer2, as in B286."""
import copy
import torch
from torch import nn
from b287_common import need
from b286_broadcast import BroadcastRefiner
from b282_model import tensor_hash


class JointModel(nn.Module):
    def __init__(self,reference,with_refiner=True):
        super().__init__();self.net=copy.deepcopy(reference);self.scale=reference.scale
        self.net.requires_grad_(True);self.net.gate.requires_grad_(False)
        self.refiner=BroadcastRefiner(True) if with_refiner else None
        for m in self.net.detector.modules():
            if isinstance(m,nn.modules.batchnorm._BatchNorm):m.requires_grad_(False)
        self.train(False)

    def train(self,mode=True):
        super().train(mode);self.net.gate.eval()
        for m in self.net.detector.modules():
            if isinstance(m,nn.modules.batchnorm._BatchNorm):m.eval()
        return self

    def prepared_forward(self,bank,unused=None,return_aux=False):
        with torch.no_grad():image,_=self.net.gate(bank)
        d=self.net.detector
        x=d.maxpool(d.relu(d.bn1(d.conv1(image))));x=d.layer2(d.layer1(x));aux={}
        if self.refiner is not None:
            delta,aux=self.refiner.components(x);x=x+delta
        x=d.layer4(d.layer3(x));z=d.fc(torch.flatten(d.avgpool(x),1))
        return (z,aux) if return_aux else z


@torch.inference_mode()
def initial_check(model,reference,bank):
    model.eval();reference.eval()
    difference=float((model.prepared_forward(bank)-reference.prepared_forward(bank)).abs().max())
    need(difference<=1e-6,'Joint candidate must initially equal unchanged B280 A1')
    shared=tensor_hash(model.net.state_dict());need(shared==tensor_hash(reference.state_dict()),'Source A1 tensors changed')
    simam=sum(type(m).__name__=='SimAM' for m in model.net.detector.modules());need(simam==8,'Keep all8 native SimAM')
    return dict(maxabs_logit_difference=difference,shared_A1_sha256=shared,original_SimAM_count=simam,
        refiner_sha256=tensor_hash(model.refiner.state_dict()) if model.refiner else None,
        extra_parameters=sum(p.numel() for p in model.refiner.parameters()) if model.refiner else 0,
        TFSE=True,LCBR=model.refiner is not None,CGCR=False,TFCG=False,Tail=False,
        position='after complete layer2; identical to the WVD LCBR factor',frontend_frozen=True)
