"""Load only original WVD ADN and its verified B284 matched continuation."""
import torch
from b286_common import need,read_json,fingerprint,digest_file,REFERENCE
import b284_common as previous
from b283_source import checked_checkpoint,PlainADN
from b282_source import SCENE_KEYS
from source_loader import load_frozen_file
from b286_model import Model


def load_sources(a,context):
    code=read_json(REFERENCE/'b283_reference/b282_reference/b280_release_sources.json')
    base_ct,state=checked_checkpoint(a.b280_run/'A0','PASS_B280_FULL_TRAIN_VAL_ONLY',code,'A0')
    cfg=base_ct['run_config']
    need(not cfg['factor_A_joint_SPWVD'] and not cfg['factor_B_TFCG_Tail'],'Use original WVD ADN A0')
    need(cfg['bank_sha256']==context['bc']['file_sha256'],'ADN/IQ bank differs')
    need((cfg['selected_rows']['train']['count'],cfg['selected_rows']['val']['count'])==(30000,5000),'Expected B28030k/5k original initialization')
    base=PlainADN().to(a.device).eval()
    base.load_state_dict(state['state_dict'],strict=True);del state
    ct,state=checked_checkpoint(a.b284_run/'ADN',previous.PASS,previous.code_hashes(),'ADN')
    continuation=ct['run_config']
    need(continuation['source_lineage']['checkpoints']['ADN']==base_ct['checkpoint_sha256'],'B284 ADN did not originate at this A0')
    need(continuation['input_image']=='original WVD' and not continuation['TFSE'] and not continuation['CGCR'] and
         not continuation['TFCG_used'] and not continuation['Tail_used'],'B284 reference must be plain ADN')
    need(continuation['bank_sha256']==context['bc']['file_sha256'],'B284 bank differs')
    need(continuation['device']==a.device.type and continuation['torch_version']==str(torch.__version__),
         'Use the same mpdnet-r10 PyTorch/device as B284 for matched continuation')
    baseline=Model(base,'ADN').to(a.device).eval()
    baseline.load_state_dict(state['state_dict'],strict=True);del state
    budget={k:continuation[k] for k in ('seed','epochs','batch','selected_rows','backbone_lr','new_module_lr','loss','weight_decay','optimizer')}
    need(budget['loss']=='CE only' and budget['epochs']==6 and budget['batch']==32 and
         (budget['selected_rows']['train']['count'],budget['selected_rows']['val']['count'])==(16000,5000),'Unexpected B284 continuation budget')
    folder=a.b284_run/'pd_scr_full'
    p=read_json(folder/'protocol_frozen.json');progress=read_json(folder/'progress.json')
    need(p['version']=='B284_TFSE_CGCR_FACTORIAL_SCORE_V1' and p['labels']==['ADN','TFSE','CGCR','FULL'],'Expected B284 full scene metadata')
    need(p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==progress['fingerprint'],'B284 protocol/progress identity differs')
    need(p['training_contracts']['ADN']==ct and p['base_contracts']['ADN']==base_ct,'B284 scores refer to other ADN weights')
    need(progress['completed']==dict(h0_cal=3000000,h0_audit=1000000,h1=37) and
         (p['h0_cal_n'],p['h0_audit_n'],p['h1_scenes_n'])==(3000000,1000000,1024),'B284 full scores incomplete')
    need(p['scene_fingerprint']==fingerprint({k:p[k] for k in SCENE_KEYS}) and p['scr_grid_db']==list(range(-24,13)),'B284 scenes/grid differs')
    generator=load_frozen_file('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
    need(p['generator_sha']==context['bc']['generator_sha256']==digest_file(generator.__file__) and
         p['master_seed']==context['bc']['seed'] and tuple(p['family_names'])==generator.TRAIN_FAMILIES,'Frozen scene generator differs')
    base.requires_grad_(False);baseline.requires_grad_(False)
    return dict(base=base,baseline=baseline,base_contract=base_ct,baseline_contract=ct,budget=budget,
                p=p,generator=generator,lineage=dict(B280_A0=base_ct['checkpoint_sha256'],B284_ADN=ct['checkpoint_sha256']))
