"""Immutable reference loading for B286; data lives only on the user's server."""
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REFERENCE=ROOT/'b284_reference'
sys.path.insert(0,str(REFERENCE))
import b284_common as old
from b271_data import need,read_json,write_json,digest_file,fingerprint,load_checkpoint

LABELS=('ADN','BGMSA','LCBR')
ARMS=('BGMSA','LCBR')
NAMES=dict(ADN='ADN (matched control, B284)',BGMSA='ADN + broadcast attention',LCBR='ADN + LCBR (proposed)')
FILES=dict(h0_cal='h0_cal_scores.npy',h0_audit='h0_audit_scores.npy',h1='dev_h1_scores.npy')
PASS='PASS_B286_BROADCAST_TRAIN_VAL_ONLY'


def validate_reference():
    for name,expected in read_json(ROOT/'b284_release_sources.json').items():
        need(digest_file(REFERENCE/name)==expected,'Embedded reference changed: '+name)
    old.validate_reference()


def code_hashes():
    return dict(B286={p.name:digest_file(p) for p in sorted(ROOT.glob('*.py'))},
                reference=digest_file(ROOT/'b284_release_sources.json'),
                provenance=digest_file(ROOT/'SOURCE_PROVENANCE.json'),
                third_party_license=digest_file(ROOT/'third_party/BGAI_LICENSE.txt'))
