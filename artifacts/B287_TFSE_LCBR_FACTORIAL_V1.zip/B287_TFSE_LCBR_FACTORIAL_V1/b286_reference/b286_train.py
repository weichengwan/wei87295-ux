"""CE-only medium continuation; two candidate modules, unchanged matched ADN."""
import gc
import time
import torch
import torch.nn.functional as F
from b286_common import need,read_json,write_json,fingerprint,digest_file,load_checkpoint,code_hashes,PASS
from b286_model import Model,initial_check
from b282_model import optimizer_for
from b282_train import better
from b284_train import evaluate
from b273_shared import atomic_save
from b273_statistics import save_csv


def snapshot(model):return {k:v.detach().cpu().clone() for k,v in model.state_dict().items()}


def diagnostics(model,images):
    with torch.inference_mode():
        _,aux=model.prepared_forward(images,return_aux=True)
    return {k:float(v) for k,v in aux.items()}


def train_arm(a,context,info,data,anchor,arm):
    folder=a.out_dir/arm;folder.mkdir(exist_ok=True)
    cfg=dict(version='B286_BROADCAST_TRAIN_V1',arm=arm,**info['budget'],source_lineage=info['lineage'],
        source_A0_initialization=True,matched_control='B284 ADN; reused unchanged',
        bank_sha256=context['bc']['file_sha256'],input_image='original WVD',
        original8SimAM=True,TFSE=False,CGCR=False,TFCG=False,Tail=False,
        position='after complete ADN layer2, before layer3',local_contrast_conditioning=arm=='LCBR',
        native_BN_affine_and_running_frozen=True,remaining_CNN_FC_trainable=True,
        selected_rows_verified=data.selection,
        selection='max VAL pAUC01 among VAL CE<=original A0 CE+0.01; CE tie-break; epoch0 eligible',
        code_sha256=code_hashes(),device=a.device.type,torch_version=str(torch.__version__),amp=False,tf32=False)
    fp=fingerprint(cfg);identity=dict(run_config=cfg,run_fingerprint=fp)
    manifest,best_path,last,contract_path=[folder/n for n in ('run_manifest.json','best.pt','last_epoch.pt','training_contract.json')]
    if manifest.exists():need(read_json(manifest)==identity,'Training identity changed; use another --out-dir')
    else:
        need(not any(folder.iterdir()),'Nonempty training folder without manifest');write_json(manifest,identity)
    if contract_path.exists():
        ct=read_json(contract_path)
        need(ct['status']==PASS and ct['run_fingerprint']==fp and digest_file(best_path)==ct['checkpoint_sha256'],'Completed candidate changed')
        print(arm+' complete; verified and skipped',flush=True);return ct
    torch.manual_seed(cfg['seed'])
    model=Model(info['base'],arm).to(a.device)
    images,_,_=data.fetch('train',slice(0,a.batch),a.device)
    initial=initial_check(model,info['base'],images)
    optimizer=optimizer_for(model,cfg['backbone_lr'],cfg['new_module_lr'])
    def state(epoch,metrics):
        return dict(state_dict=snapshot(model),epoch=epoch,val_metrics=metrics,run_config=cfg,run_fingerprint=fp)
    def commit(epoch,best,history):
        saved=state(epoch,history[-1]);saved.update(optimizer=optimizer.state_dict(),best_checkpoint=best,history=history,
            initialization=initial,anchor=anchor,torch_rng=torch.get_rng_state(),
            cuda_rng=torch.cuda.get_rng_state_all() if a.device.type=='cuda' else [])
        atomic_save(last,saved);atomic_save(best_path,best)
    if last.exists():
        saved=load_checkpoint(last)
        need(saved['run_config']==cfg and saved['run_fingerprint']==fp and saved['anchor']==anchor,'Resume identity differs')
        model.load_state_dict(saved['state_dict'],strict=True);optimizer.load_state_dict(saved['optimizer'])
        best=saved['best_checkpoint'];history=saved['history'];initial=saved['initialization'];start=saved['epoch']+1
        torch.set_rng_state(saved['torch_rng'])
        if a.device.type=='cuda':torch.cuda.set_rng_state_all(saved['cuda_rng'])
        atomic_save(best_path,best);del saved
    else:
        v=evaluate(model,data,a.device,a.batch)
        need(abs(v['val_ce']-anchor['val_ce'])<1e-6,'Initial full VAL differs from unchanged ADN A0')
        best=state(0,v);history=[dict(epoch=0,train_ce=None,**v,eligible=True,best_epoch=0,elapsed_s=0.)]
        commit(0,best,history);start=1
    print(f'B286 {arm}: original WVD; same B2846-epoch/16k budget; epochs {start}..{cfg["epochs"]}',flush=True)
    for epoch in range(start,cfg['epochs']+1):
        began=time.perf_counter();model.train();total=0.;seen=0
        for step,index in enumerate(context['b210'].indices(data.values['train'][1],epoch,a.batch,cfg['seed'])):
            image,_,y=data.fetch('train',index,a.device)
            optimizer.zero_grad(set_to_none=True)
            loss=F.cross_entropy(model.prepared_forward(image),y)
            need(torch.isfinite(loss),'Nonfinite CE');loss.backward();optimizer.step()
            total+=float(loss.detach())*len(y);seen+=len(y)
            if (step+1)%200==0:print(f'[{arm}] {epoch}/{cfg["epochs"]} TRAIN {seen:,}/{len(data.values["train"][1]):,}',flush=True)
        v=evaluate(model,data,a.device,a.batch);eligible,improved=better(v,best['val_metrics'],anchor)
        if improved:best=state(epoch,v)
        history.append(dict(epoch=epoch,train_ce=total/seen,**v,eligible=eligible,best_epoch=best['epoch'],elapsed_s=time.perf_counter()-began))
        commit(epoch,best,history);save_csv(folder/'train_val_history.csv',history)
        print(f'[{arm}] {epoch}/{cfg["epochs"]} VAL_CE={v["val_ce"]:.6f} pAUC01={v["val_pauc01"]:.6f} eligible={eligible} best={best["epoch"]} time={history[-1]["elapsed_s"]:.1f}s',flush=True)
    model.load_state_dict(best['state_dict'],strict=True)
    v=evaluate(model,data,a.device,a.batch)
    need(abs(v['val_ce']-best['val_metrics']['val_ce'])<1e-6,'Selected VAL replay differs')
    ct=dict(status=PASS,run_config=cfg,run_fingerprint=fp,checkpoint_sha256=digest_file(best_path),best_epoch=best['epoch'],
        initialization=initial,anchor_validation=anchor,selected_validation=v,module_diagnostics=diagnostics(model,images),
        CAL_AUDIT_DEV_used_for_training=False)
    write_json(contract_path,ct)
    del model,optimizer,best;gc.collect()
    if a.device.type=='cuda':torch.cuda.empty_cache()
    print(f'{PASS}; {arm}; selected epoch={ct["best_epoch"]}',flush=True)
    return ct


def preflight(a,info,data):
    anchor=evaluate(Model(info['base'],'ADN').to(a.device),data,a.device,a.batch)
    need(abs(anchor['val_ce']-info['base_contract']['selected_validation']['val_ce'])<1e-5,'B280 A0 VAL replay differs')
    baseline=evaluate(info['baseline'],data,a.device,a.batch)
    need(abs(baseline['val_ce']-info['baseline_contract']['selected_validation']['val_ce'])<1e-5,'B284 ADN VAL replay differs')
    image,_,y=data.fetch('train',slice(0,a.batch),a.device);checks=[]
    for arm in ('BGMSA','LCBR'):
        torch.manual_seed(info['budget']['seed']);model=Model(info['base'],arm).to(a.device)
        initial=initial_check(model,info['base'],image);optimizer=optimizer_for(model,1e-5,3e-4)
        model.train()
        if a.device.type=='cuda':torch.cuda.reset_peak_memory_stats(a.device)
        for _ in range(3):
            optimizer.zero_grad(set_to_none=True);loss=F.cross_entropy(model.prepared_forward(image),y)
            need(torch.isfinite(loss),'Nonfinite optimizer canary');loss.backward();optimizer.step()
        diagnostic=diagnostics(model,image)
        need(diagnostic['delta_abs_mean']>0,'Adapter failed to learn a residual')
        checks.append(dict(arm=arm,initialization=initial,three_discarded_optimizer_steps=True,diagnostics=diagnostic,
            peak_allocated_GiB=torch.cuda.max_memory_allocated(a.device)/1024**3 if a.device.type=='cuda' else None))
        print('Original ADN identity/optimizer canary passed: '+arm,flush=True)
        del model,optimizer,loss;gc.collect()
        if a.device.type=='cuda':torch.cuda.empty_cache()
    return anchor,dict(original_A0=anchor,B284_matched_control=baseline,checks=checks)
