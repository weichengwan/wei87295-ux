"""Frozen paired DEV, independent CAL/AUDIT; reuse only verified score prefixes."""
import time
import numpy as np
import torch
from b286_common import LABELS,FILES,need,read_json,write_json,fingerprint,digest_file
from b283_source import runtime_matches
from b283_score import make_iq
from b282_source import SCENE_KEYS
from source_loader import load_frozen_sources,load_frozen_file


@torch.inference_mode()
def fill_predictions(models,iq,missing,out,device,batch):
    need(iq.dtype==np.complex64 and iq.ndim==2 and iq.shape[1]==512,'Expected complex64 IQ512')
    need(out.shape==missing.shape==(len(iq),3) and missing.dtype==bool,'Invalid prediction mask')
    source,_,_=load_frozen_sources()
    for start in range(0,len(iq),batch):
        stop=min(start+batch,len(iq));mask=missing[start:stop]
        if not mask.any():continue
        x=torch.from_numpy(np.array(iq[start:stop],dtype=np.complex64,copy=True,order='C')).to(device)
        image=source.map_to_adn_input(source.wvd_base_map(x))
        for col,label in enumerate(LABELS):
            rows=np.flatnonzero(mask[:,col])
            if not len(rows):continue
            index=torch.as_tensor(rows,device=device,dtype=torch.long)
            z=models[label].prepared_forward(image.index_select(0,index))
            value=(z[:,1]-z[:,0]).double().cpu().numpy()
            need(np.isfinite(value).all(),'Nonfinite score: '+label);out[start+rows,col]=value
    need(np.isfinite(out).all(),'Unfilled score cells')
    return out


class Cache:
    def __init__(self):self.values={};self.records=[]
    def fill(self,split,start,stop,j=None):
        out=np.zeros((stop-start,3),dtype=np.float64);missing=np.ones(out.shape,dtype=bool)
        for col,label in enumerate(LABELS):
            v=self.values.get((label,split))
            if v is None:continue
            end=min(stop,v.shape[1] if split=='h1' else len(v))
            if end<=start:continue
            out[:end-start,col]=v[j,start:end] if split=='h1' else v[start:end]
            missing[:end-start,col]=False
        return out,missing


def collect_cache(a,info,contracts):
    cache=Cache()
    if a.recompute_scores:return cache
    # No score arrays are read until all candidate checkpoint selection ended.
    candidates=[(a.b284_run/'pd_scr_full',True)]
    if a.eval_size=='full':candidates.append((a.out_dir/'pd_scr_medium',False))
    for folder,is_old in candidates:
        if not (folder/'protocol_frozen.json').is_file():continue
        p=read_json(folder/'protocol_frozen.json');progress=read_json(folder/'progress.json')
        need(p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==progress['fingerprint'],'Cache protocol identity differs')
        if progress['completed']!=dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=37):continue
        need(all(p[k]==info['p'][k] for k in SCENE_KEYS if k not in ('h0_cal_n','h0_audit_n','h1_scenes_n')),'Cached scenes differ')
        if is_old:
            need(p['version']=='B284_TFSE_CGCR_FACTORIAL_SCORE_V1' and p['labels']==['ADN','TFSE','CGCR','FULL'] and
                 p['training_contracts']['ADN']==contracts['ADN'],'B284 cache weights differ')
            columns=[('ADN',0)]
        else:
            need(p['version']=='B286_BROADCAST_SCORE_V1' and p['labels']==list(LABELS) and
                 p['training_contracts']==contracts,'Medium cache weights differ')
            columns=list(zip(LABELS,range(3)))
        if not runtime_matches(p,a):continue
        for split,filename in FILES.items():
            path=folder/filename
            if not path.is_file():continue
            n=p['h1_scenes_n'] if split=='h1' else p[split+'_n']
            shape=(37,n,len(p['labels'])) if split=='h1' else (n,len(p['labels']))
            v=np.load(path,mmap_mode='r',allow_pickle=False)
            need(v.shape==shape and v.dtype==np.float64,'Cached score shape/type differs')
            record=dict(path=str(path),sha256=digest_file(path),protocol_sha256=digest_file(folder/'protocol_frozen.json'))
            for label,col in columns:
                value=v[:,:,col] if split=='h1' else v[:,col]
                need(np.isfinite(value).all(),'Nonfinite cached scores')
                existing=cache.values.get((label,split))
                if existing is not None:
                    count=min(n,existing.shape[1] if split=='h1' else len(existing))
                    old=existing[:,:count] if split=='h1' else existing[:count]
                    new=value[:,:count] if split=='h1' else value[:count]
                    need(np.array_equal(old,new),'Overlapping score prefixes disagree')
                    if (existing.shape[1] if split=='h1' else len(existing))>=n:continue
                cache.values[label,split]=value;cache.records.append(dict(label=label,split=split,**record))
    return cache


@torch.inference_mode()
def verify_cache(info,models,cache,device,batch):
    checks=[];p=info['p']
    for (label,split),value in cache.values.items():
        n=value.shape[1] if split=='h1' else len(value)
        starts=sorted(set([0,max(0,(n//batch-1)*batch)]));levels=[18,24,36] if split=='h1' else [None]
        col=LABELS.index(label);difference=0.
        for j in levels:
            for start in starts:
                stop=min(start+batch,n);iq=make_iq(info['generator'],p,split,np.arange(start,stop),j)
                mask=np.zeros((len(iq),3),bool);mask[:,col]=True
                actual=fill_predictions(models,iq,mask,np.zeros(mask.shape),device,batch)[:,col]
                expected=value[j,start:stop] if split=='h1' else value[start:stop]
                difference=max(difference,float(np.abs(actual-expected).max()))
                need(np.allclose(actual,expected,atol=5e-5,rtol=2e-5),'Cached score replay differs; inspect before --recompute-scores')
        checks.append(dict(label=label,split=split,maxabs_probe_difference=difference,replay_batches=len(starts)*len(levels),
                           cached_count=n,full_array_recomputed=False))
    return checks


def compute_chunk(info,models,p,cache,split,start,stop,device,batch,j=None):
    out,missing=cache.fill(split,start,stop,j);rows=np.flatnonzero(missing.any(1))
    if len(rows):
        iq=make_iq(info['generator'],p,split,start+rows,j)
        out[rows]=fill_predictions(models,iq,missing[rows],out[rows].copy(),device,batch)
    return out


def stream(a,info,models,p,cache):
    helper=load_frozen_file('r10_sim_stage_b216_pdscr_score_v1.py')
    progress=helper.init(a,p)
    for split,name in FILES.items():
        maximum=37 if split=='h1' else p[split+'_n'];done=progress['completed'][split]
        need(isinstance(done,int) and 0<=done<=maximum,'Invalid score progress')
        need(done==0 or (a.out_dir/name).is_file(),'Committed scores are missing; preserve existing results')
    for split in ('h0_cal','h0_audit'):
        total=p[split+'_n'];path=a.out_dir/FILES[split]
        array=helper.new_array(path,(total,3),path.exists());first=progress['completed'][split];began=time.perf_counter()
        for start in range(first,total,a.chunk):
            stop=min(start+a.chunk,total)
            array[start:stop]=compute_chunk(info,models,p,cache,split,start,stop,a.device,a.batch);array.flush()
            progress['completed'][split]=stop;write_json(a.out_dir/'progress.json',progress)
            if stop==total or stop%10000<a.chunk:
                rate=(stop-first)/max(time.perf_counter()-began,1e-6)
                print(f'[{split}] {stop:,}/{total:,}; {rate:.1f}/s; remaining~{(total-stop)/max(rate,1e-6)/60:.1f}min',flush=True)
        del array
    n=p['h1_scenes_n'];path=a.out_dir/FILES['h1'];array=helper.new_array(path,(37,n,3),path.exists())
    for j in range(progress['completed']['h1'],37):
        for start in range(0,n,a.chunk):
            stop=min(start+a.chunk,n);array[j,start:stop]=compute_chunk(info,models,p,cache,'h1',start,stop,a.device,a.batch,j)
        array.flush();progress['completed']['h1']=j+1;write_json(a.out_dir/'progress.json',progress)
        print(f'[dev_h1] SCR={p["scr_grid_db"][j]:+d} dB {j+1}/37',flush=True)
    del array
