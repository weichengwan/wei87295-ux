"""Verify old checkpoints/budgets; reuse only complete matching B283 scores."""
from pathlib import Path
import numpy as np
import torch
from b284_common import LABELS, FILES, NEW_ARMS, need, read_json, digest_file, fingerprint, load_checkpoint, code_hashes, PASS
from b283_source import checked_checkpoint, PlainADN, runtime_matches, CORE_IDENTITY
from b283_common import own_code_hashes as old_code_hashes
from b282_source import SCENE_KEYS
from b282_model import tensor_hash
from b282_model import make_a1, Candidate
from b282_train import PASS as OLD_PASS, code_hashes as old_training_hashes
from source_loader import load_frozen_file
from b284_common import REFERENCE
from b284_model import WVDArm


def load_references(a, context):
    # Metadata/weights only here: no old CAL/AUDIT/H1 score arrays are opened
    # before new TRAIN/VAL training and checkpoint selection have finished.
    code=read_json(REFERENCE/'b282_reference/b280_release_sources.json')
    contracts={};models={}
    for label,arm in [('ADN','A0'),('A1_frozen','A1')]:
        ct,state=checked_checkpoint(a.b280_run/arm,'PASS_B280_FULL_TRAIN_VAL_ONLY',code,arm)
        cfg=ct['run_config']
        need(cfg['bank_sha256']==context['bc']['file_sha256'] and not cfg['factor_B_TFCG_Tail'],'Unexpected B280 bank/Tail configuration')
        need(cfg['factor_A_joint_SPWVD']==(arm=='A1'),'Wrong B280 frontend')
        need((cfg['selected_rows']['train']['count'],cfg['selected_rows']['val']['count'])==(30000,5000),'Expected full B280 initial training')
        if arm=='A1':model=make_a1(state,a.device)
        else:
            model=PlainADN();model.load_state_dict(state['state_dict'],strict=True);model=model.to(a.device).eval()
        contracts[label]=ct;models[label]=model
        del state
    folder=a.b280_run/'pd_scr_full';p=read_json(folder/'protocol_frozen.json');progress=read_json(folder/'progress.json')
    need(p['version']=='B280_FULL_FACTORIAL_SCORE_V1' and p['labels']==['A0','A1','A2','A3'],'Expected original B280 full protocol')
    need(p['checkpoints'][:2]==[contracts['ADN'],contracts['A1_frozen']],'B280 source checkpoint metadata differs')
    need(p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==progress['fingerprint'],'B280 protocol fingerprint differs')
    need((p['h0_cal_n'],p['h0_audit_n'],p['h1_scenes_n'])==(3000000,1000000,1024) and p['scr_grid_db']==list(range(-24,13)),'Require original full scene protocol')
    need(progress['completed']==dict(h0_cal=3000000,h0_audit=1000000,h1=37),'Original B280 score metadata incomplete')
    need(p['scene_fingerprint']==fingerprint({k:p[k] for k in SCENE_KEYS}),'B280 scene fingerprint differs')
    generator=load_frozen_file('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
    need(p['generator_sha']==context['bc']['generator_sha256']==digest_file(generator.__file__),'Frozen scene generator differs')
    need(p['master_seed']==context['bc']['seed'] and tuple(p['family_names'])==generator.TRAIN_FAMILIES,'Scene seed/families differ')
    a1=contracts['A1_frozen']
    intrinsic=dict(A1_checkpoint_sha256=a1['checkpoint_sha256'],A1_run_fingerprint=a1['run_fingerprint'],
        source_protocol_sha256=digest_file(folder/'protocol_frozen.json'),source_selected_epoch=a1['best_epoch'],
        source_device=p['device'],source_torch_version=p.get('torch_version'))
    for arm in ('control','guided'):
        ct,state=checked_checkpoint(a.b282_run/arm,OLD_PASS,old_training_hashes(),arm)
        cfg=ct['run_config']
        need(cfg['bank_sha256']==context['bc']['file_sha256'] and cfg['scale']==models['A1_frozen'].scale,'B282 bank/scale differs')
        need({k:cfg['source_identity'][k] for k in CORE_IDENTITY}==intrinsic,'B282 arm came from another A1')
        model=Candidate(models['A1_frozen'],arm);model.load_state_dict(state['state_dict'],strict=True)
        models[arm]=model.to(a.device).eval();contracts[arm]=ct
        del state
    keys=('seed','epochs','batch','selected_rows','bank_sha256','scale','source_identity','backbone_lr','new_module_lr','loss','weight_decay','optimizer','code_sha256','device','torch_version')
    need(all(contracts['control']['run_config'][k]==contracts['guided']['run_config'][k] for k in keys),'Existing control/guided continuation budgets differ')
    need(contracts['control']['initialization']['shared_A1_sha256']==contracts['guided']['initialization']['shared_A1_sha256'],'Existing arms did not share A1 initialization')
    for model in models.values():model.requires_grad_(False)
    lineage=dict(A1=intrinsic,checkpoints={k:c['checkpoint_sha256'] for k,c in contracts.items()},training_fingerprints={k:c['run_fingerprint'] for k,c in contracts.items()})
    info=dict(models=models,contracts=contracts,p=p,generator=generator,lineage=lineage)
    control, guided = (info['contracts'][k]['run_config'] for k in ('control', 'guided'))
    need(control['loss'] == guided['loss'] == 'CE only', 'Expected CE-only B282 models')
    need(control['frontend_frozen'] and control['native_BN_affine_and_running_frozen'], 'Unexpected B282 fine-tuning policy')
    need(control['device'] == a.device.type and control['torch_version'] == str(torch.__version__),
         'Run in the same mpdnet-r10 device/PyTorch environment as B282 for matched continuation')
    basecfg = info['contracts']['ADN']['run_config']
    frontcfg = info['contracts']['A1_frozen']['run_config']
    for key in ('seed', 'epochs', 'batch', 'lr', 'weight_decay', 'optimizer', 'selected_rows', 'bank_sha256'):
        need(basecfg[key] == frontcfg[key], 'B280 A0/A1 initial training budgets differ: ' + key)
    info['budget'] = {k: control[k] for k in ('seed', 'epochs', 'batch', 'selected_rows', 'backbone_lr', 'new_module_lr', 'loss', 'weight_decay', 'optimizer')}
    info['base'] = info['models']['ADN']
    return info


class ScoreCache:
    def __init__(self):
        self.values = {}
        self.records = []

    def put(self, label, split, values, record):
        need(label in LABELS and split in FILES and values.dtype == np.float64, 'Invalid cached scores')
        expected_ndim = 2 if split == 'h1' else 1
        need(values.ndim == expected_ndim and values.size > 0 and np.isfinite(values).all(), 'Malformed/nonfinite cached column')
        if split == 'h1':
            need(values.shape[0] == 37, 'Expected37 cached H1 levels')
        self.values[label, split] = values
        self.records.append(dict(label=label, split=split, **record))

    def fill(self, split, start, stop, j=None):
        result = np.empty((stop-start, len(LABELS)), dtype='float64')
        missing = np.ones(result.shape, dtype=bool)
        for col, label in enumerate(LABELS):
            values = self.values.get((label, split))
            if values is None:
                continue
            count = values.shape[1] if split == 'h1' else len(values)
            end = min(stop, count)
            if end > start:
                result[:end-start, col] = values[j, start:end] if split == 'h1' else values[start:end]
                missing[:end-start, col] = False
        return result, missing


def collect_cache(a, info, metadata_only=False):
    cache = ScoreCache()
    folder = a.b283_run / 'pd_scr_full'
    if a.recompute_scores or not (folder / 'protocol_frozen.json').is_file():
        return cache
    p = read_json(folder / 'protocol_frozen.json')
    progress = read_json(folder / 'progress.json')
    need(p['version'] == 'B283_FULL_INCREMENTAL_SCORE_V1' and p['labels'] == ['A1_frozen', 'control', 'unguided', 'guided', 'ADN'], 'Unexpected B283 scoring identity')
    need(p['fingerprint'] == fingerprint({k:v for k,v in p.items() if k != 'fingerprint'}) == progress['fingerprint'], 'B283 fingerprint differs')
    need(progress['completed'] == dict(h0_cal=p['h0_cal_n'], h0_audit=p['h0_audit_n'], h1=37), 'B283 source scoring incomplete')
    need(all(p[k] == info['p'][k] for k in SCENE_KEYS), 'B283 scenes differ from frozen B280 protocol')
    need(p['source_lineage']['A1']==info['lineage']['A1'], 'B283 came from another A1')
    for label,ct in info['contracts'].items():
        need(p['training_contracts'][label]==ct and p['source_lineage']['checkpoints'][label]==ct['checkpoint_sha256'] and p['source_lineage']['training_fingerprints'][label]==ct['run_fingerprint'], 'B283 scores belong to different checkpoints: '+label)
    need(p['code_sha256'] == old_code_hashes(), 'B283 source-code identity differs')
    if not runtime_matches(p, a):
        print('B283 runtime differs; preserving arrays and recomputing all four score columns', flush=True)
        return cache
    if metadata_only:
        print('B283 cache metadata checked; raw evaluation scores are not read during training preflight', flush=True)
        return cache
    for split, filename in FILES.items():
        path = folder / filename
        if not path.is_file():
            print('No source score array for '+split+'; this split will be inferred', flush=True)
            continue
        n = p['h1_scenes_n'] if split == 'h1' else p[split+'_n']
        shape = (37, n, 5) if split == 'h1' else (n, 5)
        values = np.load(path, mmap_mode='r', allow_pickle=False)
        need(values.shape == shape and values.dtype == np.float64, 'Malformed B283 score array')
        record = dict(path=str(path.resolve()), sha256=digest_file(path), protocol_sha256=digest_file(folder/'protocol_frozen.json'))
        for label, col in [('TFSE', 1), ('FULL', 3)]:
            cache.put(label, split, values[:,:,col] if split == 'h1' else values[:,col], record)
    return cache


def load_new_models(a, info):
    contracts = dict(TFSE=info['contracts']['control'], FULL=info['contracts']['guided'])
    models = dict(TFSE=info['models']['control'], FULL=info['models']['guided'])
    for arm in NEW_ARMS:
        folder = a.out_dir / arm
        ct = read_json(folder/'training_contract.json')
        need(ct['status'] == PASS and ct['run_config']['arm'] == arm and ct['run_config']['code_sha256'] == code_hashes(), 'Incomplete/changed B284 arm: '+arm)
        need(ct['run_config']['source_lineage'] == info['lineage'], 'B284 source weights changed')
        path = folder/'best.pt'
        need(digest_file(path) == ct['checkpoint_sha256'], 'B284 checkpoint checksum differs')
        state = load_checkpoint(path)
        need(state['run_config'] == ct['run_config'] and state['run_fingerprint'] == ct['run_fingerprint'] == fingerprint(ct['run_config']) and state['epoch'] == ct['best_epoch'], 'B284 checkpoint internal identity differs')
        model = WVDArm(info['base'], arm)
        model.load_state_dict(state['state_dict'], strict=True)
        models[arm] = model.to(a.device).eval().requires_grad_(False)
        contracts[arm] = ct
    for label, ct in contracts.items():
        cfg = ct['run_config']
        b = info['budget']
        for key in ('seed', 'epochs', 'batch', 'selected_rows', 'backbone_lr', 'new_module_lr', 'loss', 'optimizer', 'weight_decay'):
            need(cfg[key] == b[key], 'Four-arm continuation budgets differ: '+label+' '+key)
    need(contracts['ADN']['initialization']['shared_A0_sha256'] == contracts['CGCR']['initialization']['shared_A0_sha256'], 'New WVD arms did not share initial A0 weights')
    need(contracts['CGCR']['initialization']['refiner_sha256'] == info['contracts']['guided']['initialization']['refiner_sha256'], 'CGCR initial expert weights differ between factor levels')
    return models, contracts
