"""Matched WVD continuation and complete CGCR-only training; CE and VAL only."""
import gc
import time
import numpy as np
import torch
import torch.nn.functional as F
from b284_common import PASS, NEW_ARMS, need, read_json, write_json, fingerprint, digest_file, load_checkpoint, code_hashes
from b284_model import WVDArm, initial_check
from b282_model import optimizer_for
from b282_train import better
from b273_shared import atomic_save, pauc
from b273_statistics import save_csv
from source_loader import load_frozen_file


@torch.inference_mode()
def evaluate(model, data, device, batch):
    model.eval()
    n = len(data.values['val'][1])
    total = 0.
    zs, ys = [], []
    for start in range(0, n, batch):
        image, guide, y = data.fetch('val', slice(start,min(start+batch,n)), device, model.refiner is not None)
        z = model.prepared_forward(image, guide)
        need(z.shape == (len(y),2) and torch.isfinite(z).all(), 'Invalid validation output')
        total += float(F.cross_entropy(z,y,reduction='sum'))
        zs.append((z[:,1]-z[:,0]).double().cpu().numpy())
        ys.append(y.cpu().numpy())
    z, y = np.concatenate(zs), np.concatenate(ys)
    return dict(val_ce=total/n, val_pauc01=pauc(z,y),
        val_auc=float(load_frozen_file('r10_sim_stage_b214_ablation_train_v1.py').auc(z,y)), n_val=n)


@torch.inference_mode()
def diagnostics(model, images, guide):
    model.eval()
    _, aux = model.prepared_forward(images, guide, True)
    if not aux:
        return dict(refiner=False)
    return dict(refiner=True, bandwidth_normalized_by_Nyquist=aux['bandwidth'].cpu().tolist(),
        high_expert_weight_mean=aux['weights'][:,0].mean(0).cpu().tolist(),
        low_expert_weight_mean=aux['weights'][:,1].mean(0).cpu().tolist(),
        mean_abs_feature_residual=float(aux['delta_abs_mean']), consistency_input_mean=float(aux['guide_mean']))


def snapshot(model):
    return {k:v.detach().cpu().clone() for k,v in model.state_dict().items()}


def config(a, info, data, arm):
    return dict(version='B284_WVD_FACTORIAL_TRAIN_V1', arm=arm, **info['budget'],
        bank_sha256=info['contracts']['ADN']['run_config']['bank_sha256'],
        scale=info['models']['A1_frozen'].scale, source_lineage=info['lineage'],
        selected_rows_verified=data.selection, input_image='original WVD', TFSE=False, CGCR=arm=='CGCR',
        fixed_guide='raw-IQ smoothing consistency from unchanged B280 smoothing_bank; not JointTFGate output' if arm=='CGCR' else None,
        all_eight_original_SimAM_retained=True, TFCG_used=False, Tail_used=False,
        frontend_learned_gate=False, native_BN_affine_and_running_frozen=True, remaining_CNN_FC_trainable=True,
        selection='same as B282: max VAL pAUC01 within source-A0 VAL CE+0.01; CE tie-break; epoch0 eligible',
        code_sha256=code_hashes(), device=a.device.type, torch_version=str(torch.__version__), amp=False, tf32=False)


def train_arm(a, context, info, data, anchor, arm):
    folder = a.out_dir/arm
    folder.mkdir(exist_ok=True)
    cfg = config(a, info, data, arm)
    fp = fingerprint(cfg)
    identity = dict(run_config=cfg, run_fingerprint=fp)
    manifest, best_path, latest, ct = [folder/name for name in ('run_manifest.json','best.pt','last_epoch.pt','training_contract.json')]
    if manifest.exists():
        need(read_json(manifest)==identity, 'Training settings changed; use a new output directory')
    else:
        need(not any(folder.iterdir()), 'Nonempty training folder without manifest')
        write_json(manifest,identity)
    if ct.exists():
        contract=read_json(ct)
        need(contract['status']==PASS and contract['run_fingerprint']==fp, 'Completed arm settings differ')
        if not best_path.exists() and latest.exists():
            saved=load_checkpoint(latest)
            need(saved['run_fingerprint']==fp,'Invalid recovery epoch')
            atomic_save(best_path,saved['best_checkpoint'])
        need(digest_file(best_path)==contract['checkpoint_sha256'], 'Completed model differs')
        print(arm+' complete; verified and skipped',flush=True)
        return contract
    torch.manual_seed(cfg['seed'])
    model=WVDArm(info['base'],arm).to(a.device)
    ix=slice(0,min(a.batch,len(data.values['train'][1])))
    images,guide,_=data.fetch('train',ix,a.device,True)
    initial=initial_check(model,info['base'],images,guide)
    need(initial['original_SimAM_count']==8, 'Original SimAM modules were not retained')
    if arm=='CGCR':
        need(initial['refiner_sha256']==info['contracts']['guided']['initialization']['refiner_sha256'], 'Initial CGCR weights differ from B282 guided')
    optimizer=optimizer_for(model,cfg['backbone_lr'],cfg['new_module_lr'])
    history=[]
    start=1
    def state(epoch,metrics):
        return dict(state_dict=snapshot(model),epoch=epoch,val_metrics=metrics,run_config=cfg,run_fingerprint=fp)
    def commit(epoch,best):
        value=state(epoch,history[-1])
        value.update(optimizer=optimizer.state_dict(),best_checkpoint=best,history=history,initialization=initial,anchor=anchor,
            torch_rng=torch.get_rng_state(),cuda_rng=torch.cuda.get_rng_state_all() if a.device.type=='cuda' else [])
        atomic_save(latest,value)
        atomic_save(best_path,best)
    if latest.exists():
        saved=load_checkpoint(latest)
        need(saved['run_config']==cfg and saved['run_fingerprint']==fp and saved['anchor']==anchor,'Resume identity differs')
        model.load_state_dict(saved['state_dict'],strict=True)
        optimizer.load_state_dict(saved['optimizer'])
        best=saved['best_checkpoint'];history=saved['history'];initial=saved['initialization'];start=saved['epoch']+1
        torch.set_rng_state(saved['torch_rng'])
        if a.device.type=='cuda':
            torch.cuda.set_rng_state_all(saved['cuda_rng'])
        atomic_save(best_path,best)
        del saved
    else:
        v=evaluate(model,data,a.device,a.batch)
        need(abs(v['val_ce']-anchor['val_ce'])<1e-6, 'Initial full VAL differs from source A0')
        best=state(0,v)
        history=[dict(epoch=0,train_ce=None,**v,eligible=True,best_epoch=0,elapsed_s=0.)]
        commit(0,best)
    print(f'B284 {arm}: WVD main image; TFSE disabled; epochs {start}..{cfg["epochs"]}; matched B282 continuation',flush=True)
    for epoch in range(start,cfg['epochs']+1):
        began=time.perf_counter();model.train();total=0.;seen=0
        for step,index in enumerate(context['b210'].indices(data.values['train'][1],epoch,a.batch,cfg['seed'])):
            image,consistency,y=data.fetch('train',index,a.device,model.refiner is not None)
            optimizer.zero_grad(set_to_none=True)
            loss=F.cross_entropy(model.prepared_forward(image,consistency),y)
            need(torch.isfinite(loss),'Nonfinite training CE')
            loss.backward();optimizer.step();total+=float(loss.detach())*len(y);seen+=len(y)
            if (step+1)%200==0:
                print(f'[{arm}] epoch {epoch}/{cfg["epochs"]} TRAIN {seen:,}/{len(data.values["train"][1]):,}',flush=True)
        v=evaluate(model,data,a.device,a.batch)
        eligible,improved=better(v,best['val_metrics'],anchor)
        if improved:
            best=state(epoch,v)
        history.append(dict(epoch=epoch,train_ce=total/seen,**v,eligible=eligible,best_epoch=best['epoch'],elapsed_s=time.perf_counter()-began))
        commit(epoch,best);save_csv(folder/'train_val_history.csv',history)
        print(f'[{arm}] {epoch}/{cfg["epochs"]} VAL_CE={v["val_ce"]:.6f} pAUC01={v["val_pauc01"]:.6f} eligible={eligible} best={best["epoch"]} time={history[-1]["elapsed_s"]:.1f}s',flush=True)
    model.load_state_dict(best['state_dict'],strict=True)
    replay=evaluate(model,data,a.device,a.batch)
    need(abs(replay['val_ce']-best['val_metrics']['val_ce'])<1e-6,'Selected checkpoint replay differs')
    contract=dict(status=PASS,run_config=cfg,run_fingerprint=fp,checkpoint_sha256=digest_file(best_path),best_epoch=best['epoch'],
        initialization=initial,anchor_validation=anchor,selected_validation=replay,
        module_diagnostics=diagnostics(model,images,guide),CAL_AUDIT_DEV_used_for_training=False,
        original_ADN_structure_retained=arm=='ADN', strict_no_learned_TFSE_frontend=True)
    write_json(ct,contract)
    del model,optimizer,best
    gc.collect()
    if a.device.type=='cuda':torch.cuda.empty_cache()
    print(f'{PASS}; {arm}; selected epoch={contract["best_epoch"]}',flush=True)
    return contract


def preflight(a, info, data):
    probe=WVDArm(info['base'],'ADN').to(a.device)
    anchor=evaluate(probe,data,a.device,a.batch)
    historical=info['contracts']['ADN']['selected_validation']['val_ce']
    need(abs(anchor['val_ce']-historical)<1e-5,'Original A0 full VAL replay differs; inspect WVD/cache/runtime')
    print(f'A0 full VAL replay passed: CE={anchor["val_ce"]:.8f}',flush=True)
    y=data.values['train'][1]
    ix=np.r_[np.flatnonzero(y==0)[:a.batch//2],np.flatnonzero(y==1)[:a.batch//2]]
    need(len(ix)==a.batch,'Not enough balanced TRAIN rows')
    images,guide,target=data.fetch('train',ix,a.device,True)
    checks=[]
    for arm in NEW_ARMS:
        torch.manual_seed(info['budget']['seed'])
        model=WVDArm(info['base'],arm).to(a.device)
        initial=initial_check(model,info['base'],images,guide)
        optimizer=optimizer_for(model,info['budget']['backbone_lr'],info['budget']['new_module_lr'])
        model.train()
        if a.device.type=='cuda':torch.cuda.reset_peak_memory_stats(a.device)
        for _ in range(3):
            optimizer.zero_grad(set_to_none=True)
            loss=F.cross_entropy(model.prepared_forward(images,guide),target)
            need(torch.isfinite(loss),'Nonfinite optimizer canary')
            loss.backward();optimizer.step()
        check=dict(arm=arm,initialization=initial,three_discarded_optimizer_steps=True,diagnostics=diagnostics(model,images,guide),
            peak_allocated_GiB=torch.cuda.max_memory_allocated(a.device)/1024**3 if a.device.type=='cuda' else None)
        if arm=='CGCR':
            need(check['diagnostics']['mean_abs_feature_residual']>0,'CGCR failed to learn in TRAIN canary')
            need(initial['refiner_sha256']==info['contracts']['guided']['initialization']['refiner_sha256'],'CGCR initialization differs')
        checks.append(check)
        del model,optimizer,loss
        gc.collect()
        if a.device.type=='cuda':torch.cuda.empty_cache()
        print('WVD optimizer canary passed: '+arm,flush=True)
    return anchor,dict(anchor=anchor,historical_A0_val_ce=historical,checks=checks)
