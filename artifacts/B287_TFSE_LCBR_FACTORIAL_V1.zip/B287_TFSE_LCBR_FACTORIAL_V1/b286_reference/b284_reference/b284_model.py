"""WVD input, original ADN/SimAM; optional unchanged B282 guided refiner."""
import copy
import torch
from torch import nn
from b284_common import need
from b282_module import CrossFrequencyRefiner
from b282_model import tensor_hash


class WVDArm(nn.Module):
    def __init__(self, reference, arm):
        super().__init__()
        need(arm in ('ADN', 'CGCR'), 'Unknown WVD arm')
        self.arm = arm
        self.net = copy.deepcopy(reference)
        # The source loader freezes references. New copies must learn again.
        self.net.requires_grad_(True)
        self.refiner = CrossFrequencyRefiner(True) if arm == 'CGCR' else None
        for m in self.net.detector.modules():
            if isinstance(m, nn.modules.batchnorm._BatchNorm):
                for p in m.parameters():
                    p.requires_grad_(False)
        self.train(False)

    def train(self, mode=True):
        super().train(mode)
        for m in self.net.detector.modules():
            if isinstance(m, nn.modules.batchnorm._BatchNorm):
                m.eval()
        return self

    def prepared_forward(self, images, consistency=None, return_aux=False):
        if self.refiner is None:
            result = self.net.prepared_forward(images)
            return (result, {}) if return_aux else result
        d = self.net.detector
        x = d.maxpool(d.relu(d.bn1(d.conv1(images))))
        x = d.layer1(x)
        x = d.layer2[0](x)
        block = d.layer2[1]
        identity = x
        x = block.relu(block.bn3(block.conv3(x)) + block.ver_bn(block.ver_conv(x)) + block.hor_bn(block.hor_conv(x)))
        x = block.simam(block.conv2(x))
        delta, aux = self.refiner.components(x, consistency)
        x = block.bn2(x + delta)
        if block.downsample is not None:
            identity = block.downsample(identity)
        x = block.relu(x + identity)
        x = d.layer4(d.layer3(x))
        result = d.fc(torch.flatten(d.avgpool(x), 1))
        return (result, aux) if return_aux else result


@torch.inference_mode()
def initial_check(model, reference, images, consistency):
    model.eval()
    reference.eval()
    expected = reference.prepared_forward(images)
    actual = model.prepared_forward(images, consistency)
    diff = float((actual - expected).abs().max())
    need(diff <= 1e-6, 'New WVD arm is not initially A0-identical')
    return dict(maxabs_logit_difference=diff,
        shared_A0_sha256=tensor_hash(model.net.state_dict()),
        refiner_sha256=tensor_hash(model.refiner.state_dict()) if model.refiner else None,
        parameters=sum(p.numel() for p in model.parameters()),
        trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),
        original_SimAM_count=sum(type(m).__name__ == 'SimAM' for m in model.modules()),
        TFSE_used=False, TFCG_used=False, Tail_used=False,
        main_image='original WVD', guide='fixed IQ-derived smoothing consistency' if model.refiner else None)
