"""Exactly four models; real raw Pd, both Pfas and transparent training budgets."""
from pathlib import Path
import shutil
import numpy as np
from b284_common import LABELS,NAMES,FACTORS,FILES,need,read_json,write_json,fingerprint
from b273_statistics import metrics_for,save_csv
from b284_plots import generate as paper_plot


def generate(folder):
    folder=Path(folder)
    p=read_json(folder/'protocol_frozen.json');progress=read_json(folder/'progress.json')
    need(p['version']=='B284_TFSE_CGCR_FACTORIAL_SCORE_V1' and p['labels']==list(LABELS),'Unexpected four-arm report')
    need(p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==progress['fingerprint'],'Score protocol identity differs')
    need(progress['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=37),'Scoring incomplete')
    arrays=[]
    for split,name in FILES.items():
        n=p['h1_scenes_n'] if split=='h1' else p[split+'_n']
        shape=(37,n,4) if split=='h1' else (n,4)
        value=np.load(folder/name,mmap_mode='r',allow_pickle=False)
        need(value.shape==shape and value.dtype==np.float64,'Invalid four-column array')
        arrays.append(value)
    curves=[];metrics=[];lookup={};table=[]
    for col,label in enumerate(LABELS):
        cv,mt=metrics_for(NAMES[label],arrays[0][:,col],arrays[1][:,col],arrays[2][:,:,col],p)
        curves+=cv;metrics+=mt
        for m in mt:lookup[label,m['nominal_pfa']]=m
    for nominal in p['nominal_pfas']:
        for label in LABELS:
            ct=p['training_contracts'][label];cfg=ct['run_config'];front,refine=FACTORS[label]
            source=p['base_contracts']['ADN' if label in ('ADN','CGCR') else 'A1_frozen']
            table.append(dict(group=label,TFSE=front,CGCR=refine,
                initial_training_rows=source['run_config']['selected_rows']['train']['count'],
                initial_training_budget_epochs=source['run_config']['epochs'],initial_selected_epoch=source['best_epoch'],
                continuation_training_rows=cfg['selected_rows']['train']['count'],continuation_budget_epochs=cfg['epochs'],
                continuation_selected_epoch=ct['best_epoch'],checkpoint_sha256=ct['checkpoint_sha256'],
                **lookup[label,nominal]))
    comparisons=[]
    for nominal in p['nominal_pfas']:
        for candidate,reference,scope in [('TFSE','ADN','TFSE without CGCR'),('CGCR','ADN','CGCR without TFSE'),
            ('FULL','TFSE','CGCR with TFSE'),('FULL','CGCR','TFSE with CGCR'),('FULL','ADN','Complete method')]:
            c,r=lookup[candidate,nominal],lookup[reference,nominal]
            delta=lambda key:None if c[key] is None or r[key] is None else c[key]-r[key]
            comparisons.append(dict(candidate=NAMES[candidate],reference=NAMES[reference],contrast=scope,nominal_pfa=nominal,
                delta_D80_db=delta('D80_db'),delta_D90_db=delta('D90_db'),pd_at_0_gain_pp=100*delta('pd_at_0'),
                candidate_false_alarms=c['audit_false_alarms'],reference_false_alarms=r['audit_false_alarms'],negative_delta_means_left=True))
    for name,rows in [('b284_curves.csv',curves),('b284_metrics.csv',metrics),('b284_ablation_table.csv',table),('b284_comparisons.csv',comparisons)]:
        save_csv(folder/name,rows)
    fmt=lambda v:'NA' if v is None else f'{v:.3f}'
    text='# TFSE x CGCR: complete four-cell ablation\n\n'
    text+='ADN retains the original WVD/ACB/SimAM/CE architecture; its matched continuation is used. TFSE-only and FULL reuse the existing B282 control/guided models. CGCR-only uses a fixed IQ-derived consistency descriptor while the classifier image remains WVD.\n\n'
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    for nominal in p['nominal_pfas']:
        selected=[r for r in table if r['nominal_pfa']==nominal]
        text+=f'Nominal Pfa={nominal:g}\n\n|Model|TFSE|CGCR|D80/dB|D90/dB|H0 false alarms|\n|---|---|---|---|---|---|\n'
        for r in selected:
            text+=f'|{r["method"]}|{int(r["TFSE"])}|{int(r["CGCR"])}|{fmt(r["D80_db"])}|{fmt(r["D90_db"])}|{r["audit_false_alarms"]}/{r["audit_n"]:,}|\n'
        text+='\n'
        out=folder/'figures'/f'pfa_{nominal:.0e}'
        manifest=paper_plot(folder/'b284_curves.csv',out,ours=NAMES['FULL'],nominal=nominal,metrics=folder/'b284_metrics.csv')
        need(len(manifest['styles'])==4,'Main plot must contain exactly four methods')
        for ext in ('pdf','png','svg'):
            shutil.copyfile(out/f'b284_curves_paper_pd_pfa_{nominal:.0e}.{ext}',folder/'figures'/f'b284_pd_scr_pfa_{nominal:.0e}.{ext}')
        fig,ax=plt.subplots(figsize=(10,2.6));ax.axis('off')
        values=[[r['method'],str(int(r['TFSE'])),str(int(r['CGCR'])),fmt(r['D80_db']),fmt(r['D90_db']),f'{r["audit_false_alarms"]}/{r["audit_n"]:,}'] for r in selected]
        t=ax.table(cellText=values,colLabels=['Model','TFSE','CGCR','D80/dB','D90/dB','H0 false alarms'],cellLoc='center',loc='center',colWidths=[.36,.08,.08,.12,.12,.24])
        t.auto_set_font_size(False);t.set_fontsize(8);t.scale(1,1.5)
        ax.set_title(f'Four-model ablation | nominal Pfa={nominal:g}')
        for ext in ('pdf','png'):fig.savefig(folder/f'b284_ablation_table_pfa_{nominal:.0e}.{ext}',dpi=300,bbox_inches='tight')
        plt.close(fig)
    text+='Matched maximum training budgets do not imply identical selected epochs or initial functions. A0/A1 are separately VAL-selected base models. Repeatedly exposed DEV is not independent final TEST. Own CAL thresholds give matched nominal Pfa; report independent actual Pfa. No curve is synthesized, shifted or smoothed.\n'
    (folder/'b284_ablation_table.md').write_text(text)
    report=dict(status='PASS_B284_FOUR_MODEL_REPORT',strict_2x2_factorial=True,labels=list(LABELS),names=NAMES,
        factors={k:list(v) for k,v in FACTORS.items()},metrics=metrics,comparisons=comparisons,table=table,
        reused_models=['B282 control as TFSE','B282 guided as FULL'],trained_WVD_arms=['ADN','CGCR'],
        matched_maximum_phase_budgets=True,independent_final=False,equal_actual_Pfa_established=False,
        source_Pd_unchanged=True,smoothing=False,curve_shifting=False,novelty_or_gain_guaranteed=False)
    write_json(folder/'b284_report.json',report)
    for r in comparisons:
        print(f'Pfa={r["nominal_pfa"]:g} {r["candidate"]} vs {r["reference"]}: delta_D90={r["delta_D90_db"]}; H0 FP={r["candidate_false_alarms"]} vs {r["reference_false_alarms"]}',flush=True)
    print('PASS_B284_FOUR_MODELS_COMPLETE: '+str(folder),flush=True)
    return report
