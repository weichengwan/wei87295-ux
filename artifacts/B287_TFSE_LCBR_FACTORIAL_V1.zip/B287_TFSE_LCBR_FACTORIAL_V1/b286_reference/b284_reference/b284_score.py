"""Four factorial cells, frozen scenes, old TFSE/FULL score reuse, resumable."""
import time
import numpy as np
import torch
from b284_common import LABELS, FILES, need, write_json
from b283_score import make_iq
from b280_frontend import smoothing_bank
from source_loader import load_frozen_sources, load_frozen_file


@torch.inference_mode()
def fill_predictions(models, iq, missing, out, device, batch):
    need(iq.dtype==np.complex64 and iq.ndim==2 and iq.shape[1]==512, 'Expected IQ512 complex64')
    need(out.shape==missing.shape==(len(iq),4) and missing.dtype==bool, 'Invalid four-model prediction mask')
    source,_,_=load_frozen_sources()
    for start in range(0,len(iq),batch):
        stop=min(start+batch,len(iq));mask=missing[start:stop]
        if not mask.any():continue
        x=torch.from_numpy(np.array(iq[start:stop],dtype=np.complex64,copy=True,order='C')).to(device)
        # TFSE disabled means original WVD is the classifier image.
        wvd=source.map_to_adn_input(source.wvd_base_map(x)) if mask[:,[0,2]].any() else None
        bank=smoothing_bank(x,models['TFSE'].scale) if mask[:,1:].any() else None
        for col,label in enumerate(LABELS):
            ix=np.flatnonzero(mask[:,col])
            if not len(ix):continue
            selected=torch.as_tensor(ix,device=device,dtype=torch.long)
            if label in ('ADN','CGCR'):
                guide=bank[:,3:4].index_select(0,selected) if label=='CGCR' else None
                z=models[label].prepared_forward(wvd.index_select(0,selected),guide)
            else:
                z=models[label].prepared_forward(bank.index_select(0,selected))
            values=(z[:,1]-z[:,0]).double().cpu().numpy()
            need(np.isfinite(values).all(),'Nonfinite score: '+label)
            out[start+ix,col]=values
    need(np.isfinite(out).all(),'Unfilled/nonfinite score cell')
    return out


def compute_chunk(info,p,cache,split,start,stop,device,batch,j=None):
    out,missing=cache.fill(split,start,stop,j)
    rows=np.flatnonzero(missing.any(1))
    if len(rows):
        iq=make_iq(info['generator'],p,split,start+rows,j)
        out[rows]=fill_predictions(info['models'],iq,missing[rows],out[rows].copy(),device,batch)
    return out,int((~missing).sum()),int(missing.sum())


@torch.inference_mode()
def verify_cache(info,cache,device,batch):
    p=info['p'];checks=[]
    for (label,split),value in cache.values.items():
        count=value.shape[1] if split=='h1' else len(value)
        starts=sorted(set([0,max(0,(count//batch-1)*batch)]))
        levels=[18,24,36] if split=='h1' else [None]
        col=LABELS.index(label);maxdiff=0.
        for j in levels:
            for start in starts:
                stop=min(start+batch,count)
                iq=make_iq(info['generator'],p,split,np.arange(start,stop),j)
                missing=np.zeros((len(iq),4),bool);missing[:,col]=True
                actual=fill_predictions(info['models'],iq,missing,np.zeros(missing.shape),device,batch)[:,col]
                expected=value[j,start:stop] if split=='h1' else value[start:stop]
                maxdiff=max(maxdiff,float(np.max(np.abs(actual-expected))))
                need(np.allclose(actual,expected,atol=5e-5,rtol=2e-5), 'B283 score replay differs: '+label+' '+split)
        checks.append(dict(label=label,split=split,cached_count=count,maxabs_probe_difference=maxdiff,
            replay_batches=len(starts)*len(levels),full_array_recomputed=False))
    print(f'B283 cached TFSE/FULL replay passed: {len(checks)} columns',flush=True)
    return checks


def stream(a,p,info,cache):
    helper=load_frozen_file('r10_sim_stage_b216_pdscr_score_v1.py')
    progress=helper.init(a,p)
    for split,name in FILES.items():
        total=37 if split=='h1' else p[split+'_n'];done=progress['completed'][split]
        need(isinstance(done,int) and 0<=done<=total,'Invalid score progress')
        need(done==0 or (a.out_dir/name).is_file(),'Committed score array is missing; preserve output and inspect')
    for split in ('h0_cal','h0_audit'):
        total=p[split+'_n'];path=a.out_dir/FILES[split]
        array=helper.new_array(path,(total,4),path.exists())
        first=progress['completed'][split];began=time.perf_counter();computed=reused=0
        for start in range(first,total,a.chunk):
            stop=min(start+a.chunk,total)
            value,r,c=compute_chunk(info,p,cache,split,start,stop,a.device,a.batch)
            array[start:stop]=value;array.flush();reused+=r;computed+=c
            progress['completed'][split]=stop;write_json(a.out_dir/'progress.json',progress)
            if stop==total or stop%10000<a.chunk:
                rate=(stop-first)/max(time.perf_counter()-began,1e-6)
                print(f'[{split}] {stop:,}/{total:,}; {rate:.1f} scenes/s; remaining~{(total-stop)/max(rate,1e-6)/60:.1f}min; reused_cells={reused:,}; inferred_cells={computed:,}',flush=True)
        del array
    path=a.out_dir/FILES['h1'];ns=p['h1_scenes_n']
    array=helper.new_array(path,(37,ns,4),path.exists())
    for j in range(progress['completed']['h1'],37):
        for start in range(0,ns,a.chunk):
            stop=min(start+a.chunk,ns)
            array[j,start:stop]=compute_chunk(info,p,cache,'h1',start,stop,a.device,a.batch,j)[0]
        array.flush();progress['completed']['h1']=j+1;write_json(a.out_dir/'progress.json',progress)
        print(f'[dev_h1] SCR={p["scr_grid_db"][j]:+d} dB {j+1}/37',flush=True)
    del array
