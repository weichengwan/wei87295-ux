"""Full frozen TRAIN/VAL; verified read-only WVD cache reuse or own rebuild."""
import shutil
from pathlib import Path
from types import SimpleNamespace
import h5py
import numpy as np
import torch
from b271_data import digest_file,fingerprint,need,read_json,write_json
from b274_data import Data
from b280_frontend import smoothing_bank
from source_loader import load_frozen_sources


def scale_for(out,context,data,device,batch):
    path=out/'train_scale.json'
    identity=dict(bank_sha256=context['bc']['file_sha256'],selected_rows=data.selection,
        method='q99 log1p(abs(SPWVD time5)); first256 TRAIN rows only',
        frontend_sha256=digest_file(Path(__file__).with_name('legacy_tf_recovered.py')))
    if path.exists():
        value=read_json(path);need(value['identity']==identity and value['fingerprint']==fingerprint(identity),'TRAIN scale identity differs')
        need(np.isfinite(value['scale']) and value['scale']>1e-4,'Invalid stored TRAIN scale');return value['scale']
    values=[];n=min(256,len(data.values['train'][1]))
    for start in range(0,n,batch):
        iq,_=data.fetch('train',slice(start,min(start+batch,n)),device)
        values.append(smoothing_bank(iq,1.)[:,1].cpu().numpy().ravel())
    scale=float(np.quantile(np.concatenate(values),.99));need(np.isfinite(scale) and scale>1e-4,'Degenerate TRAIN scale')
    write_json(path,dict(identity=identity,fingerprint=fingerprint(identity),scale=scale));return scale


def verify_cache(directory,context,data,device):
    b=context['b210'];directory=Path(directory);path=directory/b.CACHE_H5
    c=read_json(directory/b.CACHE_CT)
    need(c['status']==b.PASS_CACHE and c['bank_sha256']==context['bc']['file_sha256'] and
         c['source_sha256']==b.SOURCE_SHA and c['splits']==['train','val'] and
         c['h0_opened'] is False and c['dev_h1_opened'] is False,'WVD cache protocol differs')
    print('Verifying WVD cache SHA256: '+str(path),flush=True)
    need(digest_file(path)==c['wvd_cache_sha256'],'WVD cache checksum differs')
    source,_,_=load_frozen_sources()
    with h5py.File(path,'r') as h:
        need(set(h.keys())=={'train','val'},'Unexpected WVD cache splits')
        for split in ('train','val'):
            iq,y=data.values[split];d=h[split]['wvd']
            need(d.shape==(len(y),128,128) and d.dtype==np.dtype('float32') and np.array_equal(h[split]['label'][:],y),'WVD cache shape/order differs')
            ix=np.array([0,len(y)//2,len(y)-1]);x=torch.from_numpy(np.ascontiguousarray(iq[ix])).to(device)
            with torch.no_grad():expected=source.wvd_base_map(x).cpu().numpy()
            need(np.allclose(b.h5_rows(d,ix),expected,atol=2e-5,rtol=1e-5),'WVD cache TRAIN/VAL replay differs')
    return dict(path=str(path.resolve()),sha256=c['wvd_cache_sha256'],bank_sha256=c['bank_sha256'],
                source_sha256=c['source_sha256'],replay_rows_per_split=3)


def cache_for(a,context,data):
    selection=a.out_dir/'wvd_cache_selection.json'
    if selection.exists():
        value=read_json(selection);actual=verify_cache(Path(value['path']).parent,context,data,a.device)
        need(value==actual,'Committed WVD cache identity changed');return Path(value['path'])
    choices=[a.cache_dir] if a.cache_dir else [a.root/'output_sim_r10_b270_wvd_rebuilt_v1',a.root/'output_sim_r10_b210_30k_5k_wvd_cache_v1']
    for folder in choices:
        if not folder or not (folder/context['b210'].CACHE_CT).is_file():continue
        try:value=verify_cache(folder,context,data,a.device)
        except (RuntimeError,KeyError,OSError) as exc:
            if a.cache_dir:raise
            print('Preserving unusable old cache; own cache will be used: '+str(exc),flush=True);continue
        write_json(selection,value);return Path(value['path'])
    own=a.out_dir/'wvd_train_val';own.mkdir(exist_ok=True);b=context['b210']
    if not (own/b.CACHE_CT).exists():
        need(shutil.disk_usage(a.out_dir).free>=4*1024**3,'Need4GiB free for own WVD cache and checkpoints')
        # The frozen implementation never opens H0 or DEV. Existing partial
        # files are preserved; no automatic deletion or fallback to pilot data.
        source,_,_=load_frozen_sources()
        args=SimpleNamespace(device_resolved=a.device,wvd_batch=a.batch,bank_dir=context['bank_dir'])
        b.cache_source(source,context['bank_path'],own,args,context['bc'])
    value=verify_cache(own,context,data,a.device);write_json(selection,value);return Path(value['path'])


class PreparedData:
    def __init__(self,data,cache,scale,joint):
        self.raw=data;self.values=data.values;self.selection=data.selection;self.scale=scale;self.joint=joint
        self.cache=h5py.File(cache,'r') if not joint else None
    def fetch(self,split,index,device):
        iq,y=self.raw.fetch(split,index,device)
        if self.joint:return smoothing_bank(iq,self.scale),y
        source,_,_=load_frozen_sources()
        from b273_shared import rows
        ix=np.arange(len(self.values[split][1]))[index]
        x=torch.from_numpy(rows(self.cache[split]['wvd'],ix)).to(device)
        return source.map_to_adn_input(x),y
    def close(self):
        if self.cache is not None:self.cache.close()
