"""Train only two missing WVD arms, reuse two TFSE arms, plot exactly four."""
import argparse
import gc
import shutil
from pathlib import Path
from types import SimpleNamespace
import torch
from b284_common import ROOT,LABELS,NAMES,FACTORS,NEW_ARMS,need,read_json,write_json,fingerprint,code_hashes,validate_reference
from b271_data import device_for
from b273_shared import setup
from b274_data import resolve
from b283_run import acquire
from b282_source import SCENE_KEYS
from b284_source import load_references,collect_cache,load_new_models
from b284_train import train_arm,preflight
from b284_data import prepare
from b284_score import verify_cache,stream


def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=ROOT.parent)
    for key in ('b280-run','b282-run','b283-run','out-dir','bank-dir','cache-dir'):
        p.add_argument('--'+key,type=Path)
    p.add_argument('--stage',choices=('all','preflight','train','score','report'),default='all')
    p.add_argument('--eval-size',choices=('medium','full'),default='full')
    p.add_argument('--batch',type=int,default=32);p.add_argument('--chunk',type=int,default=512)
    p.add_argument('--device',choices=('cuda','cpu'),default='cuda');p.add_argument('--cpu-threads',type=int,default=4)
    p.add_argument('--wait-for-gpu',action='store_true');p.add_argument('--recompute-scores',action='store_true')
    a=p.parse_args(argv);a.root=a.root.resolve()
    for name,default in [('b280_run','output_b280_full_ablation_v1'),('b282_run','output_b282_a1_cfexpert_v1'),('b283_run','output_b283_tfse_cgcr_full_v1'),('out_dir','output_b284_tfse_cgcr_factorial_v1')]:
        setattr(a,name,(getattr(a,name) or a.root/default).resolve())
    need(a.root.is_dir() and a.root in a.out_dir.parents,'Use a new output directory inside project root')
    for source in (a.b280_run,a.b282_run,a.b283_run):
        need(a.out_dir!=source and source not in a.out_dir.parents and a.out_dir not in source.parents,'Output overlaps source results')
    need(a.batch==32 and a.chunk>=32 and a.chunk%32==0 and a.cpu_threads>0,'Use batch32 and chunk multiple of32')
    a.device=device_for(a.device)
    return a


def main(argv=None):
    a=cli(argv);setup(a.cpu_threads);validate_reference()
    score_dir=a.out_dir/('pd_scr_'+a.eval_size)
    if a.stage=='report':
        from b284_report import generate
        return generate(score_dir)
    print(f'B284 TFSE x CGCR four-model ablation | stage={a.stage} | eval={a.eval_size} | output={a.out_dir}',flush=True)
    with (a.root/'codex_b271_night.lock').open('a') as lock:
        acquire(lock,a.wait_for_gpu)
        context=resolve(a.root,a.bank_dir)
        info=load_references(a,context)
        collect_cache(a,info,metadata_only=True)
        identity=dict(version='B284_TFSE_CGCR_FACTORIAL_V1',source_lineage=info['lineage'],budget=info['budget'],
            code_sha256=code_hashes(),device=a.device.type,torch_version=str(torch.__version__))
        a.out_dir.mkdir(exist_ok=True)
        manifest=a.out_dir/'run_manifest.json'
        if manifest.exists():
            need(read_json(manifest)==identity,'Training source/settings changed; preserve results and use another --out-dir')
        else:
            need(not any(a.out_dir.iterdir()),'Nonempty output without run manifest')
            write_json(manifest,identity)
        print('Reuse B282 control/guided without training; new WVD groups inherit the exact same continuation budget.',flush=True)
        if a.stage in ('all','train','preflight'):
            need(shutil.disk_usage(a.out_dir).free>=2*1024**3,'Require2GiB free for two new training checkpoints; keep old results')
            data=prepare(a,context,info)
            try:
                probe_path=a.out_dir/'preflight.json'
                if probe_path.exists():
                    probe=read_json(probe_path)
                    need(probe['run_fingerprint']==fingerprint(identity),'Preflight source changed')
                    anchor=probe['result']['anchor']
                else:
                    anchor,probe=preflight(a,info,data)
                    write_json(probe_path,dict(run_fingerprint=fingerprint(identity),result=probe))
                if a.stage=='preflight':return
                for arm in NEW_ARMS:
                    train_arm(a,context,info,data,anchor,arm)
            finally:
                data.close()
            if a.stage=='train':return
        models,contracts=load_new_models(a,info)
        score_info=dict(info,models=models)
        cache=collect_cache(a,info)
        scene={k:info['p'][k] for k in SCENE_KEYS}
        if a.eval_size=='medium':scene.update(h0_cal_n=300000,h0_audit_n=200000,h1_scenes_n=512)
        p=dict(version='B284_TFSE_CGCR_FACTORIAL_SCORE_V1',**scene,scene_fingerprint=fingerprint(scene),
            labels=list(LABELS),names=NAMES,factors={k:list(v) for k,v in FACTORS.items()},ours_label='FULL',
            nominal_pfas=[1e-4,1e-5] if a.eval_size=='full' else [1e-4],
            training_contracts=contracts,base_contracts={k:info['contracts'][k] for k in ('ADN','A1_frozen')},
            source_lineage=info['lineage'],score_cache_sources=cache.records,code_sha256=code_hashes(),
            batch=a.batch,chunk=a.chunk,device=a.device.type,torch_version=str(torch.__version__),amp=False,tf32=False,
            score_definition='float64(float32 logit1 - float32 logit0)',strict_decision='score > own H0 CAL threshold',
            strict_2x2_factorial=True,matched_maximum_phase_budgets=True,independent_final=False,
            no_TFSE_definition='Original WVD classifier image; no learned JointTFGate. CGCR may independently calculate its fixed IQ-derived consistency descriptor.',
            scope='Paired exposed SIM-R10 DEV; two new WVD continuation arms and unchanged B282 TFSE/control/guided weights; not independent TEST')
        p['fingerprint']=fingerprint(p)
        # Streaming commits are also checked by the frozen init() implementation.
        numeric=a.out_dir/('cache_numeric_probe_'+a.eval_size+'.json')
        if numeric.exists():need(read_json(numeric)['protocol_fingerprint']==p['fingerprint'],'Cache replay settings changed')
        else:write_json(numeric,dict(protocol_fingerprint=p['fingerprint'],checks=verify_cache(score_info,cache,a.device,a.batch)))
        need(shutil.disk_usage(a.out_dir).free>=256*1024**2,'Require256MiB free for score arrays/reports')
        args=SimpleNamespace(out_dir=score_dir,batch=a.batch,chunk=a.chunk,device=a.device)
        print(f'Exactly4 models: CAL={p["h0_cal_n"]:,}; AUDIT={p["h0_audit_n"]:,}; H1={p["h1_scenes_n"]}x37; Pfa={p["nominal_pfas"]}',flush=True)
        stream(args,p,score_info,cache)
        del score_info,info,models
        gc.collect()
        if a.device.type=='cuda':torch.cuda.empty_cache()
        from b284_report import generate
        return generate(score_dir)


if __name__=='__main__':main()
