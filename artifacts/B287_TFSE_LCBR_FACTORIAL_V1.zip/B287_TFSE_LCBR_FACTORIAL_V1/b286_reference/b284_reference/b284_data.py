"""Exact B282 TRAIN/VAL rows; immutable full WVD cache, no H0 evaluation data."""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import h5py
import numpy as np
import torch
from b284_common import need, read_json
from b274_data import Data
from b273_shared import subset_indices, rows
from b280_frontend import smoothing_bank
from source_loader import load_frozen_sources
from b280_cache_reference import cache_for


class PreparedData:
    def __init__(self, raw, context, cache, seed, scale):
        self.raw = raw
        self.values = raw.values
        self.selection = raw.selection
        self.scale = scale
        self.cache = h5py.File(cache, 'r')
        self.original_rows = {}
        with h5py.File(context['bank_path'], 'r') as bank:
            for split, offset in [('train', 27101), ('val', 27102)]:
                labels = bank[split]['label'][:].astype('int64')
                families = bank[split]['family_index'][:] if 'family_index' in bank[split] else None
                chosen = subset_indices(labels, families, len(raw.values[split][1]), seed+offset)
                recorded = hashlib.sha256(chosen.astype('<i8').tobytes()).hexdigest()
                need(recorded == raw.selection[split]['row_indices_sha256'], 'WVD rows do not match B282 subset')
                need(np.array_equal(self.cache[split]['label'][:], labels), 'WVD/IQ label order differs')
                self.original_rows[split] = chosen

    def fetch(self, split, index, device, with_guide=False):
        source, _, _ = load_frozen_sources()
        ix = np.arange(len(self.values[split][1]))[index]
        original = self.original_rows[split][ix]
        base = torch.from_numpy(rows(self.cache[split]['wvd'], original)).to(device)
        image = source.map_to_adn_input(base)
        # This is a fixed descriptor from IQ, not a learned TFSE image.
        if with_guide:
            iq, y = self.raw.fetch(split, index, device)
            consistency = smoothing_bank(iq, self.scale)[:, 3:4]
        else:
            y = torch.from_numpy(np.ascontiguousarray(self.values[split][1][index])).to(device)
            consistency = None
        return image, consistency, y

    def close(self):
        self.cache.close()


def prepare(a, context, info):
    budget = info['budget']
    raw = Data(context, budget['selected_rows']['train']['count'], budget['selected_rows']['val']['count'], budget['seed'])
    need(raw.selection == budget['selected_rows'], 'TRAIN/VAL rows differ from existing B282 continuation')
    # Verify all35k cached labels and boundary samples, not only the subset.
    with h5py.File(context['bank_path'], 'r') as bank:
        meta = SimpleNamespace(values={s:(bank[s]['iq'], bank[s]['label'][:].astype('int64')) for s in ('train','val')})
        explicit = a.cache_dir
        old_selection = a.b280_run/'wvd_cache_selection.json'
        if explicit is None and old_selection.is_file():
            candidate = Path(read_json(old_selection)['path'])
            if candidate.is_file():
                explicit = candidate.parent
        ca = SimpleNamespace(out_dir=a.out_dir, root=a.root, cache_dir=explicit, device=a.device, batch=a.batch)
        cache = cache_for(ca, context, meta)
    return PreparedData(raw, context, cache, budget['seed'], info['models']['A1_frozen'].scale)
