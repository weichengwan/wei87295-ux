"""Strict checkpoint lineage and optional reusable B280/B282 score prefixes."""
from functools import lru_cache
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import torch
from torch import nn
from b283_common import need,read_json,write_json,fingerprint,digest_file,load_checkpoint,ROOT,LABELS,FILES
from b282_source import metadata as a1_metadata,SCENE_KEYS
from b282_model import make_a1,Candidate,ARMS
from b282_score import verify_matched
from b282_train import PASS
from b282_train import code_hashes as original_code_hashes
from source_loader import load_frozen_sources

CORE_IDENTITY=('A1_checkpoint_sha256','A1_run_fingerprint','source_protocol_sha256','source_selected_epoch','source_device','source_torch_version')


class PlainADN(nn.Module):
    def __init__(self):
        super().__init__();source,_,_=load_frozen_sources();self.detector=source.ADN18(num_classes=2)
    def prepared_forward(self,images):return self.detector(images)


def checked_checkpoint(folder,status,code,expected_arm):
    folder=Path(folder);ct_path=folder/'training_contract.json';path=folder/'best.pt'
    need(path.is_file() and ct_path.is_file(),f'Missing trained {expected_arm}: {folder}; no automatic retraining')
    c=read_json(ct_path);cfg=c['run_config']
    need(c['status']==status and cfg['arm']==expected_arm and cfg['code_sha256']==code,'Checkpoint release/arm differs: '+expected_arm)
    need(digest_file(path)==c['checkpoint_sha256'],'Checkpoint checksum differs: '+expected_arm)
    state=load_checkpoint(path)
    need(state['run_config']==cfg and state['run_fingerprint']==c['run_fingerprint']==fingerprint(cfg) and state['epoch']==c['best_epoch'],'Checkpoint internal identity differs: '+expected_arm)
    return c,state


def runtime_matches(p,a):
    return (p.get('device')==a.device.type and p.get('batch')==a.batch and p.get('torch_version')==str(torch.__version__) and p.get('amp') is False and p.get('tf32') is False)


class ScoreCache:
    def __init__(self):self.values={};self.records=[]
    def put(self,label,split,value,record):
        need(label in LABELS and split in FILES and value.dtype==np.float64,'Invalid cache label/type')
        count=value.shape[1] if split=='h1' else value.shape[0]
        need(value.ndim==(2 if split=='h1' else 1) and count>0 and np.isfinite(value).all(),'Malformed/nonfinite cached column')
        if split=='h1':need(value.shape[0]==37,'Cached H1 grid must have37 points')
        previous=self.values.get((label,split))
        if previous is not None and previous.shape!=value.shape:
            overlap=min(count,previous.shape[1] if split=='h1' else previous.shape[0])
            first=previous[:,:overlap] if split=='h1' else previous[:overlap]
            second=value[:,:overlap] if split=='h1' else value[:overlap]
            need(np.array_equal(first,second),'Overlapping historical score prefixes differ: '+label+' '+split)
        if previous is not None and (previous.shape[1] if split=='h1' else previous.shape[0])>=count:return
        self.values[label,split]=value;self.records.append(dict(label=label,split=split,count=count,**record))
    def get(self,label,split):return self.values.get((label,split))
    def fill(self,split,start,stop,j=None):
        n=stop-start;out=np.empty((n,len(LABELS)),dtype='float64');missing=np.ones(out.shape,dtype=bool)
        for col,label in enumerate(LABELS):
            v=self.get(label,split)
            if v is None:continue
            count=v.shape[1] if split=='h1' else len(v);end=min(stop,count)
            if end<=start:continue
            out[:end-start,col]=v[j,start:end] if split=='h1' else v[start:end]
            missing[:end-start,col]=False
        return out,missing


def load_sources(a,context):
    # The original metadata verifier preserves the B280 source ABI. Optional
    # cache-file availability is not treated as a change of trained weights.
    info=a1_metadata(SimpleNamespace(source_run=a.b280_run,device=a.device,batch=a.batch),context)
    reference=make_a1(info['state'],a.device);models={'A1_frozen':reference};contracts={'A1_frozen':info['contract']}
    source_code=read_json(ROOT/'b282_reference/b280_release_sources.json')
    a0,state=checked_checkpoint(a.b280_run/'A0','PASS_B280_FULL_TRAIN_VAL_ONLY',source_code,'A0')
    cfg=a0['run_config']
    need(not cfg['factor_A_joint_SPWVD'] and not cfg['factor_B_TFCG_Tail'] and cfg['bank_sha256']==context['bc']['file_sha256'],'Expected B280 WVD ADN A0')
    need(info['p']['checkpoints'][0]==a0,'B280 A0 scores refer to different weights')
    base=PlainADN();base.load_state_dict(state['state_dict'],strict=True);models['ADN']=base.to(a.device).eval();contracts['ADN']=a0
    del state
    new_contracts=[]
    for arm in ARMS:
        ct,state=checked_checkpoint(a.b282_run/arm,PASS,original_code_hashes(),arm);cfg=ct['run_config']
        need(cfg['bank_sha256']==context['bc']['file_sha256'] and cfg['scale']==reference.scale,'B282 training bank/scale differs')
        need({k:cfg['source_identity'][k] for k in CORE_IDENTITY}=={k:info['identity'][k] for k in CORE_IDENTITY},'B282 model came from another A1')
        model=Candidate(reference,arm);model.load_state_dict(state['state_dict'],strict=True);models[arm]=model.to(a.device).eval();contracts[arm]=ct
        new_contracts.append(ct);del state
    verify_matched(new_contracts)
    # Only immutable intrinsic source identity is needed if old score arrays
    # were removed; actual arrays are verified separately below.
    lineage=dict(A1={k:info['identity'][k] for k in CORE_IDENTITY},
        checkpoints={label:contracts[label]['checkpoint_sha256'] for label in LABELS},
        training_fingerprints={label:contracts[label]['run_fingerprint'] for label in LABELS})
    for model in models.values():model.requires_grad_(False)
    return dict(models=models,contracts=contracts,p=info['p'],generator=info['generator'],lineage=lineage)


def collect_caches(a,info):
    cache=ScoreCache();hashes={}
    def array(folder,p,split):
        path=folder/FILES[split]
        if not path.is_file():return None,None
        n=p['h1_scenes_n'] if split=='h1' else p[split+'_n'];shape=(37,n,4) if split=='h1' else (n,4)
        value=np.load(path,mmap_mode='r',allow_pickle=False)
        need(value.shape==shape and value.dtype==np.float64,'Historical cache shape/type differs: '+str(path))
        if path not in hashes:hashes[path]=digest_file(path)
        return value,dict(path=str(path.resolve()),sha256=hashes[path],protocol_sha256=digest_file(folder/'protocol_frozen.json'))
    if a.recompute_scores:return cache
    # Original B280 source provides full A0/A1 columns.
    if runtime_matches(info['p'],a):
        folder=a.b280_run/'pd_scr_full'
        for split in FILES:
            value,record=array(folder,info['p'],split)
            if value is not None:
                for label,col in [('A1_frozen',1),('ADN',0)]:cache.put(label,split,value[:,:,col] if split=='h1' else value[:,col],record)
    # Prefer full B282 scores if already present; otherwise reuse medium
    # prefixes. Equal overlaps must match exactly before cache reuse.
    for size in ('full','medium'):
        folder=a.b282_run/('pd_scr_'+size)
        if not (folder/'protocol_frozen.json').is_file():continue
        p=read_json(folder/'protocol_frozen.json');progress=read_json(folder/'progress.json')
        need(p['version']=='B282_CFEXPERT_SCORE_V1' and p['labels']==list(LABELS[:4]),'B282 score cache labels differ')
        need(p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==progress['fingerprint'],'B282 cache protocol identity differs')
        if progress['completed']!=dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=37):
            print('Preserving incomplete B282 score cache; skipping reuse: '+str(folder),flush=True)
            continue
        expected=(3000000,1000000,1024) if size=='full' else (300000,200000,512)
        need((p['h0_cal_n'],p['h0_audit_n'],p['h1_scenes_n'])==expected and p['scr_grid_db']==list(range(-24,13)),'Unexpected B282 cache evaluation size')
        need(p['scene_fingerprint']==fingerprint({k:p[k] for k in SCENE_KEYS}),'B282 cache scene fingerprint differs')
        need(all(p[k]==info['p'][k] for k in SCENE_KEYS if k not in ('h0_cal_n','h0_audit_n','h1_scenes_n')),'B282 cache scenes not paired to B280')
        need(p['checkpoints']==[info['contracts'][arm] for arm in ARMS] and p['code_sha256']==original_code_hashes(),'B282 cache checkpoint/code differs')
        need({k:p['source_identity'][k] for k in CORE_IDENTITY}==info['lineage']['A1'],'B282 cache A1 identity differs')
        if not runtime_matches(p,a):continue
        for split in FILES:
            value,record=array(folder,p,split)
            if value is not None:
                for col,label in enumerate(LABELS[:4]):cache.put(label,split,value[:,:,col] if split=='h1' else value[:,col],record)
    return cache
