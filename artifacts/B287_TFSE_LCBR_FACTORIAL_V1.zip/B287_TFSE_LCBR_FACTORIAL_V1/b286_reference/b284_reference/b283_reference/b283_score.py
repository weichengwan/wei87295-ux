"""Five fixed checkpoints, exact scene IDs, selective cache-prefix reuse."""
import time
from pathlib import Path
import numpy as np
import torch
from b283_common import need,read_json,write_json,fingerprint,LABELS,FILES
from b280_frontend import smoothing_bank
from source_loader import load_frozen_sources,load_frozen_file


def make_iq(generator,p,split,indices,j=None):
    scenes=[generator.make_one(p['master_seed'],p['h1_split'] if split=='h1' else p[split+'_split'],int(i),-30,10) for i in indices]
    if split!='h1':
        need(all(s['label']==0 and not np.any(s['target']) for s in scenes),'Target in H0 split')
        return np.stack([s['base'] for s in scenes]).astype('complex64')
    need(all(s['label']==1 for s in scenes),'Missing target in H1 split')
    base=np.stack([s['base'] for s in scenes]).astype('complex64').astype('complex128')
    unit=np.stack([s['unit'] for s in scenes]).astype('complex64').astype('complex128')
    power=np.array([s['cp'] for s in scenes],dtype='float64');need(np.isfinite(power).all() and (power>0).all(),'Invalid clutter power')
    amplitude=np.sqrt(power*10**(p['scr_grid_db'][j]/10))
    return (base+unit*amplitude[:,None]).astype('complex64')


@torch.inference_mode()
def fill_predictions(models,iq,missing,out,device,batch):
    """Only missing model/row cells are evaluated. Render each representation once."""
    need(iq.dtype==np.complex64 and iq.ndim==2 and iq.shape[1]==512,'Expected complex64 IQ512')
    need(out.shape==missing.shape==(len(iq),len(LABELS)) and missing.dtype==bool,'Invalid prediction mask')
    source,_,_=load_frozen_sources()
    for start in range(0,len(iq),batch):
        stop=min(start+batch,len(iq));mask=missing[start:stop]
        if not mask.any():continue
        x=torch.from_numpy(np.array(iq[start:stop],dtype=np.complex64,copy=True,order='C')).to(device)
        joint=mask[:,:4].any();plain=mask[:,4].any()
        bank=smoothing_bank(x,models['A1_frozen'].scale) if joint else None
        wvd=source.map_to_adn_input(source.wvd_base_map(x)) if plain else None
        for col,label in enumerate(LABELS):
            index=np.flatnonzero(mask[:,col])
            if not len(index):continue
            selected=torch.as_tensor(index,device=device,dtype=torch.long)
            prepared=wvd if label=='ADN' else bank
            z=models[label].prepared_forward(prepared.index_select(0,selected))
            values=(z[:,1]-z[:,0]).double().cpu().numpy()
            need(np.isfinite(values).all(),'Nonfinite model scores: '+label)
            out[start+index,col]=values
    need(np.isfinite(out).all(),'Unfilled/nonfinite output scores');return out


def compute_chunk(info,p,cache,split,start,stop,device,batch,j=None):
    out,missing=cache.fill(split,start,stop,j)
    rows=np.flatnonzero(missing.any(1));reused=int((~missing).sum());computed=int(missing.sum())
    if len(rows):
        iq=make_iq(info['generator'],p,split,start+rows,j)
        # Predictions are evaluated only for rows needing at least one model.
        # A copied block preserves all pre-filled cache values exactly.
        sub=out[rows].copy();out[rows]=fill_predictions(info['models'],iq,missing[rows],sub,device,batch)
    return out,reused,computed


@torch.inference_mode()
def verify_cache_values(info,cache,device,batch):
    """Replay first/last complete original batches, for every reusable column."""
    p=info['p'];records=[]
    for (label,split),value in cache.values.items():
        count=value.shape[1] if split=='h1' else len(value)
        starts=sorted(set([0,max(0,(count//batch-1)*batch)]))
        levels=[p['scr_grid_db'].index(-6),p['scr_grid_db'].index(0),p['scr_grid_db'].index(12)] if split=='h1' else [None]
        col=LABELS.index(label);maxdiff=0.
        for j in levels:
            for start in starts:
                stop=min(start+batch,count);iq=make_iq(info['generator'],p,split,np.arange(start,stop),j)
                missing=np.zeros((len(iq),len(LABELS)),dtype=bool);missing[:,col]=True
                actual=fill_predictions(info['models'],iq,missing,np.zeros(missing.shape),device,batch)[:,col]
                expected=value[j,start:stop] if split=='h1' else value[start:stop]
                diff=float(np.max(np.abs(actual-expected)));maxdiff=max(maxdiff,diff)
                need(np.allclose(actual,expected,atol=5e-5,rtol=2e-5),
                    f'Cached score numeric replay differs: {label} {split}; use a new output with --recompute-scores after inspection')
        records.append(dict(label=label,split=split,cached_count=count,maxabs_probe_difference=maxdiff,
            replay_batches=len(starts)*len(levels),probe_is_not_full_array_recomputation=True))
    print(f'Cache numeric replay passed: {len(records)} model/split columns',flush=True)
    return records


def stream(a,p,info,cache):
    helper=load_frozen_file('r10_sim_stage_b216_pdscr_score_v1.py');progress=helper.init(a,p)
    for split,file in FILES.items():
        total=37 if split=='h1' else p[split+'_n'];done=progress['completed'][split]
        need(isinstance(done,int) and 0<=done<=total,'Invalid committed score prefix')
        need(done==0 or (a.out_dir/file).is_file(),'Score array missing despite committed progress; preserve files and inspect')
    for split in ('h0_cal','h0_audit'):
        total=p[split+'_n'];path=a.out_dir/FILES[split];value=helper.new_array(path,(total,len(LABELS)),path.exists())
        first=progress['completed'][split];began=time.perf_counter();computed=0;reused=0
        for start in range(first,total,a.chunk):
            stop=min(start+a.chunk,total);scores,r,c=compute_chunk(info,p,cache,split,start,stop,a.device,a.batch)
            value[start:stop]=scores;value.flush();reused+=r;computed+=c
            progress['completed'][split]=stop;write_json(a.out_dir/'progress.json',progress)
            if stop==total or stop%10000<a.chunk:
                rate=(stop-first)/max(time.perf_counter()-began,1e-6)
                print(f'[{split}] {stop:,}/{total:,}; {rate:.1f} scenes/s; remaining~{(total-stop)/max(rate,1e-6)/60:.1f}min; reused_cells={reused:,}; inferred_cells={computed:,}',flush=True)
        del value
    ns=p['h1_scenes_n'];path=a.out_dir/FILES['h1'];value=helper.new_array(path,(37,ns,len(LABELS)),path.exists())
    for j in range(progress['completed']['h1'],37):
        for start in range(0,ns,a.chunk):
            stop=min(start+a.chunk,ns);value[j,start:stop]=compute_chunk(info,p,cache,'h1',start,stop,a.device,a.batch,j)[0]
        value.flush();progress['completed']['h1']=j+1;write_json(a.out_dir/'progress.json',progress)
        print(f'[dev_h1] SCR={p["scr_grid_db"][j]:+d} dB {j+1}/37',flush=True)
    del value
