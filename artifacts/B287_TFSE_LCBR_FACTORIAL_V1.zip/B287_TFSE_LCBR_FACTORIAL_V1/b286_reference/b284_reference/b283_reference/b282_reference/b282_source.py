"""Verify B280 A1 and optionally reuse its exactly paired historical scores."""
from pathlib import Path
import numpy as np
import torch
from b271_data import need,read_json,digest_file,fingerprint,load_checkpoint
from b280_frontend import smoothing_bank
from source_loader import load_frozen_file

SCENE_KEYS=('master_seed','generator_sha','h0_cal_n','h0_audit_n','h1_scenes_n','scr_grid_db',
    'h0_cal_split','h0_audit_split','h1_split','family_names','scr_definition')


def metadata(a,context):
    root=Path(a.source_run);checkpoint=root/'A1/best.pt';contract=root/'A1/training_contract.json'
    need(checkpoint.is_file() and contract.is_file(),
        'B280 A1 checkpoint/contract missing. Set --source-run to its run directory; do not retrain automatically.')
    c=read_json(contract);cfg=c['run_config']
    expected=read_json(Path(__file__).with_name('b280_release_sources.json'))
    need(c['status']=='PASS_B280_FULL_TRAIN_VAL_ONLY' and cfg['arm']=='A1' and cfg['factor_A_joint_SPWVD'] and not cfg['factor_B_TFCG_Tail'],'Expected B280 A1, not A3 or old L1-Tail')
    need(cfg['code_sha256']==expected,'A1 source release differs; preserve old files and inspect')
    need(cfg['bank_sha256']==context['bc']['file_sha256'],'A1 and TRAIN/VAL IQ bank differ')
    need((cfg['selected_rows']['train']['count'],cfg['selected_rows']['val']['count'])==(30000,5000),'Expected full B280 A1')
    need(digest_file(checkpoint)==c['checkpoint_sha256'],'A1 checkpoint checksum mismatch')
    state=load_checkpoint(checkpoint)
    need(state['run_config']==cfg and state['run_fingerprint']==c['run_fingerprint']==fingerprint(cfg) and state['epoch']==c['best_epoch'],'A1 checkpoint internal identity differs')
    folder=root/'pd_scr_full';p=read_json(folder/'protocol_frozen.json');progress=read_json(folder/'progress.json')
    need(p['version']=='B280_FULL_FACTORIAL_SCORE_V1' and p['labels']==['A0','A1','A2','A3'] and p['checkpoints'][1]==c,'B280 scoring source checkpoint differs')
    need(p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==progress['fingerprint'],'B280 score protocol identity differs')
    need((p['h0_cal_n'],p['h0_audit_n'],p['h1_scenes_n'])==(3000000,1000000,1024) and p['scr_grid_db']==list(range(-24,13)),'Expected full original B280 scene protocol')
    need(progress['completed']==dict(h0_cal=3000000,h0_audit=1000000,h1=37),'B280 scoring not complete')
    need(p['scene_fingerprint']==fingerprint({k:p[k] for k in SCENE_KEYS}),'B280 scene fingerprint differs')
    generator=load_frozen_file('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
    need(p['generator_sha']==context['bc']['generator_sha256']==digest_file(generator.__file__),'Scene generator differs')
    need(p['master_seed']==context['bc']['seed'] and tuple(p['family_names'])==generator.TRAIN_FAMILIES,'Scene seed/families differ')
    arrays={};hashes={}
    # Scores may have been removed during cleanup: recompute those splits.
    # Reuse only under the same scoring runtime and after prefix replay.
    compatible=(p['device']==a.device.type and p['batch']==a.batch and p.get('torch_version')==str(torch.__version__) and p['tf32'] is False and p.get('amp') is False)
    for key,name,shape in [('h0_cal','h0_cal_scores.npy',(3000000,4)),('h0_audit','h0_audit_scores.npy',(1000000,4)),('h1','dev_h1_scores.npy',(37,1024,4))]:
        path=folder/name
        if compatible and path.is_file():
            value=np.load(path,mmap_mode='r',allow_pickle=False)
            need(value.shape==shape and value.dtype==np.float64,'Malformed historical A1 score file: '+name)
            v=value[:,:,1] if key=='h1' else value[:,1]
            need(np.isfinite(v).all(),'Nonfinite historical A1 scores')
            arrays[key]=v;hashes[name]=digest_file(path)
    identity=dict(A1_checkpoint_sha256=c['checkpoint_sha256'],A1_run_fingerprint=c['run_fingerprint'],
        source_protocol_sha256=digest_file(folder/'protocol_frozen.json'),reused_A1_arrays_sha256=hashes,
        source_selected_epoch=c['best_epoch'],source_device=p['device'],source_torch_version=p.get('torch_version'))
    return dict(state=state,contract=c,p=p,generator=generator,arrays=arrays,identity=identity)


@torch.inference_mode()
def source_probe(info,reference,device,batch):
    """Checks every reusable split, including H1, before allowing reuse."""
    p=info['p'];g=info['generator'];differences={}
    for split,values in info['arrays'].items():
        count=64 if split!='h1' else 32
        scenes=[g.make_one(p['master_seed'],p['h1_split'] if split=='h1' else p[split+'_split'],i,-30,10) for i in range(count)]
        checks=[p['scr_grid_db'].index(0),p['scr_grid_db'].index(12)] if split=='h1' else [None]
        for j in checks:
            if split=='h1':
                base=np.stack([s['base'] for s in scenes]).astype('complex128')
                unit=np.stack([s['unit'] for s in scenes]).astype('complex128')
                amp=np.sqrt(np.array([s['cp'] for s in scenes])*10**(p['scr_grid_db'][j]/10))
                iq=(base+unit*amp[:,None]).astype('complex64');expected=values[j,:count]
            else:
                iq=np.stack([s['base'] for s in scenes]).astype('complex64');expected=values[:count]
            actual=[]
            for start in range(0,count,batch):
                x=torch.from_numpy(np.ascontiguousarray(iq[start:start+batch])).to(device)
                z=reference.prepared_forward(smoothing_bank(x,reference.scale))
                actual.extend((z[:,1]-z[:,0]).double().cpu().numpy())
            actual=np.asarray(actual);diff=float(np.max(np.abs(actual-expected)))
            need(np.allclose(actual,expected,atol=5e-5,rtol=2e-5),'A1 historical score prefix differs: '+split+'; use --recompute-a1-scores')
            differences[split+(':'+str(p['scr_grid_db'][j]) if j is not None else '')]=diff
    return dict(reused_score_prefix_checks=differences,checkpoint_verified=True,
        reuse_enabled_splits=list(info['arrays']),prefix_replay_is_not_full_new_audit=True)
