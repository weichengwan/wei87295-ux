"""Own-CAL, independent AUDIT, paired37-point DEV; resumable score prefixes."""
import gc,time
from types import SimpleNamespace
import numpy as np
import torch
from b271_data import need,read_json,write_json,fingerprint,digest_file,load_checkpoint
from b280_frontend import smoothing_bank
from b282_model import make_a1,Candidate,ARMS,LABELS,NAMES
from b282_source import SCENE_KEYS
from b282_train import PASS,code_hashes
from source_loader import load_frozen_file


@torch.inference_mode()
def predictions(models,iq,device,batch):
    """One SPWVD bank per batch, shared by all requested independent models."""
    need(iq.dtype==np.complex64 and iq.ndim==2 and iq.shape[1]==512,'Expected complex64 IQ512')
    need(models and len({m.scale for m in models})==1,'Models must share A1 scale')
    out=np.empty((len(iq),len(models)),dtype='float64')
    for start in range(0,len(iq),batch):
        # .npy inference inputs can be read-only memory maps.
        x=torch.from_numpy(np.array(iq[start:start+batch],dtype=np.complex64,order='C',copy=True)).to(device)
        bank=smoothing_bank(x,models[0].scale)
        for j,m in enumerate(models):
            z=m.prepared_forward(bank);out[start:start+len(x),j]=(z[:,1]-z[:,0]).double().cpu().numpy()
    need(np.isfinite(out).all(),'Nonfinite score output');return out


def stream(a,p,generator,models,device,reference_arrays):
    helper=load_frozen_file('r10_sim_stage_b216_pdscr_score_v1.py');progress=helper.init(a,p)
    files=dict(h0_cal='h0_cal_scores.npy',h0_audit='h0_audit_scores.npy',h1='dev_h1_scores.npy')
    for split,name in files.items():
        total=len(p['scr_grid_db']) if split=='h1' else p[split+'_n'];done=progress['completed'][split]
        need(isinstance(done,int) and 0<=done<=total,'Invalid committed score prefix')
        need(done==0 or (a.out_dir/name).is_file(),'Score array missing despite committed progress; preserve files and use a new output')
    def score_chunk(iq,split,sl,j=None):
        reuse=split in reference_arrays
        active=models[1:] if reuse else models
        actual=predictions(active,iq,device,a.batch)
        if not reuse:return actual
        old=reference_arrays[split][j,sl] if split=='h1' else reference_arrays[split][sl]
        return np.column_stack((old,actual))
    for split in ('h0_cal','h0_audit'):
        total=p[split+'_n'];path=a.out_dir/files[split];array=helper.new_array(path,(total,len(LABELS)),path.exists())
        first=progress['completed'][split];began=time.perf_counter()
        for start in range(first,total,a.chunk):
            stop=min(start+a.chunk,total)
            scenes=[generator.make_one(p['master_seed'],p[split+'_split'],i,-30,10) for i in range(start,stop)]
            need(all(s['label']==0 and not np.any(s['target']) for s in scenes),'Target found in H0')
            iq=np.stack([s['base'] for s in scenes]).astype('complex64')
            array[start:stop]=score_chunk(iq,split,slice(start,stop));array.flush()
            progress['completed'][split]=stop;write_json(a.out_dir/'progress.json',progress)
            if stop==total or stop%10000<a.chunk:
                rate=(stop-first)/max(time.perf_counter()-began,1e-6)
                print(f'[{split}] {stop:,}/{total:,}; {rate:.1f} scenes/s; remaining~{(total-stop)/max(rate,1e-6)/60:.1f}min; A1 reuse={split in reference_arrays}',flush=True)
        del array
    ns=p['h1_scenes_n'];levels=p['scr_grid_db'];path=a.out_dir/files['h1']
    array=helper.new_array(path,(len(levels),ns,len(LABELS)),path.exists())
    scenes=[generator.make_one(p['master_seed'],p['h1_split'],i,-30,10) for i in range(ns)]
    need(all(s['label']==1 for s in scenes),'Wrong H1 split')
    base=np.stack([s['base'] for s in scenes]).astype('complex64');unit=np.stack([s['unit'] for s in scenes]).astype('complex64')
    power=np.array([s['cp'] for s in scenes],dtype='float64');need(np.isfinite(power).all() and (power>0).all(),'Invalid H1 clutter power')
    for j in range(progress['completed']['h1'],len(levels)):
        scr=levels[j]
        for start in range(0,ns,a.chunk):
            stop=min(start+a.chunk,ns);amp=np.sqrt(power[start:stop]*10**(scr/10))
            iq=(base[start:stop].astype('complex128')+unit[start:stop].astype('complex128')*amp[:,None]).astype('complex64')
            array[j,start:stop]=score_chunk(iq,'h1',slice(start,stop),j)
        array.flush();progress['completed']['h1']=j+1;write_json(a.out_dir/'progress.json',progress)
        print(f'[dev_h1] SCR={scr:+d} dB {j+1}/{len(levels)}',flush=True)
    del array


def verify_matched(contracts):
    need([c['run_config']['arm'] for c in contracts]==list(ARMS),'Three trained arms required')
    keys=('seed','epochs','batch','selected_rows','bank_sha256','scale','source_identity','backbone_lr','new_module_lr','loss','code_sha256','device','torch_version')
    need(len({fingerprint({k:c['run_config'][k] for k in keys}) for c in contracts})==1,'Training budgets or source A1 differ')
    need(len({c['initialization']['shared_A1_sha256'] for c in contracts})==1,'A1 initial backbone differs')
    need(contracts[1]['initialization']['refiner_sha256']==contracts[2]['initialization']['refiner_sha256'],'Unguided/guided initial expert weights differ')


def score(a,info,reference):
    contracts=[];models=[reference]
    for arm in ARMS:
        folder=a.out_dir/arm;c=read_json(folder/'training_contract.json');path=folder/'best.pt'
        need(c['status']==PASS and c['run_config']['arm']==arm and c['run_config']['code_sha256']==code_hashes(),'Incomplete/changed B282 training')
        need(c['run_config']['source_identity']==info['identity'] and digest_file(path)==c['checkpoint_sha256'],'Source/checkpoint identity differs')
        state=load_checkpoint(path);cfg=c['run_config']
        need(state['run_config']==cfg and state['run_fingerprint']==c['run_fingerprint']==fingerprint(cfg) and state['epoch']==c['best_epoch'],'Internal selected checkpoint identity differs')
        m=Candidate(reference,arm);m.load_state_dict(state['state_dict'],strict=True);models.append(m.to(a.device).eval());contracts.append(c)
        del state
    verify_matched(contracts)
    scene={k:info['p'][k] for k in SCENE_KEYS}
    if a.eval_size=='medium':scene.update(h0_cal_n=300000,h0_audit_n=200000,h1_scenes_n=512)
    p=dict(version='B282_CFEXPERT_SCORE_V1',**scene,scene_fingerprint=fingerprint(scene),
        labels=list(LABELS),names=NAMES,ours_label='guided',nominal_pfas=[1e-4] if a.eval_size=='medium' else [1e-4,1e-5],
        source_identity=info['identity'],checkpoints=contracts,batch=a.batch,chunk=a.chunk,
        reused_A1_splits=list(info['arrays']),reused_A1_scores_prefix_replayed=True,
        code_sha256=code_hashes(),device=a.device.type,torch_version=str(torch.__version__),amp=False,tf32=False,
        score_definition='float64(float32 logit1 - float32 logit0)',strict_decision='score > own H0 CAL threshold',
        independent_final=False,scope='Paired exposed SIM-R10 DEV; A1 warm start; matched CE-only continuation; not independent TEST')
    p['fingerprint']=fingerprint(p)
    args=SimpleNamespace(out_dir=a.out_dir/('pd_scr_'+a.eval_size),batch=a.batch,chunk=a.chunk)
    print(f'B282 {a.eval_size} scoring CAL={p["h0_cal_n"]:,} AUDIT={p["h0_audit_n"]:,} H1={p["h1_scenes_n"]}x37; reuse A1: {list(info["arrays"])}',flush=True)
    stream(args,p,info['generator'],models,a.device,info['arrays'])
    del models;gc.collect()
    if a.device.type=='cuda':torch.cuda.empty_cache()
    from b282_report import generate
    return generate(args.out_dir)
