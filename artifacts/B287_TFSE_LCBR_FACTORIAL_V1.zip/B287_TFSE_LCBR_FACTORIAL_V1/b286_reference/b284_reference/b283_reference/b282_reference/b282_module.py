"""FAME-Net-inspired, consistency-guided cross-frequency expert refinement.

Reference: Du et al., IEEE TGRS 2026, doi:10.1109/TGRS.2026.3694686,
Section III-B. This is an adaptation, NOT an original FAME-Net reproduction.
Our changes: bounded smooth anisotropic masks, 2 dense lightweight experts
per band, frontend-consistency conditioning, and one zero-output residual.
Feature-map Fourier frequency is not radar Doppler frequency.
"""
import math
import torch
from torch import nn
import torch.nn.functional as F
from b271_data import need

SETTINGS = dict(position='layer2[1], after original SimAM, before bn2', channels=128,
    bottleneck=32, experts_per_band=2, routing='dense softmax, sample-level, mutually guided',
    bandwidth_min=.08, bandwidth_max=.50, bandwidth_init=.25,
    mask='complementary smooth anisotropic Gaussian; frequencies normalized by Nyquist',
    residual_scale=.1, residual_output='zero-initialized projection, no second zero gate',
    consistency='A1 smoothing consistency proxy, area-resized; not a target probability',
    reference_doi='10.1109/TGRS.2026.3694686')


class StructureExpert(nn.Module):
    def __init__(self, c):
        super().__init__()
        self.gate = nn.Sequential(nn.Conv2d(c,c,3,padding=1,groups=c),
            nn.GELU(),nn.Conv2d(c,c,1))
        self.project = nn.Conv2d(c,c,1)
    def forward(self,x):
        return self.project(x*torch.sigmoid(self.gate(x)))


class ContextExpert(nn.Module):
    def __init__(self,c):
        super().__init__()
        self.spatial=nn.Conv2d(c,c,5,padding=2,groups=c)
        self.channel=nn.Sequential(nn.AdaptiveAvgPool2d(1),nn.Conv2d(c,max(c//4,4),1),
            nn.GELU(),nn.Conv2d(max(c//4,4),c,1),nn.Sigmoid())
        self.project=nn.Conv2d(c,c,1)
    def forward(self,x):
        return self.project(x+self.spatial(x)*self.channel(x))


class CrossFrequencyRefiner(nn.Module):
    def __init__(self, guided, channels=128, width=32):
        super().__init__();self.guided=bool(guided)
        self.reduce=nn.Conv2d(channels,width,1)
        initial=(SETTINGS['bandwidth_init']-SETTINGS['bandwidth_min'])/(SETTINGS['bandwidth_max']-SETTINGS['bandwidth_min'])
        self.bandwidth_logits=nn.Parameter(torch.full((2,),math.log(initial/(1-initial))))
        # Identical tensor shapes/initial weights in guided and unguided arms.
        # Unguided receives a zero map, never the actual consistency values.
        self.router=nn.Sequential(nn.Conv2d(2*width+1,width,1),nn.GELU(),
            nn.AdaptiveAvgPool2d(1),nn.Flatten(),nn.Linear(width,4))
        self.high_experts=nn.ModuleList([StructureExpert(width) for _ in range(2)])
        self.low_experts=nn.ModuleList([ContextExpert(width) for _ in range(2)])
        self.project=nn.Conv2d(width,channels,1,bias=False)
        nn.init.zeros_(self.project.weight)

    def bands(self,x):
        h,w=x.shape[-2:]
        bw=SETTINGS['bandwidth_min']+(SETTINGS['bandwidth_max']-SETTINGS['bandwidth_min'])*torch.sigmoid(self.bandwidth_logits)
        fy=torch.fft.fftfreq(h,device=x.device,dtype=x.dtype)[:,None]/.5
        fx=torch.fft.rfftfreq(w,device=x.device,dtype=x.dtype)[None,:]/.5
        mask=torch.exp(-.5*((fy/bw[0]).square()+(fx/bw[1]).square()))
        spectrum=torch.fft.rfft2(x,norm='ortho')
        low=torch.fft.irfft2(spectrum*mask,s=(h,w),norm='ortho')
        # Complementarity follows numerically without another inverse FFT.
        return x-low,low,bw

    def components(self,x,consistency):
        need(x.ndim==4 and x.shape[1]==self.reduce.in_channels,'Invalid refiner feature shape')
        z=self.reduce(x);high,low,bw=self.bands(z)
        if self.guided:
            need(consistency is not None and consistency.ndim==4 and consistency.shape[:2]==(len(x),1),'Missing frontend consistency')
            guide=F.interpolate(consistency,size=x.shape[-2:],mode='area')
        else:
            guide=z.new_zeros((len(x),1,*x.shape[-2:]))
        weights=self.router(torch.cat((high,low,guide),dim=1)).reshape(len(x),2,2).softmax(-1)
        mixed=[]
        for j,(features,experts) in enumerate(((high,self.high_experts),(low,self.low_experts))):
            mixed.append(sum(weights[:,j,k,None,None,None]*expert(features) for k,expert in enumerate(experts)))
        delta=SETTINGS['residual_scale']*self.project(mixed[0]+mixed[1])
        return delta,dict(weights=weights,bandwidth=bw,guide_mean=guide.mean(),delta_abs_mean=delta.abs().mean())

    def forward(self,x,consistency=None):
        delta,_=self.components(x,consistency)
        return x+delta
