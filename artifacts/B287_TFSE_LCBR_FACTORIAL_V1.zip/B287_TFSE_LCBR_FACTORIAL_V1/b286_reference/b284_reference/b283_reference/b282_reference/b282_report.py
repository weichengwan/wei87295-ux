"""Raw37-point Pd, actual H0 Pfa intervals, and matched continuation contrasts."""
from pathlib import Path
import shutil
import numpy as np
from b271_data import need,read_json,write_json,fingerprint
from b273_statistics import metrics_for,save_csv
from b282_model import ARMS,LABELS,NAMES
from paper_plots import generate as paper_plot


def generate(out):
    out=Path(out);p=read_json(out/'protocol_frozen.json');progress=read_json(out/'progress.json')
    need(p['version']=='B282_CFEXPERT_SCORE_V1' and p['labels']==list(LABELS) and
        p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==progress['fingerprint'],'B282 score identity differs')
    need(progress['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=len(p['scr_grid_db'])),'Scoring incomplete')
    arrays=[]
    for name,shape in [('h0_cal_scores.npy',(p['h0_cal_n'],4)),('h0_audit_scores.npy',(p['h0_audit_n'],4)),('dev_h1_scores.npy',(len(p['scr_grid_db']),p['h1_scenes_n'],4))]:
        x=np.load(out/name,mmap_mode='r',allow_pickle=False);need(x.shape==shape and x.dtype==np.float64,'Malformed score array');arrays.append(x)
    curves=[];metrics=[];lookup={};table=[]
    for j,label in enumerate(LABELS):
        cv,mt=metrics_for(NAMES[label],arrays[0][:,j],arrays[1][:,j],arrays[2][:,:,j],p);curves+=cv;metrics+=mt
        c=None if label=='A1_frozen' else p['checkpoints'][j-1]
        for m in mt:
            lookup[label,m['nominal_pfa']]=m
            table.append(dict(group=label,selected_epoch=None if c is None else c['best_epoch'],
                extra_parameters=0 if c is None else c['initialization']['extra_parameters'],
                new_refinement_selected=False if c is None else c['new_refinement_selected'],**m))
    comparisons=[]
    for nominal in p['nominal_pfas']:
        for candidate,reference in [('control','A1_frozen'),('unguided','A1_frozen'),('guided','A1_frozen'),('unguided','control'),('guided','control'),('guided','unguided')]:
            c,r=lookup[candidate,nominal],lookup[reference,nominal]
            delta=lambda key:None if c[key] is None or r[key] is None else c[key]-r[key]
            comparisons.append(dict(candidate=candidate,reference=reference,nominal_pfa=nominal,
                delta_D80_db=delta('D80_db'),delta_D90_db=delta('D90_db'),pd_at_0_gain_pp=100*delta('pd_at_0'),
                pd_at_12_gain_pp=100*delta('pd_at_12'),candidate_false_alarms=c['audit_false_alarms'],
                reference_false_alarms=r['audit_false_alarms'],negative_delta_means_left=True))
    for name,rows in [('b282_curves.csv',curves),('b282_metrics.csv',metrics),('b282_ablation_table.csv',table),('b282_comparisons.csv',comparisons)]:save_csv(out/name,rows)
    for nominal in p['nominal_pfas']:
        figures=out/'figures'/f'pfa_{nominal:.0e}'
        paper_plot(out/'b282_curves.csv',figures,ours=NAMES['guided'],nominal=nominal,metrics=out/'b282_metrics.csv')
        for ext in ('pdf','png','svg'):
            shutil.copyfile(figures/f'b282_curves_paper_pd_pfa_{nominal:.0e}.{ext}',out/'figures'/f'b282_pd_scr_pfa_{nominal:.0e}.{ext}')
    report=dict(status='PASS_B282_PAIRED_CFEXPERT_DEV_REPORT',metrics=metrics,comparisons=comparisons,table=table,
        independent_final=False,source_Pd_unchanged=True,curve_smoothing=False,equal_actual_Pfa_established=False,
        new_module_not_selected=[arm for arm,c in zip(ARMS,p['checkpoints']) if arm!='control' and not c['new_refinement_selected']],
        gain_or_innovation_automatically_established=False,scope=p['scope'])
    write_json(out/'b282_report.json',report)
    for c in comparisons:print(f'Pfa={c["nominal_pfa"]:g} {c["candidate"]} vs {c["reference"]}: delta_D90={c["delta_D90_db"]}; H0 FP={c["candidate_false_alarms"]} vs {c["reference_false_alarms"]}',flush=True)
    if report['new_module_not_selected']:print('EPOCH0_SELECTED__NO_NEW_MODULE_GAIN_CLAIM: '+str(report['new_module_not_selected']),flush=True)
    print('PASS_B282_TRAIN_SCORE_REPORT_COMPLETE: '+str(out),flush=True);return report
