"""B280 A1 warm starts; preserve native SimAM; cross-frequency CE-only arms."""
import copy
import hashlib
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from b271_data import need
from source_loader import load_frozen_sources
from b280_frontend import JointTFGate,smoothing_bank
from b282_module import CrossFrequencyRefiner,SETTINGS

ARMS=('control','unguided','guided')
LABELS=('A1_frozen',)+ARMS
NAMES=dict(A1_frozen='A1 frozen (B280)',control='A1 continued (control)',
    unguided='A1 + cross-frequency experts',guided='A1 + consistency-guided cross-frequency experts')


class A1Core(nn.Module):
    """Exactly the B280 A1 active modules/state names, without creating TFCG."""
    def __init__(self,scale):
        super().__init__();need(np.isfinite(scale) and scale>0,'Invalid A1 scale')
        self.scale=float(scale);source,_,_=load_frozen_sources()
        self.detector=source.ADN18(num_classes=2);self.gate=JointTFGate()
    def prepared_forward(self,bank):
        image,_=self.gate(bank)
        return self.detector(image)
    def forward(self,iq):
        return self.prepared_forward(smoothing_bank(iq,self.scale))


def make_a1(state,device):
    net=A1Core(state['run_config']['scale']);net.load_state_dict(state['state_dict'],strict=True)
    return net.to(device).eval()


class Candidate(nn.Module):
    def __init__(self,reference,arm):
        super().__init__();need(arm in ARMS,'Unknown B282 arm')
        self.arm=arm;self.net=copy.deepcopy(reference);self.scale=reference.scale
        self.refiner=CrossFrequencyRefiner(arm=='guided') if arm!='control' else None
        # Frozen frontend and native BN prevent moving an already useful A1
        # representation's normalization; all other CNN/FC weights may adapt.
        for p in self.net.gate.parameters():p.requires_grad_(False)
        for m in self.net.detector.modules():
            if isinstance(m,nn.modules.batchnorm._BatchNorm):
                for p in m.parameters():p.requires_grad_(False)
        self.train(False)

    def train(self,mode=True):
        super().train(mode)
        self.net.gate.eval()
        for m in self.net.detector.modules():
            if isinstance(m,nn.modules.batchnorm._BatchNorm):m.eval()
        return self

    def prepared_forward(self,bank,return_aux=False):
        with torch.no_grad():image,front=self.net.gate(bank)
        d=self.net.detector;x=d.relu(d.bn1(d.conv1(image)));x=d.maxpool(x)
        x=d.layer1(x);x=d.layer2[0](x)
        block=d.layer2[1]
        # Keep the original ordering from frozen BasicBlock.forward.
        identity=x
        x=block.relu(block.bn3(block.conv3(x))+block.ver_bn(block.ver_conv(x))+block.hor_bn(block.hor_conv(x)))
        x=block.simam(block.conv2(x));aux={}
        if self.refiner is not None:
            delta,aux=self.refiner.components(x,front['consistency'] if self.arm=='guided' else None)
            x=x+delta
        x=block.bn2(x)
        if block.downsample is not None:identity=block.downsample(identity)
        x=block.relu(x+identity);x=d.layer3(x);x=d.layer4(x)
        x=torch.flatten(d.avgpool(x),1);z=d.fc(x)
        return (z,aux) if return_aux else z

    def forward(self,iq):
        return self.prepared_forward(smoothing_bank(iq,self.scale))


def optimizer_for(model,lr,new_lr):
    groups=[dict(params=[p for p in model.net.parameters() if p.requires_grad],lr=lr)]
    if model.refiner is not None:groups.append(dict(params=model.refiner.parameters(),lr=new_lr))
    return torch.optim.Adam(groups,weight_decay=1e-4)


def tensor_hash(state):
    h=hashlib.sha256()
    for name,v in sorted(state.items()):
        v=v.detach().cpu().contiguous();h.update(name.encode());h.update(str(v.dtype).encode())
        h.update(np.asarray(v.shape,dtype='<i8').tobytes());h.update(v.numpy().tobytes())
    return h.hexdigest()


@torch.inference_mode()
def initial_check(model,reference,bank):
    model.eval();reference.eval();ref=reference.prepared_forward(bank);actual=model.prepared_forward(bank)
    difference=float((actual-ref).abs().max())
    need(difference<=1e-6,'New arm is not initially A1-identical')
    result=dict(maxabs_logit_difference=difference,shared_A1_sha256=tensor_hash(model.net.state_dict()),
        total_parameters=sum(p.numel() for p in model.parameters()),
        trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),
        extra_parameters=sum(p.numel() for p in model.refiner.parameters()) if model.refiner else 0,
        refiner_sha256=tensor_hash(model.refiner.state_dict()) if model.refiner else None,
        all_eight_original_SimAM_retained=True,TFCG_used=False,Tail_used=False)
    need(result['shared_A1_sha256']==tensor_hash(reference.state_dict()),'Shared A1 weights changed at construction')
    return result
