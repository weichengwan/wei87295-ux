"""CE-only, matched A1 continuation; TRAIN/VAL-only selection and atomic resume."""
import gc,time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from b271_data import digest_file,fingerprint,need,read_json,write_json,load_checkpoint
from b273_shared import atomic_save,pauc
from b273_statistics import save_csv
from b280_frontend import smoothing_bank
from b282_model import Candidate,optimizer_for,initial_check,ARMS,tensor_hash
from b282_module import SETTINGS
from source_loader import load_frozen_file

PASS='PASS_B282_A1_CROSS_FREQUENCY_TRAIN_VAL_ONLY'


def code_hashes():
    root=Path(__file__).parent
    paths=list(root.glob('*.py'))+list((root/'frozen_source').glob('*.py'))+[root/'frozen_source/manifest.json',root/'b280_release_sources.json']
    return {str(p.relative_to(root)):digest_file(p) for p in sorted(paths)}


class Prepared:
    def __init__(self,data,scale):
        self.raw=data;self.values=data.values;self.selection=data.selection;self.scale=scale
    def fetch(self,split,index,device):
        iq,y=self.raw.fetch(split,index,device)
        return smoothing_bank(iq,self.scale),y


@torch.inference_mode()
def evaluate(model,data,device,batch):
    model.eval();n=len(data.values['val'][1]);total=0.;zs=[];ys=[]
    for start in range(0,n,batch):
        x,y=data.fetch('val',slice(start,min(start+batch,n)),device);z=model.prepared_forward(x)
        need(z.shape==(len(y),2) and torch.isfinite(z).all().item(),'Invalid VAL logits')
        total+=float(F.cross_entropy(z,y,reduction='sum'))
        zs.append((z[:,1]-z[:,0]).double().cpu().numpy());ys.append(y.cpu().numpy())
    z,y=np.concatenate(zs),np.concatenate(ys)
    return dict(val_ce=total/n,val_pauc01=pauc(z,y),
        val_auc=float(load_frozen_file('r10_sim_stage_b214_ablation_train_v1.py').auc(z,y)),n_val=n)


def better(value,best,anchor):
    # 2500 VAL H0 cannot validate Pfa=1e-4. pAUC@.01 is a selection proxy.
    eligible=value['val_ce']<=anchor['val_ce']+.01
    improved=(value['val_pauc01']>best['val_pauc01']+1e-12 or
        (value['val_pauc01']==best['val_pauc01'] and value['val_ce']<best['val_ce']))
    return eligible,eligible and improved


def snapshot(model):return {k:v.detach().cpu().clone() for k,v in model.state_dict().items()}


@torch.inference_mode()
def diagnostics(model,bank):
    model.eval();_,aux=model.prepared_forward(bank,True)
    if not aux:return dict(refiner=False)
    return dict(refiner=True,bandwidth_normalized_by_Nyquist=aux['bandwidth'].cpu().tolist(),
        high_expert_weight_mean=aux['weights'][:,0].mean(0).cpu().tolist(),
        low_expert_weight_mean=aux['weights'][:,1].mean(0).cpu().tolist(),
        mean_abs_feature_residual=float(aux['delta_abs_mean']),consistency_input_mean=float(aux['guide_mean']))


def train_arm(a,context,data,info,reference,anchor,arm):
    folder=a.out_dir/arm;folder.mkdir(exist_ok=True)
    cfg=dict(version='B282_CFEXPERT_CE_TRAIN_V1',arm=arm,seed=a.seed,epochs=a.epochs,batch=a.batch,
        selected_rows=data.selection,bank_sha256=context['bc']['file_sha256'],scale=reference.scale,source_identity=info['identity'],
        backbone_lr=a.lr,new_module_lr=a.new_lr,optimizer='Adam',weight_decay=1e-4,loss='CE only',
        model_settings=SETTINGS,frontend_frozen=True,native_BN_affine_and_running_frozen=True,
        remaining_CNN_FC_trainable=True,selection='max VAL pAUC01 within A1 VAL CE+0.01; CE tie-break; epoch0 eligible; no DEV selection',
        pAUC01_is_not_low_Pfa_validation=True,code_sha256=code_hashes(),device=a.device.type,torch_version=str(torch.__version__),amp=False,tf32=False)
    fp=fingerprint(cfg);manifest=folder/'run_manifest.json';best_path=folder/'best.pt';latest=folder/'last_epoch.pt';ct=folder/'training_contract.json'
    identity=dict(run_config=cfg,run_fingerprint=fp)
    if manifest.exists():need(read_json(manifest)==identity,'B282 arm settings changed; use a new --out-dir')
    else:
        need(not any(folder.iterdir()),'Nonempty B282 arm without manifest');write_json(manifest,identity)
    if ct.exists():
        c=read_json(ct);need(c['status']==PASS and c['run_fingerprint']==fp,'Completed training identity differs')
        if not best_path.exists() and latest.exists():
            saved=load_checkpoint(latest);need(saved['run_fingerprint']==fp,'Recovery checkpoint differs')
            atomic_save(best_path,saved['best_checkpoint'])
        need(digest_file(best_path)==c['checkpoint_sha256'],'Completed checkpoint changed')
        print(arm+' complete; verified and skipped',flush=True);return c
    torch.manual_seed(a.seed);model=Candidate(reference,arm).to(a.device)
    bank,_=data.fetch('train',slice(0,min(a.batch,len(data.values['train'][1]))),a.device)
    initial=initial_check(model,reference,bank);optimizer=optimizer_for(model,a.lr,a.new_lr)
    start=1;history=[]
    def state(epoch,metrics):
        return dict(state_dict=snapshot(model),epoch=epoch,val_metrics=metrics,run_config=cfg,run_fingerprint=fp)
    def commit(epoch,best):
        value=state(epoch,history[-1]);value.update(optimizer=optimizer.state_dict(),best_checkpoint=best,history=history,
            initialization=initial,anchor=anchor,torch_rng=torch.get_rng_state(),cuda_rng=torch.cuda.get_rng_state_all() if a.device.type=='cuda' else [])
        atomic_save(latest,value);atomic_save(best_path,best)
    if latest.exists():
        saved=load_checkpoint(latest)
        need(saved['run_config']==cfg and saved['run_fingerprint']==fp and saved['anchor']==anchor,'B282 resume identity differs')
        model.load_state_dict(saved['state_dict'],strict=True);optimizer.load_state_dict(saved['optimizer'])
        best=saved['best_checkpoint'];history=saved['history'];initial=saved['initialization'];start=saved['epoch']+1
        torch.set_rng_state(saved['torch_rng'])
        if a.device.type=='cuda':torch.cuda.set_rng_state_all(saved['cuda_rng'])
        atomic_save(best_path,best);del saved
    else:
        v=evaluate(model,data,a.device,a.batch)
        need(abs(v['val_ce']-anchor['val_ce'])<1e-6,'Initial VAL differs from A1 anchor')
        best=state(0,v);history=[dict(epoch=0,train_ce=None,**v,eligible=True,best_epoch=0,elapsed_s=0.)];commit(0,best)
    print(f'B282 {arm}: +{initial["extra_parameters"]:,} parameters; initial logit difference={initial["maxabs_logit_difference"]:.3g}; epochs {start}..{a.epochs}',flush=True)
    for epoch in range(start,a.epochs+1):
        began=time.perf_counter();model.train();total=0.;seen=0
        for step,index in enumerate(context['b210'].indices(data.values['train'][1],epoch,a.batch,a.seed)):
            x,y=data.fetch('train',index,a.device);optimizer.zero_grad(set_to_none=True)
            z=model.prepared_forward(x);loss=F.cross_entropy(z,y)
            need(torch.isfinite(loss).item(),'Nonfinite CE');loss.backward();optimizer.step()
            total+=float(loss.detach())*len(y);seen+=len(y)
            if (step+1)%200==0:print(f'[{arm}] epoch {epoch}/{a.epochs} TRAIN {seen:,}/{len(data.values["train"][1]):,}',flush=True)
        v=evaluate(model,data,a.device,a.batch);eligible,improved=better(v,best['val_metrics'],anchor)
        if improved:best=state(epoch,v)
        history.append(dict(epoch=epoch,train_ce=total/seen,**v,eligible=eligible,best_epoch=best['epoch'],elapsed_s=time.perf_counter()-began))
        commit(epoch,best);save_csv(folder/'train_val_history.csv',history)
        print(f'[{arm}] {epoch}/{a.epochs} VAL_CE={v["val_ce"]:.6f} pAUC01={v["val_pauc01"]:.6f} eligible={eligible} best={best["epoch"]} time={history[-1]["elapsed_s"]:.1f}s',flush=True)
    model.load_state_dict(best['state_dict'],strict=True);replay=evaluate(model,data,a.device,a.batch)
    need(abs(replay['val_ce']-best['val_metrics']['val_ce'])<1e-6,'Selected VAL replay differs')
    c=dict(status=PASS,run_config=cfg,run_fingerprint=fp,checkpoint_sha256=digest_file(best_path),best_epoch=best['epoch'],
        initialization=initial,anchor_validation=anchor,selected_validation=replay,module_diagnostics=diagnostics(model,bank),
        new_refinement_selected=arm!='control' and best['epoch']>0,no_new_improvement_claim_if_epoch0=True,
        Pd_noninferiority_established=False,CAL_AUDIT_DEV_used_for_training=False)
    write_json(ct,c);del model,optimizer,best;gc.collect()
    if a.device.type=='cuda':torch.cuda.empty_cache()
    print(f'{PASS}; {arm}; selected epoch={c["best_epoch"]}',flush=True);return c
