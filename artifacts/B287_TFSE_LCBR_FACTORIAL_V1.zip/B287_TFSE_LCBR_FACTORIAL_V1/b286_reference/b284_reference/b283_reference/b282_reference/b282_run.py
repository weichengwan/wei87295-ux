"""One command: verify B280 A1 -> matched CE fine-tuning -> score -> plot."""
import argparse,fcntl,gc,shutil,time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from b271_data import need,read_json,write_json,fingerprint,device_for
from b273_shared import setup
from b274_data import resolve,Data
from b282_source import metadata,source_probe
from b282_model import make_a1,Candidate,optimizer_for,initial_check,ARMS
from b282_train import Prepared,evaluate,train_arm,code_hashes,diagnostics


def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    for key in ('source-run','out-dir','bank-dir'):p.add_argument('--'+key,type=Path)
    p.add_argument('--stage',choices=('all','preflight','train','score','report'),default='all')
    p.add_argument('--eval-size',choices=('medium','full'),default='medium')
    p.add_argument('--wait-for-gpu',action='store_true');p.add_argument('--recompute-a1-scores',action='store_true')
    p.add_argument('--epochs',type=int,default=6);p.add_argument('--train-limit',type=int,default=16000)
    p.add_argument('--val-limit',type=int,default=5000);p.add_argument('--batch',type=int,default=32)
    p.add_argument('--chunk',type=int,default=512);p.add_argument('--lr',type=float,default=1e-5)
    p.add_argument('--new-lr',type=float,default=3e-4);p.add_argument('--seed',type=int,default=20261022)
    p.add_argument('--device',choices=('cpu','cuda'),default='cuda');p.add_argument('--cpu-threads',type=int,default=4)
    a=p.parse_args(argv);a.root=a.root.resolve();a.source_run=(a.source_run or a.root/'output_b280_full_ablation_v1').resolve()
    a.out_dir=(a.out_dir or a.root/'output_b282_a1_cfexpert_v1').resolve()
    need(a.root.is_dir() and a.root in a.out_dir.parents and a.source_run!=a.out_dir and
        a.source_run not in a.out_dir.parents and a.out_dir not in a.source_run.parents,'Use a separate B282 output inside project root')
    need(a.epochs>0 and a.batch==32 and a.chunk>=32 and a.chunk%32==0 and a.lr>0 and a.new_lr>0 and a.cpu_threads>0,'Invalid training budget')
    need(32<=a.train_limit<=30000 and a.train_limit%2==0 and a.val_limit==5000,'Use32..30000 even TRAIN rows and the full5000 VAL rows')
    a.device=device_for(a.device);return a


def acquire(lock,wait):
    attempts=0
    while True:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);return
        except BlockingIOError:
            if not wait:raise SystemExit('Another radar task holds the GPU lock; use --wait-for-gpu')
            if attempts%4==0:print('Waiting for shared radar GPU lock; B282 has not allocated GPU memory',flush=True)
            attempts+=1;time.sleep(15)


def runtime_canary(a,data,reference):
    y=data.values['train'][1];ix=np.r_[np.flatnonzero(y==0)[:16],np.flatnonzero(y==1)[:16]]
    need(len(ix)==32,'Need32 balanced TRAIN rows for optimizer canary')
    bank,target=data.fetch('train',ix,a.device);records=[]
    for arm in ARMS:
        torch.manual_seed(a.seed);model=Candidate(reference,arm).to(a.device)
        initial=initial_check(model,reference,bank);optimizer=optimizer_for(model,a.lr,a.new_lr);model.train()
        if a.device.type=='cuda':torch.cuda.reset_peak_memory_stats(a.device)
        for _ in range(3):
            optimizer.zero_grad(set_to_none=True);loss=F.cross_entropy(model.prepared_forward(bank),target)
            need(torch.isfinite(loss).item(),'Nonfinite optimizer canary');loss.backward();optimizer.step()
        record=dict(arm=arm,initialization=initial,three_optimizer_steps=True,diagnostics=diagnostics(model,bank),
            peak_allocated_GiB=torch.cuda.max_memory_allocated(a.device)/1024**3 if a.device.type=='cuda' else None)
        if arm!='control':need(record['diagnostics']['mean_abs_feature_residual']>0,'New branch failed to learn in TRAIN canary')
        records.append(record);del model,optimizer,loss;gc.collect()
        if a.device.type=='cuda':torch.cuda.empty_cache()
        print('A1 initialization/three-step optimizer canary passed: '+arm,flush=True)
    need(records[1]['initialization']['refiner_sha256']==records[2]['initialization']['refiner_sha256'],'New arm initial weights differ')
    return records


def main(argv=None):
    a=cli(argv);setup(a.cpu_threads)
    if a.stage=='report':
        from b282_report import generate
        return generate(a.out_dir/('pd_scr_'+a.eval_size))
    print(f'B282 A1 + cross-frequency experts | stage={a.stage} | output={a.out_dir}',flush=True)
    with (a.root/'codex_b271_night.lock').open('a') as lock:
        acquire(lock,a.wait_for_gpu);context=resolve(a.root,a.bank_dir);info=metadata(a,context)
        if a.recompute_a1_scores:
            info['arrays']={};info['identity']['reused_A1_arrays_sha256']={}
        reference=make_a1(info['state'],a.device)
        probe=source_probe(info,reference,a.device,a.batch)
        if a.stage=='score':
            from b282_score import score
            return score(a,info,reference)
        need(shutil.disk_usage(a.root).free>=2*1024**3,'Require2GiB free; existing B280 files are preserved')
        a.out_dir.mkdir(exist_ok=True);raw=Data(context,a.train_limit,a.val_limit,a.seed);data=Prepared(raw,reference.scale)
        identity=dict(version='B282_A1_CFEXPERT_V1',source=info['identity'],selected_rows=data.selection,
            epochs=a.epochs,batch=a.batch,lr=a.lr,new_lr=a.new_lr,seed=a.seed,device=a.device.type,
            torch_version=str(torch.__version__),code_sha256=code_hashes())
        manifest=a.out_dir/'run_manifest.json'
        if manifest.exists():need(read_json(manifest)==identity,'B282 training settings changed; use another --out-dir')
        else:
            need(not any(a.out_dir.iterdir()),'Nonempty output without B282 manifest');write_json(manifest,identity)
        write_json(a.out_dir/'source_A1_numeric_probe.json',probe)
        anchor=evaluate(reference,data,a.device,a.batch)
        original=info['contract']['selected_validation']['val_ce']
        need(abs(anchor['val_ce']-original)<1e-5,'Full VAL CE replay differs from original A1; inspect source/device before fine-tuning')
        write_json(a.out_dir/'source_A1_full_VAL_replay.json',dict(current=anchor,historical_val_ce=original,
            difference=anchor['val_ce']-original,checkpoint=info['identity']['A1_checkpoint_sha256']))
        print(f'A1 full VAL replay passed: CE={anchor["val_ce"]:.8f}; no A1 training from scratch',flush=True)
        canary=a.out_dir/'optimizer_canary.json'
        if not canary.exists():write_json(canary,dict(fingerprint=fingerprint(identity),checks=runtime_canary(a,data,reference)))
        else:need(read_json(canary)['fingerprint']==fingerprint(identity),'Optimizer canary identity differs')
        if a.stage=='preflight':return
        contracts=[train_arm(a,context,data,info,reference,anchor,arm) for arm in ARMS]
        from b282_score import verify_matched
        verify_matched(contracts)
        del data,raw;gc.collect()
        if a.stage=='train':return
        from b282_score import score
        return score(a,info,reference)


if __name__=='__main__':main()
