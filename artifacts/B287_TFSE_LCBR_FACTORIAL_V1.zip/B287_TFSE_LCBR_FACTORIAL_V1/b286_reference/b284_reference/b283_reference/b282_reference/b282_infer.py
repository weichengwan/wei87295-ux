"""Score complex64 IQ512 .npy rows with one selected B282 checkpoint."""
import argparse
from pathlib import Path
import numpy as np
import torch
from b271_data import load_checkpoint,need,digest_file,read_json,fingerprint,device_for
from b273_shared import setup
from b282_model import A1Core,Candidate
from b282_score import predictions
from b282_train import PASS,code_hashes


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--iq',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True);p.add_argument('--batch',type=int,default=32)
    p.add_argument('--device',choices=('cpu','cuda'),default='cuda');p.add_argument('--threshold',type=float)
    a=p.parse_args(argv);need(a.batch>0,'Batch must be positive');device=device_for(a.device);setup(4)
    need(not a.out.exists() and a.out.suffix=='.npz','Use a new .npz output path')
    state=load_checkpoint(a.checkpoint);cfg=state['run_config'];ct=read_json(a.checkpoint.with_name('training_contract.json'))
    need(ct['status']==PASS and ct['run_config']==cfg and cfg['code_sha256']==code_hashes() and
        ct['checkpoint_sha256']==digest_file(a.checkpoint) and state['run_fingerprint']==ct['run_fingerprint']==fingerprint(cfg) and state['epoch']==ct['best_epoch'],'Selected checkpoint identity differs')
    core=A1Core(cfg['scale']);model=Candidate(core,cfg['arm']);model.load_state_dict(state['state_dict'],strict=True);model.to(device).eval()
    iq=np.load(a.iq,mmap_mode='r',allow_pickle=False)
    need(iq.ndim==2 and iq.shape[1]==512 and iq.dtype==np.complex64 and len(iq)>0 and np.isfinite(iq).all(),'Require finite complex64 N x512 IQ .npy')
    values=predictions([model],iq,device,a.batch)[:,0];result=dict(scores=values)
    if a.threshold is not None:
        need(np.isfinite(a.threshold),'Threshold must be finite');result.update(decisions=values>a.threshold,threshold=a.threshold)
    a.out.parent.mkdir(parents=True,exist_ok=True);np.savez(a.out,**result)
    print(f'Saved {len(values):,} scores to {a.out}; threshold must come from a matching H0 calibration')


if __name__=='__main__':main()
