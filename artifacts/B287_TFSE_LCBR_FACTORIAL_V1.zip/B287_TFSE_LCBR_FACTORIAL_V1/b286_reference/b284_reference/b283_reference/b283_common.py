"""B283 scoring-only adapter; import the unchanged, vendored B282 release."""
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REFERENCE=ROOT/'b282_reference'
sys.path.insert(0,str(REFERENCE))
from b271_data import need,read_json,write_json,fingerprint,digest_file,load_checkpoint
from b282_train import code_hashes as b282_code_hashes

LABELS=('A1_frozen','control','unguided','guided','ADN')
# Preserve the first four curve positions/colors. Append original ADN.
NAMES=dict(A1_frozen='A1 frozen (B280)',control='A1 continued (control)',
    unguided='A1 + cross-frequency experts',guided='ADN + TFSE + CGCR (Ours)',ADN='ADN baseline (B280 A0)')
MODULE_NAMES=dict(TFSE=dict(zh='时频协同增强模块',en='Time-Frequency Synergistic Enhancement'),
    CGCR=dict(zh='一致性引导跨频细化模块',en='Consistency-Guided Cross-Frequency Refinement'))
FILES=dict(h0_cal='h0_cal_scores.npy',h0_audit='h0_audit_scores.npy',h1='dev_h1_scores.npy')


def own_code_hashes():
    paths=list(ROOT.glob('*.py'))+[ROOT/'b282_release_sources.json']
    return dict(B283={p.name:digest_file(p) for p in sorted(paths)},B282=b282_code_hashes())


def validate_reference():
    need(b282_code_hashes()==read_json(ROOT/'b282_release_sources.json'),'Embedded B282 code changed; preserve original training identities')
