"""Reuse B280/B282 weights; complete large two-Pfa scoring, no optimizer."""
import argparse,fcntl,gc,shutil,time
from pathlib import Path
from types import SimpleNamespace
import torch
from b283_common import need,read_json,write_json,fingerprint,validate_reference,own_code_hashes,LABELS,NAMES,MODULE_NAMES
from b271_data import device_for
from b273_shared import setup
from b274_data import resolve
from b282_source import SCENE_KEYS
from b283_source import load_sources,collect_caches
from b283_score import verify_cache_values,stream


def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    for key in ('b280-run','b282-run','out-dir','bank-dir'):p.add_argument('--'+key,type=Path)
    p.add_argument('--stage',choices=('all','preflight','score','report'),default='all')
    p.add_argument('--batch',type=int,default=32);p.add_argument('--chunk',type=int,default=512)
    p.add_argument('--device',choices=('cuda','cpu'),default='cuda');p.add_argument('--cpu-threads',type=int,default=4)
    p.add_argument('--wait-for-gpu',action='store_true');p.add_argument('--recompute-scores',action='store_true')
    a=p.parse_args(argv);a.root=a.root.resolve()
    a.b280_run=(a.b280_run or a.root/'output_b280_full_ablation_v1').resolve()
    a.b282_run=(a.b282_run or a.root/'output_b282_a1_cfexpert_v1').resolve()
    a.out_dir=(a.out_dir or a.root/'output_b283_tfse_cgcr_full_v1').resolve()
    need(a.root.is_dir() and a.root in a.out_dir.parents,'Use a separate B283 output inside root')
    for source in (a.b280_run,a.b282_run):
        need(a.out_dir!=source and source not in a.out_dir.parents and a.out_dir not in source.parents,'B283 output must not overlap source results')
    need(a.batch==32 and a.chunk>=32 and a.chunk%32==0 and a.cpu_threads>0,'Use batch32 and a positive chunk multiple of32')
    a.device=device_for(a.device);return a


def acquire(lock,wait):
    tries=0
    while True:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);return
        except BlockingIOError:
            if not wait:raise SystemExit('Another radar job holds GPU lock; use --wait-for-gpu')
            if tries%4==0:print('Waiting for shared radar GPU lock; B283 has not allocated GPU memory',flush=True)
            tries+=1;time.sleep(15)


def main(argv=None):
    a=cli(argv);setup(a.cpu_threads);validate_reference()
    if a.stage=='report':
        from b283_report import generate
        return generate(a.out_dir/'pd_scr_full')
    print(f'B283 SCORE ONLY | stage={a.stage} | output={a.out_dir}; no training or optimizer',flush=True)
    with (a.root/'codex_b271_night.lock').open('a') as lock:
        acquire(lock,a.wait_for_gpu);context=resolve(a.root,a.bank_dir);info=load_sources(a,context);cache=collect_caches(a,info)
        scene={k:info['p'][k] for k in SCENE_KEYS}
        need((scene['h0_cal_n'],scene['h0_audit_n'],scene['h1_scenes_n'])==(3000000,1000000,1024),'Require full3M/1M/1024 scene protocol')
        p=dict(version='B283_FULL_INCREMENTAL_SCORE_V1',**scene,scene_fingerprint=fingerprint(scene),
            labels=list(LABELS),names=NAMES,ours_label='guided',nominal_pfas=[1e-4,1e-5],module_names=MODULE_NAMES,
            source_lineage=info['lineage'],training_contracts=info['contracts'],score_cache_sources=cache.records,
            code_sha256=own_code_hashes(),batch=a.batch,chunk=a.chunk,device=a.device.type,torch_version=str(torch.__version__),amp=False,tf32=False,
            score_definition='float64(float32 logit1 - float32 logit0)',strict_decision='score > own full H0 CAL threshold',
            trained_new_models=False,strict_2x2_factorial=False,independent_final=False,
            scope='Full paired exposed SIM-R10 DEV; B280 baseline/front and B282 matched continuation/refinement; existing weights only')
        p['fingerprint']=fingerprint(p)
        a.out_dir.mkdir(exist_ok=True);manifest=a.out_dir/'run_manifest.json'
        identity=dict(version='B283_FULL_INCREMENTAL_V1',protocol_fingerprint=p['fingerprint'])
        if manifest.exists():need(read_json(manifest)==identity,'B283 source/settings changed; preserve old output and choose another --out-dir')
        else:
            need(not any(a.out_dir.iterdir()),'Nonempty B283 output without manifest');write_json(manifest,identity)
        probe=a.out_dir/'cache_numeric_probe.json'
        if not probe.exists():
            result=verify_cache_values(info,cache,a.device,a.batch)
            write_json(probe,dict(protocol_fingerprint=p['fingerprint'],checks=result))
        else:need(read_json(probe)['protocol_fingerprint']==p['fingerprint'],'Cache probe identity differs')
        print('Checkpoints verified: original ADN, A1 frozen, A1 control, unguided experts, TFSE+CGCR. No model retrained.',flush=True)
        print('Full evaluation: CAL3,000,000 AUDIT1,000,000 H1=1024x37; nominal Pfa=1e-4 and1e-5.',flush=True)
        if a.stage=='preflight':return
        need(shutil.disk_usage(a.root).free>=512*1024**2,'Require512MiB free for five-model score arrays and reports')
        args=SimpleNamespace(out_dir=a.out_dir/'pd_scr_full',batch=a.batch,chunk=a.chunk,device=a.device)
        stream(args,p,info,cache)
        del info;gc.collect()
        if a.device.type=='cuda':torch.cuda.empty_cache()
        from b283_report import generate
        return generate(args.out_dir)


if __name__=='__main__':main()
