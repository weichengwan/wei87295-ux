"""Large paired DEV, two Pfas, incremental ablation with training-budget audit."""
from pathlib import Path
import shutil
import numpy as np
from b283_common import need,read_json,write_json,fingerprint,LABELS,NAMES,MODULE_NAMES
from b273_statistics import metrics_for,save_csv
from b283_plots import generate as paper_plot

TABLE_ORDER=('ADN','A1_frozen','control','unguided','guided')
FACTORS=dict(ADN=(False,'none',False),A1_frozen=(True,'none',False),
    control=(True,'none',True),unguided=(True,'unguided',True),guided=(True,'guided',True))


def generate(out):
    out=Path(out);p=read_json(out/'protocol_frozen.json');progress=read_json(out/'progress.json')
    need(p['version']=='B283_FULL_INCREMENTAL_SCORE_V1' and p['labels']==list(LABELS) and p['nominal_pfas']==[1e-4,1e-5], 'Unexpected B283 protocol')
    need(p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==progress['fingerprint'],'B283 protocol identity differs')
    need(progress['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=37),'B283 scoring incomplete')
    arrays=[]
    for name,shape in [('h0_cal_scores.npy',(p['h0_cal_n'],5)),('h0_audit_scores.npy',(p['h0_audit_n'],5)),('dev_h1_scores.npy',(37,p['h1_scenes_n'],5))]:
        value=np.load(out/name,mmap_mode='r',allow_pickle=False)
        need(value.shape==shape and value.dtype==np.float64,'Invalid B283 score array');arrays.append(value)
    curves=[];metrics=[];lookup={};table=[]
    for col,label in enumerate(LABELS):
        cv,mt=metrics_for(NAMES[label],arrays[0][:,col],arrays[1][:,col],arrays[2][:,:,col],p)
        curves+=cv;metrics+=mt
        for m in mt:lookup[label,m['nominal_pfa']]=m
    for nominal in p['nominal_pfas']:
        for label in TABLE_ORDER:
            c=p['training_contracts'][label];cfg=c['run_config'];front,refine,continued=FACTORS[label]
            table.append(dict(group=label,TFSE=front,cross_frequency_refinement=refine,A1_continuation=continued,
                source_training_rows=cfg['selected_rows']['train']['count'],source_validation_rows=cfg['selected_rows']['val']['count'],
                source_epochs=cfg['epochs'],selected_epoch=c['best_epoch'],
                checkpoint_sha256=c['checkpoint_sha256'],
                new_refinement_selected=c.get('new_refinement_selected',False),
                **lookup[label,nominal]))
    comparisons=[]
    contrasts=[('A1_frozen','ADN','TFSE, matched B280 training budget'),
        ('control','A1_frozen','Additional A1 fine-tuning'),('unguided','control','Unguided cross-frequency refinement'),
        ('guided','unguided','Consistency guidance'),('guided','control','Complete refinement vs matched continuation'),
        ('guided','A1_frozen','Complete candidate vs frozen A1'),('guided','ADN','Complete pipeline vs original ADN; budgets differ')]
    for nominal in p['nominal_pfas']:
        for candidate,reference,scope in contrasts:
            c,r=lookup[candidate,nominal],lookup[reference,nominal]
            difference=lambda key:None if c[key] is None or r[key] is None else c[key]-r[key]
            comparisons.append(dict(candidate=candidate,reference=reference,contrast=scope,nominal_pfa=nominal,
                delta_D80_db=difference('D80_db'),delta_D90_db=difference('D90_db'),pd_at_0_gain_pp=100*difference('pd_at_0'),
                pd_at_12_gain_pp=100*difference('pd_at_12'),candidate_false_alarms=c['audit_false_alarms'],reference_false_alarms=r['audit_false_alarms'],
                negative_delta_means_left=True))
    for name,rows in [('b283_curves.csv',curves),('b283_metrics.csv',metrics),('b283_ablation_table.csv',table),('b283_comparisons.csv',comparisons)]:save_csv(out/name,rows)
    fmt=lambda v:'NA' if v is None else f'{v:.3f}'
    text='# Full evaluation, reused trained checkpoints\n\n'
    text+='TFSE: Time-Frequency Synergistic Enhancement. CGCR: Consistency-Guided Cross-Frequency Refinement.\n\n'
    for nominal in p['nominal_pfas']:
        text+=f'Nominal Pfa={nominal:g}\n\n|Model|TFSE|Refinement|Continuation|D80 dB|D90 dB|Pd at0dB|H0 false alarms|\n|---|---|---|---|---|---|---|---|\n'
        selected=[r for r in table if r['nominal_pfa']==nominal]
        for row in selected:
            text+=f'|{row["method"]}|{int(row["TFSE"])}|{row["cross_frequency_refinement"]}|{int(row["A1_continuation"])}|{fmt(row["D80_db"])}|{fmt(row["D90_db"])}|{fmt(row["pd_at_0"])}|{row["audit_false_alarms"]}/{row["audit_n"]:,}|\n'
        text+='\n'
        folder=out/'figures'/f'pfa_{nominal:.0e}'
        paper_plot(out/'b283_curves.csv',folder,ours=NAMES['guided'],nominal=nominal,metrics=out/'b283_metrics.csv')
        for ext in ('pdf','png','svg'):
            shutil.copyfile(folder/f'b283_curves_paper_pd_pfa_{nominal:.0e}.{ext}',out/'figures'/f'b283_pd_scr_pfa_{nominal:.0e}.{ext}')
    text+='This is an incremental ablation with a matched A1 continuation control, not a complete2x2 factorial. A0/A1 use historical B280 training; the three continuation arms share B282 budgets. Full exposed DEV is not independent final TEST. Nominal Pfa does not establish equal actual Pfa. No new model is trained here.\n'
    (out/'b283_ablation_table.md').write_text(text,encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    for nominal in p['nominal_pfas']:
        selected=[r for r in table if r['nominal_pfa']==nominal]
        display=[[r['group'],str(int(r['TFSE'])),r['cross_frequency_refinement'],str(int(r['A1_continuation'])),fmt(r['D80_db']),fmt(r['D90_db']),f'{r["audit_false_alarms"]}/{r["audit_n"]:,}'] for r in selected]
        fig,ax=plt.subplots(figsize=(11,3));ax.axis('off')
        t=ax.table(cellText=display,colLabels=['Model','TFSE','Refinement','Continuation','D80/dB','D90/dB','H0 false alarms'],cellLoc='center',loc='center')
        t.auto_set_font_size(False);t.set_fontsize(9);t.scale(1,1.5);ax.set_title(f'Incremental ablation | nominal Pfa={nominal:g} | existing checkpoints')
        for ext in ('pdf','png'):fig.savefig(out/f'b283_ablation_table_pfa_{nominal:.0e}.{ext}',dpi=300,bbox_inches='tight')
        plt.close(fig)
    report=dict(status='PASS_B283_FULL_INCREMENTAL_REPORT',metrics=metrics,comparisons=comparisons,table=table,
        module_names=MODULE_NAMES,trained_new_models=False,strict_2x2_factorial=False,
        source_values_unchanged=True,smoothing=False,independent_final=False,equal_actual_Pfa_established=False,
        novel_module_gain_automatically_established=False,
        source_training_budgets_preserved=True,scope=p['scope'])
    write_json(out/'b283_report.json',report)
    for row in comparisons:print(f'Pfa={row["nominal_pfa"]:g} {row["candidate"]} vs {row["reference"]}: delta_D90={row["delta_D90_db"]}; H0 FP={row["candidate_false_alarms"]} vs {row["reference_false_alarms"]}',flush=True)
    print('PASS_B283_FULL_SCORE_REPORT_COMPLETE: '+str(out),flush=True);return report
