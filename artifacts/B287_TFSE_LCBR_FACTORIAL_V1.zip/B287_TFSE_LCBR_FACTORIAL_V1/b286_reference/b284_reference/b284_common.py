"""B284 complete TFSE x CGCR ablation; immutable B280/B282/B283 lineage."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REFERENCE = ROOT / 'b283_reference'
sys.path.insert(0, str(REFERENCE))
import b283_common as previous
from b271_data import need, read_json, write_json, digest_file, fingerprint, load_checkpoint

LABELS = ('ADN', 'TFSE', 'CGCR', 'FULL')
NAMES = dict(ADN='ADN', TFSE='ADN + TFSE', CGCR='ADN + CGCR', FULL='ADN + TFSE + CGCR (Ours)')
FACTORS = dict(ADN=(False, False), TFSE=(True, False), CGCR=(False, True), FULL=(True, True))
NEW_ARMS = ('ADN', 'CGCR')
FILES = dict(h0_cal='h0_cal_scores.npy', h0_audit='h0_audit_scores.npy', h1='dev_h1_scores.npy')
PASS = 'PASS_B284_WVD_CGCR_TRAIN_VAL_ONLY'


def validate_reference():
    manifest = read_json(ROOT / 'b283_release_sources.json')
    for name, expected in manifest.items():
        need(digest_file(REFERENCE / name) == expected, 'Embedded reference changed: ' + name)
    previous.validate_reference()


def code_hashes():
    own = {p.name: digest_file(p) for p in sorted(ROOT.glob('*.py'))}
    own['b283_release_sources.json'] = digest_file(ROOT / 'b283_release_sources.json')
    return dict(B284=own, reference=read_json(ROOT / 'b283_release_sources.json'))
