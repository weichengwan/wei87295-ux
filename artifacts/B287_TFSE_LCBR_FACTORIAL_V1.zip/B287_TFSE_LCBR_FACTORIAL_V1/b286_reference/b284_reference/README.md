# B284：TFSE × CGCR 完整四组消融

本包修正B283缺少“无TFSE、有完整CGCR”的问题。只有下面四条主曲线：

|图例|TFSE|完整CGCR|本次处理|
|---|---|---|---|
|ADN|无|无|从B280 A0进行同预算续训；原始ADN结构不变|
|ADN + TFSE|有|无|直接复用B282 control，不重训|
|ADN + CGCR|无|有|从B280 A0训练缺失的CGCR-only组|
|ADN + TFSE + CGCR (Ours)|有|有|直接复用B282 guided，不重训|

ADN是原始WVD→ACB/ResNet18残差主干/8个SimAM→分类的SIM重建；不是原作者同数据同指标实验。四组均使用CE，不含TFCG、Tail、phase-ARS或其他旧候选模块。不会把unguided换个图例冒充CGCR-only。

## 为什么还要续训纯ADN

B280 A0/A1都分配了30,000条TRAIN、5,000条VAL、最多12轮的初始训练。已有B282 control/guided又从A1出发，用相同16,000条TRAIN、完整5,000条VAL继续训练最多6轮。

因此，本次在A0上同样训练两个WVD组，读取现有B282契约中的样本索引、种子、轮数、学习率、优化器和选择规则，不另设更有利的预算。原生BN的运行统计和仿射参数在续训期冻结，其余CNN/FC可训练，保持B282的政策。新CGCR初始专家参数也必须和B282 guided的初始哈希一致。

相同的是各阶段最大预算和选择规则，不是所选检查点的实际epoch或初始函数：B280 A0/A1原先各自选了第3/9轮，新续训组仍按VAL选最佳检查点。主图里ADN用同预算续训后的原ADN结构，原B280 A0权重不覆盖。

## 无TFSE时，CGCR如何取得引导

CGCR所需C是从原始IQ独立计算的固定平滑一致性描述，不是TFSE可训练门控的输出。

- 无TFSE的两组：分类器图像始终使用原项目WVD，完全不调用JointTFGate。
- 仅CGCR组：额外从同一IQ计算固定C，送入原B282 guided refiner；不把SPWVD图送给ADN，不新增可训练前端。
- 有TFSE的两组：保持已有TFSE图像；完整模型也使用相同定义的C。

所以“TFSE关闭”准确指关闭联合SPWVD图像修正与可训练空间门控；CGCR内部仍保留自己的固定IQ描述。不能宣称CGCR-only完全不涉及任何SPWVD相关计算。特征图FFT频率也不等于雷达物理多普勒频率。

## 运行

把`B284_TFSE_CGCR_FACTORIAL_V1.zip`上传到：

`/root/autodl-tmp/MTDSP_NATIVE_LMDA_V1/`

执行：

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
unzip -n B284_TFSE_CGCR_FACTORIAL_V1.zip
bash B284_TFSE_CGCR_FACTORIAL_V1/start_on_autodl.sh
tail -F codex_b284_four_model.log
```

启动器后台执行`conda run -n mpdnet-r10`，不需要`conda activate`，SSH断开不会中断后台进程。退出tail按Ctrl+C不会停止训练。关机或进程被终止后，在确认旧任务不在运行时重新运行同一启动命令；训练从最后完整epoch恢复，评分按已提交块恢复。

共享锁会等待其他雷达任务，等待阶段会明确打印提示。原B280/B282/B283代码包不必仍在服务器，所需未修改源码已内嵌并校验哈希。

## 默认流程与规模

1. 核对冻结30k/5k数据、B280 A0/A1、B282 control/guided的检查点/训练契约，以及B283缓存元数据。
2. 验证或重建完整TRAIN/VAL WVD缓存；只读既有缓存。核对原A0完整VAL损失与历史值。
3. 两个WVD组各做3步真实TRAIN优化器预检并丢弃预检权重，然后分别从原A0开始训练，按同一个VAL规则选择检查点。
4. 读取完成后的B283原始分数，核对首尾批次及3个H1 SCR水平；复用control→TFSE和guided→FULL两列，只推理缺失分数。
5. 全量CAL3,000,000、独立AUDIT1,000,000、37个SCR点（−24至+12dB），每点1024个相同基础H1场景；分别标定1e-4和1e-5门限、计算指标并画四条线。

不是重新训练全部四个大模型。新训练仍按B282既有16k/5k、6轮的续训预算；全量指评价规模。不会把这些续训记录改写成30k训练。

若想先用中等评价确认管线，用下面命令启动（仍完成相同两个续训组）：

```bash
bash B284_TFSE_CGCR_FACTORIAL_V1/start_on_autodl.sh --eval-size medium
```

medium为CAL300k、AUDIT200k、每SCR512个H1，仅1e-4。随后去掉`--eval-size medium`可复用已训练权重做full，但本包不同评价目录之间不承诺复用新模型medium分数前缀。默认命令直接完成full双Pfa，和已有B283对应。

## 必须保留的文件

```text
SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1/
output_b280_full_ablation_v1/
  A0/best.pt
  A0/training_contract.json
  A1/best.pt
  A1/training_contract.json
  pd_scr_full/protocol_frozen.json
  pd_scr_full/progress.json
output_b282_a1_cfexpert_v1/
  control/best.pt
  control/training_contract.json
  guided/best.pt
  guided/training_contract.json
```

可选但强烈建议保留：

```text
output_b283_tfse_cgcr_full_v1/pd_scr_full/
  protocol_frozen.json
  progress.json
  h0_cal_scores.npy
  h0_audit_scores.npy
  dev_h1_scores.npy
```

B283只剩CSV/PDF不能代替原始分数缓存；缺失npy时会从保留权重重算该split。若协议/检查点不符则停止，不静默混用。训练前只核对旧评分元数据，不用CAL/AUDIT/H1分数选择权重。

优先复用B280记录的WVD缓存或`output_sim_r10_b270_wvd_rebuilt_v1`；也可显式传`--cache-dir /缓存目录`。新训练至少预留2GiB，需新建完整WVD缓存时要求4GiB。不会删除任何旧输出。

目录名称不同可传：

```bash
bash B284_TFSE_CGCR_FACTORIAL_V1/start_on_autodl.sh \
  --b280-run /你的B280输出目录 \
  --b282-run /你的B282输出目录 \
  --b283-run /你的B283输出目录
```

需要同一个`mpdnet-r10`和PyTorch版本，保证续训与缓存的可比性。配置/源码或来源权重改变时应使用新输出目录。

## 输出与画风

```text
output_b284_tfse_cgcr_factorial_v1/
  ADN/{best.pt,last_epoch.pt,training_contract.json,train_val_history.csv}
  CGCR/{best.pt,last_epoch.pt,training_contract.json,train_val_history.csv}
  pd_scr_full/
    b284_curves.csv
    b284_metrics.csv
    b284_comparisons.csv
    b284_ablation_table.csv
    b284_ablation_table_pfa_1e-04.pdf
    b284_ablation_table_pfa_1e-05.pdf
    b284_report.json
    figures/b284_pd_scr_pfa_1e-04.pdf
    figures/b284_pd_scr_pfa_1e-05.pdf
```

主图只有ADN、ADN+TFSE、ADN+CGCR、完整模型四条。完整模型黑色实线、空心倒三角；图上方标虚警率，坐标为SCR(dB)和Pd。保留37个真实原始点，不平滑、不横移，不合成缺失结果。各自CAL标阈值，另报实际AUDIT虚警与95%区间。未达到0.9时D90为NA，不外推。

仅重画已完成结果：

```bash
/root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  bash B284_TFSE_CGCR_FACTORIAL_V1/run_b284.sh --stage report
```

## 证据边界

这次补齐的是实际四因素组合，不保证CGCR产生明显增益。B283中完整CGCR相对同预算control的D90改善只有约0.026dB（1e-4）和0dB（1e-5）；所有已完成结果保留。TFSE和CGCR的来源、公式和各自固定预处理应如实描述。已反复使用的DEV不能称为新的独立最终TEST。

本机测试使用合成IQ、合成检查点和评分夹具；不会声称已经在用户真实3080Ti/权重上训练出新Pd。实际AutoDL启动时会执行优化器预检与源检查点回放。
