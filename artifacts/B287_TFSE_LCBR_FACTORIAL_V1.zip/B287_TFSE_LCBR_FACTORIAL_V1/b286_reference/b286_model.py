"""Original WVD ADN, with optional refinement AFTER Stage2's native BN/add."""
import copy
import torch
from torch import nn
from b286_common import need
from b286_broadcast import BroadcastRefiner
from b282_model import tensor_hash


class Model(nn.Module):
    def __init__(self,reference,arm):
        super().__init__()
        need(arm in ('ADN','BGMSA','LCBR'),'Unknown B286 arm')
        self.arm=arm;self.net=copy.deepcopy(reference)
        self.net.requires_grad_(True)
        self.refiner=BroadcastRefiner(arm=='LCBR') if arm!='ADN' else None
        for m in self.net.modules():
            if isinstance(m,nn.modules.batchnorm._BatchNorm):m.requires_grad_(False)
        self.train(False)

    def train(self,mode=True):
        super().train(mode)
        for m in self.net.modules():
            if isinstance(m,nn.modules.batchnorm._BatchNorm):m.eval()
        return self

    def prepared_forward(self,images,unused=None,return_aux=False):
        d=self.net.detector
        x=d.maxpool(d.relu(d.bn1(d.conv1(images))))
        x=d.layer2(d.layer1(x));aux={}
        if self.refiner is not None:
            delta,aux=self.refiner.components(x);x=x+delta
        x=d.layer4(d.layer3(x))
        logits=d.fc(torch.flatten(d.avgpool(x),1))
        return (logits,aux) if return_aux else logits

    def forward(self,images):return self.prepared_forward(images)


@torch.inference_mode()
def initial_check(model,reference,images):
    model.eval();reference.eval()
    difference=float((model.prepared_forward(images)-reference.prepared_forward(images)).abs().max())
    need(difference<=1e-6,'Adapter must start at the unchanged source ADN function')
    count=sum(type(m).__name__=='SimAM' for m in model.net.modules())
    need(count==8,'Retain all8 original SimAM modules')
    shared=tensor_hash(model.net.state_dict())
    need(shared==tensor_hash(reference.state_dict()),'Source ADN tensors changed')
    return dict(maxabs_logit_difference=difference,shared_ADN_sha256=shared,
        total_parameters=sum(p.numel() for p in model.parameters()),
        extra_parameters=sum(p.numel() for p in model.refiner.parameters()) if model.refiner else 0,
        original_SimAM_count=count,position='after complete layer2; before layer3; outside frozen BN',
        classifier_input='unchanged original WVD',TFSE=False,CGCR=False,TFCG=False,Tail=False,
        external_IQ_consistency=False,local_contrast_conditioning=model.arm=='LCBR')
