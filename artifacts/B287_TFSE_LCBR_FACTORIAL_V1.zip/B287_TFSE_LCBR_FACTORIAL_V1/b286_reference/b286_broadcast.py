"""TIP2026 BGMSA adaptation and its local-contrast-conditioned variant.

Derived in part from bbbolt/BGAI (MIT); see third_party/BGAI_LICENSE.txt.
Paper: 10.1109/TIP.2026.3657640, Section III-B, Eqs.1-6.
This is a classification feature adapter, NOT the complete BGAI SR network.
No IAAI, reconstruction decoder, frequency experts or external guide is used.
"""
import torch
from torch import nn
import torch.nn.functional as F


def local_contrast(x, kernel=5):
    """Centre versus a leave-centre-out neighbourhood, using only this feature.

    This is a feature-contrast descriptor, not an estimated radar SCR or a target
    mask. Padding is excluded from the background mean/variance at boundaries.
    """
    area=kernel*kernel
    count=F.avg_pool2d(torch.ones_like(x[:,:1]),kernel,1,kernel//2)*area-1
    count=count.clamp_min(1)
    mean=(F.avg_pool2d(x,kernel,1,kernel//2)*area-x)/count
    second=(F.avg_pool2d(x.square(),kernel,1,kernel//2)*area-x.square())/count
    variance=(second-mean.square()).clamp_min(1e-3)
    value=torch.log1p(((x-mean).square()/variance).mean(1,keepdim=True).clamp_max(1e4))
    return value/(value.square().mean((-2,-1),keepdim=True).sqrt()+1e-6)


class WindowAttention(nn.Module):
    """BGAI single-head Q=Conv(X), K=X, V=Conv(X), depthwise local position."""
    def __init__(self, width, height, length):
        super().__init__()
        self.window=(height,length)
        self.query=nn.Conv2d(width,width,1)
        self.value=nn.Conv2d(width,width,1)
        self.local_position=nn.Conv2d(width,width,5,padding=2,groups=width)
        self.scale=width**-.5

    def partition(self,x):
        b,c,h,w=x.shape;wh,ww=self.window
        if h%wh or w%ww:raise ValueError('Window input must be padded first')
        return x.reshape(b,c,h//wh,wh,w//ww,ww).permute(0,2,4,3,5,1).reshape(-1,wh*ww,c)

    def unpartition(self,x,shape):
        b,c,h,w=shape;wh,ww=self.window
        return x.reshape(b,h//wh,w//ww,wh,ww,c).permute(0,5,1,3,2,4).reshape(b,c,h,w)

    def forward(self,x):
        value=self.value(x);position=self.local_position(value)
        q=self.partition(self.query(x)+position)
        k=self.partition(x+position)
        v=self.partition(value)
        weights=torch.softmax((q*self.scale)@k.transpose(-2,-1),dim=-1)
        return self.unpartition(weights@v,x.shape)+position


class BroadcastGate(nn.Module):
    """BGAI reset/update fusion gates; optional contrast logits added separately."""
    def __init__(self, local, router):
        super().__init__()
        self.reset=nn.Conv2d(local+router,router,1)
        self.update=nn.Conv2d(local+router,local,1)
        self.fusion=nn.Conv2d(local+router,local,1)
        self.extract=nn.Conv2d(router,local,1)

    def forward(self,x,router,contrast=None,conditioner=None):
        joint=torch.cat((x,router),1)
        reset,update=self.reset(joint),self.update(joint)
        if conditioner is not None:
            extra=conditioner(contrast)
            a,b=extra.split((router.shape[1],x.shape[1]),1)
            reset=reset+a;update=update+b
        reset,update=torch.sigmoid(reset),torch.sigmoid(update)
        candidate=torch.tanh(self.fusion(torch.cat((x,router*reset),1)))
        return (1-update)*self.extract(router)+update*candidate


class BroadcastRefiner(nn.Module):
    """128x28x28 ADN Stage2 feature -> same shape, with an identity start.

    Router/local window pattern follows the author's global, vertical,
    horizontal and square heads. Window14 and split7 suit ADN's28x28 feature.
    The LCBR variant adds ONLY the local-contrast inputs to the broadcast gates.
    Shared BGMSA tensors initialize identically for the two variants.
    """
    def __init__(self,contrast=False,channels=128):
        super().__init__()
        self.contrast=bool(contrast)
        width=channels//5
        self.norm=nn.LayerNorm(channels)
        self.router_projection=nn.Conv2d(channels,2*width,1)
        self.local_projection=nn.Conv2d(channels,3*width,1)
        self.router=WindowAttention(2*width,14,14)
        self.gates=nn.ModuleList([BroadcastGate(width,2*width) for _ in range(3)])
        self.locals=nn.ModuleList([WindowAttention(width,14,7),WindowAttention(width,7,14),WindowAttention(width,7,7)])
        self.output=nn.Conv2d(5*width,channels,1)
        # One zero factor only; output projection remains nonzero. Thus the
        # first step learns the residual gain, subsequent steps learn attention.
        self.gain=nn.Parameter(torch.zeros(()))
        self.conditioners=nn.ModuleList([nn.Conv2d(1,3*width,1,bias=False) for _ in range(3)]) if contrast else None
        if self.conditioners is not None:
            for layer in self.conditioners:nn.init.normal_(layer.weight,std=.02)

    def components(self,x):
        h,w=x.shape[-2:]
        z=self.norm(x.permute(0,2,3,1)).permute(0,3,1,2).contiguous()
        descriptor=local_contrast(z) if self.contrast else None
        pad=(0,(-w)%14,0,(-h)%14)
        z=F.pad(z,pad)
        if descriptor is not None:descriptor=F.pad(descriptor,pad)
        router=self.router(self.router_projection(z))
        streams=self.local_projection(z).chunk(3,1)
        outputs=[]
        for i,(stream,gate,attention) in enumerate(zip(streams,self.gates,self.locals)):
            if outputs:stream=stream+outputs[-1]
            conditioned=gate(stream,router,descriptor,self.conditioners[i] if self.conditioners is not None else None)
            outputs.append(attention(conditioned))
        raw=self.output(torch.cat((router,*outputs),1))[:,:,:h,:w]
        delta=torch.tanh(self.gain)*raw
        aux=dict(gain=torch.tanh(self.gain).detach(),delta_abs_mean=delta.detach().abs().mean(),
                 contrast_mean=descriptor.detach().mean() if descriptor is not None else x.new_zeros(()))
        return delta,aux

    def forward(self,x):
        return x+self.components(x)[0]
