"""Functional CPU checks. Synthetic fixtures are software tests, not radar results."""
import contextlib
import copy
import io
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock
import numpy as np
import torch
from torch import nn
import b286_common as common
from b286_broadcast import BroadcastRefiner,local_contrast
from b286_model import Model,initial_check
from b286_score import Cache,fill_predictions,stream
from b286_report import generate
from b286_train import train_arm
from b282_model import optimizer_for,tensor_hash
from b283_source import PlainADN

torch.set_num_threads(2)


class ArchitectureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.manual_seed(1);cls.base=PlainADN().eval().requires_grad_(False)
        cls.image=torch.randn(2,3,224,224)

    def test_original_ADN_identity_all_eight_SimAM_and_stage2_position(self):
        for arm in common.LABELS:
            torch.manual_seed(20261022);model=Model(self.base,arm)
            result=initial_check(model,self.base,self.image)
            self.assertEqual(result['maxabs_logit_difference'],0.)
            self.assertEqual(result['original_SimAM_count'],8)
            self.assertEqual(result['shared_ADN_sha256'],tensor_hash(self.base.state_dict()))
            self.assertFalse(result['TFSE'] or result['CGCR'] or result['TFCG'] or result['Tail'])

    def test_shared_borrowed_weights_identical_between_variants(self):
        torch.manual_seed(42);a=BroadcastRefiner(False).state_dict()
        torch.manual_seed(42);b=BroadcastRefiner(True).state_dict()
        for key,value in a.items():self.assertTrue(torch.equal(value,b[key]),key)
        self.assertTrue(any(k.startswith('conditioners.') for k in b))

    def test_both_modules_learn_and_native_BN_stays_frozen(self):
        for arm in common.ARMS:
            torch.manual_seed(5);model=Model(self.base,arm).train()
            running={k:v.clone() for k,v in model.net.named_buffers()}
            optimizer=optimizer_for(model,1e-5,3e-4)
            for _ in range(3):
                optimizer.zero_grad(set_to_none=True)
                loss=nn.functional.cross_entropy(model(self.image),torch.tensor([0,1]));loss.backward();optimizer.step()
            self.assertTrue(torch.isfinite(loss))
            self.assertGreater(abs(float(model.refiner.gain.detach())),0)
            self.assertGreater(float(model.refiner.router_projection.weight.grad.abs().sum()),0)
            self.assertGreater(float(model.net.detector.conv1.weight.grad.abs().sum()),0)
            for key,value in model.net.named_buffers():self.assertTrue(torch.equal(value,running[key]),key)
            for layer in model.net.modules():
                if isinstance(layer,nn.modules.batchnorm._BatchNorm):self.assertFalse(layer.training)
            model.eval()
            with torch.inference_mode():logits,aux=model.prepared_forward(self.image,return_aux=True)
            self.assertEqual(tuple(logits.shape),(2,2));self.assertGreater(float(aux['delta_abs_mean']),0)
            if arm=='LCBR':self.assertGreater(float(model.refiner.conditioners[0].weight.grad.abs().sum()),0)

    def test_non_multiple_windows_roundtrip_and_zero_start(self):
        for hw in [(28,28),(15,19)]:
            value=torch.randn(2,128,*hw)
            for mode in (False,True):
                module=BroadcastRefiner(mode)
                with torch.inference_mode():out=module(value)
                self.assertTrue(torch.equal(out,value))

    def test_local_contrast_constant_spike_and_gradients(self):
        self.assertLess(float(local_contrast(torch.ones(1,3,17,17)).abs().max()),1e-4)
        value=torch.zeros(1,3,17,17);value[:,:,8,8]=3;value.requires_grad_()
        contrast=local_contrast(value)
        self.assertGreater(float(contrast[0,0,8,8].detach()),float(contrast[0,0,0,0].detach()))
        contrast.sum().backward();self.assertTrue(torch.isfinite(value.grad).all())


class TinyModel(nn.Module):
    """Fast classification fixture used ONLY for training-state/resume tests."""
    def __init__(self,base,arm):
        super().__init__();self.net=copy.deepcopy(base)
        self.refiner=nn.Linear(3,3);self.gain=nn.Parameter(torch.zeros(()))
    def prepared_forward(self,x,unused=None,return_aux=False):
        delta=self.gain*self.refiner(x);z=self.net(x+delta)
        aux=dict(delta_abs_mean=delta.detach().abs().mean())
        return (z,aux) if return_aux else z


class PipelineTests(unittest.TestCase):
    def test_embedded_sources_match(self):
        common.validate_reference()
        self.assertTrue(common.code_hashes()['B286'])

    def test_masked_inference_preserves_cached_scores(self):
        class Predictor:
            def __init__(self,n):self.n=n
            def prepared_forward(self,image):
                v=image.flatten(1).mean(1)+self.n
                return torch.stack((-v,v),1)
        source=SimpleNamespace(wvd_base_map=lambda x:x.real[:,None,:],map_to_adn_input=lambda x:x)
        iq=np.ones((7,512),np.complex64);out=np.full((7,3),-123.,dtype=np.float64)
        missing=np.ones(out.shape,bool);missing[:,0]=False
        models={k:Predictor(i) for i,k in enumerate(common.LABELS)}
        with mock.patch('b286_score.load_frozen_sources',return_value=(source,None,None)):
            value=fill_predictions(models,iq,missing,out.copy(),torch.device('cpu'),3)
        self.assertTrue(np.all(value[:,0]==-123.))
        self.assertTrue(np.all(value[:,1]==4.));self.assertTrue(np.all(value[:,2]==6.))

    def test_stream_interruption_resumes_without_changing_committed_rows(self):
        def compute(info,models,p,cache,split,start,stop,device,batch,j=None):
            base=np.arange(start,stop,dtype=float)[:,None]+np.arange(3)[None,:]
            return base+(100*(j or 0) if split=='h1' else 0)
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp)/'scores';p=dict(h0_cal_n=9,h0_audit_n=7,h1_scenes_n=4,scr_grid_db=list(range(-24,13)),fingerprint='synthetic-test-only')
            args=SimpleNamespace(out_dir=folder,chunk=4,batch=2,device=torch.device('cpu'))
            count=0
            def interrupted(*args,**kwargs):
                nonlocal count
                count+=1
                if count==2:raise RuntimeError('simulated network/process interruption')
                return compute(*args,**kwargs)
            with mock.patch('b286_score.compute_chunk',side_effect=interrupted),contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaisesRegex(RuntimeError,'simulated'):stream(args,None,None,p,Cache())
            progress=common.read_json(folder/'progress.json');self.assertEqual(progress['completed']['h0_cal'],4)
            first=np.load(folder/common.FILES['h0_cal'])[:4].copy()
            with mock.patch('b286_score.compute_chunk',side_effect=compute),contextlib.redirect_stdout(io.StringIO()):stream(args,None,None,p,Cache())
            self.assertTrue(np.array_equal(np.load(folder/common.FILES['h0_cal'])[:4],first))
            self.assertEqual(common.read_json(folder/'progress.json')['completed'],dict(h0_cal=9,h0_audit=7,h1=37))
            for j in (0,24,36):self.assertTrue(np.array_equal(np.load(folder/common.FILES['h1'])[j],compute(None,None,p,None,'h1',0,4,None,None,j)))

    def test_three_curve_report_preserves_hits_and_Pfa(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp);p=dict(version='B286_BROADCAST_SCORE_V1',labels=list(common.LABELS),h0_cal_n=300000,h0_audit_n=200000,h1_scenes_n=16,
                scr_grid_db=list(range(-24,13)),nominal_pfas=[1e-4])
            p['fingerprint']=common.fingerprint(p)
            common.write_json(folder/'protocol_frozen.json',p)
            common.write_json(folder/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=300000,h0_audit=200000,h1=37)))
            rng=np.random.default_rng(12)
            cal=rng.normal(size=(300000,3));audit=rng.normal(size=(200000,3));h1=rng.normal(size=(37,16,3))+np.linspace(-5,5,37)[:,None,None]
            for split,value in [('h0_cal',cal),('h0_audit',audit),('h1',h1)]:np.save(folder/common.FILES[split],value)
            with contextlib.redirect_stdout(io.StringIO()):report=generate(folder)
            self.assertEqual(len(report['metrics']),3);self.assertFalse(report['curve_smoothing'])
            for i,row in enumerate(report['metrics']):self.assertEqual(row['audit_false_alarms'],int((audit[:,i]>row['threshold']).sum()))
            self.assertTrue((folder/'figures/b286_pd_scr_pfa_1e-04.pdf').is_file())
            self.assertTrue(np.array_equal(np.load(folder/common.FILES['h1']),h1))

    def test_optimizer_checkpoint_interruption_resume_matches_uninterrupted(self):
        x=torch.tensor([[1.,0.,0.],[0.,1.,0.],[.8,.1,0.],[.1,.8,0.]])
        y=np.array([0,1,0,1],dtype='int64')
        class Data:
            values=dict(train=(x,y),val=(x,y));selection=dict(train=dict(count=4),val=dict(count=4))
            def fetch(self,split,index,device,with_guide=False):return x[index].to(device),None,torch.tensor(y[index],device=device)
        data=Data();torch.manual_seed(7);base=nn.Linear(3,2)
        budget=dict(seed=23,epochs=3,batch=2,selected_rows=data.selection,backbone_lr=1e-5,new_module_lr=3e-4,loss='CE only',weight_decay=1e-4,optimizer='Adam')
        info=dict(base=base,budget=budget,lineage=dict(test_only='synthetic'))
        context=dict(bc=dict(file_sha256='synthetic'),b210=SimpleNamespace(indices=lambda labels,epoch,batch,seed:[np.arange(0,2),np.arange(2,4)]))
        import b286_train
        evaluate=b286_train.evaluate
        with tempfile.TemporaryDirectory() as tmp:
            args=SimpleNamespace(out_dir=Path(tmp)/'reference',device=torch.device('cpu'),batch=2);args.out_dir.mkdir()
            with mock.patch('b286_train.Model',TinyModel),mock.patch('b286_train.initial_check',return_value=dict(synthetic_test_only=True)),contextlib.redirect_stdout(io.StringIO()):
                anchor=evaluate(TinyModel(base,'LCBR'),data,args.device,2)
                reference=train_arm(args,context,info,data,anchor,'LCBR')
                expected=common.load_checkpoint(args.out_dir/'LCBR/last_epoch.pt')
                args.out_dir=Path(tmp)/'resumed';args.out_dir.mkdir();calls=0
                def fail_on_epoch2(*a,**k):
                    nonlocal calls
                    calls+=1
                    if calls==3:raise RuntimeError('simulated training interruption')
                    return evaluate(*a,**k)
                with mock.patch('b286_train.evaluate',side_effect=fail_on_epoch2):
                    with self.assertRaisesRegex(RuntimeError,'simulated'):train_arm(args,context,info,data,anchor,'LCBR')
                self.assertEqual(common.load_checkpoint(args.out_dir/'LCBR/last_epoch.pt')['epoch'],1)
                actual_ct=train_arm(args,context,info,data,anchor,'LCBR')
                actual=common.load_checkpoint(args.out_dir/'LCBR/last_epoch.pt')
                self.assertEqual(tensor_hash(expected['state_dict']),tensor_hash(actual['state_dict']))
                self.assertEqual(reference['selected_validation'],actual_ct['selected_validation'])


if __name__=='__main__':unittest.main()
