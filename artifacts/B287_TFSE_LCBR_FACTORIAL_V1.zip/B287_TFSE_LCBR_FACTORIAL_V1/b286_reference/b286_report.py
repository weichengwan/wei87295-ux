"""Three real Pd curves; label the Pfa and report actual held-out H0 alarms."""
from pathlib import Path
import numpy as np
from b286_common import LABELS,NAMES,FILES,need,read_json,write_json,fingerprint
from b273_statistics import metrics_for,save_csv


def generate(folder):
    folder=Path(folder);p=read_json(folder/'protocol_frozen.json');progress=read_json(folder/'progress.json')
    need(p['version']=='B286_BROADCAST_SCORE_V1' and p['labels']==list(LABELS),'Wrong B286 report protocol')
    need(p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==progress['fingerprint'],'Report identity differs')
    need(progress['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=37),'Scoring incomplete')
    arrays=[]
    for split,name in FILES.items():
        n=p['h1_scenes_n'] if split=='h1' else p[split+'_n'];shape=(37,n,3) if split=='h1' else (n,3)
        value=np.load(folder/name,mmap_mode='r',allow_pickle=False)
        need(value.shape==shape and value.dtype==np.float64,'Invalid score array');arrays.append(value)
    curves=[];metrics=[];lookup={}
    for col,label in enumerate(LABELS):
        cv,mt=metrics_for(NAMES[label],arrays[0][:,col],arrays[1][:,col],arrays[2][:,:,col],p)
        curves+=cv;metrics+=mt
        for row in mt:lookup[label,row['nominal_pfa']]=row
    comparisons=[]
    for nominal in p['nominal_pfas']:
        for candidate,reference in [('BGMSA','ADN'),('LCBR','ADN'),('LCBR','BGMSA')]:
            c,r=lookup[candidate,nominal],lookup[reference,nominal]
            difference=lambda k:None if c[k] is None or r[k] is None else c[k]-r[k]
            comparisons.append(dict(candidate=NAMES[candidate],reference=NAMES[reference],nominal_pfa=nominal,
                delta_D80_db=difference('D80_db'),delta_D90_db=difference('D90_db'),
                pd_at_0_gain_pp=100*difference('pd_at_0'),candidate_H0_false_alarms=c['audit_false_alarms'],
                reference_H0_false_alarms=r['audit_false_alarms'],negative_delta_means_left=True))
    for name,data in [('b286_metrics.csv',metrics),('b286_curves.csv',curves),('b286_comparisons.csv',comparisons)]:save_csv(folder/name,data)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    styles=dict(ADN=dict(color='#9467bd',marker='o'),BGMSA=dict(color='#1f77b4',marker='s'),LCBR=dict(color='black',marker='v'))
    out=folder/'figures';out.mkdir(exist_ok=True)
    for nominal in p['nominal_pfas']:
        fig,ax=plt.subplots(figsize=(7.5,4.8))
        for label in LABELS:
            rows=[r for r in curves if r['method']==NAMES[label] and r['nominal_pfa']==nominal]
            ax.plot([r['scr_db'] for r in rows],[r['pd'] for r in rows],label=NAMES[label],
                linestyle='-',linewidth=1.6,markevery=3,markersize=5,markerfacecolor='white',**styles[label])
        exponent=int(round(np.log10(nominal)))
        ax.set_title(r'Nominal $P_{fa}=10^{'+str(exponent)+'}$')
        ax.set_xlabel('SCR (dB)');ax.set_ylabel(r'$P_d$');ax.set_xlim(-24,12);ax.set_ylim(0,1.02)
        ax.grid(alpha=.25);ax.legend(fontsize=8);fig.tight_layout()
        for suffix in ('pdf','png','svg'):fig.savefig(out/f'b286_pd_scr_pfa_{nominal:.0e}.{suffix}',dpi=300)
        plt.close(fig)
    for row in comparisons:
        print(f'{row["candidate"]} vs {row["reference"]}; Pfa={row["nominal_pfa"]:.0e}: delta_D80={row["delta_D80_db"]}; delta_D90={row["delta_D90_db"]}; H0 FP={row["candidate_H0_false_alarms"]} vs {row["reference_H0_false_alarms"]}',flush=True)
    report=dict(status='PASS_B286_MEDIUM_REPORT' if p['h0_cal_n']==300000 else 'PASS_B286_FULL_REPORT',
        metrics=metrics,comparisons=comparisons,source_Pd_unchanged=True,curve_smoothing=False,
        fixed_checkpoints_selected_using_TRAIN_VAL_only=True,independent_final=False,
        novelty_or_improvement_established=False,
        interpretation='Negative delta is a descriptive DEV left shift. Inspect own actual Pfa and uncertainty; this screen is not independent confirmation.')
    write_json(folder/'b286_report.json',report)
    print('B286 complete: '+str(folder),flush=True);return report
