"""B286 TIP2026 broadcast adaptation: medium TRAIN->CAL->AUDIT->37-point Pd."""
import argparse
import gc
import shutil
from pathlib import Path
from types import SimpleNamespace
import torch
from b286_common import ROOT,LABELS,ARMS,NAMES,PASS,need,read_json,write_json,fingerprint,digest_file,load_checkpoint,code_hashes,validate_reference
from b286_model import Model
from b286_source import load_sources
from b286_train import train_arm,preflight
from b286_score import collect_cache,verify_cache,stream
from b271_data import device_for
from b273_shared import setup
from b274_data import resolve
from b284_data import prepare as old_prepare
from b283_run import acquire
from b282_source import SCENE_KEYS


class WVDOnlyData:
    def __init__(self,wrapped):
        self.wrapped=wrapped;self.values=wrapped.values;self.selection=wrapped.selection
    def fetch(self,split,index,device,with_guide=False):return self.wrapped.fetch(split,index,device,False)
    def close(self):self.wrapped.close()


def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=ROOT.parent)
    for key in ('b280-run','b284-run','out-dir','bank-dir','cache-dir'):p.add_argument('--'+key,type=Path)
    p.add_argument('--stage',choices=('all','preflight','train','score','report'),default='all')
    p.add_argument('--eval-size',choices=('medium','full'),default='medium')
    p.add_argument('--batch',type=int,default=32);p.add_argument('--chunk',type=int,default=512)
    p.add_argument('--device',choices=('cuda','cpu'),default='cuda');p.add_argument('--cpu-threads',type=int,default=4)
    p.add_argument('--wait-for-gpu',action='store_true');p.add_argument('--recompute-scores',action='store_true')
    a=p.parse_args(argv);a.root=a.root.resolve()
    for name,default in [('b280_run','output_b280_full_ablation_v1'),('b284_run','output_b284_tfse_cgcr_factorial_v1'),('out_dir','output_b286_adn_lcbr_v1')]:
        setattr(a,name,(getattr(a,name) or a.root/default).resolve())
    need(a.root.is_dir() and a.root in a.out_dir.parents,'Use a separate output inside project root')
    for source in (a.b280_run,a.b284_run):
        need(a.out_dir!=source and source not in a.out_dir.parents and a.out_dir not in source.parents,'Output overlaps old research results')
    need(a.batch==32 and a.chunk>=32 and a.chunk%32==0 and a.cpu_threads>0,'Use batch32, positive CPU threads and chunk multiple of32')
    a.device=device_for(a.device)
    return a


def load_models(a,info):
    models=dict(ADN=info['baseline']);contracts=dict(ADN=info['baseline_contract'])
    for arm in ARMS:
        folder=a.out_dir/arm;ct=read_json(folder/'training_contract.json');cfg=ct['run_config']
        need(ct['status']==PASS and cfg['arm']==arm and cfg['source_lineage']==info['lineage'] and cfg['code_sha256']==code_hashes(),'Candidate settings changed/incomplete')
        need(all(cfg[k]==v for k,v in info['budget'].items()),'Candidate budget differs from matched B284 ADN')
        path=folder/'best.pt';need(digest_file(path)==ct['checkpoint_sha256'],'Candidate checkpoint checksum differs')
        state=load_checkpoint(path)
        need(state['run_config']==cfg and state['run_fingerprint']==ct['run_fingerprint']==fingerprint(cfg) and state['epoch']==ct['best_epoch'],'Candidate checkpoint internal identity differs')
        model=Model(info['base'],arm).to(a.device)
        model.load_state_dict(state['state_dict'],strict=True);models[arm]=model.eval().requires_grad_(False);contracts[arm]=ct
    return models,contracts


def main(argv=None):
    a=cli(argv);setup(a.cpu_threads);validate_reference()
    score_dir=a.out_dir/('pd_scr_'+a.eval_size)
    if a.stage=='report':
        from b286_report import generate
        return generate(score_dir)
    print(f'B286 ADN + TIP2026 broadcast refinement | stage={a.stage} | eval={a.eval_size} | output={a.out_dir}',flush=True)
    with (a.root/'codex_b271_night.lock').open('a') as lock:
        acquire(lock,a.wait_for_gpu)
        context=resolve(a.root,a.bank_dir);info=load_sources(a,context)
        identity=dict(version='B286_ADN_LCBR_V1',source_lineage=info['lineage'],budget=info['budget'],
            code_sha256=code_hashes(),device=a.device.type,torch_version=str(torch.__version__))
        a.out_dir.mkdir(exist_ok=True);manifest=a.out_dir/'run_manifest.json'
        if manifest.exists():need(read_json(manifest)==identity,'Settings changed; preserve output and use a different --out-dir')
        else:
            need(not any(a.out_dir.iterdir()),'Nonempty output without run manifest');write_json(manifest,identity)
        if a.stage in ('all','train','preflight'):
            need(shutil.disk_usage(a.out_dir).free>=1024**3,'Require1GiB free for candidates; preserve old results')
            # Reuse the tested immutable TRAIN/VAL WVD row/cache verifier.
            proxy=dict(budget=info['budget'],models=dict(A1_frozen=SimpleNamespace(scale=1.)))
            data=WVDOnlyData(old_prepare(a,context,proxy))
            try:
                path=a.out_dir/'preflight.json'
                if path.exists():
                    result=read_json(path);need(result['run_fingerprint']==fingerprint(identity),'Preflight identity changed')
                    anchor=result['result']['original_A0']
                else:
                    anchor,result=preflight(a,info,data);write_json(path,dict(run_fingerprint=fingerprint(identity),result=result))
                if a.stage=='preflight':return
                for arm in ARMS:train_arm(a,context,info,data,anchor,arm)
            finally:data.close()
            if a.stage=='train':return
        models,contracts=load_models(a,info)
        cache=collect_cache(a,info,contracts)
        scene={k:info['p'][k] for k in SCENE_KEYS}
        if a.eval_size=='medium':scene.update(h0_cal_n=300000,h0_audit_n=200000,h1_scenes_n=512)
        p=dict(version='B286_BROADCAST_SCORE_V1',**scene,scene_fingerprint=fingerprint(scene),
            labels=list(LABELS),names=NAMES,ours_label='LCBR',nominal_pfas=[1e-4] if a.eval_size=='medium' else [1e-4,1e-5],
            training_contracts=contracts,source_lineage=info['lineage'],score_cache_sources=cache.records,
            code_sha256=code_hashes(),batch=a.batch,chunk=a.chunk,device=a.device.type,torch_version=str(torch.__version__),amp=False,tf32=False,
            score_definition='float64(float32 logit1 - float32 logit0)',strict_decision='score > own H0 CAL threshold',
            training_budget_unchanged_from_B284=True,training_rows=16000,validation_rows=5000,continuation_epochs=6,
            original_WVD_input=True,TFSE_used=False,CGCR_used=False,TFCG_used=False,Tail_used=False,
            independent_final=False,scope='Paired exposed SIM-R10 DEV screen; native ADN control reused; two BGMSA feature adaptations, no original SR-network reproduction claim')
        p['fingerprint']=fingerprint(p)
        path=a.out_dir/('cache_numeric_probe_'+a.eval_size+'.json')
        if path.exists():need(read_json(path)['protocol_fingerprint']==p['fingerprint'],'Cache replay identity changed')
        else:write_json(path,dict(protocol_fingerprint=p['fingerprint'],checks=verify_cache(info,models,cache,a.device,a.batch)))
        need(shutil.disk_usage(a.out_dir).free>=256*1024**2,'Require256MiB free for evaluation arrays/reports')
        print(f'ADN control reused; CAL={p["h0_cal_n"]:,}; AUDIT={p["h0_audit_n"]:,}; H1={p["h1_scenes_n"]}x37; Pfa={p["nominal_pfas"]}',flush=True)
        stream(SimpleNamespace(out_dir=score_dir,batch=a.batch,chunk=a.chunk,device=a.device),info,models,p,cache)
        del models,info;gc.collect()
        if a.device.type=='cuda':torch.cuda.empty_cache()
        from b286_report import generate
        result=generate(score_dir)
        if a.eval_size=='medium':print('Stopped after medium DEV. Review b286_comparisons.csv/Pd/actual Pfa before requesting full evaluation.',flush=True)
        return result


if __name__=='__main__':main()
