"""Complete TFSE x LCBR experiment, preserving the released B286 package."""
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REFERENCE=ROOT/'b286_reference'
sys.path.insert(0,str(REFERENCE))
import b286_common as previous
from b286_common import need,read_json,write_json,fingerprint,digest_file,load_checkpoint

LABELS=('ADN','TFSE','LCBR','FULL')
NAMES=dict(ADN='ADN',TFSE='ADN + TFSE',LCBR='ADN + LCBR',FULL='ADN + TFSE + LCBR (Ours)')
FACTORS=dict(ADN=(False,False),TFSE=(True,False),LCBR=(False,True),FULL=(True,True))
FILES=dict(h0_cal='h0_cal_scores.npy',h0_audit='h0_audit_scores.npy',h1='dev_h1_scores.npy')
PASS='PASS_B287_TFSE_LCBR_TRAIN_VAL_ONLY'


def validate_reference():
    for name,expected in read_json(ROOT/'b286_release_sources.json').items():
        need(digest_file(REFERENCE/name)==expected,'Embedded B286 file changed: '+name)
    previous.validate_reference()


def code_hashes():
    return dict(B287={p.name:digest_file(p) for p in sorted(ROOT.glob('*.py'))},
                reference=digest_file(ROOT/'b286_release_sources.json'))
