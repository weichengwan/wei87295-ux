"""Complete both required effects: LCBR>ADN and TFSE+LCBR>TFSE."""
import argparse
import copy
import gc
import shutil
from pathlib import Path
from types import SimpleNamespace
import torch
from b287_common import ROOT,LABELS,NAMES,FACTORS,PASS,need,read_json,write_json,fingerprint,digest_file,load_checkpoint,code_hashes,validate_reference
from b287_source import load_sources,standalone_folder,load_standalone
from b287_model import JointModel
from b287_train import TFSEData,train_joint,preflight
from b287_score import collect_cache,verify_cache,stream
from b286_common import code_hashes as wvd_hashes
from b286_train import train_arm as train_wvd,preflight as preflight_wvd
from b286_run import WVDOnlyData
from b284_data import prepare as prepare_wvd
from b271_data import device_for
from b273_shared import setup
from b274_data import resolve,Data
from b283_run import acquire
from b282_source import SCENE_KEYS


def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=ROOT.parent)
    for key in ('b280-run','b282-run','b284-run','b286-run','out-dir','bank-dir','cache-dir'):p.add_argument('--'+key,type=Path)
    p.add_argument('--stage',choices=('all','preflight','train','score','report'),default='all')
    p.add_argument('--eval-size',choices=('medium','full'),default='medium')
    p.add_argument('--batch',type=int,default=32);p.add_argument('--chunk',type=int,default=512)
    p.add_argument('--device',choices=('cuda','cpu'),default='cuda');p.add_argument('--cpu-threads',type=int,default=4)
    p.add_argument('--wait-for-gpu',action='store_true');p.add_argument('--recompute-scores',action='store_true')
    a=p.parse_args(argv);a.root=a.root.resolve()
    for name,default in [('b280_run','output_b280_full_ablation_v1'),('b282_run','output_b282_a1_cfexpert_v1'),
                         ('b284_run','output_b284_tfse_cgcr_factorial_v1'),('b286_run','output_b286_adn_lcbr_v1'),
                         ('out_dir','output_b287_tfse_lcbr_factorial_v1')]:
        setattr(a,name,(getattr(a,name) or a.root/default).resolve())
    need(a.root.is_dir() and a.root in a.out_dir.parents,'Use a separate B287 output inside project root')
    for source in (a.b280_run,a.b282_run,a.b284_run,a.b286_run):
        need(a.out_dir!=source and source not in a.out_dir.parents and a.out_dir not in source.parents,'Output overlaps existing results')
    need(a.batch==32 and a.chunk>=32 and a.chunk%32==0 and a.cpu_threads>0,'Use batch32 and chunk multiple of32')
    a.device=device_for(a.device);return a


def prepare_standalone(a,context,info,folder,mode,preflight_only=False):
    if mode=='existing_B286':
        load_standalone(folder,info,a.device)
        print('Reuse completed B286 LCBR; no standalone retraining',flush=True);return
    sa=copy.copy(a);sa.out_dir=folder.parent;sa.out_dir.mkdir(exist_ok=True)
    proxy=dict(budget=info['budget'],models=dict(A1_frozen=SimpleNamespace(scale=1.)))
    data=WVDOnlyData(prepare_wvd(sa,context,proxy))
    try:
        check_path=sa.out_dir/'preflight.json'
        identity=dict(source_lineage=info['wvd']['lineage'],budget=info['budget'],code_sha256=wvd_hashes(),device=a.device.type,torch_version=str(torch.__version__))
        if check_path.exists():
            check=read_json(check_path);need(check['identity']==identity,'Standalone preflight changed')
            anchor=check['result']['original_A0']
        else:
            anchor,result=preflight_wvd(sa,info['wvd'],data)
            write_json(check_path,dict(identity=identity,result=result))
        if not preflight_only:
            print('B286 LCBR result unavailable; train only this missing standalone cell in B287, preserving B286.',flush=True)
            train_wvd(sa,context,info['wvd'],data,anchor,'LCBR')
    finally:data.close()


def load_models(a,info,standalone):
    independent,ct=load_standalone(standalone,info,a.device)
    models=dict(ADN=info['wvd']['baseline'],TFSE=info['tfse_control'],LCBR=independent)
    contracts=dict(ADN=info['wvd']['baseline_contract'],TFSE=info['tfse_contract'],LCBR=ct)
    folder=a.out_dir/'FULL';ct=read_json(folder/'training_contract.json');cfg=ct['run_config']
    need(ct['status']==PASS and cfg['arm']=='FULL' and cfg['source_lineage']==info['lineage'] and cfg['code_sha256']==code_hashes(),'Joint candidate changed/incomplete')
    need(all(cfg[k]==v for k,v in info['budget'].items()),'Joint budget differs from matched controls')
    path=folder/'best.pt';need(digest_file(path)==ct['checkpoint_sha256'],'Joint checkpoint checksum differs')
    state=load_checkpoint(path)
    need(state['run_config']==cfg and state['run_fingerprint']==ct['run_fingerprint']==fingerprint(cfg) and state['epoch']==ct['best_epoch'],'Joint checkpoint internal identity differs')
    model=JointModel(info['a1']).to(a.device);model.load_state_dict(state['state_dict'],strict=True)
    models['FULL']=model.eval().requires_grad_(False);contracts['FULL']=ct
    return models,contracts


def main(argv=None):
    a=cli(argv);setup(a.cpu_threads);validate_reference();score_dir=a.out_dir/('pd_scr_'+a.eval_size)
    if a.stage=='report':
        from b287_report import generate
        return generate(score_dir)
    print(f'B287 TFSE x LCBR four-model check | stage={a.stage} | eval={a.eval_size} | output={a.out_dir}',flush=True)
    with (a.root/'codex_b271_night.lock').open('a') as lock:
        acquire(lock,a.wait_for_gpu);context=resolve(a.root,a.bank_dir);info=load_sources(a,context)
        identity=dict(version='B287_TFSE_LCBR_FACTORIAL_V1',source_lineage=info['lineage'],budget=info['budget'],
            code_sha256=code_hashes(),device=a.device.type,torch_version=str(torch.__version__))
        a.out_dir.mkdir(exist_ok=True);path=a.out_dir/'run_manifest.json'
        if path.exists():need(read_json(path)==identity,'Settings changed; preserve output and use another --out-dir')
        else:
            need(not any(a.out_dir.iterdir()),'Nonempty B287 output without manifest');write_json(path,identity)
        standalone,mode=standalone_folder(a)
        if a.stage in ('all','train','preflight'):
            needed=1024**3 if mode=='existing_B286' else 2*1024**3
            need(shutil.disk_usage(a.out_dir).free>=needed,'Not enough free space for missing candidate checkpoints; keep existing results')
            prepare_standalone(a,context,info,standalone,mode,a.stage=='preflight')
            raw=Data(context,info['budget']['selected_rows']['train']['count'],info['budget']['selected_rows']['val']['count'],info['budget']['seed'])
            need(raw.selection==info['budget']['selected_rows'],'Joint TRAIN/VAL rows differ from matched controls')
            data=TFSEData(raw,info['a1'].scale);path=a.out_dir/'joint_preflight.json'
            if path.exists():
                result=read_json(path);need(result['run_fingerprint']==fingerprint(identity),'Joint preflight identity changed')
                anchor=result['result']['original_A1']
            else:
                anchor,result=preflight(a,info,data);write_json(path,dict(run_fingerprint=fingerprint(identity),result=result))
            if a.stage=='preflight':return
            train_joint(a,context,info,data,anchor)
            del data,raw;gc.collect()
            if a.device.type=='cuda':torch.cuda.empty_cache()
            if a.stage=='train':return
        models,contracts=load_models(a,info,standalone);cache=collect_cache(a,info,contracts)
        scene={k:info['p'][k] for k in SCENE_KEYS}
        if a.eval_size=='medium':scene.update(h0_cal_n=300000,h0_audit_n=200000,h1_scenes_n=512)
        p=dict(version='B287_TFSE_LCBR_SCORE_V1',**scene,scene_fingerprint=fingerprint(scene),
            labels=list(LABELS),names=NAMES,factors={k:list(v) for k,v in FACTORS.items()},ours_label='FULL',
            nominal_pfas=[1e-4] if a.eval_size=='medium' else [1e-4,1e-5],
            training_contracts=contracts,source_lineage=info['lineage'],standalone_source=str(standalone),score_cache_sources=cache.records,
            code_sha256=code_hashes(),batch=a.batch,chunk=a.chunk,device=a.device.type,torch_version=str(torch.__version__),amp=False,tf32=False,
            score_definition='float64(float32 logit1 - float32 logit0)',strict_decision='score > own H0 CAL threshold',
            matched_maximum_phase_budgets=True,training_rows=16000,validation_rows=5000,continuation_epochs=6,
            two_required_contrasts=[['LCBR','ADN'],['FULL','TFSE']],strict_2x2_factorial=True,
            CGCR_used=False,TFCG_used=False,Tail_used=False,independent_final=False,
            scope='Paired exposed SIM-R10 DEV; all four cells. Existing ADN and TFSE controls reused; standalone LCBR reused when complete; joint candidate starts at original A1, not a further-trained control.')
        p['fingerprint']=fingerprint(p);path=a.out_dir/('cache_numeric_probe_'+a.eval_size+'.json')
        if path.exists():need(read_json(path)['protocol_fingerprint']==p['fingerprint'],'Cache replay identity changed')
        else:write_json(path,dict(protocol_fingerprint=p['fingerprint'],checks=verify_cache(info,models,cache,a.device,a.batch)))
        need(shutil.disk_usage(a.out_dir).free>=256*1024**2,'Require256MiB free for four-column scores/reports')
        print(f'Four cells: CAL={p["h0_cal_n"]:,}; AUDIT={p["h0_audit_n"]:,}; H1={p["h1_scenes_n"]}x37; Pfa={p["nominal_pfas"]}',flush=True)
        stream(SimpleNamespace(out_dir=score_dir,batch=a.batch,chunk=a.chunk,device=a.device),info,models,p,cache)
        del models,info;gc.collect()
        if a.device.type=='cuda':torch.cuda.empty_cache()
        from b287_report import generate
        result=generate(score_dir)
        if a.eval_size=='medium':print('Stopped after medium DEV; require BOTH standalone and with-TFSE gains before progressing.',flush=True)
        return result


if __name__=='__main__':main()
