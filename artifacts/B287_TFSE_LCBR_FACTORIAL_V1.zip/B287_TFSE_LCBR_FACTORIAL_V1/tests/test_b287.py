"""Functional software checks; synthetic fixtures are not measured radar results."""
import contextlib
import copy
import io
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock
import numpy as np
import torch
from torch import nn
import b287_common as common
from b287_model import JointModel,initial_check
from b287_score import Cache,fill_predictions,stream
from b287_report import comparisons_for,generate
from b287_source import standalone_folder
from b287_train import train_joint
from b282_model import A1Core,Candidate,optimizer_for,tensor_hash
from b280_frontend import smoothing_bank
from b286_broadcast import BroadcastRefiner

torch.set_num_threads(2)


class ArchitectureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.manual_seed(2);cls.a1=A1Core(1.).eval().requires_grad_(False)
        # Nonzero learned-style frontend controls ensure the adapter preserves
        # a trained TFSE function, not merely its initial window5 identity.
        with torch.no_grad():
            nn.init.normal_(cls.a1.gate.head.weight,std=.03)
            nn.init.normal_(cls.a1.gate.head.bias,std=.03)
        cls.bank=smoothing_bank(torch.randn(2,512,dtype=torch.complex64),1.)

    def test_joint_identity_to_original_A1_and_existing_TFSE_control(self):
        for refine in (False,True):
            torch.manual_seed(20261022);model=JointModel(self.a1,refine)
            result=initial_check(model,self.a1,self.bank)
            self.assertEqual(result['maxabs_logit_difference'],0.)
            self.assertEqual(result['original_SimAM_count'],8)
            self.assertEqual(result['LCBR'],refine)
        control=Candidate(self.a1,'control').eval()
        with torch.inference_mode():
            self.assertTrue(torch.equal(control.prepared_forward(self.bank),JointModel(self.a1,False).prepared_forward(self.bank)))

    def test_same_module_initial_tensors_in_both_factor_levels(self):
        torch.manual_seed(20261022);expected=BroadcastRefiner(True).state_dict()
        torch.manual_seed(20261022);actual=JointModel(self.a1).refiner.state_dict()
        self.assertEqual(tensor_hash(expected),tensor_hash(actual))

    def test_joint_learns_while_TFSE_and_native_BN_remain_unchanged(self):
        torch.manual_seed(4);model=JointModel(self.a1)
        before={k:v.clone() for k,v in model.net.gate.state_dict().items()}
        running={k:v.clone() for k,v in model.net.detector.named_buffers()}
        optimizer=optimizer_for(model,1e-5,3e-4);model.train()
        for _ in range(3):
            optimizer.zero_grad(set_to_none=True)
            loss=nn.functional.cross_entropy(model.prepared_forward(self.bank),torch.tensor([0,1]));loss.backward();optimizer.step()
        self.assertTrue(torch.isfinite(loss))
        self.assertGreater(float(model.refiner.conditioners[0].weight.grad.abs().sum()),0)
        self.assertGreater(float(model.net.detector.conv1.weight.grad.abs().sum()),0)
        self.assertTrue(all(torch.equal(v,before[k]) for k,v in model.net.gate.state_dict().items()))
        self.assertTrue(all(torch.equal(v,running[k]) for k,v in model.net.detector.named_buffers()))
        self.assertTrue(all(p.grad is None for p in model.net.gate.parameters()))
        model.eval()
        with torch.inference_mode():_,aux=model.prepared_forward(self.bank,return_aux=True)
        self.assertGreater(float(aux['delta_abs_mean']),0)


def lookup_fixture(joint_d90=1.2):
    return {(label,1e-4):dict(D80_db=d90-1,D90_db=d90,pd_at_0=.5,audit_false_alarms=20)
            for label,d90 in [('ADN',5.),('TFSE',1.),('LCBR',4.),('FULL',joint_d90)]}


class PipelineTests(unittest.TestCase):
    def test_embedded_B286_sources_unchanged(self):
        common.validate_reference()
        self.assertTrue(common.code_hashes()['B287'])

    def test_standalone_gain_does_not_excuse_joint_regression_or_tie(self):
        for joint in (1.2,1.):
            rows,checks=comparisons_for(lookup_fixture(joint),[1e-4])
            self.assertEqual(checks[0]['standalone_D90'],'left')
            self.assertFalse(checks[0]['both_D90_improvements_descriptive'])
            self.assertEqual(len(rows),5)
        _,checks=comparisons_for(lookup_fixture(.8),[1e-4])
        self.assertTrue(checks[0]['both_D90_improvements_descriptive'])
        self.assertFalse(checks[0]['actual_Pfa_equivalence_established'])

    def test_unreached_D90_is_not_fabricated_as_a_numeric_gain(self):
        lookup=lookup_fixture(.8);lookup['ADN',1e-4]['D90_db']=None
        rows,checks=comparisons_for(lookup,[1e-4])
        self.assertEqual(checks[0]['standalone_D90'],'newly_reaches')
        self.assertIsNone(rows[0]['delta_D90_db'])

    def test_completed_B286_is_selected_and_choice_is_persistent(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);a=SimpleNamespace(out_dir=root/'new',b286_run=root/'old');a.out_dir.mkdir()
            (a.b286_run/'LCBR').mkdir(parents=True);common.write_json(a.b286_run/'LCBR/training_contract.json',{})
            folder,mode=standalone_folder(a)
            self.assertEqual(mode,'existing_B286');self.assertEqual(folder,a.b286_run/'LCBR')
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);a=SimpleNamespace(out_dir=root/'new',b286_run=root/'old');a.out_dir.mkdir()
            folder,mode=standalone_folder(a);self.assertEqual(mode,'own_missing_cell')
            (a.b286_run/'LCBR').mkdir(parents=True);common.write_json(a.b286_run/'LCBR/training_contract.json',{})
            self.assertEqual(standalone_folder(a),(folder,mode))

    def test_four_column_mask_and_WVD_TFSE_dispatch(self):
        class Predictor:
            scale=1.
            def __init__(self,n):self.n=n
            def prepared_forward(self,value):
                z=value.flatten(1).mean(1)+self.n
                return torch.stack((-z,z),1)
        source=SimpleNamespace(wvd_base_map=lambda x:x.real[:,None,:],map_to_adn_input=lambda x:x)
        iq=np.ones((7,512),dtype=np.complex64);out=np.zeros((7,4));out[:,0]=-123.
        missing=np.ones(out.shape,bool);missing[:,0]=False
        models={k:Predictor(i) for i,k in enumerate(common.LABELS)}
        with mock.patch('b287_score.load_frozen_sources',return_value=(source,None,None)),mock.patch('b287_score.smoothing_bank',side_effect=lambda x,s:x.real[:,None,:]+10):
            value=fill_predictions(models,iq,missing,out.copy(),torch.device('cpu'),3)
        for i,target in enumerate((-123.,24.,6.,28.)):self.assertTrue(np.all(value[:,i]==target))

    def test_four_column_stream_resume_preserves_committed_scores(self):
        def compute(info,models,p,cache,split,start,stop,device,batch,j=None):
            return np.arange(start,stop,dtype=float)[:,None]+np.arange(4)[None,:]+(100*(j or 0) if split=='h1' else 0)
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp)/'scores';p=dict(h0_cal_n=9,h0_audit_n=7,h1_scenes_n=4,scr_grid_db=list(range(-24,13)),fingerprint='software-test-only')
            args=SimpleNamespace(out_dir=folder,chunk=4,batch=2,device=torch.device('cpu'));count=0
            def interrupted(*args,**kwargs):
                nonlocal count
                count+=1
                if count==2:raise RuntimeError('simulated interruption')
                return compute(*args,**kwargs)
            with mock.patch('b287_score.compute_chunk',side_effect=interrupted),contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaisesRegex(RuntimeError,'simulated'):stream(args,None,None,p,Cache())
            first=np.load(folder/common.FILES['h0_cal'])[:4].copy()
            with mock.patch('b287_score.compute_chunk',side_effect=compute),contextlib.redirect_stdout(io.StringIO()):stream(args,None,None,p,Cache())
            self.assertTrue(np.array_equal(np.load(folder/common.FILES['h0_cal'])[:4],first))
            self.assertEqual(common.read_json(folder/'progress.json')['completed'],dict(h0_cal=9,h0_audit=7,h1=37))
            self.assertEqual(np.load(folder/common.FILES['h1']).shape,(37,4,4))

    def test_four_model_report_preserves_raw_hits_and_lists_both_effects(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp);p=dict(version='B287_TFSE_LCBR_SCORE_V1',labels=list(common.LABELS),h0_cal_n=300000,h0_audit_n=200000,h1_scenes_n=16,
                scr_grid_db=list(range(-24,13)),nominal_pfas=[1e-4],training_contracts={})
            for k in common.LABELS:p['training_contracts'][k]=dict(run_config=dict(epochs=6,selected_rows=dict(train=dict(count=16000))),best_epoch=2)
            p['fingerprint']=common.fingerprint(p);common.write_json(folder/'protocol_frozen.json',p)
            common.write_json(folder/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=300000,h0_audit=200000,h1=37)))
            rng=np.random.default_rng(12);cal=rng.normal(size=(300000,4));audit=rng.normal(size=(200000,4))
            h1=rng.normal(size=(37,16,4))+np.linspace(-5,5,37)[:,None,None]
            for split,value in [('h0_cal',cal),('h0_audit',audit),('h1',h1)]:np.save(folder/common.FILES[split],value)
            with contextlib.redirect_stdout(io.StringIO()):report=generate(folder)
            self.assertEqual(len(report['metrics']),4);self.assertEqual(len(report['comparisons']),5)
            self.assertTrue(report['strict_2x2_factorial'])
            self.assertTrue((folder/'figures/b287_pd_scr_pfa_1e-04.pdf').is_file())
            self.assertTrue((folder/'b287_ablation_table_pfa_1e-04.pdf').is_file())
            self.assertTrue(np.array_equal(np.load(folder/common.FILES['h1']),h1))


class TinyA1(nn.Module):
    scale=1.
    def __init__(self):super().__init__();self.detector=nn.Linear(3,2)


class TinyRefiner(nn.Module):
    def __init__(self):super().__init__();self.proj=nn.Linear(3,3);self.gain=nn.Parameter(torch.zeros(()))
    def forward(self,x):return self.gain*self.proj(x)


class TinyJoint(nn.Module):
    def __init__(self,base):super().__init__();self.net=copy.deepcopy(base);self.refiner=TinyRefiner()
    def prepared_forward(self,x,unused=None,return_aux=False):
        delta=self.refiner(x);z=self.net.detector(x+delta)
        return (z,dict(delta_abs_mean=delta.detach().abs().mean())) if return_aux else z


class TrainingTests(unittest.TestCase):
    def test_joint_optimizer_resume_matches_uninterrupted_and_uses_A1(self):
        import b287_train
        evaluate=b287_train.evaluate
        x=torch.tensor([[1.,0.,0.],[0.,1.,0.],[.8,.1,0.],[.1,.8,0.]])
        y=np.array([0,1,0,1],dtype='int64')
        class Data:
            values=dict(train=(x,y),val=(x,y));selection=dict(train=dict(count=4),val=dict(count=4))
            def fetch(self,split,index,device,with_guide=False):return x[index].to(device),None,torch.tensor(y[index],device=device)
        data=Data();torch.manual_seed(7);base=TinyA1()
        budget=dict(seed=23,epochs=3,batch=2,selected_rows=data.selection,backbone_lr=1e-5,new_module_lr=3e-4,loss='CE only',weight_decay=1e-4,optimizer='Adam')
        info=dict(a1=base,budget=budget,lineage=dict(test_only='synthetic'))
        context=dict(bc=dict(file_sha256='synthetic'),b210=SimpleNamespace(indices=lambda *a:[np.arange(0,2),np.arange(2,4)]))
        with tempfile.TemporaryDirectory() as tmp:
            args=SimpleNamespace(out_dir=Path(tmp)/'reference',device=torch.device('cpu'),batch=2);args.out_dir.mkdir()
            with mock.patch('b287_train.JointModel',TinyJoint),mock.patch('b287_train.initial_check',return_value=dict(synthetic_test_only=True)),contextlib.redirect_stdout(io.StringIO()):
                torch.manual_seed(23);anchor=evaluate(TinyJoint(base),data,args.device,2)
                reference=train_joint(args,context,info,data,anchor);expected=common.load_checkpoint(args.out_dir/'FULL/last_epoch.pt')
                args.out_dir=Path(tmp)/'resumed';args.out_dir.mkdir();calls=0
                def fail(*a,**k):
                    nonlocal calls
                    calls+=1
                    if calls==3:raise RuntimeError('simulated training interruption')
                    return evaluate(*a,**k)
                with mock.patch('b287_train.evaluate',side_effect=fail):
                    with self.assertRaisesRegex(RuntimeError,'simulated'):train_joint(args,context,info,data,anchor)
                actual_ct=train_joint(args,context,info,data,anchor);actual=common.load_checkpoint(args.out_dir/'FULL/last_epoch.pt')
                self.assertEqual(tensor_hash(expected['state_dict']),tensor_hash(actual['state_dict']))
                self.assertEqual(reference['selected_validation'],actual_ct['selected_validation'])
                self.assertTrue(actual_ct['run_config']['source_A1_initialization'])
                self.assertTrue(actual_ct['run_config']['TFSE'] and actual_ct['run_config']['LCBR'])


if __name__=='__main__':unittest.main()
