"""Reuse matched ADN and TFSE controls, verify identical continuation budgets."""
import torch
from b287_common import need,read_json,write_json,load_checkpoint,fingerprint,digest_file,REFERENCE
from b286_source import load_sources as wvd_sources
from b286_common import PASS as WVD_PASS,code_hashes as wvd_hashes
from b286_model import Model as WVDModel
from b283_source import checked_checkpoint,CORE_IDENTITY
from b282_model import make_a1,Candidate
from b282_train import PASS as TFSE_PASS,code_hashes as tfse_hashes


def load_sources(a,context):
    wvd=wvd_sources(a,context)
    code=read_json(REFERENCE/'b284_reference/b283_reference/b282_reference/b280_release_sources.json')
    a1_ct,state=checked_checkpoint(a.b280_run/'A1','PASS_B280_FULL_TRAIN_VAL_ONLY',code,'A1')
    cfg=a1_ct['run_config']
    need(cfg['factor_A_joint_SPWVD'] and not cfg['factor_B_TFCG_Tail'] and cfg['bank_sha256']==context['bc']['file_sha256'],'Expected TFSE-only B280 A1')
    for key in ('seed','epochs','batch','lr','weight_decay','optimizer','selected_rows','bank_sha256'):
        need(cfg[key]==wvd['base_contract']['run_config'][key],'B280 A0/A1 initial budgets differ: '+key)
    a1=make_a1(state,a.device).eval().requires_grad_(False);del state
    control_ct,state=checked_checkpoint(a.b282_run/'control',TFSE_PASS,tfse_hashes(),'control')
    c=control_ct['run_config']
    need(all(c[k]==v for k,v in wvd['budget'].items()),'B282 TFSE control and B284 ADN budgets differ')
    need(c['bank_sha256']==context['bc']['file_sha256'] and c['scale']==a1.scale and c['frontend_frozen'] and c['native_BN_affine_and_running_frozen'],'TFSE control bank/frontend/BN policy differs')
    need(c['device']==a.device.type and c['torch_version']==str(torch.__version__),'Use the same mpdnet-r10 runtime as B282/B284')
    intrinsic=dict(A1_checkpoint_sha256=a1_ct['checkpoint_sha256'],A1_run_fingerprint=a1_ct['run_fingerprint'],
        source_protocol_sha256=digest_file(a.b280_run/'pd_scr_full/protocol_frozen.json'),source_selected_epoch=a1_ct['best_epoch'],
        source_device=wvd['p']['device'],source_torch_version=wvd['p']['torch_version'])
    need({k:c['source_identity'][k] for k in CORE_IDENTITY}==intrinsic,'TFSE control came from another A1/protocol')
    need(wvd['p']['base_contracts']['A1_frozen']==a1_ct and wvd['p']['training_contracts']['TFSE']==control_ct,'B284 TFSE scores refer to different weights')
    control=Candidate(a1,'control');control.load_state_dict(state['state_dict'],strict=True)
    control=control.to(a.device).eval().requires_grad_(False);del state
    lineage=dict(**wvd['lineage'],B280_A1=a1_ct['checkpoint_sha256'],B282_TFSE_control=control_ct['checkpoint_sha256'])
    return dict(wvd=wvd,a1=a1,a1_contract=a1_ct,tfse_control=control,tfse_contract=control_ct,
                budget=wvd['budget'],lineage=lineage,p=wvd['p'],generator=wvd['generator'])


def standalone_folder(a):
    """Commit the source choice so reruns cannot silently switch selected weights."""
    path=a.out_dir/'standalone_source.json'
    if path.exists():
        d=read_json(path)
        expected=a.b286_run/'LCBR' if d['mode']=='existing_B286' else a.out_dir/'standalone_wvd/LCBR'
        need(d['mode'] in ('existing_B286','own_missing_cell') and d['path']==str(expected),'Standalone source selection differs')
        return expected,d['mode']
    existing=a.b286_run/'LCBR'
    mode='existing_B286' if (existing/'training_contract.json').is_file() else 'own_missing_cell'
    selected=existing if mode=='existing_B286' else a.out_dir/'standalone_wvd/LCBR'
    write_json(path,dict(mode=mode,path=str(selected)))
    return selected,mode


def load_standalone(folder,info,device):
    ct,state=checked_checkpoint(folder,WVD_PASS,wvd_hashes(),'LCBR')
    cfg=ct['run_config'];wvd=info['wvd']
    need(cfg['source_lineage']==wvd['lineage'] and cfg['bank_sha256']==wvd['base_contract']['run_config']['bank_sha256'],'Standalone LCBR source differs')
    need(all(cfg[k]==v for k,v in info['budget'].items()) and cfg['local_contrast_conditioning'] and not cfg['TFSE'],'Standalone LCBR budget/factors differ')
    model=WVDModel(wvd['base'],'LCBR').to(device)
    model.load_state_dict(state['state_dict'],strict=True)
    return model.eval().requires_grad_(False),ct
