"""Four factor cells and BOTH independent incremental-effect checks."""
from pathlib import Path
import numpy as np
from b287_common import LABELS,NAMES,FACTORS,FILES,need,read_json,write_json,fingerprint
from b273_statistics import metrics_for,save_csv


def left_status(candidate,reference,key):
    c,r=candidate[key],reference[key]
    if c is None:return 'unreached' if r is not None else 'both_unreached'
    if r is None:return 'newly_reaches'
    return 'left' if c<r else 'tie' if c==r else 'right'


def comparisons_for(lookup,nominals):
    rows=[];checks=[]
    contrasts=[('LCBR','ADN','LCBR without TFSE'),('FULL','TFSE','LCBR with TFSE'),
               ('TFSE','ADN','TFSE without LCBR'),('FULL','LCBR','TFSE with LCBR'),('FULL','ADN','Complete method')]
    for nominal in nominals:
        for candidate,reference,description in contrasts:
            c,r=lookup[candidate,nominal],lookup[reference,nominal]
            delta=lambda k:None if c[k] is None or r[k] is None else c[k]-r[k]
            rows.append(dict(candidate=NAMES[candidate],reference=NAMES[reference],contrast=description,nominal_pfa=nominal,
                delta_D80_db=delta('D80_db'),delta_D90_db=delta('D90_db'),pd_at_0_gain_pp=100*delta('pd_at_0'),
                D80_comparison=left_status(c,r,'D80_db'),D90_comparison=left_status(c,r,'D90_db'),
                candidate_H0_false_alarms=c['audit_false_alarms'],reference_H0_false_alarms=r['audit_false_alarms'],
                negative_delta_means_left=True))
        standalone=left_status(lookup['LCBR',nominal],lookup['ADN',nominal],'D90_db')
        combined=left_status(lookup['FULL',nominal],lookup['TFSE',nominal],'D90_db')
        standalone80=left_status(lookup['LCBR',nominal],lookup['ADN',nominal],'D80_db')
        combined80=left_status(lookup['FULL',nominal],lookup['TFSE',nominal],'D80_db')
        improves=lambda state:state in ('left','newly_reaches')
        checks.append(dict(nominal_pfa=nominal,standalone_D90=standalone,combined_D90=combined,
            standalone_D80=standalone80,combined_D80=combined80,
            both_D90_improvements_descriptive=improves(standalone) and improves(combined),
            both_D80_improvements_descriptive=improves(standalone80) and improves(combined80),
            both_D80_D90_improvements_descriptive=all(map(improves,(standalone,combined,standalone80,combined80))),
            actual_Pfa_equivalence_established=False,independent_test_confirmation=False))
    return rows,checks


def generate(folder):
    folder=Path(folder);p=read_json(folder/'protocol_frozen.json');progress=read_json(folder/'progress.json')
    need(p['version']=='B287_TFSE_LCBR_SCORE_V1' and p['labels']==list(LABELS),'Unexpected four-factor protocol')
    need(p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==progress['fingerprint'],'Report identity differs')
    need(progress['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=37),'Scoring incomplete')
    arrays=[]
    for split,name in FILES.items():
        n=p['h1_scenes_n'] if split=='h1' else p[split+'_n'];shape=(37,n,4) if split=='h1' else (n,4)
        value=np.load(folder/name,mmap_mode='r',allow_pickle=False)
        need(value.shape==shape and value.dtype==np.float64,'Invalid four-column score array');arrays.append(value)
    curves=[];metrics=[];lookup={};table=[]
    for col,label in enumerate(LABELS):
        cv,mt=metrics_for(NAMES[label],arrays[0][:,col],arrays[1][:,col],arrays[2][:,:,col],p)
        curves+=cv;metrics+=mt
        for row in mt:
            lookup[label,row['nominal_pfa']]=row
            cfg=p['training_contracts'][label]['run_config']
            table.append(dict(group=label,TFSE=FACTORS[label][0],LCBR=FACTORS[label][1],
                continuation_epochs=cfg['epochs'],continuation_train_rows=cfg['selected_rows']['train']['count'],
                selected_epoch=p['training_contracts'][label]['best_epoch'],**row))
    comparisons,checks=comparisons_for(lookup,p['nominal_pfas'])
    for name,value in [('b287_curves.csv',curves),('b287_metrics.csv',metrics),('b287_ablation_table.csv',table),('b287_comparisons.csv',comparisons)]:save_csv(folder/name,value)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    styles=dict(ADN=dict(color='#9467bd',marker='o'),TFSE=dict(color='#ff7f0e',marker='s'),
                LCBR=dict(color='#2ca02c',marker='D'),FULL=dict(color='black',marker='v'))
    out=folder/'figures';out.mkdir(exist_ok=True)
    fmt=lambda value:'NA' if value is None else f'{value:.3f}'
    for nominal in p['nominal_pfas']:
        fig,ax=plt.subplots(figsize=(7.5,4.8))
        for label in LABELS:
            rows=[r for r in curves if r['method']==NAMES[label] and r['nominal_pfa']==nominal]
            ax.plot([r['scr_db'] for r in rows],[r['pd'] for r in rows],label=NAMES[label],linestyle='-',linewidth=1.6,
                    markevery=3,markersize=5,markerfacecolor='white',**styles[label])
        exponent=int(round(np.log10(nominal)))
        ax.set_title(r'Nominal $P_{fa}=10^{'+str(exponent)+'}$');ax.set_xlabel('SCR (dB)');ax.set_ylabel(r'$P_d$')
        ax.set_xlim(-24,12);ax.set_ylim(0,1.02);ax.grid(alpha=.25);ax.legend(fontsize=8);fig.tight_layout()
        for suffix in ('pdf','png','svg'):fig.savefig(out/f'b287_pd_scr_pfa_{nominal:.0e}.{suffix}',dpi=300)
        plt.close(fig)
        selected=[r for r in table if r['nominal_pfa']==nominal]
        values=[[r['method'],int(r['TFSE']),int(r['LCBR']),fmt(r['D80_db']),fmt(r['D90_db']),f'{r["audit_false_alarms"]}/{r["audit_n"]:,}'] for r in selected]
        fig,ax=plt.subplots(figsize=(10,2.6));ax.axis('off')
        tab=ax.table(cellText=values,colLabels=['Model','TFSE','LCBR','D80/dB','D90/dB','H0 false alarms'],cellLoc='center',loc='center',colWidths=[.36,.08,.08,.12,.12,.24])
        tab.auto_set_font_size(False);tab.set_fontsize(8);tab.scale(1,1.5);ax.set_title(f'Four-model ablation | nominal Pfa={nominal:g}')
        for suffix in ('pdf','png'):fig.savefig(folder/f'b287_ablation_table_pfa_{nominal:.0e}.{suffix}',dpi=300,bbox_inches='tight')
        plt.close(fig)
    for row in comparisons:
        print(f'Pfa={row["nominal_pfa"]:.0e} {row["candidate"]} vs {row["reference"]}: delta_D80={row["delta_D80_db"]}; delta_D90={row["delta_D90_db"]}; H0 FP={row["candidate_H0_false_alarms"]} vs {row["reference_H0_false_alarms"]}',flush=True)
    for check in checks:print('Both required D90 improvements (descriptive DEV): '+str(check),flush=True)
    report=dict(status='PASS_B287_FOUR_MODEL_REPORT',strict_2x2_factorial=True,labels=list(LABELS),metrics=metrics,
        comparisons=comparisons,two_required_checks=checks,source_Pd_unchanged=True,curve_smoothing=False,
        independent_final=False,actual_Pfa_equivalence_established=False,novelty_or_improvement_established=False,
        interpretation='Both module-alone and module-with-TFSE effects must be assessed, with own actual H0 false alarms and uncertainty. A D90 tie fails the descriptive improvement check; DEV is not independent confirmation.')
    write_json(folder/'b287_report.json',report);print('B287 four-model report complete: '+str(folder),flush=True)
    return report
