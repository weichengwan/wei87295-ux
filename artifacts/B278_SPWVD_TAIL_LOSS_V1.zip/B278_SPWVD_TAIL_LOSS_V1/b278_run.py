"""B278 loss ablation; reuse CE control, train two objectives, medium only."""
import argparse,fcntl,gc,shutil,time
from pathlib import Path
from b271_data import device_for,need,write_json
from b271_score import original_protocol
from b273_shared import setup
from b274_data import Data,resolve
from b276_source import metadata
from b276_train import train_arm
from b277_references import full_metadata
from b278_model import ARMS,hooks


def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    for key in ('source-run','full-run','out-dir','bank-dir','b213-dir'):p.add_argument('--'+key,type=Path)
    p.add_argument('--stage',choices=('all','preflight','train','score','report'),default='all')
    p.add_argument('--arms',nargs='+',choices=ARMS,default=list(ARMS))
    p.add_argument('--wait-for-gpu',action='store_true')
    p.add_argument('--epochs',type=int,default=4);p.add_argument('--batch',type=int,default=32)
    p.add_argument('--train-limit',type=int,default=16000);p.add_argument('--val-limit',type=int,default=3000)
    p.add_argument('--lr',type=float,default=1e-5);p.add_argument('--new-lr',type=float,default=1e-4)
    p.add_argument('--seed',type=int,default=20261022);p.add_argument('--cpu-threads',type=int,default=4)
    p.add_argument('--device',choices=('cpu','cuda'),default='cuda')
    a=p.parse_args(argv);a.root=a.root.resolve()
    a.source_run=(a.source_run or a.root/'output_b274_single_spwvd_resnet18_v1').resolve()
    a.full_run=(a.full_run or a.root/'output_b276_spwvd_adn_phase_v1').resolve()
    a.out_dir=(a.out_dir or a.root/'output_b278_loss_ablation_v1').resolve()
    need(a.root.is_dir() and a.out_dir!=a.root and all(a.out_dir!=v and v not in a.out_dir.parents for v in (a.source_run,a.full_run)), 'Use a separate B278 output directory')
    need(a.batch==32 and a.epochs>0 and a.lr>0 and a.new_lr>0 and a.cpu_threads>0 and len(set(a.arms))==len(a.arms),'Invalid loss-ablation budget')
    need(2<=a.train_limit<=30000 and 2<=a.val_limit<=5000 and a.train_limit%2==a.val_limit%2==0,'Invalid balanced subset')
    a.device=device_for(a.device);return a


def references(a,context,selection):
    _,old,generator=original_protocol(a.root,context,a.b213_dir)
    source=metadata(run_dir=a.source_run,context=context,device=a.device,selection=selection,original=old)
    full=full_metadata(folder=a.full_run/'pd_scr_medium',context=context,original=old,
                       device=a.device,data_selection=selection,source=source,a=a)
    return source,full,old,generator


def acquire(lock,wait):
    attempts=0
    while True:
        try:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);return
        except BlockingIOError:
            if not wait:raise SystemExit('Another radar job holds the GPU lock; B278 not started')
            if attempts%4==0:print('Waiting for B277/other radar job; B278 has not allocated GPU memory',flush=True)
            attempts+=1;time.sleep(15)


def main(argv=None):
    a=cli(argv);setup(a.cpu_threads)
    print(f'B278 loss ablation | stage={a.stage} | output={a.out_dir}',flush=True)
    if a.stage=='report':
        from b278_report import generate
        return generate(a.out_dir/'pd_scr_medium')
    with (a.root/'codex_b271_night.lock').open('a') as lock:
        acquire(lock,a.wait_for_gpu)
        need(shutil.disk_usage(a.root).free>=2*1024**3,'Require2GiB free for separate loss-ablation checkpoints')
        context=resolve(a.root,a.bank_dir);data=Data(context,a.train_limit,a.val_limit,a.seed)
        source,full,old,generator=references(a,context,data.selection)
        print('B274 initialization and completed B276 CE control verified; same data/epochs/LRs; no ARS',flush=True)
        if a.stage=='preflight':
            a.out_dir.mkdir(parents=True,exist_ok=True)
            write_json(a.out_dir/'preflight.json',dict(selection=data.selection,source=str(source['run_dir']),
                reused_CE_control=str(full['folder']),new_arms=a.arms))
            return
        if a.stage in ('all','train'):
            print('TRAIN/VAL only. Original Tail vs TRAIN-memory tail; original B276 CE reused unchanged',flush=True)
            for arm in a.arms:train_arm(a,context,data,source,arm,hooks(arm))
        selection=data.selection;del data;gc.collect()
        if a.device.type=='cuda':
            import torch
            torch.cuda.empty_cache()
        if a.stage!='train':
            from b278_score import score
            return score(a,context,selection)


if __name__=='__main__':main()
