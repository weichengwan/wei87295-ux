"""Score loss arms on paired medium scenes; B276 CE scores reused read-only."""
from types import SimpleNamespace
import torch
from b271_data import digest_file,fingerprint,load_checkpoint,need,read_json
from b271_score import SCENE_KEYS
from b276_score import stream
from b276_train import code_hashes,configuration
from b277_references import full_arrays
from b278_model import factory,hooks,NAMES,PASS
from b278_run import references


def score(a,context,selection):
    source,full,old,generator=references(a,context,selection)
    cached,reuse=full_arrays(full);models=[];identities=[];definitions={}
    for arm in a.arms:
        folder=a.out_dir/arm;contract=read_json(folder/'training_contract.json');path=folder/'best.pt'
        expected=configuration(a,context,SimpleNamespace(selection=selection),source,arm,hooks(arm))
        need(contract['status']==PASS and contract['run_config']==expected and
             contract['run_fingerprint']==fingerprint(expected) and digest_file(path)==contract['checkpoint_sha256'],
             'B278 trained loss/config/checkpoint differs')
        state=load_checkpoint(path)
        need(state['run_config']==expected and state['run_fingerprint']==contract['run_fingerprint'] and state['epoch']==contract['best_epoch'],
             'B278 internal checkpoint identity differs')
        model=factory(arm,expected['backend'],expected['scale']);model.load_state_dict(state['state_dict'],strict=True)
        model.to(a.device).eval();models.append(model);definitions[arm]=expected['loss_parameters']
        identities.append(dict(arm=arm,sha256=contract['checkpoint_sha256'],selected_epoch=contract['best_epoch'],
            validation=contract['selected_validation'],initialization=contract['initialization'],
            module_diagnostics=contract['module_diagnostics'],trainable_parameters=contract['trainable_parameters']))
    scene={k:old[k] for k in SCENE_KEYS};scene.update(h0_cal_n=500000,h0_audit_n=200000)
    labels=list(a.arms)+['REF_'+k for k in full['p']['labels']]
    names={**{k:NAMES[k] for k in a.arms},**{'REF_'+k:v for k,v in full['p']['names'].items()}}
    p=dict(version='B278_LOSS_ABLATION_SCORE_V1',**scene,scene_fingerprint=fingerprint(scene),nominal_pfas=[1e-4],
        labels=labels,names=names,candidate_labels=list(a.arms),ours_label=a.arms[-1],checkpoints=identities,
        loss_definitions=definitions,reused_CE_checkpoint=full['full_identity'],reused_baselines={'B276':reuse},
        training_budget=dict(train_n=selection['train']['count'],val_n=selection['val']['count'],epochs=a.epochs,batch=32,
                             seed=a.seed,backbone_lr=a.lr,new_parameters_lr=a.new_lr),
        batch=32,device=a.device.type,tf32=False,code_sha256=code_hashes(),
        score_definition='float64(float32 logit1 - float32 logit0)',strict_decision='score > own H0 CAL threshold',
        train_memory_used_for_inference=False,train_alpha_is_nominal_pfa=False,
        scope='Fixed SPWVD ADN/WCSG/TFCG, matched initialization and budget; previously exposed medium DEV; loss novelty/gain unverified')
    p['fingerprint']=fingerprint(p);args=SimpleNamespace(out_dir=a.out_dir/'pd_scr_medium',batch=32,chunk=512)
    print(f'B278 scores {a.arms}; reused B276 CE GPU forwards=0; CAL500k CHECK200k H1=1024x37',flush=True)
    stream(args,p,generator,models,None,a.device,cached)
    from b278_report import generate
    return generate(args.out_dir)
