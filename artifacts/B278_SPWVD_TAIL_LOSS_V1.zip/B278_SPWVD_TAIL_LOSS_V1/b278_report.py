"""Separate loss ablation from architecture ablation; no promised improvement."""
import csv,shutil
from pathlib import Path
import numpy as np
from b271_data import fingerprint,need,read_json,write_json
from b273_statistics import metrics_for,save_csv
from paper_plots import generate as paper_plot


def table_rows(p,lookup):
    plans=[('A3','REF_adn','CE',0.,'read-only completed B276')]
    plans.extend((row,label,loss,.05,'new loss arm') for row,label,loss in
                 [('A4','original_tail','CE + original Tail'),('A5','memory_tail','CE + TRAIN-memory tail')]
                 if label in p['labels'])
    count={v['arm']:v['trainable_parameters'] for v in p['checkpoints']}
    return [dict(row=row,method=p['names'][label],frontend='SPWVD',ADN_ACB=True,WCSG=True,TFCG=True,SimAM=False,phase_ARS=False,
        loss=loss,loss_weight=weight,parameters=p['reused_CE_checkpoint']['trainable_parameters'] if label=='REF_adn' else count[label],
        D50_db=lookup[label]['D50_db'],D80_db=lookup[label]['D80_db'],D90_db=lookup[label]['D90_db'],
        pd_at_0=lookup[label]['pd_at_0'],actual_pfa=lookup[label]['actual_pfa'],
        audit_false_alarms=lookup[label]['audit_false_alarms'],audit_n=lookup[label]['audit_n'],
        matched_initialization_and_budget=True,training_operation=operation)
        for row,label,loss,weight,operation in plans]


def generate(out):
    out=Path(out);p=read_json(out/'protocol_frozen.json');progress=read_json(out/'progress.json')
    need(p['version']=='B278_LOSS_ABLATION_SCORE_V1' and p['nominal_pfas']==[1e-4] and
         p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==progress['fingerprint'],'B278 score protocol differs')
    need(progress['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=len(p['scr_grid_db'])),'B278 scoring incomplete')
    n=len(p['labels']);arrays=[]
    for name,shape in [('h0_cal_scores.npy',(p['h0_cal_n'],n)),('h0_audit_scores.npy',(p['h0_audit_n'],n)),
                       ('dev_h1_scores.npy',(len(p['scr_grid_db']),p['h1_scenes_n'],n))]:
        values=np.load(out/name,mmap_mode='r',allow_pickle=False)
        need(values.shape==shape and values.dtype==np.dtype('float64'),'Malformed B278 raw scores');arrays.append(values)
    curves=[];metrics=[];lookup={}
    for j,label in enumerate(p['labels']):
        cv,mt=metrics_for(p['names'][label],arrays[0][:,j],arrays[1][:,j],arrays[2][:,:,j],p)
        curves+=cv;metrics+=mt;lookup[label]=mt[0]
    comparisons=[]
    pairs=[(label,'REF_adn') for label in p['candidate_labels']]
    if all(k in lookup for k in ('memory_tail','original_tail')):pairs.append(('memory_tail','original_tail'))
    for left,right in pairs:
        a,b=lookup[left],lookup[right]
        delta=lambda key:None if a[key] is None or b[key] is None else a[key]-b[key]
        comparisons.append(dict(candidate=a['method'],reference=b['method'],delta_D80_db=delta('D80_db'),delta_D90_db=delta('D90_db'),
            pd_at_0_gain_pp=100*delta('pd_at_0'),candidate_false_alarms=a['audit_false_alarms'],reference_false_alarms=b['audit_false_alarms'],
            identical_detection_architecture=True,matched_initialization_and_budget=True,negative_delta_means_left=True))
    for name,rows in [('b278_curves.csv',curves),('b278_metrics.csv',metrics),('b278_comparisons.csv',comparisons)]:save_csv(out/name,rows)
    rows=table_rows(p,lookup)
    with (out/'b278_loss_ablation_table.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    fmt=lambda v:'NA' if v is None else f'{v:.3f}'
    text='|Row|Loss|D80/dB|D90/dB|Pd@0|Actual Pfa|\n|---|---|---|---|---|---|\n'
    for r in rows:text+=f"|{r['row']}|{r['loss']}|{fmt(r['D80_db'])}|{fmt(r['D90_db'])}|{fmt(r['pd_at_0'])}|{r['actual_pfa']:.2e}|\n"
    text+='\nAll rows: same SPWVD/ADN/WCSG/TFCG, initialization, TRAIN/VAL selection, extra training budget and VAL CE selection. No phase ARS. TRAIN memory alpha=.01 is a surrogate; independent CAL sets the Pfa=1e-4 threshold. Previously exposed DEV, not FINAL.\n'
    (out/'b278_loss_ablation_table.md').write_text(text)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(10,2.8));ax.axis('off')
    content=[[r['row'],r['loss'],fmt(r['D80_db']),fmt(r['D90_db']),fmt(r['pd_at_0']),f"{r['actual_pfa']:.2e}"] for r in rows]
    t=ax.table(cellText=content,colLabels=['Row','Training objective','D80/dB','D90/dB','Pd at 0 dB','Actual Pfa'],loc='center',cellLoc='center')
    t.auto_set_font_size(False);t.set_fontsize(9);t.scale(1,1.5)
    ax.set_title('Loss ablation | fixed SPWVD ADN/WCSG/TFCG | nominal Pfa=1e-4')
    fig.text(.02,.03,'Matched initialization and additional budget; CE control reused from B276. Exposed DEV.',fontsize=8)
    fig.tight_layout(rect=(0,.1,1,1))
    for ext in ('pdf','png'):fig.savefig(out/f'b278_loss_ablation_table.{ext}',dpi=300,bbox_inches='tight')
    plt.close(fig)
    report=dict(status='PASS_B278_MEDIUM_LOSS_ABLATION_REPORT',metrics=metrics,comparisons=comparisons,loss_ablation_table=rows,
        loss_definitions=p['loss_definitions'],scope=p['scope'],source_reuse=p['reused_baselines'],
        independent_final=False,automatic_promotion=False,second_innovation_established=False,
        train_memory_used_for_inference=False,nominal_pfa_guaranteed_by_training_loss=False,equal_actual_pfa_established=False)
    write_json(out/'b278_report.json',report)
    selected=[v for v in curves if v['method'] in {r['method'] for r in rows}]
    save_csv(out/'b278_loss_ablation_curves.csv',selected)
    paper_plot(out/'b278_loss_ablation_curves.csv',out/'figures',ours=p['names'][p['ours_label']],nominal=1e-4,metrics=out/'b278_metrics.csv')
    for ext in ('pdf','png','svg'):shutil.copyfile(out/'figures'/f'b278_loss_ablation_curves_paper_pd_pfa_1e-04.{ext}',out/'figures'/f'b278_pd_scr_pfa_1e-04.{ext}')
    for r in rows:print(f"{r['row']} {r['loss']}: D90={r['D90_db']} H0 FP={r['audit_false_alarms']}/{r['audit_n']}",flush=True)
    print('B278 stopped after medium DEV; no automatic full run',flush=True)
    return report
