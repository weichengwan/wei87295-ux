"""Generated CPU loss/regression tests; no AutoDL detector results claimed."""
import copy,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
import numpy as np
import torch
import torch.nn.functional as F
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from b271_data import digest_file,read_json,write_json,fingerprint,load_checkpoint
from b273_shared import setup
from b273_statistics import metrics_for,save_csv
from b274_model import SingleBranch,select_backend
from b276_score import predictions,stream
from b276_model import verify_initial
import b276_train as trainer
from b278_model import ARMS,NAMES,factory,initialize,hooks,objective
from b278_loss import original_tail,TrainNegativeMemory
from b278_report import generate
import b278_run as runner
from test_b276 import fixture,source_fixture
from test_b277 import completed_full
from source_loader import load_frozen_file


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):setup(2)

    def test_original_tail_matches_frozen_value_and_gradients(self):
        source=load_frozen_file('r10_sim_stage_b215_tpht_train_v1.py')
        z=torch.randn(12,2,dtype=torch.float64,requires_grad=True);labels=torch.tensor([0]*6+[1]*6)
        image=torch.ones(12,1,2,2,dtype=torch.float64);aux=dict(input_gray=image,output_gray=image*.97)
        total,*_=source.compute_loss('L1_TAIL',z,labels,aux)
        ours=F.cross_entropy(z,labels)+.05*original_tail(z,labels)
        torch.testing.assert_close(total,ours,atol=1e-12,rtol=1e-12)
        torch.testing.assert_close(torch.autograd.grad(total,z)[0],torch.autograd.grad(ours,z)[0],atol=1e-12,rtol=1e-12)
        for value in (0,1):
            logits=torch.randn(4,2,requires_grad=True);loss=original_tail(logits,torch.full((4,),value))
            self.assertEqual(float(loss),0.);loss.backward();self.assertTrue(torch.isfinite(logits.grad).all())

    def test_memory_active_gradients_warmup_affine_reference_and_state(self):
        memory=TrainNegativeMemory(capacity=8,warmup_h0=4)
        labels=torch.tensor([0,0,1,1]);z=torch.tensor([[0.,0.],[0.,1.],[0.,2.],[0.,3.]],requires_grad=True)
        loss=memory(z,labels);torch.testing.assert_close(loss,original_tail(z,labels));loss.backward()
        memory.append(torch.tensor([-3.,-2.,-1.,0.,1.,2.,3.,4.]));self.assertEqual(int(memory.size),8)
        start=copy.deepcopy(memory.state_dict())
        z=torch.tensor([[0.,6.],[0.,0.],[0.,2.],[0.,1.]],requires_grad=True);raw=memory(z,labels)
        raw.backward();self.assertGreater(float(z.grad[0,1]),0.);self.assertLess(float(z.grad[3,1]),0.)
        self.assertTrue(torch.isfinite(z.grad).all());self.assertEqual(int(memory.reference_updates),1)
        # Standardization prevents the regularizer being improved merely by
        # shifting/scaling every score and the TRAIN-memory reference together.
        a=TrainNegativeMemory(capacity=8,warmup_h0=4);a.load_state_dict(start)
        b=TrainNegativeMemory(capacity=8,warmup_h0=4);b.load_state_dict(start)
        b.scores.mul_(2).add_(7)
        transformed=z.detach().clone();transformed[:,1]=2*(z.detach()[:,1]-z.detach()[:,0])+7;transformed[:,0]=0
        torch.testing.assert_close(a(z.detach(),labels),b(transformed,labels),rtol=2e-6,atol=2e-6)
        state=copy.deepcopy(a.state_dict());c=TrainNegativeMemory(capacity=8,warmup_h0=4);c.load_state_dict(state)
        torch.testing.assert_close(a(z.detach(),labels),c(z.detach(),labels))
        c.eval()
        with self.assertRaisesRegex(RuntimeError,'only update during TRAIN'):c(z,labels)

    def test_same_architecture_initialization_and_eval_never_updates_memory(self):
        with tempfile.TemporaryDirectory() as d:
            backend=select_backend(Path(d),'recovered');teacher=SingleBranch(backend,2.).eval();iq=torch.randn(2,512,dtype=torch.complex64)
            models=[]
            for arm in ARMS:
                torch.manual_seed(20261022);model=factory(arm,backend,2.);initialize(model,teacher,arm)
                self.assertLess(verify_initial(model,teacher,iq)['maxabs_logit_difference'],5e-5)
                self.assertEqual(sum(p.numel() for p in model.parameters()),14533299)
                models.append(model.eval())
            torch.testing.assert_close(models[0](iq),models[1](iq),rtol=0,atol=0)
            memory=models[1].tail_memory;before=copy.deepcopy(memory.state_dict())
            predictions(models,None,iq.numpy(),torch.device('cpu'),32)
            for k,v in before.items():self.assertTrue(torch.equal(v,memory.state_dict()[k]),k)
            model=models[1];model.train();model.tail_memory.settings['warmup_h0']=2
            z,ce,loss=objective(model,iq,torch.tensor([0,1]));loss.backward()
            self.assertEqual(int(model.tail_memory.size),1)

    def test_real_runner_preflight_train_and_score_entrypoints(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);context,data,g=fixture(root);source=source_fixture(root,context,data,g)
            argv=['--root',d,'--source-run',str(source['run_dir']),'--full-run',str(root/'full'),
                  '--device','cpu','--train-limit','4','--val-limit','4']
            args=runner.cli(argv);full,old=completed_full(root,context,data,g,source,args)
            files=[p for directory in (source['run_dir'],full.parent,context['bank_dir']) for p in directory.rglob('*') if p.is_file()]
            before={str(p):digest_file(p) for p in files}
            with patch.object(runner,'resolve',return_value=context),patch.object(runner,'original_protocol',return_value=(None,old,g)):
                runner.main(argv+['--stage','preflight']);runner.main(argv+['--stage','train'])
                for arm in ARMS:
                    contract=read_json(args.out_dir/arm/'training_contract.json')
                    self.assertEqual(contract['epochs_executed'],4);self.assertIn('loss_parameters',contract['run_config'])
                    self.assertEqual(contract['trainable_parameters'],14533299)
                import b278_score,b278_report
                def probe(score_args,p,generator,models,teacher,device,cached):
                    self.assertEqual(p['candidate_labels'],list(ARMS));self.assertEqual(cached['h0_cal'].shape,(500000,2))
                    self.assertFalse(p['train_alpha_is_nominal_pfa']);self.assertEqual(p['nominal_pfas'],[1e-4])
                    scores=predictions(models,None,data.values['val'][0],device,32)
                    self.assertEqual(scores.shape,(4,2));self.assertTrue(np.isfinite(scores).all())
                with patch.object(b278_score,'stream',side_effect=probe) as scoring,patch.object(b278_report,'generate',return_value=True):
                    self.assertTrue(runner.main(argv+['--stage','score']));scoring.assert_called_once()
            self.assertEqual(before,{str(p):digest_file(p) for p in files})

    def test_memory_resume_after_active_reference_updates(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);context,data,g=fixture(root);source=source_fixture(root,context,data,g)
            h=hooks('memory_tail')
            def small_factory(arm,backend,scale):
                model=factory(arm,backend,scale);model.tail_memory.settings['warmup_h0']=2
                return model
            h['factory']=small_factory
            a=SimpleNamespace(out_dir=root/'interrupted',seed=20261022,epochs=2,batch=2,lr=1e-5,new_lr=1e-4,device=torch.device('cpu'))
            save=trainer.atomic_save;stopped=[False]
            def interrupt(path,state):
                save(path,state)
                if path.name=='last_epoch.pt' and state['epoch']==1 and not stopped[0]:stopped[0]=True;raise InterruptedError('Committed epoch')
            with patch.object(trainer,'atomic_save',side_effect=interrupt):
                with self.assertRaises(InterruptedError):trainer.train_arm(a,context,data,source,'memory_tail',h)
            trainer.train_arm(a,context,data,source,'memory_tail',h);x=load_checkpoint(a.out_dir/'memory_tail/last_epoch.pt')
            a.out_dir=root/'continuous';trainer.train_arm(a,context,data,source,'memory_tail',h);y=load_checkpoint(a.out_dir/'memory_tail/last_epoch.pt')
            for k,v in x['state_dict'].items():self.assertTrue(torch.equal(v,y['state_dict'][k]),k)
            self.assertGreater(int(x['state_dict']['tail_memory.reference_updates']),0)

    def test_real_stream_and_resume_no_memory_updates(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);context,data,g=fixture(root);backend=select_backend(root,'recovered');teacher=SingleBranch(backend,2.).eval();models=[]
            for arm in ARMS:
                model=factory(arm,backend,2.);initialize(model,teacher,arm);models.append(model.eval())
            p=dict(master_seed=20261009,h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',
                h0_cal_n=4,h0_audit_n=4,h1_scenes_n=2,scr_grid_db=[-1,0,1],labels=list(ARMS)+['REF_adn']);p['fingerprint']=fingerprint(p)
            cached=dict(h0_cal=np.zeros((4,1)),h0_audit=np.zeros((4,1)),h1=np.zeros((3,2,1)))
            a=SimpleNamespace(out_dir=root/'scoring',batch=2,chunk=2)
            stream(a,p,g,models,None,torch.device('cpu'),cached)
            before={path.name:digest_file(path) for path in a.out_dir.iterdir() if path.suffix=='.npy'}
            stream(a,p,g,models,None,torch.device('cpu'),cached)
            self.assertEqual(before,{path.name:digest_file(path) for path in a.out_dir.iterdir() if path.suffix=='.npy'})
            self.assertEqual(int(models[1].tail_memory.updates),0)

    def test_analytic_loss_report_table_and_queue(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);cal=np.linspace(-6,6,100000);audit=np.linspace(-6,6,20000);q=(np.arange(1024)+.5)/1024
            h1=np.stack([6+(scr-np.log(q/(1-q)))/3 for scr in range(-24,13)])
            labels=list(ARMS)+['REF_adn'];p=dict(version='B278_LOSS_ABLATION_SCORE_V1',h0_cal_n=100000,h0_audit_n=20000,h1_scenes_n=1024,
                scr_grid_db=list(range(-24,13)),nominal_pfas=[1e-4],labels=labels,names={**{k:NAMES[k] for k in ARMS},'REF_adn':NAMES['CE']},
                candidate_labels=list(ARMS),ours_label='memory_tail',checkpoints=[dict(arm=arm,trainable_parameters=14533299) for arm in ARMS],
                reused_CE_checkpoint=dict(trainable_parameters=14533299),loss_definitions={k:hooks(k)['loss_parameters'] for k in ARMS},
                reused_baselines={},scope='Synthetic analytic report fixture')
            p['fingerprint']=fingerprint(p);write_json(root/'protocol_frozen.json',p)
            write_json(root/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=100000,h0_audit=20000,h1=37)))
            for name,value in [('h0_cal_scores.npy',np.stack([cal]*3,1)),('h0_audit_scores.npy',np.stack([audit]*3,1)),
                               ('dev_h1_scores.npy',np.stack([h1+1/3,h1+2/3,h1],2))]:np.save(root/name,value)
            report=generate(root);self.assertEqual(len(report['loss_ablation_table']),3)
            self.assertEqual([v['row'] for v in report['loss_ablation_table']],['A3','A4','A5'])
            self.assertAlmostEqual(report['comparisons'][0]['delta_D90_db'],-1.,places=8)
            self.assertAlmostEqual(report['comparisons'][1]['delta_D90_db'],-2.,places=8)
            self.assertFalse(report['second_innovation_established']);self.assertTrue((root/'b278_loss_ablation_table.pdf').is_file())
            manifest=read_json(root/'figures/b278_loss_ablation_curves_paper_manifest.json')
            self.assertEqual(manifest['styles'][NAMES['memory_tail']]['marker'],'v');self.assertFalse(manifest['smoothing'])
            with patch.object(runner.fcntl,'flock',side_effect=[BlockingIOError(),None]),patch.object(runner.time,'sleep') as sleep:
                runner.acquire(object(),True);sleep.assert_called_once_with(15)

    @unittest.skipUnless(torch.cuda.is_available(),'Local CUDA unavailable')
    def test_cuda_loss_active_memory_backward(self):
        memory=TrainNegativeMemory(capacity=8,warmup_h0=4).cuda();memory.append(torch.arange(8,device='cuda',dtype=torch.float32))
        logits=torch.randn(4,2,device='cuda',requires_grad=True);labels=torch.tensor([0,0,1,1],device='cuda')
        loss=memory(logits,labels);loss.backward();self.assertTrue(torch.isfinite(logits.grad).all())


if __name__=='__main__':unittest.main(verbosity=2)
