# B278：结构固定的尾部损失消融

本包把“结构改进”和“损失改进”分开验证。当前B277保持原目录运行；不要用本包覆盖B277。B278使用同一个GPU锁等待，所有输出写到独立的`output_b278_loss_ablation_v1`。

|行|结构|损失|操作|
|---|---|---|---|
|A3|SPWVD ADN/WCSG/TFCG，无ARS|CE|只读复用已完成B276|
|A4|同A3|CE + 0.05 × 原B215 Tail|新增训练|
|A5|同A3|CE + 0.05 × TRAIN记忆参考尾部损失|新增训练，实验性设计|

A4/A5与B276 CE组具有相同B274预训练源、TRAIN/VAL行、随机种子、4个额外epoch、batch32、Adam/weight decay、参数组学习率、最低VAL CE选模规则（含epoch0）。不从B276已经训练4epoch的权重再训练，避免额外预算不公平。三个模型检测结构、参数量相同，为14,533,299；记忆池是训练状态，不增加推理算子或检测参数。

历史“L1-Tail”是WVD+WCSG+TFCG+尾部损失的整个方法名，不是L1范数，也不能直接作为单独损失的开关。B278先在固定SPWVD结构上隔离损失贡献；原L1-Tail分数仍随B276参考缓存保留，属于历史方法对照。

## 两条拟验证贡献

1. 结构：面向时频输入的分层门控ADN。WCSG和TFCG可以在论文中归为一条结构设计，但B277仍逐项消融；SPWVD作为有引用的既有输入表征。
2. 学习目标：训练负样本记忆引导的尾部间隔学习。用历史TRAIN负样本的上分位参考和标准化间隔，补充CE对整体分类的优化。A5须与CE和原Tail比较，结果出来前不认定为已成立创新。

这是本轮在原B215基础上的实验设计，不是某篇最新论文的原样复现；难例挖掘、分位参考、训练记忆本身均为已有思路。是否有足够方法新意还需要相关工作比较和独立实验。完整公式、超参数和限制见`LOSS_DESIGN.md`。

## 运行

把完整`B278_SPWVD_TAIL_LOSS_V1.zip`上传到项目根目录。已上传就直接解压，不再下载覆盖它。

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
unzip -o B278_SPWVD_TAIL_LOSS_V1.zip
nohup /root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  bash B278_SPWVD_TAIL_LOSS_V1/run_b278.sh --wait-for-gpu \
  > codex_b278_loss.log 2>&1 < /dev/null &
tail -F codex_b278_loss.log
```

B277/其他任务持有GPU锁时，每分钟打印等待；获得锁前不分配GPU显存。两组各TRAIN16000/VAL3000、额外4epoch，batch32，原参数LR1e-5、新结构参数LR1e-4。训练只读TRAIN/VAL；核对旧模型身份只读元数据和SHA，不以CAL/AUDIT/H1评分选模。VAL仅评价CE；新增损失的全部设置预先固定。

训练后自动为两个新模型评分：CAL500k、CHECK200k、H1每SCR1024条×37点，名义Pfa仅1e-4，不自动扩到全量。旧B276组与参考方法直接复用原始分数，独立CAL阈值、全部H0虚警数和37点H1检出数重放核对；旧文件不改写。评分只用检测器输出，不用训练记忆池参考值作阈值。

`--stage preflight/train/score/report`可单独执行各阶段。同一命令重跑从最后完整epoch或评分进度恢复，记忆池、优化器、随机状态一并恢复。改变arms/数据/预算/损失设置需新的`--out-dir`；默认预算须匹配已完成的B276 CE对照，否则拒绝复用。

## 输出

`output_b278_loss_ablation_v1/pd_scr_medium/`：

- `b278_loss_ablation_table.csv/.md/.pdf/.png`：A3/A4/A5三行，含D50/D80/D90、Pd@0、实际Pfa和虚警数。
- `b278_metrics.csv`、`b278_curves.csv`、`b278_comparisons.csv`、`b278_report.json`：保留完整参考曲线与配置记录。
- `figures/b278_pd_scr_pfa_1e-04.pdf/.png/.svg`：三组损失Pd图，A5为黑色虚线空心倒三角，坐标SCR(dB)、Pd；不平滑、不移动数据点。
- 各训练组的`train_val_history.csv`同时记录CE与实际总训练目标。

B277的A1/A2/A3与此处A3/A4/A5可在完成来源/预算核对后整理进同一论文表格。本包不自动改写正在运行的B277结果。

## 验证范围

生成IQ上的功能测试覆盖原Tail与冻结源码的损失值/梯度一致、记忆激活后的梯度方向、尺度/平移参考行为、断点恢复、真实入口训练与重载预测、纯推理不改动记忆、原评分重放、表图生成和GPU排队。实际AutoDL权重和CUDA不在本地，功能测试不证明检测改善或论文录用。该开发集已反复查看，最终结论还需要独立场景。
