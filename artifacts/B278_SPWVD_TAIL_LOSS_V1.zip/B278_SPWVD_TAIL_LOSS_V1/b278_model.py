"""Identical B276 no-ARS architecture; only the training objective differs."""
import torch
import torch.nn.functional as F
from b271_data import need
from b276_model import MigratedADN, migrate
from b278_loss import ORIGINAL, MEMORY, TrainNegativeMemory, original_tail

ARMS=('original_tail','memory_tail')
NAMES={'original_tail':'SPWVD ADN/WCSG/TFCG + original Tail',
       'memory_tail':'SPWVD ADN/WCSG/TFCG + TRAIN-memory tail',
       'CE':'SPWVD ADN/WCSG/TFCG'}
PASS='PASS_B278_LOSS_ABLATION_TRAIN_VAL_ONLY'
VERSION='B278_LOSS_ABLATION_TRAIN_V1'


class LossArm(MigratedADN):
    def __init__(self,arm,backend,scale):
        need(arm in ARMS,'Unknown B278 loss arm')
        super().__init__(backend,scale,phase=False);self.arm=arm
        self.tail_memory=TrainNegativeMemory() if arm=='memory_tail' else None


def factory(arm,backend,scale):return LossArm(arm,backend,scale)
def initialize(model,teacher,arm):return migrate(model,teacher,'adn')


def objective(model,iq,labels):
    z=model(iq);ce=F.cross_entropy(z,labels)
    raw=original_tail(z,labels) if model.arm=='original_tail' else model.tail_memory(z,labels)
    weight=ORIGINAL['weight'] if model.arm=='original_tail' else MEMORY['weight']
    return z,ce,ce+weight*raw


@torch.inference_mode()
def diagnostics(model,probe):
    _,aux=model(probe,return_aux=True)
    result=dict(architecture_identical_to_B276_adn=True,phase_ARS=False,
                loss_parameters=ORIGINAL if model.arm=='original_tail' else MEMORY,
                wcsg_gain_mean=float((aux['gate']/model.suppressor.initial_gain).mean()))
    if model.tail_memory is not None:result.update(model.tail_memory.diagnostics())
    return result


def hooks(arm):
    need(arm in ARMS,'Unknown loss arm')
    return dict(status=PASS,version=VERSION,factory=factory,migrate=initialize,
                objective=objective,diagnostics=diagnostics,
                loss_name='CE+0.05 original B215 Tail' if arm=='original_tail' else 'CE+0.05 TRAIN-memory tail surrogate',
                loss_parameters=dict(ORIGINAL if arm=='original_tail' else MEMORY))
