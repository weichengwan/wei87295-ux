#!/usr/bin/env bash
set -euo pipefail
b271_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
project_root="$(dirname -- "$b271_dir")"
budget_profile=medium
score_only=0
run_dir=""
while [ "$#" -gt 0 ]; do
  case "$1" in
    small|medium|full) budget_profile="$1"; shift ;;
    --profile) budget_profile="${2:?Missing profile}"; shift 2 ;;
    --score-only) score_only=1; shift ;;
    --run-dir) run_dir="${2:?Missing run directory}"; shift 2 ;;
    *) printf 'Unknown argument: %s\n' "$1" >&2; exit 64 ;;
  esac
done
case "$budget_profile" in small|medium|full) ;; *) printf 'Invalid profile.\n' >&2; exit 64 ;; esac
cd "$b271_dir"
run_dir="${run_dir:-$project_root/output_b271_v2_$budget_profile}"
exec 9>"$project_root/codex_b271_night.lock"
flock -n 9 || { printf 'An existing B271 task is still running; wait for it to stop.\n' >&2; exit 1; }
date -Is
printf 'Budget=%s; nominal Pfa=1e-4; no automatic promotion.\n' "$budget_profile"
if [ "$score_only" -eq 0 ]; then
  train_started=$SECONDS
  bash run_b271_train.sh --profile "$budget_profile" --out-dir "$run_dir" --device cuda --resume
  printf 'Training stage: %ss\n' "$((SECONDS-train_started))"
fi
score_started=$SECONDS
bash run_b271_score.sh --profile "$budget_profile" --run-dir "$run_dir" \
  --batch 32 --chunk 512 --device cuda
printf 'Scoring stage: %ss\n' "$((SECONDS-score_started))"
printf 'Stage complete; inspect Pd curves before requesting a larger budget.\n'
date -Is
