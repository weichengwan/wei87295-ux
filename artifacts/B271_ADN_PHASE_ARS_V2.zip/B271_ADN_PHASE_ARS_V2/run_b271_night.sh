#!/usr/bin/env bash
set -euo pipefail
b271_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
exec bash "$b271_dir/run_b271_stage.sh" "$@"
