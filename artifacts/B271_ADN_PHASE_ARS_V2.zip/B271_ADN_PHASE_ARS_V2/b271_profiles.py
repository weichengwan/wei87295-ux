"""Fixed small/medium/full budgets; no automatic promotion to a larger run."""
from __future__ import annotations
from copy import deepcopy

PROFILES = {
    "small": dict(train_limit=8000, val_limit=2000, epochs=4, min_epochs=2, patience=2,
                  train_h0_proposals=20000, pool_size=256,
                  h0_cal_n=100000, h0_audit_n=50000, h1_scenes_n=256,
                  scr_grid_db=[-24,-18,-12,-9,-6,-3,0,3,6,9,12],
                  nominal_pfas=[1e-4], evaluation_seed_offset=27101),
    "medium": dict(train_limit=16000, val_limit=3000, epochs=6, min_epochs=3, patience=2,
                   train_h0_proposals=60000, pool_size=512,
                   h0_cal_n=500000, h0_audit_n=200000, h1_scenes_n=1024,
                   scr_grid_db=list(range(-24,13)), nominal_pfas=[1e-4],
                   evaluation_seed_offset=27102),
    "full": dict(train_limit=0, val_limit=0, epochs=12, min_epochs=4, patience=3,
                 train_h0_proposals=200000, pool_size=1024,
                 h0_cal_n=3000000, h0_audit_n=1000000, h1_scenes_n=1024,
                 scr_grid_db=list(range(-24,13)), nominal_pfas=[1e-4],
                 evaluation_seed_offset=0),
}

def profile(name):
    if name not in PROFILES:
        raise ValueError("Unknown budget profile: "+str(name))
    return deepcopy(PROFILES[name])
