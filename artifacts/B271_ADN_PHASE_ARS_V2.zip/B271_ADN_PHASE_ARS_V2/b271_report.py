"""Raw curves with own CAL thresholds, independent AUDIT, and internal fusion target."""
from __future__ import annotations
import csv
import os
from pathlib import Path
import numpy as np

from b271_data import digest_file, fingerprint, need, read_json, write_json
from source_loader import load_frozen_file

NAMES={"guided":"ADN/L1 + phase-ARS","no_phase":"ADN/L1 + ARS without phase",
       "head_control":"ADN/L1 head control","L1_TAIL":"L1-Tail"}


def save_csv(path,rows):
    if not rows:return
    with Path(path).open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def crossing(x,y,level):
    if y[0]>=level:return float(x[0])
    for i in range(1,len(x)):
        if y[i-1]<level<=y[i]:
            return float(x[i-1]+(level-y[i-1])*(x[i]-x[i-1])/(y[i]-y[i-1]))
    return None


def metrics_for(name,cal,audit,h1,protocol):
    statistics=load_frozen_file("r10_sim_stage_b216_pdscr_report_v1.py")
    need(np.isfinite(cal).all() and np.isfinite(audit).all() and np.isfinite(h1).all(),"Nonfinite scores")
    curves,metrics=[],[]
    for nominal in protocol.get("nominal_pfas",(1e-4,1e-5)):
        threshold,k,cal_fp=statistics.cutoff(cal,nominal)
        false=int((audit>threshold).sum())
        low,high=statistics.wilson(false,len(audit))
        hits=(h1>threshold).sum(1)
        pd=hits/h1.shape[1]
        metric=dict(method=name,nominal_pfa=nominal,actual_pfa=false/len(audit),
                    audit_false_alarms=false,audit_n=len(audit),actual_pfa_ci95_low=low,
                    actual_pfa_ci95_high=high,threshold=threshold,cal_n=len(cal),
                    cal_tail_support=k,cal_exceedances=cal_fp,
                    D50_db=crossing(protocol["scr_grid_db"],pd,.5),
                    D80_db=crossing(protocol["scr_grid_db"],pd,.8),
                    D90_db=crossing(protocol["scr_grid_db"],pd,.9))
        for level in (0,6,9,12):
            metric["pd_at_"+str(level)]=float(pd[protocol["scr_grid_db"].index(level)]) if level in protocol["scr_grid_db"] else None
        metrics.append(metric)
        for scr,n in zip(protocol["scr_grid_db"],hits):
            lo,hi=statistics.wilson(int(n),h1.shape[1])
            curves.append(dict(method=name,nominal_pfa=nominal,scr_db=scr,hits=int(n),
                               n_h1=h1.shape[1],pd=float(n/h1.shape[1]),pd_ci95_low=lo,pd_ci95_high=hi))
    return curves,metrics


def frozen_comparators(root,protocol):
    """Read-only old score banks; no LMDA code/weights are part of our model."""
    root=Path(root)
    if protocol.get("budget_profile","full")!="full":
        return [],dict(available=False,reason="Fresh screening scenes differ from old full score banks; historical rankmix is not overlaid")
    b222=root/"output_sim_r10_b222_gpu_dualpfa_v1/seed_20261022"
    lmda=root/"output_sim_r10_b223_external_baselines_v1/dl/LMDA_PF/seed_20261022"
    old=root/"output_sim_r10_b227_score_fusion_exploratory_v1/seed_20261022"
    if not all((p/"protocol_frozen.json").is_file() for p in (b222,lmda)) or not (old/"b227_provenance.json").is_file():
        return [],dict(available=False,reason="Original B222/B223/B227 score reference unavailable")
    a,b=read_json(b222/"protocol_frozen.json"),read_json(lmda/"protocol_frozen.json")
    provenance=read_json(old/"b227_provenance.json")
    need(a["scene_fingerprint"]==b["b213_scene_fingerprint"]==protocol["scene_fingerprint"]==provenance["scene_fingerprint"],
         "Cached comparator scene identity differs")
    need(a["checkpoint_sha256"]["L1-Tail"]==protocol["original_checkpoint_sha256"],"Cached comparator uses different original L1")
    need(provenance["source_protocol_sha256"]==dict(B222=digest_file(b222/"protocol_frozen.json"),
                                                  LMDA=digest_file(lmda/"protocol_frozen.json")),
         "Cached comparator source protocols changed")
    need(a["methods"]==["Original ADN","L1-Tail","Original M2","FT-KD-Order"] and b["method"]=="LMDA-PF",
         "Cached comparator column order differs")
    n=protocol["h0_cal_n"];m=protocol["h0_audit_n"];ns=protocol["h1_scenes_n"];levels=protocol["scr_grid_db"]
    pa,pb=read_json(b222/"progress.json"),read_json(lmda/"progress.json")
    for p,c in ((pa,a),(pb,b)):
        need(p["fingerprint"]==c["fingerprint"] and (p["h0_cal"],p["h0_audit"],p["h1_scr"])==(n,m,len(levels)),
             "Cached comparator is incomplete")
    need(a["scr_grid_db"]==b["scr_db"]==levels and a["h1_per_scr"]==b["h1_per_scr"]==ns,
         "Cached comparator grid differs")
    arrays=[]
    hashes={}
    for folder,cols in ((b222,4),(lmda,1)):
        three=[]
        for name,shape in (("h0_cal_scores.npy",(n,cols)),("h0_audit_scores.npy",(m,cols)),
                           ("dev_h1_scores_37.npy",(len(levels),ns,cols))):
            path=folder/name
            need(path.is_file(),"Missing comparator array: "+str(path))
            x=np.load(path,mmap_mode="r",allow_pickle=False)
            need(x.shape==shape and x.dtype==np.dtype("float64") and np.isfinite(x).all(),"Comparator array malformed")
            three.append(x);hashes[str(path)]=digest_file(path)
        arrays.append(three)
    ac,aa,ah=arrays[0];mc,ma,mh=arrays[1]
    # Exact original B227 definition: fixed left empirical CAL CDF, then own
    # fused CAL threshold. No AUDIT/H1 re-ranking or new weight selection.
    sl,sm=np.sort(ac[:,1]),np.sort(mc[:,0])
    def mix(l,m):
        # Preserve the original order of FP64 operations, including division
        # before weighting. Reassociation can change ties in the extreme tail.
        ql=np.searchsorted(sl,l,side="left").astype("float64")/n
        qm=np.searchsorted(sm,m,side="left").astype("float64")/n
        return .75*qm+.25*ql
    fusion=(mix(ac[:,1],mc[:,0]),mix(aa[:,1],ma[:,0]),mix(ah[:,:,1],mh[:,:,0]))
    reference_protocol={**protocol,"nominal_pfas":[1e-4,1e-5]}
    curves,metrics=metrics_for("INTERNAL fixed rankmix LMDA75/L125",*fusion,reference_protocol)
    with (old/"b227_curves.csv").open(encoding="utf-8-sig",newline="") as f:old_curves=list(csv.DictReader(f))
    for row in curves:
        matches=[r for r in old_curves if r["method"]=="Rank mix LMDA75/L125" and
                 float(r["nominal_pfa"])==row["nominal_pfa"] and int(float(r["scr_db"]))==row["scr_db"]]
        need(len(matches)==1 and int(matches[0]["hits"])==row["hits"],"Original rankmix hit replay failed")
    with (old/"b227_pfa.csv").open(encoding="utf-8-sig",newline="") as f:old_pfa=list(csv.DictReader(f))
    for row in metrics:
        matches=[r for r in old_pfa if r["method"]=="Rank mix LMDA75/L125" and float(r["nominal_pfa"])==row["nominal_pfa"]]
        need(len(matches)==1 and int(matches[0]["false_alarms"])==row["audit_false_alarms"],"Original rankmix AUDIT replay failed")
    adn=(ac[:,0],aa[:,0],ah[:,:,0])
    return [("Original ADN (frozen score bank)",adn),("INTERNAL fixed rankmix LMDA75/L125",fusion)],dict(
        available=True,rankmix_all_74_hits_replayed=True,rankmix_audit_counts_replayed=True,
        scene_protocol_matches=True,individual_scene_ids_rehashed=False,
        source_array_sha256=hashes,reference_is_exploratory_dev=True,
        note="Old score banks retain their old numeric implementation. New inference uses explicit FP32 margins with TF32 disabled; no claim of bitwise old/new L1 score equality.")


def generate(out,root):
    out=Path(out)
    p=read_json(out/"protocol_frozen.json");progress=read_json(out/"progress.json")
    need(p["version"]=="B271_PHASE_ARS_SCORE_V1" and fingerprint({k:v for k,v in p.items() if k!="fingerprint"})==p["fingerprint"]==progress["fingerprint"],"Scoring protocol changed")
    need(progress["completed"]==dict(h0_cal=p["h0_cal_n"],h0_audit=p["h0_audit_n"],h1=len(p["scr_grid_db"])),"Scoring incomplete")
    cal=np.load(out/"h0_cal_scores.npy",mmap_mode="r")
    audit=np.load(out/"h0_audit_scores.npy",mmap_mode="r")
    h1=np.load(out/"dev_h1_scores.npy",mmap_mode="r")
    cols=len(p["labels"])
    need(cal.shape==(p["h0_cal_n"],cols) and audit.shape==(p["h0_audit_n"],cols)
         and h1.shape==(len(p["scr_grid_db"]),p["h1_scenes_n"],cols),"Score shapes differ")
    curves,metrics=[],[]
    for i,name in enumerate(p["labels"]):
        c,m=metrics_for(NAMES[name],cal[:,i],audit[:,i],h1[:,:,i],p)
        curves.extend(c);metrics.extend(m)
    comparators,status=frozen_comparators(root,p)
    ref_curves,ref_metrics=[],[]
    for name,arrays in comparators:
        c,m=metrics_for(name,*arrays,p)
        if name.startswith("Original ADN"):
            curves.extend(c);metrics.extend(m)
        else:
            ref_curves.extend(c);ref_metrics.extend(m)
    targets=[]
    for m in [r for r in metrics if r["method"]==NAMES["guided"]]:
        ref=[r for r in ref_metrics if r["nominal_pfa"]==m["nominal_pfa"]]
        if not ref:continue
        ref=ref[0]
        target=ref["D90_db"]-1 if ref["D90_db"] is not None else None
        d=m["D90_db"]
        achieved=bool(d<=target) if d is not None and target is not None else None
        actual_guard=m["actual_pfa"]<=ref["actual_pfa"]
        targets.append(dict(method=m["method"],nominal_pfa=m["nominal_pfa"],
                            reference_D90_db=ref["D90_db"],one_db_D90_target=target,new_D90_db=d,
                            delta_D90_db=d-ref["D90_db"] if d is not None and ref["D90_db"] is not None else None,
                            one_db_D90_met=achieved,new_actual_pfa=m["actual_pfa"],
                            reference_actual_pfa=ref["actual_pfa"],audit_actual_not_above_reference=actual_guard,
                            with_audit_guard=achieved and actual_guard if achieved is not None else None,
                            scope="DEV descriptive; not independent FINAL"))
    save_csv(out/"b271_curves.csv",curves);save_csv(out/"b271_metrics.csv",metrics)
    diagnostic=out/"diagnostics";diagnostic.mkdir(exist_ok=True)
    save_csv(diagnostic/"rankmix_reference_curves.csv",ref_curves)
    save_csv(diagnostic/"rankmix_reference_metrics.csv",ref_metrics)
    save_csv(diagnostic/"b271_vs_rankmix_1db.csv",targets)
    comparisons=[]
    for candidate in [r for r in metrics if r["method"]==NAMES["guided"]]:
        baseline=next(r for r in metrics if r["method"]==NAMES["L1_TAIL"] and r["nominal_pfa"]==candidate["nominal_pfa"])
        delta=lambda field: candidate[field]-baseline[field] if candidate[field] is not None and baseline[field] is not None else None
        comparisons.append(dict(nominal_pfa=candidate["nominal_pfa"],delta_D80_db=delta("D80_db"),
            delta_D90_db=delta("D90_db"),pd_at_0_gain_pp=100*delta("pd_at_0"),
            new_actual_pfa=candidate["actual_pfa"],l1_actual_pfa=baseline["actual_pfa"],
            new_audit_false_alarms=candidate["audit_false_alarms"],l1_audit_false_alarms=baseline["audit_false_alarms"],
            audit_n=candidate["audit_n"],cal_tail_support=candidate["cal_tail_support"],
            diagnostic_only=True,automatic_promotion=False))
    save_csv(out/"b271_vs_l1_screen.csv",comparisons)
    profile_name=p.get("budget_profile","full")
    screening=profile_name!="full"
    report=dict(status="PASS_B271_DEV_REPORT",metrics=metrics,rankmix_reference=status,internal_targets=targets,
                budget_profile=profile_name,screening=screening,automatic_promotion=False,
                comparisons_vs_l1=comparisons,full_pfa1e5_gain_established=False,
                selection_warning="VAL pAUC proxy does not validate Pfa=1e-5",
                evaluation=dict(h0_cal_n=p["h0_cal_n"],h0_check_n=p["h0_audit_n"],h1_per_scr=p["h1_scenes_n"],
                                scr_grid=p["scr_grid_db"],nominal_pfas=p.get("nominal_pfas",[1e-4,1e-5])),
                scope="Screening/development only; not independent FINAL",
                tail_warning="This version evaluates nominal Pfa1e-4 only. Medium has50 CAL tail samples and~20 expected check false alarms. Screening is development, not independent final evidence.",
                smoothing=False,independent_final=False)
    write_json(out/"b271_report.json",report)
    os.environ.setdefault("MPLCONFIGDIR",str(out/".matplotlib_cache"))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    figures=out/"figures";figures.mkdir(exist_ok=True)
    for nominal in p.get("nominal_pfas",(1e-4,1e-5)):
        fig,ax=plt.subplots(figsize=(8,5))
        for name in dict.fromkeys(r["method"] for r in curves):
            q=sorted([r for r in curves if r["method"]==name and r["nominal_pfa"]==nominal],key=lambda r:r["scr_db"])
            ax.plot([r["scr_db"] for r in q],[r["pd"] for r in q],label=name,marker="o",markevery=3,markersize=3)
        ax.set(xlabel="Input SCR (dB)",ylabel="Empirical Pd",xlim=(-24,12),ylim=(0,1.02),
               title=f"SIM-R10 {profile_name.upper()} {'SCREEN' if screening else 'DEV'} | nominal Pfa={nominal:.0e}")
        ax.grid(alpha=.25);ax.legend(fontsize=8);fig.tight_layout()
        for ext in ("pdf","png"):fig.savefig(figures/f"b271_pd_scr_pfa_{nominal:.0e}.{ext}",dpi=180)
        plt.close(fig)
    for t in targets:print(f"INTERNAL rankmix target: Pfa={t['nominal_pfa']:.0e}, D90={t['new_D90_db']}, target={t['one_db_D90_target']}, met={t['one_db_D90_met']}",flush=True)
    for c in comparisons:
        print(f"vs L1 Pfa={c['nominal_pfa']:.0e}: delta_D80={c['delta_D80_db']}, "
              f"delta_D90={c['delta_D90_db']}, Pd@0 gain={c['pd_at_0_gain_pp']:+.3f}pp; "
              f"CHECK FP {c['new_audit_false_alarms']}/{c['audit_n']} vs {c['l1_audit_false_alarms']}/{c['audit_n']}",flush=True)
    print("Budget stage complete. Stopped; no automatic promotion.",flush=True)
    print(f"Report complete: {out/'b271_metrics.csv'}",flush=True)
    return report
