#!/usr/bin/env python3
"""Train only the small phase/ARS adaptation; frozen original ADN/L1 stays fixed."""
from __future__ import annotations

import argparse
import gc
import hashlib
import math
import time
from pathlib import Path

import h5py
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

from b271_data import digest_file, fingerprint, load_checkpoint, need, prepare_training, read_json, verify_l1_checkpoint, write_json
from b271_model import B271Net
from b271_profiles import profile
from source_loader import load_frozen_file, load_frozen_sources

VERSION = "B271_PHASE_ARS_TRAIN_V1"
PASS = "PASS_B271_FROZEN_L1__TRAIN_VAL_ONLY"


def rows(dataset, indices):
    indices = np.asarray(indices, dtype=np.int64)
    unique, inverse = np.unique(indices, return_inverse=True)
    return np.ascontiguousarray(dataset[unique][inverse])


def atomic_save(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(value, temporary)
    temporary.replace(path)


def selected_checkpoint(path, expected_sha, run_fingerprint, model_config, epoch, proxy):
    need(path.is_file() and digest_file(path) == expected_sha,
         "Selected checkpoint missing or differs from committed epoch; preserve files and use a new output directory")
    state = load_checkpoint(path)
    need(state.get("run_fingerprint") == run_fingerprint and
         state.get("model_config") == model_config and state.get("epoch") == epoch and
         abs(state["val_metrics"]["pauc01"]-proxy) < 1e-12,
         "Selected checkpoint internal identity differs from committed training state")
    return state


def setup(threads):
    torch.set_num_threads(threads)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False


def make_model(config, checkpoint, device):
    model = B271Net(**config)
    model.load_l1_checkpoint(checkpoint)
    return model.to(device)


def reference_forward(model, images):
    x, _ = model.suppressor(images)
    return model.detector(x)


def pauc(scores, labels, limit=0.01):
    """Exact empirical ROC area over [0,limit], divided by limit; ties grouped."""
    scores, labels = np.asarray(scores, float), np.asarray(labels)
    n0, n1 = int((labels == 0).sum()), int((labels == 1).sum())
    need(n0 and n1, "Validation requires both classes")
    order = np.argsort(-scores, kind="stable")
    s, y = scores[order], labels[order]
    ends = np.r_[np.flatnonzero(s[:-1] != s[1:]), len(s)-1]
    fp = np.r_[0., np.cumsum(y == 0)[ends] / n0]
    tp = np.r_[0., np.cumsum(y == 1)[ends] / n1]
    # Preserve every ROC vertex at the boundary. Collapsing duplicate FPRs
    # through np.interp can incorrectly give a boundary vertical jump area.
    included = fp <= limit
    x, z = fp[included], tp[included]
    if x[-1] < limit:
        right = int(np.searchsorted(fp, limit, side="left"))
        left = right-1
        endpoint = tp[left]+(tp[right]-tp[left])*(limit-fp[left])/(fp[right]-fp[left])
        x, z = np.r_[x, limit], np.r_[z, endpoint]
    integrate = np.trapezoid if hasattr(np, "trapezoid") else np.trapz
    return float(integrate(z, x) / limit)


def subset_indices(labels, families, limit, seed):
    """Deterministic equal-label, proportional-family subset of frozen rows."""
    labels = np.asarray(labels)
    need(np.isin(labels, (0,1)).all(), "Invalid subset labels")
    if not limit or limit >= len(labels):
        return np.arange(len(labels), dtype="int64")
    need(limit >= 2 and limit % 2 == 0, "Subset size must be even and at least two")
    families = np.zeros(len(labels), dtype="int64") if families is None else np.asarray(families)
    need(families.shape == labels.shape, "Subset family shape differs")
    selected=[]
    for label in (0,1):
        available=np.flatnonzero(labels==label);count=limit//2
        need(len(available)>=count, "Insufficient rows for balanced subset")
        values=np.unique(families[available])
        groups=[available[families[available]==v] for v in values]
        desired=count*np.array([len(g) for g in groups],dtype=float)/len(available)
        quota=np.floor(desired).astype(int)
        remainder=count-int(quota.sum())
        quota[np.argsort(-(desired-quota),kind="stable")[:remainder]]+=1
        for j,(group,n) in enumerate(zip(groups,quota)):
            rng=np.random.default_rng(seed+1000*label+j)
            selected.extend(rng.permutation(group)[:n])
    return np.sort(np.asarray(selected,dtype="int64"))


class Data:
    def __init__(self, context, train_limit=0, val_limit=0, seed=20261022):
        self.context = context
        self.maps = h5py.File(context["cache"], "r")
        self.iq = h5py.File(context["bank_dir"] / context["b210"].H5_NAME, "r")
        self.selected = {}
        self.selection = {}
        for split,limit,offset in (("train",train_limit,27101),("val",val_limit,27102)):
            need(np.array_equal(self.maps[split]["label"][:], self.iq[split]["label"][:]),
                 "Original IQ/cache label ordering differs")
            labels=self.maps[split]["label"][:].astype("int64")
            families=self.iq[split]["family_index"][:] if "family_index" in self.iq[split] else None
            chosen=subset_indices(labels,families,limit,seed+offset)
            self.selected[split]=chosen
            self.selection[split]=dict(count=len(chosen),original_count=len(labels),
                row_indices_sha256=hashlib.sha256(chosen.astype("<i8").tobytes()).hexdigest(),
                counts_by_label={str(v):int((labels[chosen]==v).sum()) for v in (0,1)},
                family_stratified=families is not None)
        self.labels = rows(self.maps["train"]["label"],self.selected["train"]).astype("int64")

    def original_rows(self, split, indices):
        return self.selected[split][np.asarray(indices,dtype="int64")]

    def fetch(self, split, indices):
        indices=self.original_rows(split,indices)
        maps = rows(self.maps[split]["wvd"], indices).astype("float32")
        iq = rows(self.iq[split]["iq"], indices).astype("complex64")
        labels = rows(self.iq[split]["label"], indices).astype("int64")
        return maps, iq, labels

    def close(self):
        self.maps.close()
        self.iq.close()


def tensors(context, maps, iq):
    device = context["device"]
    images = context["source"].map_to_adn_input(torch.from_numpy(maps).to(device))
    return images, torch.from_numpy(iq).to(device)


@torch.inference_mode()
def validation(model, data, context, batch, reference_only=False):
    model.eval()
    score, labels, loss, correct = [], [], 0., 0
    n = len(data.selected["val"])
    for start in range(0, n, batch):
        indices = np.arange(start, min(start+batch, n))
        maps, iq, y = data.fetch("val", indices)
        images, iq = tensors(context, maps, iq)
        logits = reference_forward(model,images) if reference_only else model(images, iq)
        target = torch.from_numpy(y).to(context["device"])
        loss += float(F.cross_entropy(logits, target, reduction="sum"))
        correct += int((logits.argmax(1) == target).sum())
        score.append((logits[:, 1]-logits[:, 0]).double().cpu().numpy())
        labels.append(y)
    score, labels = np.concatenate(score), np.concatenate(labels)
    original = load_frozen_file("r10_sim_stage_b214_ablation_train_v1.py")
    return dict(val_ce=loss/n, val_acc=correct/n, auc=original.auc(score, labels),
                pauc01=pauc(score, labels), n_val=n, n_h0=int((labels == 0).sum()),
                n_h1=int((labels == 1).sum()), proxy_fpr_limit=0.01,
                proxy_is_not_pfa_1e5_validation=True)


@torch.inference_mode()
def extra_h0_pool(a, context, model, initialization_sha):
    """Screen an independent TRAIN-only stream; retain only hard/random IQ.

    This explicitly increases the training exposure budget. It does not open
    original CAL/AUDIT/DEV arrays. The exact same pool is used by all ablations.
    """
    n = a.train_h0_proposals
    if n == 0:
        return None
    folder = a.out_dir / "train_h0_pool"
    config = dict(version=VERSION, n_proposals=n, retained_hard=min(a.pool_size, n),
                  retained_random=min(256, n), master_seed=20261009,
                  split="b271_training_h0_v1", generator_sha=context["bc"].get("generator_sha256"),
                  baseline_checkpoint_sha=initialization_sha, source_sha=context["b210"].SOURCE_SHA,
                  bank_sha=context["bc"]["file_sha256"], device_type=context["device"].type,
                  tf32=False, screening_batch=a.batch, random_selection_seed=a.seed+90001,
                  screening_code_sha256=digest_file(Path(__file__)))
    fp = fingerprint(config)
    contract_path, target = folder/"contract.json", folder/"pool.h5"
    if contract_path.exists():
        contract = read_json(contract_path)
        need(contract["fingerprint"] == fp and digest_file(target) == contract["pool_sha256"],
             "Independent training H0 pool changed")
        return target
    folder.mkdir(exist_ok=True)
    progress_path, score_path = folder/"progress.json", folder/"baseline_scores.npy"
    if progress_path.exists():
        progress = read_json(progress_path)
        need(progress["fingerprint"] == fp and score_path.is_file(), "Pool resume identity differs")
        scores = np.load(score_path, mmap_mode="r+")
    else:
        need(not score_path.exists() and not target.exists(), "Untracked pool files; preserve output")
        progress = dict(fingerprint=fp, done=0)
        scores = np.lib.format.open_memmap(score_path, mode="w+", dtype="float64", shape=(n,))
        write_json(progress_path, progress)
    need(scores.shape == (n,), "Proposal score shape differs")
    generator = load_frozen_file("r10_sim_iq512_builder_v1_EARLIEST_HDF5.py")
    model.eval()
    started, initially = time.perf_counter(), int(progress["done"])
    need(0<=initially<=n and scores.dtype==np.dtype("float64"), "Invalid proposal progress/dtype")
    for start in range(initially, n, 256):
        stop = min(start+256, n)
        samples = [generator.make_one(config["master_seed"], config["split"], i, -30, 10)
                   for i in range(start, stop)]
        need(all(s["label"] == 0 and not np.any(s["target"]) for s in samples), "TRAIN H0 contains a target")
        iq = np.stack([s["base"] for s in samples]).astype("complex64")
        for first in range(0, len(iq), a.batch):
            x = torch.from_numpy(iq[first:first+a.batch]).to(context["device"])
            images = context["source"].map_to_adn_input(context["source"].wvd_base_map(x))
            logits = reference_forward(model, images)
            scores[start+first:start+first+len(x)] = (logits[:, 1].double()-logits[:, 0].double()).cpu().numpy()
        scores.flush()
        progress["done"] = stop
        write_json(progress_path, progress)
        if stop == n or stop % 10000 < 256:
            rate = (stop-initially)/max(time.perf_counter()-started, 1e-6)
            print(f"[TRAIN-only H0 proposals] {stop:,}/{n:,}; {rate:.1f}/s", flush=True)
    need(np.isfinite(scores).all(), "Nonfinite proposal score")
    top = np.argsort(np.asarray(scores), kind="stable")[-config["retained_hard"]:]
    random = np.random.default_rng(config["random_selection_seed"]).choice(n, config["retained_random"], replace=False)
    ids = np.unique(np.r_[top, random])
    temp = target.with_suffix(".h5.tmp")
    need(not temp.exists() and not target.exists(), "Incomplete retained pool exists; inspect before retrying")
    with h5py.File(temp, "w") as h:
        h.create_dataset("proposal_index", data=ids)
        iq_ds = h.create_dataset("iq", (len(ids), 512), dtype="complex64", compression="lzf")
        w_ds = h.create_dataset("wvd", (len(ids), 128, 128), dtype="float32", chunks=(1,128,128), compression="lzf")
        for start in range(0, len(ids), a.batch):
            end = min(start+a.batch, len(ids))
            iq = np.stack([generator.make_one(config["master_seed"], config["split"], int(i), -30, 10)["base"]
                           for i in ids[start:end]]).astype("complex64")
            x = torch.from_numpy(iq).to(context["device"])
            iq_ds[start:end], w_ds[start:end] = iq, context["source"].wvd_base_map(x).cpu().numpy()
    temp.replace(target)
    write_json(contract_path, dict(config=config, fingerprint=fp, pool_sha256=digest_file(target),
                                   retained=len(ids), proposal_scores_sha256=digest_file(score_path),
                                   original_cal_audit_dev_opened=False))
    print(f"TRAIN-only hard/random H0 pool: {len(ids)} retained from {n:,} independent proposals", flush=True)
    return target


@torch.inference_mode()
def hard_order(model, data, context, pool, batch):
    model.eval()
    indices = np.flatnonzero(data.labels == 0)
    values = []
    for start in range(0, len(indices), batch):
        maps, iq, _ = data.fetch("train", indices[start:start+batch])
        images, iq = tensors(context, maps, iq)
        logits = model(images, iq)
        values.extend((logits[:, 1]-logits[:, 0]).cpu().tolist())
    source = np.zeros(len(indices), dtype="int64")
    if pool is not None:
        extra_scores = []
        for start in range(0, len(pool["iq"]), batch):
            maps = np.asarray(pool["wvd"][start:start+batch], dtype="float32")
            iq = np.asarray(pool["iq"][start:start+batch], dtype="complex64")
            images, iq = tensors(context, maps, iq)
            logits = model(images, iq)
            extra_scores.extend((logits[:, 1]-logits[:, 0]).cpu().tolist())
        source = np.r_[source, np.ones(len(extra_scores), dtype="int64")]
        indices = np.r_[indices, np.arange(len(extra_scores))]
        values.extend(extra_scores)
    selected = np.argsort(np.asarray(values), kind="stable")[-min(256, len(values)):]
    return np.stack((source[selected], indices[selected]), 1)


def fetch_hard(selection, data, pool):
    maps, iq = [], []
    for is_pool, index in selection:
        index=int(index) if is_pool else int(data.original_rows("train",[index])[0])
        group = pool if is_pool else data.maps["train"]
        maps.append(group["wvd"][int(index)])
        iq.append((pool["iq"] if is_pool else data.iq["train"]["iq"])[int(index)])
    return np.asarray(maps, dtype="float32"), np.asarray(iq, dtype="complex64")


def train_one(a, context, data, initialization, initialization_sha, pool_path, variant):
    out = a.out_dir / variant
    config = dict(version=VERSION, seed=a.seed, variant=variant, epochs=a.epochs,
                  budget_profile=a.profile, selected_rows=data.selection,
                  min_epochs=a.min_epochs, patience=a.patience, batch=a.batch, lr=a.lr,
                  bank_sha=context["bc"]["file_sha256"], cache_sha=context["cc"]["wvd_cache_sha256"],
                  initialization_sha=initialization_sha, pool_sha=digest_file(pool_path) if pool_path else None,
                  hard_weight=a.hard_weight, consistency_weight=a.consistency_weight, warp_weight=a.warp_weight,
                  maximum_offset=a.maximum_offset, correction_bound=a.correction_bound,
                  code_sha={p.name:digest_file(p) for p in sorted(Path(__file__).parent.glob("*.py"))})
    fp = fingerprint(config)
    contract_path, latest = out/"training_contract.json", out/"last_epoch.pt"
    if contract_path.exists():
        c = read_json(contract_path)
        need(c["run_fingerprint"] == fp and digest_file(out/"best.pt") == c["checkpoint_sha256"],
             "Completed run differs; choose a new output directory")
        print(f"[{variant}] completed and verified", flush=True)
        return c
    if out.exists() and any(out.iterdir()):
        need(a.resume and latest.is_file(), "Incomplete model output; resume same configuration or use new output")
    out.mkdir(exist_ok=True)
    torch.manual_seed(a.seed)
    model_config = dict(variant=variant, maximum_offset=a.maximum_offset, correction_bound=a.correction_bound)
    model = make_model(model_config, initialization, context["device"])
    optimizer = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=a.lr, weight_decay=1e-3)
    history, start_epoch, best_epoch, best_proxy = [], 1, 0, -1.
    initial = validation(model, data, context, a.batch)
    baseline = validation(model,data,context,a.batch,reference_only=True)
    need(abs(initial["val_ce"]-baseline["val_ce"]) < 1e-6,
         "Zero-initialized candidate differs from original L1 on the SAME selected VAL rows")
    if len(data.selected["val"])==len(data.iq["val"]["label"]):
        need(abs(initial["val_ce"]-initialization["val_metrics"]["val_ce"]) < 1e-4,
             "Full frozen validation CE does not replay historical L1")
    def snapshot(epoch, metrics):
        return dict(version=VERSION, variant=variant, state_dict=model.state_dict(),
                    model_config=model_config, epoch=epoch, val_metrics=metrics,
                    run_config=config, run_fingerprint=fp, initialization_sha256=initialization_sha)
    if latest.exists():
        state = load_checkpoint(latest)
        need(state["run_fingerprint"] == fp and state["model_config"] == model_config,
             "Resume configuration differs")
        best_epoch, best_proxy = state["best_epoch"], state["best_proxy"]
        best_sha = state.get("best_checkpoint_sha256")
        selected_checkpoint(out/"best.pt", best_sha, fp, model_config, best_epoch, best_proxy)
        model.load_state_dict(state["state_dict"], strict=True)
        optimizer.load_state_dict(state["optimizer"])
        history, start_epoch = state["history"], state["epoch"]+1
        torch.set_rng_state(state["torch_rng"])
        if context["device"].type == "cuda":
            torch.cuda.set_rng_state_all(state["cuda_rng"])
    else:
        best_proxy = initial["pauc01"]
        atomic_save(out/"best.pt", snapshot(0, initial))
        best_sha = digest_file(out/"best.pt")
        write_json(out/"initial_validation.json", initial)
    reference_loss = load_frozen_sources()[2]
    pool = h5py.File(pool_path, "r") if pool_path else None
    try:
        last_epoch = start_epoch-1
        for epoch in range(start_epoch, a.epochs+1):
            if a.patience and last_epoch >= a.min_epochs and last_epoch-best_epoch >= a.patience:
                break
            started = time.perf_counter()
            bank = hard_order(model, data, context, pool, a.batch) if a.hard_weight else None
            model.train()
            totals = np.zeros(7)
            seen, global_step = 0, 0
            for indices in context["b210"].indices(data.labels, epoch, a.batch, a.seed):
                maps, iq, labels = data.fetch("train", indices)
                n = len(indices)
                if bank is not None:
                    chosen = bank[(np.arange(16)+16*global_step) % len(bank)]
                    extra_maps, extra_iq = fetch_hard(chosen, data, pool)
                    maps, iq = np.concatenate((maps, extra_maps)), np.concatenate((iq, extra_iq))
                images, iq_tensor = tensors(context, maps, iq)
                y = torch.from_numpy(labels).to(context["device"])
                optimizer.zero_grad(set_to_none=True)
                logits, aux = model(images, iq_tensor, return_aux=True)
                aux = {k:v[:n] if torch.is_tensor(v) and v.ndim and len(v)==len(images) else v for k,v in aux.items()}
                original, _, _, _ = reference_loss.compute_loss("L1_TAIL", logits[:n], y, aux)
                hard = logits.new_zeros(())
                positive = torch.nonzero(y==1, as_tuple=False).flatten()
                if bank is not None:
                    # Re-forward current hard samples, retaining their gradient.
                    margin = logits[:, 1]-logits[:, 0]
                    hard = F.softplus(0.5 + margin[n:, None]-margin[positive][None]).mean()
                consistency = logits.new_zeros(())
                if a.consistency_weight and positive.numel():
                    chosen = positive[:4]
                    source_rows = data.original_rows("train",np.asarray(indices)[chosen.cpu().numpy()])
                    target = rows(data.iq["train"]["target_iq"], source_rows).astype("complex64")
                    stronger = iq[chosen.cpu().numpy()] + np.float32(10**(3/20)-1) * target
                    stronger_iq = torch.from_numpy(stronger).to(context["device"])
                    stronger_maps = context["source"].wvd_base_map(stronger_iq)
                    stronger_images = context["source"].map_to_adn_input(stronger_maps)
                    z = model(stronger_images, stronger_iq)
                    strong_score = z[:, 1]-z[:, 0]
                    weak_score = (logits[chosen, 1]-logits[chosen, 0]).detach()
                    consistency = F.relu(weak_score-strong_score).mean()
                warp = aux["offset_regularizer"]
                loss = original + a.hard_weight*hard + a.consistency_weight*consistency + a.warp_weight*warp
                need(torch.isfinite(loss).item(), "Nonfinite training objective")
                loss.backward()
                norm = torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], 1.)
                need(torch.isfinite(norm).item(), "Nonfinite new-module gradient")
                optimizer.step()
                diagnostic = aux["offset_diagnostics"]
                saturation = max((d["saturation"] for d in diagnostic),default=0.)
                folded = max((d["negative_jacobian"] for d in diagnostic),default=0.)
                totals += np.array([float(loss.detach()),float(original.detach()),float(hard.detach()),
                                    float(consistency.detach()),float(warp.detach()),saturation,folded])*n
                seen += n
                global_step += 1
            metrics = validation(model, data, context, a.batch)
            eligible = metrics["val_ce"] <= initial["val_ce"] + 0.03
            if eligible and metrics["pauc01"] > best_proxy+1e-6:
                best_epoch, best_proxy = epoch, metrics["pauc01"]
                atomic_save(out/"best.pt", snapshot(epoch, metrics))
                best_sha = digest_file(out/"best.pt")
            row = dict(epoch=epoch, train_loss=float(totals[0]/seen), original_loss=float(totals[1]/seen),
                       crossbatch_rank=float(totals[2]/seen), consistency_loss=float(totals[3]/seen),
                       offset_penalty=float(totals[4]/seen),offset_saturation=float(totals[5]/seen),
                       offset_negative_jacobian=float(totals[6]/seen),
                       **metrics, ce_guard_pass=eligible, best_epoch=best_epoch,
                       elapsed_s=time.perf_counter()-started)
            history.append(row)
            state = snapshot(epoch, metrics)
            state.update(optimizer=optimizer.state_dict(),history=history,best_epoch=best_epoch,
                         best_proxy=best_proxy,best_checkpoint_sha256=best_sha,torch_rng=torch.get_rng_state(),
                         cuda_rng=torch.cuda.get_rng_state_all() if context["device"].type=="cuda" else [])
            atomic_save(latest, state)
            pd.DataFrame(history).to_csv(out/"train_val_history.csv", index=False)
            last_epoch = epoch
            print(f"[{variant}] {epoch}/{a.epochs} VAL_CE={metrics['val_ce']:.6f} "
                  f"pAUC01={metrics['pauc01']:.6f} best_epoch={best_epoch} "
                  f"time={row['elapsed_s']:.1f}s", flush=True)
        best = selected_checkpoint(out/"best.pt", best_sha, fp, model_config, best_epoch, best_proxy)
        model.load_state_dict(best["state_dict"], strict=True)
        restored = validation(model, data, context, a.batch)
        need(abs(restored["pauc01"]-best_proxy)<1e-8, "Selected checkpoint replay differs")
        # Confirm that no original tensor, including all BN buffers, changed.
        for key, value in initialization["state_dict"].items():
            need(torch.equal(model.state_dict()[key].cpu(),value.cpu()), "Frozen original L1 changed: "+key)
        contract = dict(version=VERSION,status=PASS,variant=variant,run_fingerprint=fp,
                        model_config=model_config,best_epoch=best_epoch,epochs_executed=last_epoch,
                        selected_validation=restored,checkpoint_sha256=digest_file(out/"best.pt"),
                        initialization_sha256=initialization_sha,run_config=config,
                        baseline_validation=baseline,budget_profile=a.profile,selected_rows=data.selection,
                        trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),
                        original_weights_and_bn_unchanged=True,
                        selection="VAL pAUC[0,0.01] with CE <= original CE+0.03; epoch0 eligible",
                        original_cal_audit_dev_used=False,
                        one_db_gain_established=False)
        write_json(contract_path, contract)
        print(f"[{variant}] complete; selected epoch={best_epoch}; {out/'best.pt'}", flush=True)
    finally:
        if pool:pool.close()
    del model, optimizer
    gc.collect()
    if context["device"].type=="cuda":torch.cuda.empty_cache()
    return contract


def cli(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, default=Path(__file__).resolve().parent.parent)
    p.add_argument("--cache-dir", type=Path)
    p.add_argument("--out-dir", type=Path)
    p.add_argument("--l1-checkpoint", type=Path)
    p.add_argument("--variants", default="guided")
    p.add_argument("--profile", choices=("small","medium","full"), default="medium")
    p.add_argument("--train-limit", type=int)
    p.add_argument("--val-limit", type=int)
    p.add_argument("--epochs", type=int)
    p.add_argument("--min-epochs", type=int)
    p.add_argument("--patience", type=int)
    p.add_argument("--batch", type=int, default=32)
    p.add_argument("--lr", type=float, default=2e-4)
    p.add_argument("--hard-weight", type=float, default=0.05)
    p.add_argument("--consistency-weight", type=float, default=0.05)
    p.add_argument("--warp-weight", type=float, default=0.001)
    p.add_argument("--train-h0-proposals", type=int)
    p.add_argument("--pool-size", type=int)
    p.add_argument("--maximum-offset", type=float, default=0.75)
    p.add_argument("--correction-bound", type=float, default=3.)
    p.add_argument("--seed", type=int, default=20261022)
    p.add_argument("--device", choices=("cuda","cpu"), default="cuda")
    p.add_argument("--cpu-threads", type=int, default=4)
    p.add_argument("--resume", action="store_true")
    p.add_argument("--preflight", action="store_true")
    a=p.parse_args(argv)
    budget=profile(a.profile)
    for field in ("train_limit","val_limit","epochs","min_epochs","patience","train_h0_proposals","pool_size"):
        if getattr(a,field) is None:setattr(a,field,budget[field])
    need(a.train_limit>=0 and a.val_limit>=0 and a.train_limit%2==a.val_limit%2==0,"Invalid train/VAL subset sizes")
    need(a.batch>0 and a.batch%2==0 and a.epochs>=a.min_epochs>=1 and a.patience>=0, "Invalid batch/epoch settings")
    need(a.train_h0_proposals>=0 and a.pool_size>0 and a.cpu_threads>0, "Invalid H0 pool/thread settings")
    need(math.isfinite(a.lr) and a.lr>0 and all(math.isfinite(v) and v>=0 for v in
         (a.hard_weight,a.consistency_weight,a.warp_weight)), "Invalid optimizer/loss settings")
    need(0<a.maximum_offset<=1 and 0<a.correction_bound<=5, "Invalid adaptation bounds")
    a.root=a.root.resolve()
    a.out_dir=(a.out_dir or a.root/("output_b271_v2_"+a.profile)).resolve()
    a.l1_checkpoint=(a.l1_checkpoint or a.root/"output_sim_r10_b215_tpht_train_v1"/f"trainseed_{a.seed}"/"L1_TAIL/best_val_ce.pt").resolve()
    if a.cache_dir is None and (a.root/"output_sim_r10_b270_wvd_rebuilt_v1").is_dir():
        a.cache_dir=a.root/"output_sim_r10_b270_wvd_rebuilt_v1"
    a.variants=a.variants.split(",")
    need(len(a.variants)==len(set(a.variants)) and set(a.variants)<=set(("guided","no_phase","head_control")), "Unknown/duplicate variants")
    return a


def main(argv=None):
    a=cli(argv)
    setup(a.cpu_threads)
    context=prepare_training(a.root,cache_dir=a.cache_dir,device=a.device)
    initialization,sha=verify_l1_checkpoint(a.l1_checkpoint,context,a.seed)
    data=Data(context,a.train_limit,a.val_limit,a.seed)
    print(f"B271 {a.profile}: TRAIN={len(data.labels)}, VAL={len(data.selected['val'])}, maximum_epochs={a.epochs}",flush=True)
    try:
        if a.preflight:
            model=make_model(dict(variant="guided"),initialization,context["device"])
            result=validation(model,data,context,a.batch)
            baseline=validation(model,data,context,a.batch,reference_only=True)
            need(abs(result["val_ce"]-baseline["val_ce"])<1e-6,"Same-subset original validation replay failed")
            if len(data.selected["val"])==len(data.iq["val"]["label"]):
                need(abs(result["val_ce"]-initialization["val_metrics"]["val_ce"])<1e-4,"Full original validation replay failed")
            print("B271 data/model preflight passed; no updates executed",flush=True)
            return
        a.out_dir.mkdir(parents=True,exist_ok=True)
        run=dict(version=VERSION,seed=a.seed,variants=a.variants,bank_dir=str(context["bank_dir"]),
                 profile=a.profile,selected_rows=data.selection,
                 cache_dir=str(context["cache_dir"]),l1_checkpoint=str(a.l1_checkpoint),
                 initialization_sha256=sha,proposal_count=a.train_h0_proposals)
        manifest=a.out_dir/"run_manifest.json"
        if manifest.exists():need(read_json(manifest)==run,"Run manifest differs; choose a new output")
        else:
            need(not any(a.out_dir.iterdir()),"Output is not empty")
            write_json(manifest,run)
        torch.manual_seed(a.seed)
        screening=make_model(dict(variant="head_control"),initialization,context["device"])
        pool=extra_h0_pool(a,context,screening,sha) if a.hard_weight else None
        del screening
        if context["device"].type=="cuda":torch.cuda.empty_cache()
        for variant in a.variants:
            train_one(a,context,data,initialization,sha,pool,variant)
    finally:
        data.close()
    print(PASS,flush=True)


if __name__=="__main__":
    main()
