# B271 V2：默认中规模，Pfa=10⁻⁴，出图后停止

供下一轮候选筛选使用。当前V1任务继续原配置。本包独立目录为
B271_ADN_PHASE_ARS_V2，输出与V1分开，GPU任务共用排他锁。
模型结构、原L1权重与BN冻结方式与V1相同，详见MODEL_DETAILS.md。

## 固定预算

| 档位 | 新模块TRAIN / VAL | 最多epoch | 训练H0提案 | CAL / H0检查 | H1 / SCR | SCR点数 |
|---|---:|---:|---:|---:|---:|---:|
| small | 8000 / 2000 | 4 | 20000 | 100000 / 50000 | 256 | 11 |
| medium（默认） | 16000 / 3000 | 6 | 60000 | 500000 / 200000 | 1024 | 37 |
| full（显式请求） | 30000 / 5000 | 12 | 200000 | 3000000 / 1000000 | 1024 | 37 |

三个档位均只输出Pfa=1e-4。中规模不是只跑少量目标：保留完整37个SCR点和
每点1024个目标。CAL有50个名义尾部样本，H0检查预计20个虚警；仍有抽样
不确定性，报告提供实际虚警率与Wilson区间。不会用小样本声称1e-5结论。

每档只运行一次训练→评分→绘图，结束就停止，不自动升级。先看D80/D90、
Pd@0变化和实际虚警，再决定扩大、修改或放弃。未通过筛选也不代表已经证明
模型无效：欠训练、抽样波动和不同种子仍可能影响结果。

## 数据与恢复

原30K/5K冻结IQ与WVD缓存直接读取，不复制。medium/small从原TRAIN和VAL
分别按标签平衡、杂波类型比例抽取固定子集，保存源行号摘要；IQ、WVD、
target_iq和难例索引保持对应。同子集原L1前向用于初始化重放及CE选择保护。
full仍核对历史完整VAL的CE。抽子集不会重新训练已有L1预训练权重。

small/medium的CAL、H0检查与H1使用独立开发种子/阶段，区别于原B213大规模
场景；候选和原L1在同一档位使用同一场景与各自CAL门限。跨档曲线不作未经
核实的逐场景配对结论。筛选结果用于开发，不能包装为独立盲测。

额外H0提案仅为训练曝光：medium最多保留512个高分和256个随机候选，不保存
6万条完整WVD。历史完整scorebank只在full档位核验与使用；不同筛选场景下
不叠加历史LMDA/排名融合曲线。本候选不加载LMDA网络或权重。

训练恢复在epoch边界，评分在H0分块/H1-SCR边界。配置、源代码、checkpoint、
数据或已提交数组变动会拒绝混用。新预算使用独立输出目录。extra_h0_pool保留池
写入中断的.tmp会停止并保留现场，不会自动删除。原B270恢复缓存继续使用。

## AutoDL运行

~~~bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1/B271_ADN_PHASE_ARS_V2
nohup /root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  bash run_b271_stage.sh medium \
  >> ../codex_b271_v2_medium.log 2>&1 < /dev/null &
tail -f ../codex_b271_v2_medium.log
~~~

脚本打印阶段耗时和推理速度/ETA。输出在 ../output_b271_v2_medium：
guided/train_val_history.csv、guided/best.pt，以及pd_scr_medium_v2下的
b271_metrics.csv、b271_curves.csv、b271_vs_l1_screen.csv、b271_report.json和
figures/b271_pd_scr_pfa_1e-04.pdf（另有PNG）。

只对已有权重做中规模评分，避免重复训练：

~~~bash
bash run_b271_stage.sh medium --score-only \
  --run-dir /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1/output_b271_phase_ars_v1
~~~

这会使用新筛选场景，不复用V1大规模CAL的数值前缀。当前V1在运行时共享锁
会拒绝并行启动。新推理结果另存已有run下的pd_scr_medium_v2。

需要进一步确认时，显式运行bash run_b271_stage.sh full；该档独立从原L1
初始化训练，不把中规模筛选权重静默改作完整预算模型。可选择small初筛，
但默认medium符合当前需求。自定义预算、消融请用run_b271_train.sh --help。

## 方法与验证限制

参考TPAMI2025的SFM下采样前重采样机制，并独立做IQ相位证据适配，具体来源
及实现见MODEL_DETAILS.md与provenance.json。新增输入IQ、额外训练曝光、
仿真target_iq一致性监督需要披露；不能把全部增益归给采样模块。guided/
no_phase/head_control是组合控制，不能单独分离相位、功率、重采样和直接证据头
的每一项贡献。同预算控制与后续单因素消融仍需真实实验。

仅完成13项人工输入CPU功能测试、脚本顺序/失败停止/共享锁验证和9份原源码
摘要校验。人工构造的左移只是报告逻辑测试，不是检测效果。未在AutoDL真实
运行V2，未证明1dB改善。基于已有约519条/秒，中规模从头评分约24分钟，
不含训练、校验和加载；实耗以新日志为准。

~~~bash
python -m unittest discover -s tests -v
~~~
