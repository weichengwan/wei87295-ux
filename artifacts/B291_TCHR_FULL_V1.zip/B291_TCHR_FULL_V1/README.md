# B291：TFSE 条件高频细化，全量 Ours 继续训练

只训练两个 **ADN + TFSE + TCHR** 候选配置。均从已经完成的 **B289 FULL（ADN + TFSE + DHiF）** 权重开始；不训练、不继续训练、不完整评分原始 ADN、TFSE-only、ADN+DHiF 或外部 baseline。B289 旧 Ours 分数仅在训练和选择完成后按严格协议核对并只读叠图，缺失时跳过，不触发重跑。

## 实质改动和来源

借鉴 Li 等的 *Dynamic High-Frequency Convolution for Infrared Small Target Detection*，IEEE TCSVT 2026，DOI **10.1109/TCSVT.2026.3661285**。作者仓库：<https://github.com/TinaLRJ/DHiF>，核对提交 `06862c844bc16a3b5ee0d0019e5ae24f0f1bb4e7`。`dhif_module.py` 是原机制的独立实现，历史数值核对见 `AUTHOR_PARITY.json`，不是 B291 原创。

候选改进模块名：**时频条件高频细化**，**Time-frequency Conditioned High-frequency Refinement (TCHR)**。

```
复数 IQ512
  → 既有 TFSE：1/5/9 时间窗 SPWVD 组 + 空间门控 → 3×224×224
  → 原 ADN Stem → Layer1 → Layer2（含原生 SimAM）
  → TCHR → 原 Layer3 → Layer4 → 池化 → 二分类分数

TFSE 一致性、跨尺度差异、增益和两路修正控制
  → 5 通道条件图 → 小型卷积分支（857 个新增参数）
  → 直接调节 TCHR 内部 9×9 动态滤波矩阵
```

令已有 DHiF 的滤波预激活为 `u`，条件分支为 `H(g)`：

1. `A0=tanh(u)`：保留训练好的原算子。
2. `D=tanh(u+H(g))-tanh(u)`，在输入 patch 维上减均值。
3. `ΔA=0.25*D/(1+max(abs(D)))`，`A=A0+ΔA`。
4. 后续保留 DHiF 的局部滤波、原始 patch 加和及基卷积。

**只有新增修正 ΔA** 具有零输入和，因此对局部恒定 patch 的新增响应为零；原 DHiF 不具有这一保证，图像边缘的零填充也不能当作恒定 patch。这里的高频指 CNN 特征变化，不等同于目标物理多普勒。条件图并非目标真值，也不能保证高一致性区域都是目标。

新增分支末层零初始化，所有 B289 张量完整加载，启动时检查初始 logits 与旧 Ours 最大差不超过 1e-6。只将 TFSE 最后的 27 个控制参数开放为低学习率联合训练；TFSE pre 网络、所有原生 BN 参数和运行统计保持冻结。原 ADN 的 8 个 SimAM 完整保留。TFCG、旧 Tail 和 CGCR 均未接回。

这些是可检验的任务适配设计，论文应注明 DHiF 来源。是否能称为有效创新还需要实验和匹配训练预算的消融支持；改名本身不是创新。当前两配置同时改变参数和随机种子，是探索配置，不是单因素消融，也不能用二者方差充当随机种子置信区间。

## 损失与配置

`L = CE + λ_rank L_rank + 0.02 L_keep`。

- 用冻结 B289 Ours 对 **200,000 个独立 TRAIN-only H0** 提案打分，保留 1,024 个高分和 1,024 个不重叠随机 H0；额外缓存约数 MiB，不生成多 GiB 特征缓存。
- 专用生成 split 为 `train_h0_b291`，每条样本验证 H0 和无目标，与正式 CAL、AUDIT、DEV_H1 分离。原 TRAIN 的教师分数仅用于响应保持。
- 每批 24 条原 TRAIN + 8 条 H0 回放，每 epoch 遍历全部原 30,000 条 TRAIN；完整 5,000 条 VAL 不加回放。
- `L_rank` 比较 batch 中最高四分之一 H0 分数与 H1，softplus 温度 .5、间隔 .5；分数按冻结原 TRAIN H0 的 IQR 尺度标准化。H1 权重有下限，按冻结教师不确定性加权。
- `L_keep` 对教师分数为正的 TRAIN H1，惩罚标准化目标分数下降超过 .25，允许目标响应增加。
- 权重衰减 1e-5，梯度裁剪 5，12 epochs：第 1 epoch 只训练新条件分支，之后联合训练并余弦降到初始学习率的 20%。不使用 AMP、TF32。

| 配置 | seed | 骨干 LR | 已有 DHiF LR | 新条件分支 LR | TFSE head LR | λ_rank |
|---|---:|---:|---:|---:|---:|---:|
| conservative | 20261023 | 2e-6 | 2e-5 | 1e-4 | 5e-7 | .05 |
| tail_focused | 20261024 | 3e-6 | 3e-5 | 1.5e-4 | 1e-6 | .10 |

已有权重已收敛，因此减少更新幅度；新增路径需要较高 LR 才能学到条件信息。高分 H0 回放面向尾部排序，**不保证**比旧 Ours 左移，更不保证 1 dB。

只按 full VAL pAUC@FPR≤.01 选 checkpoint，并要求 CE≤初始 CE+.02；包含 epoch0 回退。若没有训练 epoch 超过初始指标，`source_function_fallback=true` 明确标出，不能把这条原函数曲线当作新模块有效的证据。5000 VAL 中的2500 H0不足以直接验证1e-5性能，pAUC只是选择代理指标。两配置的选择在读取正式分数前提交，随后保留并报告两者全部结果。

## 运行

解压到 `/root/autodl-tmp/MTDSP_NATIVE_LMDA_V1/B291_TCHR_FULL_V1` 后：

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
bash B291_TCHR_FULL_V1/start_on_autodl.sh
tail -F codex_b291_tchr_full.log
```

启动器使用 `nohup`、`conda run -n mpdnet-r10` 和共享锁 `codex_b271_night.lock`，排队等待之前使用该锁的任务，不终止旧实验。其它未使用该锁的任务不受此排队器管理。断开 SSH/热点不影响已启动的后台进程；服务器关机、容器停止或进程被杀会中断。使用相同命令可恢复：训练按已提交 epoch 恢复，提案打分/推理按已提交 chunk 恢复。重复点击启动有 PID 检查。

默认只读取以下旧文件：

- `SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1` 中的 IQ TRAIN/VAL bank、contract、audit。
- `output_b289_dhif_two_full_v2/FULL/{best.pt,training_contract.json}`。
- `output_b289_dhif_two_full_v2/pd_scr_full/protocol_frozen.json`（场景定义）。
- `output_b280_full_ablation_v1/A1/training_contract.json`（只读 TFSE scale 和来源哈希；不加载 A1 权重）。

所有旧文件哈希受到保护。若路径不同，可给 `start_on_autodl.sh` 传 `--old-ours-run /实际B289目录 --b280-run /实际B280目录`。缺文件时明确报错，不自动重训 baseline。新目录须为项目根目录下的 `output_b291_tchr_*`，默认 `output_b291_tchr_full_v1`。约需 3 GiB 可用空间用于两配置的断点权重、原子写临时文件和分数。

## 全量评估及结果

直接全量，不先跑 medium：**3,000,000 H0 CAL +1,000,000 独立 H0 AUDIT +每 SCR 1024 H1，SCR -24…+24 dB，49点，Pfa=1e-4和1e-5**。两配置共享 IQ 和 TFSE bank 计算，各自使用自己 CAL 阈值，以严格 `score>threshold` 判决；阈值不按 Pd 调整。H0 AUDIT 报实际虚警及 Wilson 区间。

`output_b291_tchr_full_v1/pd_scr_full/`：

- `b291_metrics.csv`：D50/D80/D90、最大 Pd及所有对应 SCR、实际虚警。
- `b291_curves.csv`：逐点原始 Pd、计数、区间，固定先验 .5 下的 Precision/F1。
- `b291_comparisons.csv`：与旧 Ours 的共同 SCR 区间差异；仅当旧分数协议核对成功时生成。
- `b291_report.json`：来源、回退标志、VAL选择、分数哈希。
- `figures/`：两个 Pfa 的 Pd/Precision/F1，实线、空心倒三角，标题标 Pfa，轴为 SCR(dB)和 Pd。

旧 Ours 只有 -24…+12 时不延长、外推或平移其曲线。F1/Precision取决于预先固定的目标先验；这里的 .5 不代表真实海上部署先验。两配置均为反复查看过的 DEV 上探索实验，最终论文结论需要保留独立测试和匹配预算验证。

CPU 只重画，不需要 GPU，也不会推理：

```bash
/root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  bash B291_TCHR_FULL_V1/run_b291.sh --stage report --device cpu
```

## 本地验证边界

见 `VALIDATION.json`。CPU 合成测试覆盖：非零旧 DHiF 的精确接入、条件敏感性、修正零输入和、各路径梯度、训练 split 隔离、原文件不变、训练和推理恢复、仅用 VAL 选择及双虚警率报告。这里没有 AutoDL 数据或 CUDA，未测真实 Pd、运行耗时或 GPU 峰值；服务器启动时会先运行 batch32 三步梯度/显存 canary，再继续正式训练。
