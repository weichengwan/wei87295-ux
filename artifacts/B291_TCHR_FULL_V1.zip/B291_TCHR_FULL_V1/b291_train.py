"""Full TRAIN/VAL continuation of Ours only; two predeclared settings."""
import gc
import math
import time
import numpy as np
import torch
import torch.nn.functional as F
from b289_common import (need,read_json,write_json,fingerprint,code_hashes,digest_file,save_csv,
    atomic_save,load_checkpoint,snapshot,setup,roc_metrics,TRAIN_PASS)
from b291_model import Model,initial_check
from b291_loss import objective
from b291_source import verify_protected
from tfse_frontend import smoothing_bank

PRESETS={
    'conservative':dict(seed=20261023,backbone_lr=2e-6,dhif_lr=2e-5,guide_lr=1e-4,tfse_head_lr=5e-7,rank_weight=.05),
    'tail_focused':dict(seed=20261024,backbone_lr=3e-6,dhif_lr=3e-5,guide_lr=1.5e-4,tfse_head_lr=1e-6,rank_weight=.10),
}

@torch.inference_mode()
def evaluate(model,raw,device,batch):
    model.eval();n=len(raw.values['val'][1]);total=0.;scores=[];labels=[]
    for start in range(0,n,batch):
        iq,y=raw.fetch('val',slice(start,min(start+batch,n)),device)
        z=model.prepared_forward(smoothing_bank(iq,model.scale))
        need(z.shape==(len(y),2) and torch.isfinite(z).all(),'Invalid full VAL logits')
        total+=float(F.cross_entropy(z,y,reduction='sum'))
        scores.append((z[:,1]-z[:,0]).double().cpu().numpy());labels.append(y.cpu().numpy())
    return dict(val_ce=total/n,n_val=n,**roc_metrics(np.concatenate(scores),np.concatenate(labels)))

def optimizer_for(model,preset):
    groups=[]
    for name,params in [('backbone',model.net.detector.parameters()),('dhif',(p for n,p in model.refiner.named_parameters() if not n.startswith('guide.'))),
                        ('guide',model.refiner.guide.parameters()),('tfse_head',model.net.gate.head.parameters())]:
        lr=preset[name+'_lr'];groups.append(dict(params=list(params),lr=lr,base_lr=lr,name=name))
    return torch.optim.Adam(groups,weight_decay=1e-5)

def better(v,best):
    return v['val_pauc01']>best['val_pauc01']+1e-12 or (abs(v['val_pauc01']-best['val_pauc01'])<=1e-12 and v['val_ce']<best['val_ce'])

def preflight(a,info,raw,pool):
    setup(a.cpu_threads,291);model=Model(info['old'],a.correction_bound).to(a.device)
    iq,y=raw.fetch('train',slice(0,a.batch),a.device);bank=smoothing_bank(iq,model.scale)
    initial=initial_check(model,info['old'],bank);model.set_phase(False)
    opt=optimizer_for(model,PRESETS['conservative']);before=snapshot(model.refiner.guide)
    checks=[]
    if a.device.type=='cuda':torch.cuda.reset_peak_memory_stats(a.device)
    teacher=torch.as_tensor(pool['train_teacher'][:a.batch],device=a.device)
    for step in range(3):
        model.train();opt.zero_grad(set_to_none=True)
        loss,parts=objective(model.prepared_forward(bank),y,teacher,float(pool['scale']),.05)
        need(torch.isfinite(loss),'Nonfinite preflight loss');loss.backward()
        values={k:float(p.grad.abs().sum()) for k,p in [('guide_output',model.refiner.guide[-1].weight),
            ('guide_input',model.refiner.guide[0].weight),('old_dynamic',model.refiner.operator_conv[0].weight),
            ('tfse_head',model.net.gate.head.weight)]}
        need(all(np.isfinite(list(values.values()))) and values['guide_output']>0 and values['old_dynamic']>0,'New or pretrained path has no gradient')
        if step>0:need(values['guide_input']>0 and values['tfse_head']>0,'Conditioning path did not become trainable')
        checks.append(dict(step=step+1,loss=float(loss.detach()),**values));opt.step()
    need(any(not torch.equal(v,model.refiner.guide.state_dict()[k]) for k,v in before.items()),'Guide never updated')
    result=dict(initialization=initial,optimizer_steps=checks,discarded=True,
        peak_allocated_GiB=torch.cuda.max_memory_allocated(a.device)/1024**3 if a.device.type=='cuda' else None,
        source_unchanged=verify_protected(info))
    del model,opt,bank,iq,y,loss;gc.collect()
    if a.device.type=='cuda':torch.cuda.empty_cache()
    return result

def config(a,context,info,raw,label,pool_ct):
    return dict(version='B291_TCHR_FULL_TRAIN_V1',arm='OURS_TCHR',preset=label,parameters=PRESETS[label],
        epochs=a.epochs,warmup_epochs=a.warmup_epochs,batch=a.batch,replay_per_batch=a.replay_batch,
        selected_rows=raw.selection,bank_sha256=context['bc']['file_sha256'],source_lineage=info['lineage'],
        initial_checkpoint=info['lineage']['B289_FULL'],pool_contract=pool_ct,correction_bound=a.correction_bound,
        loss='CE + TRAIN-only hard H0 pairwise ranking + .02 positive-response retention',
        optimizer='Adam',weight_decay=1e-5,schedule='guide-only warmup then joint cosine decay to 20 percent',
        BN_affine_and_running_frozen=True,TFSE_pre_frozen=True,TFSE_head_joint_low_lr=True,
        selection='max full VAL pAUC01 with CE <= initial CE + .02; include epoch0 fallback; CE tiebreak',
        CAL_AUDIT_H1_used_for_training_or_selection=False,TFCG=False,old_Tail=False,
        code_sha256=code_hashes(),device=a.device.type,torch_version=str(torch.__version__),amp=False,tf32=False,
        budget_matched_baseline_control=False,seed_and_parameters_change_together=True)

def train_one(a,context,info,raw,pool,pool_ct,label):
    need(label in PRESETS,'Only Ours TCHR presets may train')
    folder=a.out_dir/label;folder.mkdir(exist_ok=True)
    cfg=config(a,context,info,raw,label,pool_ct);fp=fingerprint(cfg);manifest=folder/'run_manifest.json'
    identity=dict(run_config=cfg,run_fingerprint=fp);cp=folder/'training_contract.json';bp=folder/'best.pt';lp=folder/'last_epoch.pt'
    if manifest.exists():need(read_json(manifest)==identity,'Training preset changed; use fresh B291 output')
    else:
        need(not any(folder.iterdir()),'Unidentified candidate folder');write_json(manifest,identity)
    if cp.exists():
        ct=read_json(cp);need(ct['status']==TRAIN_PASS and ct['run_fingerprint']==fp and digest_file(bp)==ct['checkpoint_sha256'],'Completed training differs')
        print(label+' complete; skipped retraining',flush=True);return ct
    ps=PRESETS[label];setup(a.cpu_threads,ps['seed']);model=Model(info['old'],a.correction_bound).to(a.device)
    opt=optimizer_for(model,ps);start=1;history=[]
    def state(epoch,v):return dict(state_dict=snapshot(model),epoch=epoch,val_metrics=v,run_config=cfg,run_fingerprint=fp)
    def commit(epoch):
        payload=state(epoch,history[-1]);payload.update(optimizer=opt.state_dict(),best_checkpoint=best,history=history,
            initialization=initial,anchor=anchor,torch_rng=torch.get_rng_state(),cuda_rng=torch.cuda.get_rng_state_all() if a.device.type=='cuda' else [])
        atomic_save(lp,payload);atomic_save(bp,best);save_csv(folder/'train_val_history.csv',history)
    if lp.exists():
        saved=load_checkpoint(lp);need(saved['run_config']==cfg and saved['run_fingerprint']==fp,'Resume identity differs')
        model.load_state_dict(saved['state_dict'],strict=True);opt.load_state_dict(saved['optimizer']);best=saved['best_checkpoint']
        history=saved['history'];initial=saved['initialization'];anchor=saved['anchor'];start=saved['epoch']+1
        torch.set_rng_state(saved['torch_rng'])
        if a.device.type=='cuda':torch.cuda.set_rng_state_all(saved['cuda_rng'])
        del saved
    else:
        iq,_=raw.fetch('train',slice(0,a.batch),a.device);initial=initial_check(model,info['old'],smoothing_bank(iq,model.scale))
        anchor=evaluate(model,raw,a.device,a.batch)
        need(abs(anchor['val_ce']-info['contract']['selected_validation']['val_ce'])<=2e-4,'Old Ours full VAL replay differs')
        best=state(0,anchor);history=[dict(epoch=0,train_loss=None,**anchor,eligible=True,best_epoch=0,phase='source_identity',elapsed_s=0.)]
        commit(0);del iq
    n=len(raw.values['train'][1]);base_batch=a.batch-a.replay_batch
    for epoch in range(start,a.epochs+1):
        began=time.perf_counter();warmup=epoch<=a.warmup_epochs;model.set_phase(warmup);model.train()
        progress=max(0,epoch-a.warmup_epochs-1)/max(1,a.epochs-a.warmup_epochs-1)
        factor=.2+.8*.5*(1+math.cos(math.pi*progress))
        for group in opt.param_groups:group['lr']=group['base_lr']*(1 if warmup else factor)
        rng=np.random.default_rng(ps['seed']+997*epoch);order=rng.permutation(n);seen=0;total=0.
        for offset in range(0,n,base_batch):
            ids=order[offset:offset+base_batch];ri=rng.choice(len(pool['iq']),a.replay_batch,replace=False)
            iq=np.concatenate([raw.values['train'][0][ids],pool['iq'][ri]])
            y=np.r_[raw.values['train'][1][ids],np.zeros(len(ri),dtype='int64')]
            teacher=np.r_[pool['train_teacher'][ids],pool['source_margin'][ri]]
            x=torch.from_numpy(iq).to(a.device);target=torch.from_numpy(y).to(a.device);teacher=torch.from_numpy(teacher).to(a.device)
            bank=smoothing_bank(x,model.scale);opt.zero_grad(set_to_none=True)
            loss,_=objective(model.prepared_forward(bank),target,teacher,float(pool['scale']),ps['rank_weight'])
            need(torch.isfinite(loss),'Nonfinite TRAIN objective');loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5.);opt.step()
            seen+=len(ids);total+=float(loss.detach())*len(ids)
            if seen==n or seen%6400<base_batch:print(f'[{label}] epoch {epoch}/{a.epochs} original TRAIN {seen:,}/{n:,} + replay',flush=True)
        v=evaluate(model,raw,a.device,a.batch);eligible=v['val_ce']<=anchor['val_ce']+.02
        if eligible and better(v,best['val_metrics']):best=state(epoch,v)
        elapsed=time.perf_counter()-began
        history.append(dict(epoch=epoch,train_loss=total/n,**v,eligible=eligible,best_epoch=best['epoch'],
            phase='guide_only' if warmup else 'joint_TCHR_TFSEhead_CNN',elapsed_s=elapsed))
        commit(epoch)
        print(f'[{label}] {epoch}/{a.epochs} VAL_CE={v["val_ce"]:.6f} pAUC01={v["val_pauc01"]:.6f} '
            f'eligible={eligible} best_epoch={best["epoch"]} time={elapsed:.1f}s',flush=True)
    model.load_state_dict(best['state_dict'],strict=True);v=evaluate(model,raw,a.device,a.batch)
    need(abs(v['val_ce']-best['val_metrics']['val_ce'])<1e-6,'Selected VAL replay differs')
    ct=dict(status=TRAIN_PASS,run_config=cfg,run_fingerprint=fp,checkpoint_sha256=digest_file(bp),best_epoch=best['epoch'],
        initialization=initial,anchor_validation=anchor,selected_validation=v,source_function_fallback=best['epoch']==0,
        protected_sources=verify_protected(info),no_baseline_trained=True)
    write_json(cp,ct);del model,opt,best;gc.collect()
    if a.device.type=='cuda':torch.cuda.empty_cache()
    print(f'{TRAIN_PASS}; {label}; selected epoch={ct["best_epoch"]}; source fallback={ct["source_function_fallback"]}',flush=True)
    return ct

def load_selected(a,info,label):
    need(label in PRESETS,'Only Ours TCHR presets may load')
    folder=a.out_dir/label;ct=read_json(folder/'training_contract.json');cfg=ct['run_config'];path=folder/'best.pt'
    need(ct['status']==TRAIN_PASS and cfg['arm']=='OURS_TCHR' and cfg['source_lineage']==info['lineage'] and cfg['code_sha256']==code_hashes(),'Selected candidate identity differs')
    need(digest_file(path)==ct['checkpoint_sha256'],'Selected checkpoint changed');state=load_checkpoint(path)
    need(state['run_config']==cfg and state['run_fingerprint']==ct['run_fingerprint']==fingerprint(cfg) and state['epoch']==ct['best_epoch'],'Selected checkpoint internal identity differs')
    model=Model(info['old'],cfg['correction_bound']);model.load_state_dict(state['state_dict'],strict=True)
    return model.to(a.device).eval().requires_grad_(False),ct
