"""Only two TCHR Ours continuations. Direct FULL train/score, no screening."""
import argparse
import fcntl
import gc
import shutil
import time
from pathlib import Path
import torch
from b289_common import ROOT,need,read_json,write_json,fingerprint,code_hashes,validate_sources,setup
from b289_data import resolve,Data
from b291_source import load_sources,verify_protected
from b291_pool import prepare
from b291_train import PRESETS,preflight,train_one,load_selected
from b291_score import protocol,stream

def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=ROOT.parent)
    for key in ('bank-dir','b280-run','old-ours-run','out-dir'):p.add_argument('--'+key,type=Path)
    p.add_argument('--epochs',type=int,default=12);p.add_argument('--warmup-epochs',type=int,default=1)
    p.add_argument('--batch',type=int,default=32);p.add_argument('--replay-batch',type=int,default=8)
    p.add_argument('--chunk',type=int,default=512);p.add_argument('--cpu-threads',type=int,default=4)
    p.add_argument('--device',choices=('cuda','cpu'),default='cuda')
    p.add_argument('--max-scr',type=int,default=24);p.add_argument('--positive-prior',type=float,default=.5)
    p.add_argument('--correction-bound',type=float,default=.25)
    p.add_argument('--proposals',type=int,default=200000)
    p.add_argument('--hard-pool',type=int,default=1024);p.add_argument('--random-pool',type=int,default=1024)
    p.add_argument('--stage',choices=('all','train','score','report'),default='all')
    p.add_argument('--wait-for-gpu',action='store_true')
    a=p.parse_args(argv);a.root=a.root.resolve()
    for key,name in [('b280_run','output_b280_full_ablation_v1'),('old_ours_run','output_b289_dhif_two_full_v2'),('out_dir','output_b291_tchr_full_v1')]:
        setattr(a,key,(getattr(a,key) or a.root/name).resolve())
    need(a.root.is_dir() and a.out_dir.parent==a.root and a.out_dir.name.startswith('output_b291_tchr_'),'Use a direct new output_b291_tchr_* folder')
    for old in (a.b280_run,a.old_ours_run):need(old!=a.out_dir and old not in a.out_dir.parents and a.out_dir not in old.parents,'Output overlaps protected source')
    need(a.epochs>0 and 0<=a.warmup_epochs<=a.epochs and a.batch==32 and 0<a.replay_batch<=8,'Invalid training batch/schedule')
    need(a.chunk>=32 and a.chunk%32==0 and a.cpu_threads>0 and 12<=a.max_scr<=40 and 0<a.positive_prior<1,'Invalid inference settings')
    need(0<a.correction_bound<=.5 and a.hard_pool>=32 and a.random_pool>=32 and a.proposals>=a.hard_pool+a.random_pool,'Invalid correction bound/proposal pool')
    if a.out_dir.exists() and any(a.out_dir.iterdir()):
        need((a.out_dir/'run_manifest.json').is_file(),'Nonempty output lacks B291 identity')
        need(not any(f.is_symlink() for f in a.out_dir.rglob('*')),'Output contains symlinks; preserve it')
    if a.device=='cuda' and a.stage!='report':need(torch.cuda.is_available(),'CUDA unavailable')
    a.device=torch.device(a.device);return a

def acquire(lock,wait):
    while True:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);return
        except BlockingIOError:
            need(wait,'Another experiment holds shared GPU lock')
            print('Waiting for current radar GPU experiment; no task interrupted.',flush=True);time.sleep(30)

def choose(a,cts):
    rows=[dict(label=k,best_epoch=v['best_epoch'],val_pauc01=v['selected_validation']['val_pauc01'],
        val_ce=v['selected_validation']['val_ce'],source_function_fallback=v['source_function_fallback'],checkpoint_sha256=v['checkpoint_sha256']) for k,v in cts.items()]
    best=sorted(rows,key=lambda r:(-r['val_pauc01'],r['val_ce'],r['label']))[0]
    value=dict(version='B291_VAL_ONLY_PRESET_SELECTION_V1',candidates=rows,selected_label=best['label'],
        rule='max full VAL pAUC01 then min VAL CE; both configurations fully scored',
        H0_CAL_AUDIT_H1_used=False,committed_before_score=True,seed_and_parameters_vary=True)
    value['fingerprint']=fingerprint(value);path=a.out_dir/'val_configuration_selection.json'
    if path.exists():need(read_json(path)==value,'Committed VAL choice changed')
    else:write_json(path,value)
    return value

def main(argv=None):
    a=cli(argv);validate_sources()
    if a.stage=='report':
        from b291_report import generate
        generate(a.out_dir/'pd_scr_full',a.old_ours_run);return
    setup(a.cpu_threads,20261023)
    with (a.root/'codex_b271_night.lock').open('a') as lock:
        acquire(lock,a.wait_for_gpu);context=resolve(a);info=load_sources(a,context)
        a.out_dir.mkdir(exist_ok=True)
        identity=dict(version='B291_TCHR_FULL_V1',only_method='ADN + TFSE + TCHR',presets=PRESETS,
            epochs=a.epochs,warmup_epochs=a.warmup_epochs,batch=a.batch,replay_batch=a.replay_batch,
            proposals=a.proposals,hard_pool=a.hard_pool,random_pool=a.random_pool,correction_bound=a.correction_bound,
            source_lineage=info['lineage'],code_sha256=code_hashes(),device=a.device.type,
            torch_version=str(torch.__version__),cpu_threads=a.cpu_threads,chunk=a.chunk,max_scr=a.max_scr,
            positive_prior=a.positive_prior,train=30000,val=5000,h0_cal=3000000,h0_audit=1000000,h1_per_scr=1024,
            no_ADN_or_TFSE_baseline_training_or_full_scoring=True)
        mp=a.out_dir/'run_manifest.json'
        if mp.exists():need(read_json(mp)==identity,'Run settings changed; preserve output and choose fresh B291 folder')
        else:
            need(not any(a.out_dir.iterdir()),'Unidentified output contents');write_json(mp,identity)
        print('B291 TCHR | direct FULL | only two Ours configurations | output='+str(a.out_dir),flush=True)
        if a.stage in ('all','train'):
            need(shutil.disk_usage(a.out_dir).free>=3*1024**3,'Need 3 GiB free for resumable checkpoints; no files deleted')
            raw=Data(context,30000,20261023);pool,ct=prepare(a,info,raw)
            pf=a.out_dir/'preflight.json';fp=fingerprint(identity)
            if pf.exists():need(read_json(pf)['run_fingerprint']==fp,'Preflight identity changed')
            else:write_json(pf,dict(run_fingerprint=fp,checks=preflight(a,info,raw,pool)))
            for label in PRESETS:train_one(a,context,info,raw,pool,ct,label)
            del raw,pool;gc.collect();verify_protected(info)
            if a.device.type=='cuda':torch.cuda.empty_cache()
            if a.stage=='train':return
        models={};cts={}
        for label in PRESETS:models[label],cts[label]=load_selected(a,info,label)
        selection=choose(a,cts);p=protocol(a,info,models,cts,selection)
        print('FULL score: two Ours candidates, shared IQ; CAL 3M + AUDIT 1M + H1 1024 x '+str(len(p['scr_grid_db'])),flush=True)
        need(shutil.disk_usage(a.out_dir).free>=256*1024**2,'Need 256 MiB for scores/figures')
        stream(a,info,models,p,a.out_dir/'pd_scr_full');del models;gc.collect()
        from b291_report import generate
        generate(a.out_dir/'pd_scr_full',a.old_ours_run)
        write_json(a.out_dir/'protected_sources_after_run.json',verify_protected(info))
        print('PASS_B291_OURS_TCHR_FULL_COMPLETE: '+str(a.out_dir),flush=True)

if __name__=='__main__':main()
