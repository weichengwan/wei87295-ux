"""Synthetic CPU functional checks, never claims AutoDL Pd or GPU readiness."""
import contextlib
import io
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import numpy as np
import torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from b289_common import (ROOT,FILES,setup,generator,read_json,write_json,fingerprint,digest_file,
    atomic_save,snapshot,load_checkpoint)
from b289_model import Model as OldModel,TFSECore
from b291_model import Model,TCHR,initial_check
from b291_source import load_sources,verify_protected
from b291_train import evaluate,preflight,train_one,load_selected,PRESETS
from b291_pool import prepare,make_h0,TRAIN_SPLIT
from b291_loss import objective
from b291_run import cli,choose
from b291_score import protocol,stream
from b291_report import generate
from tfse_frontend import smoothing_bank

def fixture(root):
    setup(2,42);root.mkdir(parents=True,exist_ok=True)
    a=SimpleNamespace(root=root,b280_run=root/'B280',old_ours_run=root/'B289',out_dir=root/'output_b291_tchr_fixture',
        device=torch.device('cpu'),batch=2,replay_batch=1,chunk=4,cpu_threads=2,epochs=2,warmup_epochs=1,
        correction_bound=.25,proposals=12,hard_pool=2,random_pool=2,max_scr=24,positive_prior=.5)
    a.out_dir.mkdir();g=generator();context=dict(bc=dict(seed=20261009,file_sha256='fixture-only',generator_sha256=digest_file(g.__file__)))
    raw=SimpleNamespace(values={},selection={})
    for split,n in [('train',8),('val',4)]:
        rows=[g.make_one(20261009,split,i,-15,10) for i in range(n)]
        raw.values[split]=(np.stack([s['iq'] for s in rows]),np.array([s['label'] for s in rows],dtype='int64'))
        raw.selection[split]=dict(count=n,fixture_only=True)
    def fetch(split,idx,device):
        iq,y=raw.values[split];return torch.from_numpy(np.ascontiguousarray(iq[idx])).to(device),torch.from_numpy(np.ascontiguousarray(y[idx])).to(device)
    raw.fetch=fetch
    old=OldModel(TFSECore(1.),True).eval()
    with torch.no_grad():
        old.net.gate.head.weight.normal_(0,.02)
        old.refiner.operator_conv[0].weight.normal_(0,.001)
    a1=dict(checkpoint_sha256='A1-fixture-hash',run_config=dict(scale=1.,code_sha256=read_json(ROOT/'expected_source_code.json')['B280']))
    ap=a.b280_run/'A1';ap.mkdir(parents=True);write_json(ap/'training_contract.json',a1)
    cfg=dict(arm='FULL',code_sha256=read_json(ROOT/'expected_ours_code.json'),TFSE=True,LCBR=False,CGCR=False,TFCG=False,Tail=False,
        bank_sha256='fixture-only',selected_rows=dict(train=dict(count=30000),val=dict(count=5000)),source_lineage=dict(B280_A1='A1-fixture-hash'))
    sp=a.old_ours_run/'FULL';sp.mkdir(parents=True)
    atomic_save(sp/'best.pt',dict(state_dict=snapshot(old),run_config=cfg,run_fingerprint=fingerprint(cfg),epoch=3))
    ct=dict(status='PASS_B289_DHIF_FULL_TRAIN_VAL_ONLY',run_config=cfg,run_fingerprint=fingerprint(cfg),best_epoch=3,
        checkpoint_sha256=digest_file(sp/'best.pt'),selected_validation=evaluate(old,raw,a.device,a.batch))
    write_json(sp/'training_contract.json',ct)
    scene=dict(master_seed=20261009,generator_sha=context['bc']['generator_sha256'],h0_cal_n=3000000,h0_audit_n=1000000,h1_scenes_n=1024,
        scr_grid_db=list(range(-24,13)),h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',family_names=list(g.TRAIN_FAMILIES),scr_definition='synthetic-fixture-only')
    p=dict(version='B289_DHIF_TWO_MODEL_FULL_SCORE_V2',**scene,training_contracts=dict(FULL=ct),labels=['DHIF','FULL'])
    p['fingerprint']=fingerprint(p);folder=a.old_ours_run/'pd_scr_full';folder.mkdir();write_json(folder/'protocol_frozen.json',p)
    return a,context,load_sources(a,context),raw

class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):torch.set_num_threads(2)

    def test_conditioning_zero_DC_bound_and_real_guide_dependence(self):
        setup(2,4);m=TCHR(4);x=torch.randn(2,4,6,5);d=torch.rand(2,6,5,9)
        with torch.no_grad():m.guide[-1].weight.normal_(0,.1)
        op,delta=m.conditioned_operator(d,torch.rand(2,5,6,5))
        self.assertLess(float(delta.sum(-2).abs().max()),2e-7)
        self.assertLessEqual(float(delta.abs().max()),.25)
        constant=torch.ones(2,4,6,5,9)
        self.assertLess(float(torch.einsum('bchwi,bhwij->bchwj',constant,delta).abs().max()),2e-7)
        g1=torch.rand(2,5,6,5);g2=g1+1
        self.assertGreater(float((m(x,g1)-m(x,g2)).abs().max()),0)
        self.assertGreater(float(delta.abs().sum()),0)

    def test_loss_gradients_and_single_class_batches(self):
        z=torch.tensor([[0.,2.],[0.,-1.],[0.,.2],[0.,1.]],requires_grad=True)
        y=torch.tensor([0,0,1,1]);t=torch.tensor([1.,-1.,1.,2.])
        loss,parts=objective(z,y,t,1.,.1);loss.backward()
        self.assertGreater(float(parts['rank']),0)
        self.assertGreater(float(z.grad[0,1]),0);self.assertLess(float(z.grad[2,1]),0)
        for yy in (torch.zeros(4,dtype=torch.long),torch.ones(4,dtype=torch.long)):
            out,_=objective(z,yy,t,.1,.1);self.assertTrue(torch.isfinite(out))

    def test_source_only_FULL_identity_gradients_and_training_split_isolation(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            a,ctx,info,raw=fixture(Path(tmp));self.assertFalse((a.b280_run/'A0').exists())
            self.assertFalse((a.old_ours_run/'DHIF').exists());self.assertFalse((a.b280_run/'A1/best.pt').exists())
            bank=smoothing_bank(raw.fetch('train',slice(0,2),a.device)[0],1.)
            self.assertEqual(initial_check(Model(info['old']),info['old'],bank)['initial_maxabs_logit_difference'],0.)
            calls=[];original=info['generator'].make_one
            def tracked(seed,split,index,lo,hi):calls.append(split);return original(seed,split,index,lo,hi)
            with patch.object(info['generator'],'make_one',side_effect=tracked):pool,ct=prepare(a,info,raw)
            self.assertEqual(set(calls),{TRAIN_SPLIT});self.assertFalse(ct['official_CAL_AUDIT_H1_accessed'])
            self.assertEqual(len(set(pool['indices'].tolist())),4)
            pool2,ct2=prepare(a,info,raw);self.assertEqual(ct,ct2);np.testing.assert_array_equal(pool['iq'],pool2['iq'])
            result=preflight(a,info,raw,pool);self.assertEqual(result['initialization']['new_parameters'],857)
            self.assertGreater(result['optimizer_steps'][1]['guide_input'],0)
            self.assertTrue(verify_protected(info)['unchanged'])

    def test_training_resume_selection_score_and_CPU_report(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            a,ctx,info,raw=fixture(Path(tmp)/'resume');pool,pc=prepare(a,info,raw);interrupted=[]
            def stop(path,obj):
                atomic_save(path,obj)
                if Path(path).name=='last_epoch.pt' and obj['epoch']==1 and not interrupted:
                    interrupted.append(True);raise RuntimeError('synthetic interruption')
            with patch('b291_train.atomic_save',side_effect=stop):
                with self.assertRaisesRegex(RuntimeError,'synthetic interruption'):train_one(a,ctx,info,raw,pool,pc,'conservative')
            ct=train_one(a,ctx,info,raw,pool,pc,'conservative');sha=digest_file(a.out_dir/'conservative/best.pt')
            train_one(a,ctx,info,raw,pool,pc,'conservative');self.assertEqual(sha,digest_file(a.out_dir/'conservative/best.pt'))
            train_one(a,ctx,info,raw,pool,pc,'tail_focused')
            b,ctx2,info2,raw2=fixture(Path(tmp)/'continuous');pool2,pc2=prepare(b,info2,raw2)
            train_one(b,ctx2,info2,raw2,pool2,pc2,'conservative')
            left=load_checkpoint(a.out_dir/'conservative/last_epoch.pt')['state_dict'];right=load_checkpoint(b.out_dir/'conservative/last_epoch.pt')['state_dict']
            self.assertTrue(all(torch.equal(v,right[k]) for k,v in left.items()))
            models={};cts={}
            for k in PRESETS:models[k],cts[k]=load_selected(a,info,k)
            selection=choose(a,cts);self.assertFalse(selection['H0_CAL_AUDIT_H1_used'])
            self.assertFalse((a.out_dir/'pd_scr_full').exists());p=protocol(a,info,models,cts,selection)
            self.assertEqual((p['h0_cal_n'],p['h0_audit_n'],p['h1_scenes_n']),(3000000,1000000,1024))
            self.assertEqual(p['nominal_pfas'],[1e-4,1e-5]);self.assertEqual(len(p['scr_grid_db']),49)
            p.update(h0_cal_n=9,h0_audit_n=7,h1_scenes_n=4,scr_grid_db=[-24,0,24]);p.pop('fingerprint');p['fingerprint']=fingerprint(p)
            folder=a.out_dir/'pd_scr_full';stream(a,info,models,p,folder)
            hashes={f:digest_file(folder/f) for f in FILES.values()};stream(a,info,models,p,folder)
            self.assertEqual(hashes,{f:digest_file(folder/f) for f in FILES.values()})
            # Separate synthetic CAL distribution for the report test. Keep
            # the production >=10 tail-event requirement at Pfa=1e-5 intact.
            # These values are fixture scores, never claimed neural outputs.
            p['h0_cal_n']=1000000;p.pop('fingerprint');p['fingerprint']=fingerprint(p)
            cal=np.stack([np.linspace(-5,5,1000000),np.linspace(-4,6,1000000)],1)
            np.save(folder/FILES['h0_cal'],cal)
            write_json(folder/'protocol_frozen.json',p)
            write_json(folder/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=1000000,h0_audit=7,h1=3)))
            report=generate(folder,a.old_ours_run)
            self.assertEqual(report['executed_runs'],list(PRESETS));self.assertFalse(report['other_methods_executed'])
            self.assertTrue((folder/'figures/b291_pd_scr_pfa_1e-05.pdf').is_file())
            self.assertTrue(verify_protected(info)['unchanged'])
            with self.assertRaisesRegex(RuntimeError,'Only Ours'):train_one(a,ctx,info,raw,pool,pc,'ADN')

    def test_CLI_prevents_source_output_and_medium_runs(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            a=cli(['--root',tmp,'--device','cpu']);self.assertEqual(a.epochs,12)
            with self.assertRaisesRegex(RuntimeError,'direct new'):cli(['--root',tmp,'--device','cpu','--out-dir',str(root/'output_b289_dhif_two_full_v2')])
            self.assertFalse(hasattr(a,'screen'))

if __name__=='__main__':unittest.main()
