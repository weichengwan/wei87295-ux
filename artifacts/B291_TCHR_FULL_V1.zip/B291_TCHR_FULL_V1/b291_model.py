"""TFSE-conditioned dynamic refinement, initialized at the trained B289 Ours."""
import copy
import torch
from torch import nn
import torch.nn.functional as F
from b289_common import need
from b289_model import Model as OldModel, TFSECore, tensor_hash
from dhif_module import DHiF


class TCHR(DHiF):
    def __init__(self, channels=128, bound=.25):
        super().__init__(channels)
        self.bound = float(bound)
        self.guide = nn.Sequential(nn.Conv2d(5,8,1),nn.SiLU(),
            nn.Conv2d(8,8,3,padding=1,groups=8),nn.SiLU(),nn.Conv2d(8,81,1))
        nn.init.zeros_(self.guide[-1].weight); nn.init.zeros_(self.guide[-1].bias)

    def conditioned_operator(self, descriptor, guide):
        # Original pretrained operator is kept, not projected or relabelled.
        u = self.operator_conv[0](descriptor)
        a0 = torch.tanh(u).reshape(*u.shape[:-1],9,9)
        q = self.guide(guide).permute(0,2,3,1)
        delta = (torch.tanh(u+q)-torch.tanh(u)).reshape_as(a0)
        # Sum over INPUT patch index i. Added correction rejects a constant
        # local patch; this claim does not apply to the original operator a0.
        delta = delta-delta.mean(dim=-2,keepdim=True)
        delta = self.bound*delta/(1+delta.abs().amax(dim=(-2,-1),keepdim=True))
        return a0+delta, delta

    def forward(self, x, guide):
        b,c,h,w=x.shape
        guide=F.adaptive_avg_pool2d(guide,(h,w))
        patches=F.unfold(x,3,padding=1).reshape(b,c,9,h,w).permute(0,1,3,4,2)
        descriptor=torch.norm(patches,p=2,dim=1)
        operators,_=self.conditioned_operator(descriptor,guide)
        filtered=torch.einsum('bchwi,bhwij->bchwj',patches,operators)
        kernels=self.weight.reshape(c,c,9).permute(1,0,2)
        return (torch.einsum('bchwk,ock->bohw',patches+filtered,kernels)+self.bias[None,:,None,None]).contiguous()


class Model(nn.Module):
    def __init__(self, old, bound=.25):
        super().__init__();need(old.with_tfse,'Only existing Ours FULL is supported')
        self.net=copy.deepcopy(old.net);self.scale=old.scale
        self.refiner=TCHR(128,bound)
        missing,unexpected=self.refiner.load_state_dict(old.refiner.state_dict(),strict=False)
        need(not unexpected and all(k.startswith('guide.') for k in missing),'Unmatched pretrained DHiF tensors')
        self.set_phase(True);self.eval()

    def set_phase(self,warmup):
        self.requires_grad_(False)
        self.refiner.guide.requires_grad_(True)
        if not warmup:
            self.refiner.requires_grad_(True);self.net.detector.requires_grad_(True)
            self.net.gate.head.requires_grad_(True)
        for m in self.net.detector.modules():
            if isinstance(m,nn.modules.batchnorm._BatchNorm):m.requires_grad_(False)

    def train(self,mode=True):
        super().train(mode);self.net.gate.eval()
        for m in self.net.detector.modules():
            if isinstance(m,nn.modules.batchnorm._BatchNorm):m.eval()
        return self

    def prepared_forward(self,bank,return_aux=False):
        image,aux=self.net.gate(bank)
        z1,z9=bank[:,:1],bank[:,2:3]
        discrepancy=(z1-z9).abs()/(z1+z9+1e-6)
        guide=torch.cat([aux['consistency'],discrepancy,(aux['gain']-1)/.2,
            aux['correction_short']/.25,aux['correction_long']/.25],1)
        d=self.net.detector;x=d.maxpool(d.relu(d.bn1(d.conv1(image))))
        x=d.layer2(d.layer1(x));refined=self.refiner(x,guide)
        z=d.fc(torch.flatten(d.avgpool(d.layer4(d.layer3(refined))),1))
        return (z,dict(mean_abs_feature_change=(refined-x).abs().mean())) if return_aux else z


@torch.inference_mode()
def initial_check(model,old,bank):
    model.eval();old.eval()
    error=float((model.prepared_forward(bank)-old.prepared_forward(bank)).abs().max())
    need(error<=1e-6,'Conditioned module changed source function before training')
    need(tensor_hash(model.net.state_dict())==tensor_hash(old.net.state_dict()),'Source detector/TFSE tensors changed')
    for k,v in old.refiner.state_dict().items():need(torch.equal(model.refiner.state_dict()[k],v),'Source DHiF tensor changed: '+k)
    count=sum(type(m).__name__=='SimAM' for m in model.net.detector.modules())
    need(count==8,'Original ADN SimAM blocks changed')
    return dict(initial_maxabs_logit_difference=error,new_parameters=sum(p.numel() for p in model.refiner.guide.parameters()),
        native_SimAM_count=count,pretrained_tensors_preserved=True,position='after Layer2 before Layer3')
