"""Mine an independent TRAIN-only H0 proposal pool with frozen existing Ours."""
import time
import numpy as np
import torch
from b289_common import need,read_json,write_json,digest_file,fingerprint
from tfse_frontend import smoothing_bank

TRAIN_SPLIT='train_h0_b291'

def make_h0(g,seed,indices):
    need(TRAIN_SPLIT not in g.SPLIT_NAMES,'Mining split unexpectedly aliases an official data split')
    rows=[g.make_one(seed,TRAIN_SPLIT,int(i),-30,10) for i in indices]
    need(all(s['label']==0 and not np.any(s['target']) for s in rows),'TRAIN-only proposal is not H0')
    return np.stack([s['base'] for s in rows]).astype('complex64')

@torch.inference_mode()
def margins(old,iq,device,batch):
    values=[]
    for start in range(0,len(iq),batch):
        x=torch.from_numpy(np.ascontiguousarray(iq[start:start+batch])).to(device)
        z=old.prepared_forward(smoothing_bank(x,old.scale))
        values.append((z[:,1]-z[:,0]).float().cpu().numpy())
    result=np.concatenate(values);need(np.isfinite(result).all(),'Nonfinite frozen source margins')
    return result

def prepare(a,info,raw):
    folder=a.out_dir/'train_only_replay';folder.mkdir(exist_ok=True)
    identity=dict(version='B291_TRAIN_ONLY_H0_REPLAY_V1',split=TRAIN_SPLIT,proposals=a.proposals,
        hard=a.hard_pool,random=a.random_pool,master_seed=info['scene']['master_seed'],
        source_checkpoint=info['lineage']['B289_FULL'],source_generator=info['scene']['generator_sha'],
        train_selection=raw.selection['train'],device=a.device.type,torch_version=str(torch.__version__),batch=a.batch)
    fp=fingerprint(identity);mp=folder/'manifest.json';pp=folder/'progress.json';cp=folder/'contract.json'
    if mp.exists():need(read_json(mp)==identity,'TRAIN proposal settings changed')
    else:
        need(not any(folder.iterdir()),'Unidentified mining cache');write_json(mp,identity)
    cache=folder/'retained.npz'
    if cp.exists():
        ct=read_json(cp);need(ct['fingerprint']==fp and digest_file(cache)==ct['cache_sha256'],'Replay pool changed')
        with np.load(cache,allow_pickle=False) as v:pool={k:v[k] for k in v.files}
        need(pool['iq'].shape==(a.hard_pool+a.random_pool,512) and pool['train_teacher'].shape==(len(raw.values['train'][1]),),'Replay cache shape differs')
        return pool,ct
    sp=folder/'proposal_margins.npy'
    progress=read_json(pp) if pp.exists() else dict(fingerprint=fp,done=0)
    need(progress['fingerprint']==fp,'Mining progress identity differs')
    done=progress['done']
    need(0<=done<=a.proposals and (done==0 or sp.exists()),'Invalid mining resume metadata')
    scores=np.lib.format.open_memmap(sp,mode='r+' if sp.exists() else 'w+',dtype='float32',shape=(a.proposals,))
    need(scores.shape==(a.proposals,) and scores.dtype==np.float32,'Mining score cache differs')
    if done:
        ids=np.arange(max(0,done-a.batch),done)
        replay=margins(info['old'],make_h0(info['generator'],identity['master_seed'],ids),a.device,a.batch)
        need(np.allclose(scores[ids],replay,rtol=2e-5,atol=5e-5),'Mining committed prefix replay differs')
    began=time.perf_counter()
    for start in range(done,a.proposals,a.chunk):
        stop=min(start+a.chunk,a.proposals)
        scores[start:stop]=margins(info['old'],make_h0(info['generator'],identity['master_seed'],range(start,stop)),a.device,a.batch)
        scores.flush();write_json(pp,dict(fingerprint=fp,done=stop))
        if stop==a.proposals or stop%10000<a.chunk:
            rate=(stop-done)/max(time.perf_counter()-began,1e-6)
            print(f'[TRAIN-only H0 mining] {stop:,}/{a.proposals:,}; {rate:.1f}/s',flush=True)
    hard=np.argsort(-np.asarray(scores),kind='stable')[:a.hard_pool]
    remaining=np.setdiff1d(np.arange(a.proposals),hard,assume_unique=True)
    random=np.random.default_rng(291071).choice(remaining,a.random_pool,replace=False)
    indices=np.r_[hard,random].astype('int64')
    teacher=margins(info['old'],raw.values['train'][0],a.device,a.batch)
    h0=teacher[raw.values['train'][1]==0];q25,q75=np.quantile(h0,[.25,.75]);scale=max(float((q75-q25)/1.349),.1)
    pool=dict(iq=make_h0(info['generator'],identity['master_seed'],indices),source_margin=np.asarray(scores[indices]).copy(),
        indices=indices,train_teacher=teacher,scale=np.array(scale,dtype='float64'))
    tmp=folder/'retained.tmp.npz';np.savez(tmp,**pool);tmp.replace(cache)
    ct=dict(fingerprint=fp,identity=identity,cache_sha256=digest_file(cache),retained=len(indices),
        train_margin_scale=scale,hard_source_margin_min=float(scores[hard].min()),
        official_CAL_AUDIT_H1_accessed=False,source_frozen=True,source_model='B289 FULL Ours only')
    write_json(cp,ct);del scores
    print(f'TRAIN-only replay ready: {len(indices)} H0 retained; margin scale={scale:.6g}',flush=True)
    return pool,ct
