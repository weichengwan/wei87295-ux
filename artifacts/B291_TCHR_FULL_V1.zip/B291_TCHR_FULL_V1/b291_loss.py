"""TRAIN-only top-negative ranking plus positive-response retention."""
import torch
import torch.nn.functional as F

def objective(logits,y,teacher,scale,rank_weight,retention_weight=.02):
    ce=F.cross_entropy(logits,y);s=(logits[:,1]-logits[:,0])/scale;t=teacher/scale
    pos=y==1;neg=y==0;rank=ce*0;retain=ce*0
    if pos.any() and neg.any():
        high=s[neg].topk(max(1,(int(neg.sum())+3)//4)).values
        p=torch.sigmoid(teacher[pos]).detach()
        weights=.25+.75*4*p*(1-p)
        pair=.5*F.softplus((high[None,:]-s[pos,None]+.5)/.5)
        rank=(pair.mean(1)*weights).sum()/weights.sum()
    confident=pos & (teacher>0)
    if confident.any():retain=F.relu(t[confident]-s[confident]-.25).mean()
    return ce+rank_weight*rank+retention_weight*retain,dict(ce=ce.detach(),rank=rank.detach(),retention=retain.detach())
