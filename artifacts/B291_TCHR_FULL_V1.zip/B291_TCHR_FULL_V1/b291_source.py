"""Load only trained B289 FULL; A1 is metadata-only. Never load A0/DHIF."""
import torch
from b289_common import ROOT,need,read_json,digest_file,load_checkpoint,fingerprint,generator
from b289_model import Model as OldModel,TFSECore

SCENE_KEYS=('master_seed','generator_sha','h0_cal_n','h0_audit_n','h1_scenes_n','scr_grid_db',
    'h0_cal_split','h0_audit_split','h1_split','family_names','scr_definition')

def load_sources(a,context):
    folder=a.old_ours_run/'FULL';path=folder/'best.pt';cp=folder/'training_contract.json'
    ct=read_json(cp);cfg=ct['run_config']
    need(ct['status']=='PASS_B289_DHIF_FULL_TRAIN_VAL_ONLY' and cfg['arm']=='FULL','Require completed B289 FULL Ours')
    need(cfg['code_sha256']==read_json(ROOT/'expected_ours_code.json'),'B289 source release differs')
    need(cfg['TFSE'] and not any(cfg[k] for k in ('LCBR','CGCR','TFCG','Tail')),'Wrong source architecture')
    need(cfg['bank_sha256']==context['bc']['file_sha256'],'Old Ours uses another TRAIN/VAL bank')
    need((cfg['selected_rows']['train']['count'],cfg['selected_rows']['val']['count'])==(30000,5000),'Require full30k/5k source')
    need(digest_file(path)==ct['checkpoint_sha256'],'B289 FULL checkpoint changed')
    state=load_checkpoint(path)
    need(state['run_config']==cfg and state['run_fingerprint']==ct['run_fingerprint']==fingerprint(cfg)
         and state['epoch']==ct['best_epoch'],'B289 checkpoint internal identity differs')
    a1path=a.b280_run/'A1/training_contract.json';a1=read_json(a1path)
    need(a1['checkpoint_sha256']==cfg['source_lineage']['B280_A1'],'TFSE scale metadata lineage differs')
    need(a1['run_config']['code_sha256']==read_json(ROOT/'expected_source_code.json')['B280'],'A1 metadata release differs')
    old=OldModel(TFSECore(a1['run_config']['scale']),True)
    old.load_state_dict(state['state_dict'],strict=True);old.to(a.device).eval().requires_grad_(False)
    # Only scene definitions are read here, no CAL/AUDIT/H1 score arrays.
    pp=a.old_ours_run/'pd_scr_full/protocol_frozen.json';p=read_json(pp)
    need(p['version']=='B289_DHIF_TWO_MODEL_FULL_SCORE_V2' and p['training_contracts']['FULL']==ct,'Source scene/checkpoint mismatch')
    need(p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'}),'Invalid source scene fingerprint')
    scene={k:p[k] for k in SCENE_KEYS};g=generator()
    need(scene['generator_sha']==context['bc']['generator_sha256']==digest_file(g.__file__)
         and scene['master_seed']==context['bc']['seed'] and tuple(scene['family_names'])==g.TRAIN_FAMILIES,'Source scene generator differs')
    need((p['h0_cal_n'],p['h0_audit_n'],p['h1_scenes_n'])==(3000000,1000000,1024),'Require source full scene')
    protected={str(x):digest_file(x) for x in (path,cp,a1path,pp)}
    lineage=dict(B280_A1=a1['checkpoint_sha256'],B289_FULL=ct['checkpoint_sha256'])
    return dict(old=old,contract=ct,scene=scene,generator=g,lineage=lineage,protected_sources=protected)

def verify_protected(info):
    for path,sha in info['protected_sources'].items():need(digest_file(path)==sha,'Protected source changed: '+path)
    return dict(unchanged=True,sha256=info['protected_sources'])
