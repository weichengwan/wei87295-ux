# B276: SPWVD → ADN/WCSG/TFCG + 对齐的 phase-ARS

这是一个待验证的新候选模型，代码已完成CPU功能测试，尚无AutoDL训练结果。保留B274已经表现良好的SPWVD显示、缩放和ResNet权重，再迁入ADN/L1的结构；不再在冻结WVD网络旁增加一个未适配分支。

## 三个配对实验

|输出子目录|结构|目的|
|---|---|---|
|continued|B274 SPWVD + 标准ResNet18，继续训练|控制额外训练轮数|
|adn|相同SPWVD → 居中WCSG → ADN18的ACB/TFCG → 分类头|测试ADN结构迁移|
|phase|相同SPWVD → 居中WCSG → ADN18的ACB/TFCG + phase-ARS → 分类头|测试相位引导重采样的额外作用|

这里只有一个图像骨干。没有WVD/SPWVD双支路，没有WVD显示再归一化，没有LMDA模块，没有额外的IQ分类头。全网络及BN均可训练。本轮统一使用CE；它是借用ADN/L1结构的受控实验，不宣称继续使用了原L1-Tail的尾部排序损失。后续再单独检验尾部损失。

## 初始化为什么不会丢掉B274

1. stem、各块的中心3×3、第二3×3、BN、shortcut、FC完整复制B274。
2. ADN新增3×1、1×3卷积的BN缩放和偏置初始为0，因此初始侧分支输出为0。
3. 使用原L1源码的TFCG，原有零初始化使其初始为恒等。
4. 使用原WCSG，末层权重置零，除去初始常数增益，使初始输入保持不变。训练后允许抑制或小幅放大；这是迁移所需的工程调整，不单独宣称原创模块。
5. ARS沿用B271的零偏移初始化。每个模型在TRAIN前32条上核对初始logit是否复现B274，失败立即停止。

SPWVD图像是`频率×时间`，与旧WVD的`时间×频率`不同。新phase evidence按实际估计器的FFT128网格、q=2f(mod1)、时间中心4j+2对齐，去掉旧WVD512→128的频率插值偏移并调整轴顺序。原B271对旧WVD的坐标不因此被认为错误。

## 运行

将ZIP上传至`/root/autodl-tmp/MTDSP_NATIVE_LMDA_V1`：

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
unzip -n B276_SPWVD_ADN_PHASE_V1.zip
nohup /root/miniconda3/bin/conda run --no-capture-output -n mpdnet-r10 \
  bash B276_SPWVD_ADN_PHASE_V1/run_b276.sh \
  > codex_b276_spwvd_adn_phase.log 2>&1 < /dev/null &
tail -F codex_b276_spwvd_adn_phase.log
```

默认TRAIN16000、VAL3000，同B274完全相同的冻结行；每组额外4epoch，batch32，原权重LR1e-5、新参数LR1e-4，Adam，weight decay1e-4。phase组另沿用偏移平滑/折叠惩罚，权重0.02。三个组的额外数据和轮数一致，但新参数组LR、参数量及phase正则存在已声明差异。以最小VAL CE选权重，epoch0也可被选中，绝不用DEV Pd选模型。

训练后只做Pfa1e-4：500k CAL、200k CHECK、每SCR1024条H1、37点。统一计算严格`score > own CAL threshold`，同时输出实际H0虚警计数及95%区间、D50/D80/D90。B274及原五条对比曲线读取冻结原始分数并逐项复核，不重跑对比模型GPU推理。不同模型实际Pfa估计值可能不同，图不会掩盖这个差别。

评分多加一个无训练参数的`IQ mean power (diagnostic)`，直接用IQ平均功率判决，几乎不增加耗时。它用于排查收益是否主要来自全局能量线索；单凭此诊断不能证明相位或条带机制的因果贡献。

唯一重模型推理是这次新训练的三个组；SPWVD图像每批只生成一次。不会自动启动3M/1M全量，也不生成大时频磁盘缓存。3080Ti尚未实测，建议给单包预留约1.5–3小时作为粗略排期，实际以每轮耗时和CAL日志ETA为准。

## 必需旧文件

- `output_b274_single_spwvd_resnet18_v1/`内的`best.pt`、训练manifest/contract及`pd_scr_medium`完整原始npy、协议、progress、curves/metrics CSV。
- 冻结IQ银行及原B213场景协议。所有SHA、TRAIN/VAL行、场景、数值设置均在训练前核对。
- B274原前端文件仍需存在，或其配置指向的已验证旧B236脚本。使用B274记录的原路径及SHA，绝不悄悄替换前端。

若B274使用旧B236脚本，会先用单音与调频探针数值核对其图像是否与当前支持的SPWVD网格/归一化一致；不一致时在训练前停止，保留旧结果，不能静默套用错误的phase坐标。

B274权重和原结果均不改写。新目录为`output_b276_spwvd_adn_phase_v1`。命令重跑可从最后完整epoch恢复；更改预算/代码时请使用新的`--out-dir`，不要覆盖已有实验。

`--stage train`只训练；`--stage score`读取已完成权重评分；`--stage report`只重画完成结果。其他参数见`python b276_run.py --help`。默认三组建议一起保留。

与B271/272/273/274/275共用GPU锁。第二个独立任务若发现锁被占用会退出，不会静默排队。如需连续跑B276和B275，见`run_both_sequential.sh`。

两份包都解压后，可以将上面的`run_b276.sh`替换为`run_both_sequential.sh`。它先完成B276，再执行B275的旧LMDA只读回放与ADSCM替换实验；任一步报错会停止，具体原因写入同一个日志。

## 结果与论文边界

输出`pd_scr_medium/b276_report.json`、`b276_metrics.csv`、`b276_comparisons.csv`、原始分数及PDF/PNG/SVG。新方法黑色虚线空心倒三角；坐标为`SCR (dB)`、`Pd`，不平滑、不移点。原五条B273对比曲线的顺序/颜色保持；B274作为新增强对照保留。

“SPWVD优于旧方案”仍混合了窗长、显示归一化、训练/冻结策略及骨干差异，本轮不宣称已经分离所有因素。统一缩放保留绝对幅度可能有效，也需要后续在独立海况、功率扰动、多个种子和实际Pfa下验证。模型/测试集已多次用DEV筛选，不能充当独立最终测试。

论文可据实讨论时频表示与相位证据的坐标匹配、方向卷积和门控的适配；必须用消融和独立结果支持。借鉴来源应正常引用，迁移初始化本身也不自动构成创新点。

来源：ADN, IEEE Sensors Journal2023, DOI10.1109/JSEN.2023.3259953；Wang & Wang, Remote Sensing2024,16,4662, DOI10.3390/rs16244662（时频分支启发，非完整三通道复现）；Chen et al., Spatial Frequency Modulation for Semantic Segmentation, TPAMI2025, DOI10.1109/TPAMI.2025.3592621（ARS概念来源，本包为B271的任务适配，不是SFM原网络）。WCSG/TFCG沿用用户冻结实现。
