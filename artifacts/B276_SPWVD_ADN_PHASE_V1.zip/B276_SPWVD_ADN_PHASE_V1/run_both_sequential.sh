#!/usr/bin/env bash
# Run from conda run -n mpdnet-r10; both packages must already be extracted.
set -euo pipefail
package_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
project_root=$(dirname -- "$package_dir")
lmda_package="$project_root/B275_LMDA_REPLAY_CORE_V1"
test -f "$lmda_package/run_b275.sh"
cd -- "$project_root"
printf 'Starting B276 SPWVD -> ADN/phase-ARS\n'
bash "$package_dir/run_b276.sh"
printf 'B276 finished. Checking historical LMDA-PF, then testing ADSCM replacement.\n'
bash "$lmda_package/run_b275.sh" --stage replay
bash "$lmda_package/run_b275.sh" --stage core-night
printf 'Both medium experiments finished. No full-size run was started.\n'
