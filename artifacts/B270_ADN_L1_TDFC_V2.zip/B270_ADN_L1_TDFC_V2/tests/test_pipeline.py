"""CPU integration with temporary synthetic fixtures, not detection experiments."""
from __future__ import annotations

import copy
import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import h5py
import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT / "package" if (ROOT / "package").is_dir() else ROOT
sys.path.insert(0, str(PACKAGE))

import r10_sim_stage_b270_tdfc_train as training
import r10_sim_stage_b270_tdfc_score as scoring
from b270_data import digest_file, evaluate, fingerprint, prepare_training, resolve_data, write_json, load_checkpoint
from b270_model import B270Net
from b270_report import generate, first_crossing, historical_reference, rankmix_target_checks, NAMES
from source_loader import load_frozen_sources, load_frozen_file


def training_fixture(root):
    source, trainer, original = load_frozen_sources()
    b210 = load_frozen_file("r10_sim_stage_b210_a3_adn_earlystop_v1.py")
    cache = root / "small_synthetic_wvd.h5"
    with h5py.File(cache, "w") as h:
        rng = np.random.default_rng(7)
        for split in ("train", "val"):
            g = h.create_group(split)
            g.create_dataset("wvd", data=rng.random((4, 128, 128), dtype=np.float32))
            g.create_dataset("label", data=np.array([0, 1, 0, 1], dtype=np.uint8))
    context = dict(cache=cache, source=source, device=torch.device("cpu"), b210=b210, bc={"file_sha256": "synthetic-bank-unit-test"}, cc={"wvd_cache_sha256": digest_file(cache)})
    torch.manual_seed(20261022)
    model = trainer.ProposedWrapper(source, dict(original.CFG))
    with h5py.File(cache, "r") as h:
        val = evaluate(model, source, h["val"], context["device"], 2)
    ck = dict(method="L1_TAIL", seed=20261022, epoch=1, cfg=original.CFG, state_dict=model.state_dict(), val_metrics=val, source_sha256=b210.SOURCE_SHA, trainer_sha256=b210.TRAINER_SHA, bank_sha256=context["bc"]["file_sha256"], wvd_cache_sha256=context["cc"]["wvd_cache_sha256"])
    return context, ck


class PipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)

    def test_train_selection_resume_and_no_overwrite(self):
        with tempfile.TemporaryDirectory(prefix="b270_internal_training_fixture_") as directory:
            root = Path(directory)
            context, initialization = training_fixture(root)
            a = training.cli(["--root", str(root), "--out-dir", str(root/"uninterrupted"), "--epochs", "2", "--min-epochs", "1", "--batch", "2", "--device", "cpu", "--cpu-threads", "2"])
            contract = training.train_one(a, context, "adaptive", initialization, "unit-test-init-sha")
            self.assertEqual(contract["epochs_executed"], 2)
            original_last = load_checkpoint(a.out_dir/"trainseed_20261022/B270_TDFC/last_epoch.pt")
            self.assertEqual(training.train_one(a, context, "adaptive", initialization, "unit-test-init-sha"), contract)
            changed = copy.copy(a)
            changed.lr *= 2
            with self.assertRaises(RuntimeError):
                training.train_one(changed, context, "adaptive", initialization, "unit-test-init-sha")
            b = copy.copy(a)
            b.out_dir = root/"interrupted"
            actual_save = training.atomic_save

            def interrupted_save(path, payload):
                actual_save(path, payload)
                if Path(path).name == "last_epoch.pt" and payload["epoch"] == 1:
                    raise InterruptedError("Internal test interruption after durable epoch 1")

            with patch.object(training, "atomic_save", interrupted_save):
                with self.assertRaises(InterruptedError):
                    training.train_one(b, context, "adaptive", initialization, "unit-test-init-sha")
            b.resume = True
            resumed = training.train_one(b, context, "adaptive", initialization, "unit-test-init-sha")
            restored_last = load_checkpoint(b.out_dir/"trainseed_20261022/B270_TDFC/last_epoch.pt")
            self.assertEqual(resumed["best_epoch"], contract["best_epoch"])
            for key, value in original_last["state_dict"].items():
                torch.testing.assert_close(restored_last["state_dict"][key], value, rtol=0, atol=0)
            self.assertFalse(contract["h0_test_opened"])
            self.assertFalse(contract["h1_dev_opened"])

    def test_validation_matches_original_b214(self):
        with tempfile.TemporaryDirectory() as directory:
            context, initialization = training_fixture(Path(directory))
            model = B270Net(enhancement="none")
            model.load_l1_checkpoint(initialization)
            legacy = load_frozen_file("r10_sim_stage_b214_ablation_train_v1.py")
            with h5py.File(context["cache"], "r") as h:
                actual = evaluate(model, context["source"], h["val"], context["device"], 2)
                original = legacy.val_predict(context["source"], model, h["val"], context["device"], 2)
            self.assertEqual(actual, original)

    def test_actual_generator_score_stream_resume_and_precision(self):
        with tempfile.TemporaryDirectory(prefix="b270_internal_score_fixture_") as directory:
            root = Path(directory)
            a = SimpleNamespace(out_dir=root/"scores", batch=2, chunk=4)
            generator = load_frozen_file("r10_sim_iq512_builder_v1_EARLIEST_HDF5.py")
            source = load_frozen_sources()[0]
            model = B270Net(enhancement="none").eval()
            p = dict(version=scoring.VERSION, master_seed=20261009, h0_cal_n=8, h0_audit_n=4, h1_scenes_n=4, scr_grid_db=[-24, 0, 12], labels=[{"seed":20261022,"method":"L1_TAIL"}], baseline_score_reuse=None)
            p["fingerprint"] = fingerprint(p)
            scoring.stream_scores(a, p, generator, [model], source, torch.device("cpu"))
            first = np.load(a.out_dir/"dev_h1_scores.npy").copy()
            progress = json.loads((a.out_dir/"progress.json").read_text())
            progress["completed"]["h0_cal"] = 4
            progress["completed"]["h1"] = 2
            write_json(a.out_dir/"progress.json", progress)
            # Corrupt only the uncommitted suffix; resumed scoring must repair it.
            m = np.load(a.out_dir/"dev_h1_scores.npy", mmap_mode="r+")
            m[2] = -999
            m.flush()
            del m
            scoring.stream_scores(a, p, generator, [model], source, torch.device("cpu"))
            np.testing.assert_array_equal(np.load(a.out_dir/"dev_h1_scores.npy"), first)
            samples = [generator.make_one(p["master_seed"], "h0_cal", i, -30, 10) for i in range(4)]
            iq = np.stack([d["base"] for d in samples]).astype(np.complex64)
            score = scoring.model_scores([model], source, iq, torch.device("cpu"), 2)
            legacy = load_frozen_file("r10_sim_stage_b216_pdscr_score_v1.py")
            old_labels = legacy.LABELS
            legacy.LABELS = ((20261022, "L1_TAIL"),)
            try:
                original = legacy.predict([model], source, iq, torch.device("cpu"), 2)
            finally:
                legacy.LABELS = old_labels
            np.testing.assert_array_equal(score, original)
            np.testing.assert_array_equal(score[:, 0], np.load(a.out_dir/"h0_cal_scores.npy")[:4, 0])
            # Reuse the scores produced above as a genuine internal score cache;
            # verify a copied reference column and deterministic replay, then
            # ensure a deliberately corrupted sampled score is rejected.
            cached_proto=dict(version="SIM_R10_B216_PDSCR_V1",scene_fingerprint="internal-scene-fixture",labels=p["labels"],checkpoints=[dict(method="L1_TAIL",seed=20261022,sha256="internal-checkpoint-sha")])
            cached_proto["fingerprint"]=fingerprint(cached_proto)
            write_json(a.out_dir/"protocol_frozen.json",cached_proto)
            write_json(a.out_dir/"progress.json",dict(fingerprint=cached_proto["fingerprint"],completed=dict(h0_cal=8,h0_audit=4,h1=3)))
            original_protocol=dict(p,scene_fingerprint="internal-scene-fixture")
            reuse,arrays=scoring.cached_baseline(root,a.out_dir,original_protocol,"internal-checkpoint-sha",20261022)
            scoring.verify_cached_replay(reuse,arrays,original_protocol,generator,model,source,torch.device("cpu"),2)
            b=SimpleNamespace(out_dir=root/"reused",batch=2,chunk=4)
            proto=dict(p,labels=[dict(seed=20261022,method="B270_TDFC"),dict(seed=20261022,method="L1_TAIL")],baseline_score_reuse=reuse)
            proto["fingerprint"]=fingerprint({k:v for k,v in proto.items() if k!="fingerprint"})
            scoring.stream_scores(b,proto,generator,[model],source,torch.device("cpu"),arrays)
            for name in ("h0_cal_scores.npy","h0_audit_scores.npy","dev_h1_scores.npy"):
                result=np.load(b.out_dir/name)
                np.testing.assert_array_equal(result[...,0],result[...,1])
            bad={k:np.array(v) for k,v in arrays.items()}
            bad["h0_cal_scores.npy"][0,0]+=0.1
            with self.assertRaises(RuntimeError):
                scoring.verify_cached_replay(reuse,bad,original_protocol,generator,model,source,torch.device("cpu"),2)

    def test_canonical_data_discovery_preflight_and_reject_modified_data(self):
        with tempfile.TemporaryDirectory(prefix="b270_internal_canonical_shape_fixture_") as directory:
            root = Path(directory)
            b210 = load_frozen_file("r10_sim_stage_b210_a3_adn_earlystop_v1.py")
            generator = load_frozen_file("r10_sim_iq512_builder_v1_EARLIEST_HDF5.py")
            bank = root/"SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1"
            cache = root/"existing_wvd_cache"
            bank.mkdir();cache.mkdir()
            for target, name, kind in ((bank,b210.H5_NAME,"iq"),(cache,b210.CACHE_H5,"wvd")):
                with h5py.File(target/name, "w") as h:
                    for split, count in (("train",30000),("val",5000)):
                        g=h.create_group(split)
                        shape=(count,512) if kind=="iq" else (count,128,128)
                        g.create_dataset(kind,shape=shape,dtype="complex64" if kind=="iq" else "float32",chunks=(1,*shape[1:]),compression="lzf")
                        g.create_dataset("label",data=(np.arange(count)%2).astype("uint8"))
            bc=dict(version="SIM_R10_IQ512_GENERATOR_V1",preset="pilot",n_pulses=512,status="PASS_SIM_R10_IQ512_BUILDER_V1__SYNTHETIC_INTERNAL_FIXTURE",counts={"train":30000,"val":5000},file_sha256=digest_file(bank/b210.H5_NAME),seed=20261009,generator_sha256=digest_file(generator.__file__))
            write_json(bank/b210.CT_NAME,bc)
            write_json(bank/"sim_r10_iq512_audit_v1.json",dict(status="PASS_SIM_R10_IQ512_AUDIT_V1__SYNTHETIC_INTERNAL_FIXTURE",bank_sha256=bc["file_sha256"]))
            cc=dict(status=b210.PASS_CACHE,bank_sha256=bc["file_sha256"],source_sha256=b210.SOURCE_SHA,trainer_sha256=b210.TRAINER_SHA,bank_contract_sha256=digest_file(bank/b210.CT_NAME),wvd_cache_sha256=digest_file(cache/b210.CACHE_H5))
            write_json(cache/b210.CACHE_CT,cc)
            context=prepare_training(root,device="cpu")
            self.assertEqual(context["cache_dir"],cache)
            self.assertEqual(context["bank_dir"],bank)
            # Verify the command-line preflight on an actual temporary tree.
            source, trainer, original=load_frozen_sources()
            m=trainer.ProposedWrapper(source,dict(original.CFG))
            cp=root/"output_sim_r10_b215_tpht_train_v1/trainseed_20261022/L1_TAIL"
            cp.mkdir(parents=True)
            payload=dict(method="L1_TAIL",seed=20261022,epoch=1,cfg=original.CFG,state_dict=m.state_dict(),val_metrics={"val_ce":0.7},bank_sha256=bc["file_sha256"],wvd_cache_sha256=cc["wvd_cache_sha256"],source_sha256=b210.SOURCE_SHA,trainer_sha256=b210.TRAINER_SHA)
            torch.save(payload,cp/"best_val_ce.pt")
            contract=dict(status=original.PASS,method="L1_TAIL",seed=20261022,params_loss=original.PARAMS,best_checkpoint_sha256=digest_file(cp/"best_val_ce.pt"),**{k:payload[k] for k in ("bank_sha256","wvd_cache_sha256","source_sha256","trainer_sha256")})
            write_json(cp/"training_contract.json",contract)
            training.main(["--root",str(root),"--device","cpu","--cpu-threads","2","--preflight"])
            scene=dict(master_seed=20261009,generator_sha=digest_file(generator.__file__),h0_cal_n=3000000,h0_audit_n=1000000,h1_scenes_n=1024,scr_grid_db=list(range(-24,13)),h0_cal_split="h0_cal",h0_audit_split="h0_audit",h1_split="dev_h1",family_names=list(generator.TRAIN_FAMILIES),scr_definition="10log10(mean(|target IQ|^2)/mean(|clutter IQ|^2)), pre-Doppler")
            protocol=dict(version="SIM_R10_B213_SCOREBANK_V1",training_bank_sha=bc["file_sha256"],**scene,scene_fingerprint=fingerprint(scene))
            protocol["fingerprint"]=fingerprint(protocol)
            prior=root/"existing_b213";prior.mkdir()
            write_json(prior/"protocol_frozen.json",protocol)
            write_json(prior/"progress.json",dict(fingerprint=protocol["fingerprint"],completed=dict(h0_cal=3000000,h0_audit=1000000,h1=37)))
            path,validated,gen=scoring.original_protocol(root,None,context)
            self.assertEqual(validated["scene_fingerprint"],"9aab64a16dfa300a0e4398ef5d67f3132fef87c722d458ad58090615af2c95c5")
            changed=dict(protocol,h0_cal_n=100000)
            changed["scene_fingerprint"]=fingerprint({k:changed[k] for k in scoring.SCENE_KEYS})
            changed["fingerprint"]=fingerprint({k:v for k,v in changed.items() if k!="fingerprint"})
            write_json(prior/"protocol_frozen.json",changed)
            with self.assertRaises(RuntimeError):scoring.original_protocol(root,prior,context)
            write_json(prior/"protocol_frozen.json",protocol)
            # Exercise the actual scoring CLI's model-loading and provenance
            # path. Only the stream workload is bounded at a test seam; the
            # public CLI still requires full canonical scene counts.
            run_dir=root/"output_b270_tdfc_v1"
            run_dir.mkdir()
            run=dict(seed=20261022,methods=["B270_TDFC"],root=str(root),bank_dir=str(bank),cache_dir=str(cache),l1_checkpoint=str(cp/"best_val_ce.pt"))
            write_json(run_dir/"run_manifest.json",run)
            new_model=B270Net()
            new_model.load_l1_checkpoint(payload)
            new_dir=run_dir/"trainseed_20261022/B270_TDFC"
            new_dir.mkdir(parents=True)
            new_cp=dict(payload,method="B270_TDFC",state_dict=new_model.state_dict(),model_config=new_model.model_config,loss_params=original.PARAMS,run_fingerprint="synthetic-internal-run")
            torch.save(new_cp,new_dir/"best_val_ce.pt")
            new_contract=dict(contract,status=training.PASS,method="B270_TDFC",run_fingerprint=new_cp["run_fingerprint"],best_checkpoint_sha256=digest_file(new_dir/"best_val_ce.pt"))
            write_json(new_dir/"training_contract.json",new_contract)
            actual_stream=scoring.stream_scores
            def bounded_stream(args,p,gen,models,source,device,cached=None):
                self.assertEqual((p["h0_cal_n"],p["h0_audit_n"],p["h1_scenes_n"]),(3000000,1000000,1024))
                self.assertEqual([v["method"] for v in p["labels"]],["B270_TDFC","L1_TAIL"])
                short=dict(p,h0_cal_n=4,h0_audit_n=2,h1_scenes_n=2,scr_grid_db=[0])
                short["fingerprint"]=fingerprint({k:v for k,v in short.items() if k!="fingerprint"})
                actual_stream(args,short,gen,models,source,device,cached)
            with patch.object(scoring,"stream_scores",bounded_stream):
                scoring.main(["--root",str(root),"--run-dir",str(run_dir),"--device","cpu","--cpu-threads","2","--batch","2","--chunk","4","--stage","score","--no-reuse-baseline"])
            scored=np.load(run_dir/"pd_scr/dev_h1_scores.npy")
            self.assertEqual(scored.shape,(1,2,2))
            np.testing.assert_array_equal(scored[...,0],scored[...,1])
            with h5py.File(cache/b210.CACHE_H5,"r+") as h:h["train"]["label"][0]=1
            with self.assertRaises(RuntimeError):prepare_training(root,device="cpu")

    def test_full_count_report_known_horizontal_shift(self):
        with tempfile.TemporaryDirectory(prefix="b270_internal_analytic_report_fixture_") as directory:
            out=Path(directory)
            p=dict(version=scoring.VERSION,scene_fingerprint="synthetic-internal-analytic-test",h0_cal_n=3000000,h0_audit_n=1000000,h1_scenes_n=1024,scr_grid_db=list(range(-24,13)),labels=[{"seed":20261022,"method":"B270_TDFC"},{"seed":20261022,"method":"L1_TAIL"}])
            p["fingerprint"]=fingerprint(p)
            write_json(out/"protocol_frozen.json",p)
            write_json(out/"progress.json",dict(fingerprint=p["fingerprint"],completed=dict(h0_cal=3000000,h0_audit=1000000,h1=37)))
            for name,count in (("h0_cal_scores.npy",3000000),("h0_audit_scores.npy",1000000)):
                array=np.lib.format.open_memmap(out/name,mode="w+",dtype="float64",shape=(count,2))
                for st in range(0,count,100000):
                    en=min(count,st+100000)
                    value=np.arange(st,en,dtype=np.float64)/count
                    array[st:en]=value[:,None]
                array.flush();del array
            h1=np.empty((37,1024,2),np.float64)
            distribution=(np.arange(1024)+0.5)/1024
            for j,scr in enumerate(p["scr_grid_db"]):
                h1[j,:,1]=0.99995+0.015*(scr/10-(distribution-0.5))
                h1[j,:,0]=h1[j,:,1]+0.003
            np.save(out/"dev_h1_scores.npy",h1)
            report=generate(out)
            self.assertEqual(len(report["shifts_vs_l1"]),2)
            for row in report["shifts_vs_l1"]:
                self.assertAlmostEqual(row["delta_D90_db"],-2.0,delta=0.02)
                self.assertAlmostEqual(row["delta_D80_db"],-2.0,delta=0.02)
                self.assertGreater(row["pd_at_0_gain_percentage_points"],0)
            for name in ("b270_curves.csv","b270_metrics.csv","b270_report.json","figures/b270_pd_scr_pfa_1e-5.pdf"):
                self.assertGreater((out/name).stat().st_size,0)
            self.assertIsNone(first_crossing([-1,0,1],[0.1,0.2,0.3],0.9))

    def test_rankmix_target_uses_fusion_not_l1_and_requires_replay(self):
        with (PACKAGE/"historical_reference/b229_curves.csv").open(newline="") as f:
            old = list(csv.DictReader(f))
        curves, metrics = [], []
        for pfa in (1e-4, 1e-5):
            for row in old:
                if float(row["nominal_pfa"]) == pfa and row["method"] == "L1-Tail":
                    curves.append(dict(method="L1-Tail", nominal_pfa=pfa, scr_db=int(row["scr_db"]), hits=int(row["hits"]), n_h1=1024, pd=float(row["pd"])))
            ref = sorted([r for r in old if float(r["nominal_pfa"]) == pfa and r["method"] == "Rank mix LMDA75/L125"], key=lambda r:int(r["scr_db"]))
            # Shift uploaded fusion hit counts left by exactly one grid step.
            y = [float(r["pd"]) for r in ref[1:]] + [float(ref[-1]["pd"])]
            method = NAMES["B270_TDFC"]
            for scr,pd in zip(range(-24,13),y):
                curves.append(dict(method=method, nominal_pfa=pfa, scr_db=scr, hits=round(pd*1024), n_h1=1024, pd=pd))
            metrics.append(dict(method=method, seed=20261022, nominal_pfa=pfa, actual_pfa=1e-5, **{key:first_crossing(list(range(-24,13)), y, level) for key,level in (("D50_db",.5),("D80_db",.8),("D90_db",.9))}))
        fusion,status = historical_reference(curves)
        self.assertTrue(status["baseline_aggregate_hit_replay"])
        self.assertEqual(len(fusion),74)
        rows = rankmix_target_checks(metrics, curves, status)
        for row in rows:
            self.assertAlmostEqual(row["delta_vs_rankmix_D90_db"],-1.0)
            self.assertTrue(row["D90_db_1db_target_met"])
            self.assertTrue(row["entire_overlap_1db_target_met"])
            self.assertTrue(row["D90_target_with_audit_guard"])
        pfa5 = next(r for r in rows if r["nominal_pfa"]==1e-5)
        self.assertAlmostEqual(pfa5["target_D90_db"],1.5567567567567573)
        metrics[-1]["actual_pfa"] = 2e-5
        rows = rankmix_target_checks(metrics, curves, status)
        self.assertFalse(rows[-1]["D90_target_with_audit_guard"])
        curves[0]["hits"] += 1
        fusion,status = historical_reference(curves)
        self.assertFalse(status["baseline_aggregate_hit_replay"])
        self.assertFalse(fusion)
        rows = rankmix_target_checks(metrics, curves, status)
        self.assertTrue(all(r["D90_db_1db_target_met"] is None for r in rows))
        self.assertTrue(all(r["entire_overlap_1db_target_met"] is None for r in rows))


if __name__=="__main__":
    unittest.main(verbosity=2)
