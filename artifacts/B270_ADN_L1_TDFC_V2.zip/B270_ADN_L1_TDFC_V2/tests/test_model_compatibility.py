"""Internal CPU checks using the real frozen model and synthetic inputs.

These do not validate SIM-R10 training, detection benefit, or Pd/Pfa performance.
"""
from __future__ import annotations

import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT / "package" if (ROOT / "package").is_dir() else ROOT
sys.path.insert(0, str(PACKAGE))

from b270_model import B270Net
from b270_loss import l1_tail_loss
from source_loader import load_frozen_sources
from tdfc_module import TimeFrequencyResidualCalibration


class CompatibilityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)
        torch.manual_seed(20261022)
        cls.source, cls.trainer, cls.reference = load_frozen_sources()
        cls.baseline = cls.trainer.ProposedWrapper(cls.source, dict(cls.reference.CFG)).eval()
        manifest = json.loads((PACKAGE / "frozen_source" / "manifest.json").read_text())
        cls.checkpoint = {
            "method": "L1_TAIL", "cfg": dict(cls.reference.CFG),
            "state_dict": cls.baseline.state_dict(),
            "source_sha256": manifest[cls.source.__file__.split("/")[-1]],
            "trainer_sha256": manifest[cls.trainer.__file__.split("/")[-1]],
        }
        cls.x = cls.source.map_to_adn_input(torch.rand(4, 128, 128))
        cls.labels = torch.tensor([0, 1, 0, 1])

    def initialized_model(self, enhancement="adaptive"):
        model = B270Net(enhancement=enhancement)
        model.load_l1_checkpoint(self.checkpoint)
        return model

    def test_initial_logits_match_complete_l1_tail(self):
        with torch.no_grad():
            expected = self.baseline(self.x)
            for enhancement in ("adaptive", "fixed", "none"):
                with self.subTest(enhancement=enhancement):
                    model = self.initialized_model(enhancement).eval()
                    actual = model(self.x)
                    torch.testing.assert_close(actual, expected, rtol=0, atol=0)
                    self.assertEqual(sum(type(m).__name__ == "TFCG" for m in model.modules()), 8)
                    self.assertIsNotNone(model.suppressor)
                    self.assertEqual(actual.shape, (4, 2))

    def test_rejects_mismatched_checkpoint_and_lineage(self):
        model = B270Net()
        for field, wrong in (("method", "A3"), ("cfg", {}), ("source_sha256", "changed")):
            with self.subTest(field=field), self.assertRaises(ValueError):
                cp = dict(self.checkpoint)
                cp[field] = wrong
                model.load_l1_checkpoint(cp)
        for remove in (True, False):
            cp = dict(self.checkpoint)
            cp["state_dict"] = dict(cp["state_dict"])
            if remove:
                cp["state_dict"].pop("detector.fc.bias")
            else:
                cp["state_dict"]["unexpected.weight"] = torch.ones(1)
            with self.assertRaises(ValueError):
                model.load_l1_checkpoint(cp)

    def test_train_updates_new_module_and_preserves_frozen_shallow_bn(self):
        model = self.initialized_model()
        parameters = model.configure_training("high")
        model.train()
        optimizer = torch.optim.Adam(parameters, lr=3e-5, betas=(0.9, 0.99))
        initial = model.tdfc.project.weight.detach().clone()
        shallow_mean = model.detector.bn1.running_mean.detach().clone()
        shallow_weight = model.detector.conv1.weight.detach().clone()
        self.assertFalse(model.suppressor.training)
        self.assertFalse(model.detector.layer1.training)
        self.assertFalse(model.detector.layer2.training)
        self.assertTrue(model.detector.layer3.training)
        for step in range(2):
            optimizer.zero_grad(set_to_none=True)
            logits, aux = model(self.x, return_aux=True)
            loss, ce, parts, weighted = l1_tail_loss(logits, self.labels, aux)
            self.assertTrue(torch.isfinite(loss).item())
            self.assertEqual(parts["num_hard_h0"], 1)
            self.assertEqual(parts["num_weak_h1"], 1)
            self.assertEqual(float(weighted["hard_h0"]), 0.0)
            self.assertEqual(float(weighted["preserve_h1"]), 0.0)
            loss.backward()
            self.assertGreater(float(model.tdfc.project.weight.grad.abs().sum()), 0)
            self.assertTrue(all(p.grad is None or torch.isfinite(p.grad).all() for p in parameters))
            if step == 1:
                self.assertGreater(float(model.tdfc.route[-1].weight.grad.abs().sum()), 0)
                self.assertGreater(float(model.tdfc.pool_route[-1].weight.grad.abs().sum()), 0)
                self.assertGreater(float(model.tdfc.time_long.weight.grad.abs().sum()), 0)
                self.assertGreater(float(model.tdfc.frequency_long.weight.grad.abs().sum()), 0)
            optimizer.step()
        self.assertFalse(torch.equal(model.tdfc.project.weight.detach(), initial))
        torch.testing.assert_close(model.detector.bn1.running_mean, shallow_mean, rtol=0, atol=0)
        torch.testing.assert_close(model.detector.conv1.weight, shallow_weight, rtol=0, atol=0)

    def test_adaptive_routing_and_bound_are_samplewise(self):
        torch.manual_seed(19)
        module = TimeFrequencyResidualCalibration(channels=16).eval()
        with torch.no_grad():
            module.project.weight.normal_(0, 0.1)
        x = torch.randn(3, 16, 14, 14)
        result, weights = module(x, return_weights=True)
        self.assertFalse(torch.allclose(weights[0], weights[1]))
        torch.testing.assert_close(weights.sum(1), torch.ones(3))
        self.assertTrue((weights > 0).all())
        for i in range(3):
            single, single_weights = module(x[i:i+1], return_weights=True)
            torch.testing.assert_close(single, result[i:i+1], atol=1e-6, rtol=1e-5)
            torch.testing.assert_close(single_weights, weights[i:i+1], atol=1e-6, rtol=1e-5)
        # Bounded multiplicative residual, for both positive and negative inputs.
        self.assertTrue(((result - x).abs() <= module.gamma * x.abs() + 1e-6).all())
        fixed = TimeFrequencyResidualCalibration(channels=16, adaptive=False)
        _, fixed_weights = fixed(x, return_weights=True)
        torch.testing.assert_close(fixed_weights, torch.full((3, 4), 0.25), rtol=0, atol=0)
        self.assertIsNone(fixed.pool_route)

    def test_axis_filters_and_hybrid_pooling_act_on_corresponding_axes(self):
        module = TimeFrequencyResidualCalibration(channels=8).eval()
        # A temporal impulse spreads only along H for time filters, only W for
        # frequency filters. This catches swapped WVD axis implementations.
        u = torch.zeros(1, 8, 13, 13)
        u[:, :, 6, 6] = 1
        time = module.time_long(u)
        freq = module.frequency_long(u)
        self.assertEqual(int(torch.count_nonzero(time[0, 0, :, 6])), 9)
        self.assertEqual(int(torch.count_nonzero(freq[0, 0, 6, :])), 9)
        self.assertEqual(int(torch.count_nonzero(time[0, 0, 6, :])), 1)
        self.assertEqual(int(torch.count_nonzero(freq[0, 0, :, 6])), 1)
        weights = module.pool_route(torch.randn(3, 16)).softmax(1)
        torch.testing.assert_close(weights.sum(1), torch.ones(3))
        self.assertFalse(torch.allclose(weights[0], weights[1]))

    def test_checkpoint_roundtrip_and_scoring_batch_invariance(self):
        model = self.initialized_model().eval()
        with torch.no_grad():
            model.tdfc.project.weight.normal_(0, 0.05)
            expected = model(self.x)
        checkpoint = {"model_config": model.model_config, "state_dict": model.state_dict()}
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model.pt"
            torch.save(checkpoint, path)
            loaded = torch.load(path, map_location="cpu", weights_only=True)
            restored = B270Net(**loaded["model_config"]).eval()
            restored.load_state_dict(loaded["state_dict"], strict=True)
            with torch.no_grad():
                actual = restored(self.x)
                torch.testing.assert_close(actual, expected, rtol=0, atol=0)
                split = torch.cat([restored(self.x[i:i+1]) for i in range(4)])
                actual_score = actual[:, 1].double() - actual[:, 0].double()
                split_score = split[:, 1].double() - split[:, 0].double()
                torch.testing.assert_close(split_score, actual_score, rtol=1e-5, atol=1e-5)
                self.assertTrue(torch.isfinite(actual_score).all())

    def test_actual_wvd_iq512_preprocessing(self):
        torch.manual_seed(13)
        iq = torch.complex(torch.randn(2, 512), torch.randn(2, 512))
        maps = self.source.wvd_base_map(iq).clone()
        self.assertEqual(maps.shape, (2, 128, 128))
        self.assertTrue(torch.isfinite(maps).all())
        self.assertTrue(((maps >= 0) & (maps <= 1)).all())
        model = self.initialized_model().eval()
        with torch.no_grad():
            logits = model(self.source.map_to_adn_input(maps))
        self.assertEqual(logits.shape, (2, 2))
        self.assertTrue(torch.isfinite(logits).all())


if __name__ == "__main__":
    unittest.main(verbosity=2)
