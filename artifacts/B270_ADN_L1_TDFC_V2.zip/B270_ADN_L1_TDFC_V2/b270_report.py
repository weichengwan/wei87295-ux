"""Raw Pd/SCR curves, audited Pfa, and first-crossing SCR metrics; DEV only."""
from __future__ import annotations

import csv
import os
from pathlib import Path

import numpy as np

from b270_data import fingerprint, need, read_json, write_json
from source_loader import load_frozen_file

NAMES = {"B270_TDFC": "L1-Tail+TDFC", "L1_CONTROL": "L1-Tail control", "B270_FIXED": "L1-Tail+fixed", "L1_TAIL": "L1-Tail"}
PFAS = (1e-4, 1e-5)


def first_crossing(x, y, level):
    """Linear interpolation at the first raw crossing; no smoothing/extrapolation."""
    if y[0] >= level:
        return float(x[0])
    for i in range(1, len(x)):
        if y[i-1] < level <= y[i]:
            return float(x[i-1] + (level-y[i-1]) * (x[i]-x[i-1]) / (y[i]-y[i-1]))
    return None


def save_csv(path, rows):
    need(rows, f"No rows to write: {path}")
    with Path(path).open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def historical_reference(curves):
    directory = Path(__file__).resolve().parent / "historical_reference"
    path = directory / "b229_curves.csv"
    if not path.is_file():
        return [], dict(available=False)
    with path.open(encoding="utf-8-sig", newline="") as f:
        old = list(csv.DictReader(f))
    baseline = {(r["nominal_pfa"], r["scr_db"]): r for r in curves if r["method"] == "L1-Tail"}
    matched = True
    old_baseline = [r for r in old if r["method"] == "L1-Tail"]
    if len(old_baseline) != len(baseline):
        matched = False
    for r in old_baseline:
        key = (float(r["nominal_pfa"]), int(float(r["scr_db"])))
        now = baseline.get(key)
        if now is None or int(r["hits"]) != now["hits"] or int(r["n_h1"]) != now["n_h1"]:
            matched = False
    provenance = read_json(directory / "b229_provenance.json")
    status = dict(available=True, baseline_aggregate_hit_replay=matched, paired_scene_identity="UNVERIFIED", original_provenance=provenance, usage="Historical overlay only; no paired significance claims against the historical fusion")
    fusion = [dict(nominal_pfa=float(r["nominal_pfa"]), scr_db=int(float(r["scr_db"])), pd=float(r["pd"])) for r in old if r["method"] == "Rank mix LMDA75/L125"] if matched else []
    return fusion, status


def rankmix_target_checks(metrics, curves, historical):
    """Descriptive comparisons to the uploaded fixed fusion, never paired claims.

    The same nominal Pfa is required. Aggregate baseline replay is a consistency
    check; it does not establish historical scene pairing. A target check is
    suppressed when replay fails. Audit rates are reported, never refitted.
    """
    path = Path(__file__).resolve().parent / "historical_reference" / "b229_curves.csv"
    if not path.is_file():
        return []
    with path.open(encoding="utf-8-sig", newline="") as f:
        old = list(csv.DictReader(f))
    with path.with_name("b229_metrics.csv").open(encoding="utf-8-sig", newline="") as f:
        old_metrics = list(csv.DictReader(f))
    comparable = historical.get("baseline_aggregate_hit_replay") is True
    targets = []
    for pfa in PFAS:
        reference = sorted([r for r in old if r["method"] == "Rank mix LMDA75/L125" and float(r["nominal_pfa"]) == pfa], key=lambda r: float(r["scr_db"]))
        need(len(reference) == 37 and [int(float(r["scr_db"])) for r in reference] == list(range(-24, 13)), "Incomplete historical rank mix curve")
        need(all(int(r["n_h1"]) == 1024 and abs(float(r["pd"])-int(r["hits"])/1024) < 1e-10 for r in reference), "Invalid historical rank mix hits")
        y_ref = np.array([float(r["pd"]) for r in reference])
        ref_metrics = [r for r in old_metrics if r["method"] == "Rank mix LMDA75/L125" and float(r["nominal_pfa"]) == pfa]
        need(len(ref_metrics) == 1, "Missing/ambiguous historical rank mix metrics")
        audit_ref = float(ref_metrics[0]["actual_pfa"])
        for metric in [m for m in metrics if m["nominal_pfa"] == pfa and m["method"] != "L1-Tail"]:
            current = sorted([r for r in curves if r["method"] == metric["method"] and r["nominal_pfa"] == pfa], key=lambda r: r["scr_db"])
            need(len(current) == 37, "Incomplete new curve for rank mix comparison")
            y_new = np.array([r["pd"] for r in current])
            row = dict(method=metric["method"], seed=metric["seed"], nominal_pfa=pfa, reference="Rank mix LMDA75/L125", target_left_shift_db=1.0, baseline_aggregate_hit_replay=comparable, historical_scene_pairing="UNVERIFIED", comparison_scope="DEV descriptive only", new_audit_actual_pfa=metric["actual_pfa"], reference_audit_actual_pfa=audit_ref)
            for key, level in (("D50_db", 0.5), ("D80_db", 0.8), ("D90_db", 0.9)):
                ref_d = first_crossing(list(range(-24, 13)), y_ref, level)
                need(ref_d is not None and abs(ref_d-float(ref_metrics[0][key])) < 1e-9, "Historical rank mix metrics disagree with its raw curve")
                target_d = None if ref_d is None else ref_d - 1.0
                new_d = metric[key]
                row["reference_"+key] = ref_d
                row["target_"+key] = target_d
                row["new_"+key] = new_d
                row["delta_vs_rankmix_"+key] = None if new_d is None or ref_d is None else new_d - ref_d
                row[key+"_1db_target_met"] = None if not comparable or target_d is None or new_d is None else bool(new_d <= target_d + 1e-10)
            # On the one-dB grid, a left-shift target is exactly y_ref(SCR+1).
            # This checks the whole available overlap, not just a crossing.
            gaps = y_new[:-1] - y_ref[1:]
            row.update(pointwise_common_scr_min=-24, pointwise_common_scr_max=11, pointwise_points=36, points_below_1db_target=int(np.count_nonzero(gaps < -1e-12)), min_pd_gap_to_1db_target=float(gaps.min()), entire_overlap_1db_target_met=None if not comparable else bool(np.all(gaps >= -1e-12)))
            audit_guard = metric["actual_pfa"] <= audit_ref + 1e-15
            row["audit_actual_pfa_not_above_reference"] = audit_guard
            row["D90_target_with_audit_guard"] = None if row["D90_db_1db_target_met"] is None else bool(row["D90_db_1db_target_met"] and audit_guard)
            targets.append(row)
    return targets


def generate(directory):
    out = Path(directory)
    protocol = read_json(out / "protocol_frozen.json")
    progress = read_json(out / "progress.json")
    need(protocol.get("version") == "B270_LMDA_TDFC_SIMR10_PDSCR_DEV_V2", "Not a B270 V2 scoring output")
    need(fingerprint({k: v for k, v in protocol.items() if k != "fingerprint"}) == protocol["fingerprint"] == progress["fingerprint"], "Report protocol fingerprint mismatch")
    need(progress["completed"] == {"h0_cal": protocol["h0_cal_n"], "h0_audit": protocol["h0_audit_n"], "h1": len(protocol["scr_grid_db"])}, "Scoring incomplete; finish the score stage first")
    need((protocol["h0_cal_n"], protocol["h0_audit_n"], protocol["h1_scenes_n"]) == (3000000, 1000000, 1024) and protocol["scr_grid_db"] == list(range(-24, 13)), "Report requires the original full scene protocol")
    labels = protocol["labels"]
    n = len(labels)
    arrays = [np.load(out / name, mmap_mode="r") for name in ("h0_cal_scores.npy", "h0_audit_scores.npy", "dev_h1_scores.npy")]
    cal, audit, h1 = arrays
    need(cal.shape == (protocol["h0_cal_n"], n) and audit.shape == (protocol["h0_audit_n"], n) and h1.shape == (37, 1024, n), "Score array shape mismatch")
    need(all(a.dtype == np.dtype("float64") and np.isfinite(a).all() for a in arrays), "Bad score dtype or NaN/Inf")
    baseline = next(i for i, label in enumerate(labels) if label["method"] == "L1_TAIL")
    statistics = load_frozen_file("r10_sim_stage_b216_pdscr_report_v1.py")
    curves, metrics, paired, shifts = [], [], [], []
    detections, cutoffs = {}, {}
    for pfa in PFAS:
        for i, label in enumerate(labels):
            threshold, support, cal_fp = statistics.cutoff(cal[:, i], pfa)
            fp = int(np.count_nonzero(audit[:, i] > threshold))
            actual_pfa = fp / len(audit)
            pfa_low, pfa_high = statistics.wilson(fp, len(audit))
            hit = h1[:, :, i] > threshold
            detections[pfa, i] = hit
            cutoffs[pfa, i] = threshold
            y = hit.sum(axis=1) / protocol["h1_scenes_n"]
            method = NAMES.get(label["method"], label["method"])
            for j, scr in enumerate(protocol["scr_grid_db"]):
                hits = int(hit[j].sum())
                low, high = statistics.wilson(hits, protocol["h1_scenes_n"])
                curves.append(dict(method=method, seed=label["seed"], nominal_pfa=pfa, scr_db=scr, hits=hits, n_h1=protocol["h1_scenes_n"], pd=float(y[j]), pd_ci95_low=low, pd_ci95_high=high, audit_actual_pfa=actual_pfa))
            metric = dict(method=method, seed=label["seed"], nominal_pfa=pfa, actual_pfa=actual_pfa, audit_false_alarms=fp, audit_n=len(audit), actual_pfa_ci95_low=pfa_low, actual_pfa_ci95_high=pfa_high, threshold=threshold, cal_n=len(cal), cal_nominal_tail_support=support, cal_exceedances=cal_fp, D50_db=first_crossing(protocol["scr_grid_db"], y, 0.5), D80_db=first_crossing(protocol["scr_grid_db"], y, 0.8), D90_db=first_crossing(protocol["scr_grid_db"], y, 0.9), mean_pd_scr_m24_to_0=float(y[:25].mean()))
            for scr in (0, 6, 9, 12):
                metric[f"pd_at_{scr}"] = float(y[protocol["scr_grid_db"].index(scr)])
            metrics.append(metric)
        ref = next(r for r in metrics if r["method"] == "L1-Tail" and r["nominal_pfa"] == pfa)
        for i, label in enumerate(labels):
            if i == baseline:
                continue
            method = NAMES.get(label["method"], label["method"])
            m = next(r for r in metrics if r["method"] == method and r["nominal_pfa"] == pfa)
            row = dict(method=method, nominal_pfa=pfa, reference="L1-Tail", pd_at_0_gain_percentage_points=100*(m["pd_at_0"]-ref["pd_at_0"]), mean_pd_m24_to_0_gain=m["mean_pd_scr_m24_to_0"]-ref["mean_pd_scr_m24_to_0"])
            for key in ("D50_db", "D80_db", "D90_db"):
                row["delta_" + key] = m[key]-ref[key] if m[key] is not None and ref[key] is not None else None
            shifts.append(row)
            current, reference = detections[pfa, i], detections[pfa, baseline]
            for j, scr in enumerate(protocol["scr_grid_db"]):
                wins = int(np.count_nonzero(current[j] & ~reference[j]))
                losses = int(np.count_nonzero(~current[j] & reference[j]))
                paired.append(dict(method=method, reference="L1-Tail", nominal_pfa=pfa, scr_db=scr, n_h1=1024, wins=wins, losses=losses, ties=1024-wins-losses, delta_pd=(wins-losses)/1024))
    fusion, historical = historical_reference(curves)
    targets = rankmix_target_checks(metrics, curves, historical)
    save_csv(out / "b270_curves.csv", curves)
    save_csv(out / "b270_metrics.csv", metrics)
    if shifts:
        save_csv(out / "b270_shift_metrics.csv", shifts)
        save_csv(out / "b270_paired_deltas.csv", paired)
    if targets:
        save_csv(out / "b270_vs_rankmix_1db.csv", targets)
    report = dict(
        status="PASS_B270_REPORT_DEV_ONLY", scene_fingerprint=protocol["scene_fingerprint"],
        profile="original full 3M H0 CAL / 1M H0 AUDIT / 1024 paired H1 / 37 SCR", metrics=metrics, shifts_vs_l1=shifts,
        historical_reference=historical, rankmix_1db_target_checks=targets, smoothing=False,
        primary_target="At nominal Pfa=1e-5: D90 <= historical fixed rank mix D90 - 1 dB, with the actual audit Pfa also reported. This is a DEV screening target, not independent confirmation.",
        shift_interpretation="Negative delta D50/D80/D90 means a left shift at that detection level, not improvement over the entire curve. Unreached levels remain null; first raw crossing is linearly interpolated.",
        scope="DEV exploratory, one training seed. H0 AUDIT is not used for training or threshold fitting. These are not independent FINAL results; a lower nominal Pfa alone does not establish matched actual Pfa.",
    )
    write_json(out / "b270_report.json", report)
    plot(out, curves, labels, fusion)
    for row in shifts:
        print(f"{row['method']} Pfa={row['nominal_pfa']:.0e}: delta_D80={row['delta_D80_db']}, delta_D90={row['delta_D90_db']}, Pd@0 gain={row['pd_at_0_gain_percentage_points']:+.3f} pp", flush=True)
    for row in targets:
        print(f"{row['method']} vs fixed rank mix Pfa={row['nominal_pfa']:.0e}: delta_D90={row['delta_vs_rankmix_D90_db']}; 1dB D90 target={row['D90_db_1db_target_met']}; with audit guard={row['D90_target_with_audit_guard']} (DEV descriptive; historical pairing unverified)", flush=True)
    print(f"Report complete: {out / 'b270_metrics.csv'}", flush=True)
    return report


def plot(out, curves, labels, fusion):
    # Keep generated caches beside the report when home is read-only; honor
    # existing user bindings rather than changing their configured locations.
    os.environ.setdefault("MPLCONFIGDIR", str(out / ".matplotlib_cache"))
    os.environ.setdefault("XDG_CACHE_HOME", str(out / ".cache"))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    directory = out / "figures"
    directory.mkdir(exist_ok=True)
    for pfa in PFAS:
        fig, ax = plt.subplots(figsize=(9, 5.4))
        for label in labels:
            method = NAMES.get(label["method"], label["method"])
            rows = sorted([r for r in curves if r["method"] == method and r["nominal_pfa"] == pfa], key=lambda r: r["scr_db"])
            ax.plot([r["scr_db"] for r in rows], [r["pd"] for r in rows], label=method, lw=1.8)
        old = sorted([r for r in fusion if r["nominal_pfa"] == pfa], key=lambda r: r["scr_db"])
        if old:
            ax.plot([r["scr_db"] for r in old], [r["pd"] for r in old], "--", color="gray", lw=1.3, label="Rank mix LMDA75/L125 (historical)")
            ax.plot([r["scr_db"]-1 for r in old], [r["pd"] for r in old], ":", color="gray", lw=1.1, label="Rank mix -1 dB target (not a result)")
        ax.set(xlabel="Input SCR (dB)", ylabel="Empirical Pd", xlim=(-24, 12), ylim=(0, 1.02), title=f"SIM-R10 DEV | nominal Pfa={pfa:.0e} | seed={labels[0]['seed']}")
        ax.set_xticks(range(-24, 13, 4))
        ax.grid(alpha=0.2)
        ax.legend(loc="lower right", fontsize=8)
        fig.tight_layout()
        tag = "1e-4" if pfa == 1e-4 else "1e-5"
        for extension in ("png", "pdf"):
            fig.savefig(directory / f"b270_pd_scr_pfa_{tag}.{extension}", dpi=220)
        plt.close(fig)
