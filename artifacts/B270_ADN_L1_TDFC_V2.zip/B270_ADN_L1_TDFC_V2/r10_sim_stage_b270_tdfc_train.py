#!/usr/bin/env python3
"""Train full L1-Tail plus one residual calibration module on the frozen SIM bank."""
from __future__ import annotations

import argparse
import gc
import json
import math
import random
import time
from pathlib import Path

import h5py
import numpy as np
import pandas as pd
import torch

from b270_data import digest_file, evaluate, fingerprint, load_checkpoint, need, prepare_training, read_json, verify_l1_checkpoint, write_json
from b270_loss import l1_tail_loss
from b270_model import B270Net
from source_loader import load_frozen_sources

VERSION = "B270_LMDA_TDFC_SIMR10_TRAIN_V2"
PASS = "PASS_B270_TRAIN_VAL_ONLY__MIN_VAL_CE__NO_H0_NO_DEV"
METHODS = {"adaptive": "B270_TDFC", "none": "L1_CONTROL", "fixed": "B270_FIXED"}


def cli(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, default=Path(__file__).resolve().parent.parent)
    p.add_argument("--bank-dir", type=Path)
    p.add_argument("--cache-dir", type=Path)
    p.add_argument("--out-dir", type=Path)
    p.add_argument("--l1-checkpoint", type=Path)
    p.add_argument("--init", choices=("l1", "scratch"), default="l1")
    p.add_argument("--methods", default="adaptive,none", help="adaptive, none (same-budget L1 control), fixed (fixed-mixture control)")
    p.add_argument("--train-policy", choices=("auto", "high", "all"), default="auto")
    p.add_argument("--seed", type=int, default=20261022)
    p.add_argument("--epochs", type=int, default=15)
    p.add_argument("--min-epochs", type=int, default=6)
    p.add_argument("--patience", type=int, default=0, help="0 gives equal fixed budgets; otherwise TRAIN/VAL early stopping")
    p.add_argument("--batch", type=int, default=32)
    p.add_argument("--lr", type=float, default=3e-5)
    p.add_argument("--module-lr", type=float, help="Defaults to 10 times base learning rate")
    p.add_argument("--clip-norm", type=float, default=5.0)
    p.add_argument("--reduction", type=int, default=8)
    p.add_argument("--time-kernel", type=int, default=9)
    p.add_argument("--frequency-kernel", type=int, default=9)
    p.add_argument("--gamma", type=float, default=0.2)
    p.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto")
    p.add_argument("--cpu-threads", type=int, default=4)
    p.add_argument("--resume", action="store_true", help="Resume an interrupted epoch-boundary checkpoint with exactly the same configuration")
    p.add_argument("--preflight", action="store_true", help="Verify existing data and initialization without starting training")
    a = p.parse_args(argv)
    need(a.batch > 0 and a.batch % 2 == 0, "Training batch must be positive and even")
    need(a.epochs >= a.min_epochs >= 1 and a.patience >= 0, "Invalid epoch/early-stop settings")
    need(a.seed >= 0 and a.cpu_threads >= 1, "Invalid seed or CPU thread count")
    a.module_lr = a.module_lr if a.module_lr is not None else 10 * a.lr
    need(all(math.isfinite(v) and v > 0 for v in (a.lr, a.module_lr, a.clip_norm)), "Invalid optimizer parameters")
    a.methods = [x.strip() for x in a.methods.split(",")]
    need(a.methods and len(a.methods) == len(set(a.methods)) and set(a.methods) <= set(METHODS), "Invalid or duplicate methods")
    a.train_policy = ("high" if a.init == "l1" else "all") if a.train_policy == "auto" else a.train_policy
    need(a.init != "scratch" or a.train_policy == "all", "A from-scratch run must train all layers")
    a.root = a.root.resolve()
    a.out_dir = (a.out_dir or a.root / "output_b270_adn_l1_tdfc_v2").resolve()
    a.l1_checkpoint = (a.l1_checkpoint or a.root / "output_sim_r10_b215_tpht_train_v1" / f"trainseed_{a.seed}" / "L1_TAIL" / "best_val_ce.pt").resolve()
    # Constructor validation is duplicated here to fail before data hashes or work.
    need(a.reduction >= 1 and all(k >= 1 and k % 2 == 1 for k in (a.time_kernel, a.frequency_kernel)), "Invalid calibration dimensions")
    need(math.isfinite(a.gamma) and 0 < a.gamma < 1, "gamma must be strictly between 0 and 1")
    return a


def atomic_save(path, data):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(data, temporary)
    temporary.replace(path)


def code_hashes():
    root = Path(__file__).resolve().parent
    return {p.name: digest_file(p) for p in sorted(root.glob("*.py"))}


def train_one(a, context, enhancement, initialization, initialization_sha):
    method = METHODS[enhancement]
    out = a.out_dir / f"trainseed_{a.seed}" / method
    config = dict(
        version=VERSION, seed=a.seed, enhancement=enhancement, init=a.init,
        train_policy=a.train_policy, epochs=a.epochs, min_epochs=a.min_epochs,
        patience=a.patience, batch=a.batch, lr=a.lr, module_lr=a.module_lr,
        clip_norm=a.clip_norm, reduction=a.reduction, time_kernel=a.time_kernel,
        frequency_kernel=a.frequency_kernel, gamma=a.gamma,
        initialization_sha256=initialization_sha,
        bank_sha256=context["bc"]["file_sha256"],
        wvd_cache_sha256=context["cc"]["wvd_cache_sha256"],
        code_sha256=code_hashes(),
    )
    run_fingerprint = fingerprint(config)
    contract_path = out / "training_contract.json"
    if contract_path.is_file():
        c = read_json(contract_path)
        need(c.get("status") == PASS and c.get("run_fingerprint") == run_fingerprint, "Completed experiment has a different configuration; choose a new --out-dir")
        need(digest_file(out / "best_val_ce.pt") == c["best_checkpoint_sha256"], "Completed checkpoint checksum mismatch")
        print(f"[{method}] completed; verified and skipped", flush=True)
        return c
    latest = out / "last_epoch.pt"
    if out.exists() and any(out.iterdir()):
        need(a.resume and latest.is_file(), f"Incomplete output at {out}; use --resume with the same configuration or select a new output directory")
    else:
        out.mkdir(parents=True, exist_ok=True)
    random.seed(a.seed)
    np.random.seed(a.seed)
    torch.manual_seed(a.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(a.seed)
    model = B270Net(enhancement=enhancement, reduction=a.reduction, time_kernel=a.time_kernel, frequency_kernel=a.frequency_kernel, gamma=a.gamma)
    if initialization is not None:
        model.load_l1_checkpoint(initialization)
    model.to(context["device"])
    parameters = model.configure_training(a.train_policy)
    base = [p for n, p in model.named_parameters() if p.requires_grad and not n.startswith("tdfc.")]
    extra = [p for n, p in model.named_parameters() if p.requires_grad and n.startswith("tdfc.")]
    groups = [{"params": base, "lr": a.lr}]
    if extra:
        groups.append({"params": extra, "lr": a.module_lr})
    optimizer = torch.optim.Adam(groups, betas=(0.9, 0.99))
    hist, best, best_epoch, first_epoch = [], float("inf"), -1, 1
    loss_reference = load_frozen_sources()[2]

    def snapshot(epoch, metrics):
        return dict(
            version=VERSION, method=method, seed=a.seed, epoch=epoch,
            state_dict=model.state_dict(), model_config=model.model_config, cfg=model.cfg,
            loss_params=loss_reference.PARAMS, val_metrics=metrics,
            selected_by="min VAL CE (warm initialization epoch 0 eligible)",
            run_config=config, run_fingerprint=run_fingerprint,
            bank_sha256=context["bc"]["file_sha256"],
            wvd_cache_sha256=context["cc"]["wvd_cache_sha256"],
            source_sha256=context["b210"].SOURCE_SHA,
            trainer_sha256=context["b210"].TRAINER_SHA,
        )

    if latest.is_file():
        state = load_checkpoint(latest)
        need(state.get("run_fingerprint") == run_fingerprint, "Resume configuration/fingerprint differs")
        need((out / "best_val_ce.pt").is_file(), "Resume is missing the selected checkpoint")
        model.load_state_dict(state["state_dict"], strict=True)
        optimizer.load_state_dict(state["optimizer"])
        hist, best, best_epoch = state["history"], state["best_val_ce"], state["best_epoch"]
        first_epoch = state["epoch"] + 1
        torch.set_rng_state(state["torch_rng"])
        if context["device"].type == "cuda" and state.get("cuda_rng"):
            torch.cuda.set_rng_state_all(state["cuda_rng"])
        print(f"[{method}] resume after epoch {state['epoch']}", flush=True)
    with h5py.File(context["cache"], "r") as h:
        if first_epoch == 1:
            initial_val = evaluate(model, context["source"], h["val"], context["device"], a.batch)
            if initialization is not None:
                need(abs(initial_val["val_ce"] - initialization["val_metrics"]["val_ce"]) < 1e-4, "Initialization no longer reproduces the original L1-Tail validation CE")
                best, best_epoch = initial_val["val_ce"], 0
                atomic_save(out / "best_val_ce.pt", snapshot(0, initial_val))
            write_json(out / "initial_validation.json", dict(**initial_val, eligible_for_selection=initialization is not None))
        labels = h["train"]["label"][:].astype(np.int64)
        last_epoch = first_epoch - 1
        for epoch in range(first_epoch, a.epochs + 1):
            # If the saved epoch already exhausted the early-stop patience,
            # resuming must not add an extra optimizer epoch.
            if a.patience and last_epoch >= a.min_epochs and last_epoch - best_epoch >= a.patience:
                break
            model.train()
            start_time = time.perf_counter()
            total_sum, ce_sum, tail_sum, count = 0.0, 0.0, 0.0, 0
            for rows in context["b210"].indices(labels, epoch, a.batch, a.seed):
                maps = context["b210"].h5_rows(h["train"]["wvd"], rows)
                x = context["source"].map_to_adn_input(torch.from_numpy(maps).to(context["device"]))
                y = torch.from_numpy(labels[rows]).long().to(context["device"])
                optimizer.zero_grad(set_to_none=True)
                logits, aux = model(x, return_aux=True)
                loss, ce, parts, weighted = l1_tail_loss(logits, y, aux)
                need(torch.isfinite(loss).item(), "Nonfinite training objective")
                loss.backward()
                norm = torch.nn.utils.clip_grad_norm_(parameters, a.clip_norm)
                need(torch.isfinite(norm).item(), "Nonfinite training gradient norm")
                optimizer.step()
                n = len(rows)
                count += n
                total_sum += float(loss.detach()) * n
                ce_sum += float(ce.detach()) * n
                tail_sum += float(weighted["tail"].detach()) * n
            need(count == len(labels), "Balanced epoch sampler did not cover the entire training split")
            metrics = evaluate(model, context["source"], h["val"], context["device"], a.batch)
            need(math.isfinite(metrics["val_ce"]), "Nonfinite validation CE")
            row = dict(epoch=epoch, method=method, seed=a.seed, train_loss=total_sum/count, train_ce=ce_sum/count, train_tail_weighted=tail_sum/count, **metrics, elapsed_s=time.perf_counter()-start_time)
            hist.append(row)
            if metrics["val_ce"] < best:
                best, best_epoch = metrics["val_ce"], epoch
                atomic_save(out / "best_val_ce.pt", snapshot(epoch, metrics))
            state = snapshot(epoch, metrics)
            state.update(optimizer=optimizer.state_dict(), history=hist, best_val_ce=best, best_epoch=best_epoch, torch_rng=torch.get_rng_state(), cuda_rng=torch.cuda.get_rng_state_all() if context["device"].type == "cuda" else [])
            atomic_save(latest, state)
            pd.DataFrame(hist).to_csv(out / "train_val_history.csv", index=False)
            last_epoch = epoch
            print(f"[{method}] {epoch}/{a.epochs} VAL_CE={metrics['val_ce']:.6f} VAL_AUC={metrics['auc']:.6f} best_epoch={best_epoch} time={row['elapsed_s']:.1f}s", flush=True)
        checkpoint = load_checkpoint(out / "best_val_ce.pt")
        model.load_state_dict(checkpoint["state_dict"], strict=True)
        restored = evaluate(model, context["source"], h["val"], context["device"], a.batch)
        need(abs(restored["val_ce"] - best) < 1e-4, "Selected checkpoint validation CE did not restore")
    contract = dict(
        version=VERSION, status=PASS, method=method, seed=a.seed,
        run_fingerprint=run_fingerprint, run_config=config, model_config=model.model_config,
        best_epoch=best_epoch, epochs_executed=last_epoch, best_val_ce=best,
        best_val_auc=restored["auc"], best_checkpoint_sha256=digest_file(out / "best_val_ce.pt"),
        initialization_checkpoint_sha256=initialization_sha,
        source_sha256=context["b210"].SOURCE_SHA, trainer_sha256=context["b210"].TRAINER_SHA,
        bank_sha256=context["bc"]["file_sha256"], wvd_cache_sha256=context["cc"]["wvd_cache_sha256"],
        cfg=model.cfg, params_loss=loss_reference.PARAMS,
        params_model=sum(p.numel() for p in model.parameters()), params_trainable=sum(p.numel() for p in parameters),
        selected_by="min VAL CE; warm-start epoch 0 also eligible", training_splits=["train", "val"],
        h0_test_opened=False, h1_dev_opened=False,
    )
    write_json(contract_path, contract)
    print(f"[{method}] completed: {out / 'best_val_ce.pt'}", flush=True)
    del model, optimizer
    gc.collect()
    if context["device"].type == "cuda":
        torch.cuda.empty_cache()
    return contract


def main(argv=None):
    a = cli(argv)
    torch.set_num_threads(a.cpu_threads)
    torch.backends.cudnn.benchmark = False
    context = prepare_training(a.root, a.bank_dir, a.cache_dir, a.device)
    initialization, sha = (verify_l1_checkpoint(a.l1_checkpoint, context, a.seed) if a.init == "l1" else (None, None))
    print(f"B270 | {a.init} initialization | {a.train_policy} layers | TRAIN/VAL only", flush=True)
    print(f"Bank: {context['bank_dir']}\nCache: {context['cache_dir']}\nOutput: {a.out_dir}", flush=True)
    if a.preflight:
        print("Data and initialization preflight passed; no optimizer steps executed", flush=True)
        return
    run = dict(version=VERSION, seed=a.seed, methods=[METHODS[x] for x in a.methods], init=a.init, root=str(a.root), bank_dir=str(context["bank_dir"]), cache_dir=str(context["cache_dir"]), l1_checkpoint=str(a.l1_checkpoint), training_scope="TRAIN/VAL only")
    a.out_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = a.out_dir / "run_manifest.json"
    if manifest_path.exists():
        need(read_json(manifest_path) == run, "Run manifest differs; select a new --out-dir")
    else:
        need(not any(a.out_dir.iterdir()), "Output directory already contains unrelated files")
        write_json(manifest_path, run)
    for enhancement in a.methods:
        train_one(a, context, enhancement, initialization, sha)
    print(PASS, flush=True)


if __name__ == "__main__":
    main()
