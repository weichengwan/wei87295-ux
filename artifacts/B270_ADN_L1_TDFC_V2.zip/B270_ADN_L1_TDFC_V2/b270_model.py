"""Preserve the original L1-Tail architecture and insert one layer3 module."""
from __future__ import annotations

import torch
from torch import nn

from source_loader import load_frozen_sources
from tdfc_module import TimeFrequencyResidualCalibration


class B270Net(nn.Module):
    def __init__(self, enhancement="adaptive", reduction=8, time_kernel=9,
                 frequency_kernel=9, gamma=0.2, module_revision="lmda_axis_hybrid_v2"):
        super().__init__()
        if enhancement not in ("adaptive", "fixed", "none"):
            raise ValueError("enhancement must be adaptive, fixed, or none")
        if module_revision != "lmda_axis_hybrid_v2":
            raise ValueError("Incompatible residual-module revision")
        source, trainer, reference = load_frozen_sources()
        # Instantiate the whole original model first, in its original RNG order.
        base = trainer.ProposedWrapper(source, dict(reference.CFG))
        self.detector = base.detector
        self.suppressor = base.suppressor
        self.cfg = dict(reference.CFG)
        self.model_config = dict(
            enhancement=enhancement, reduction=reduction,
            time_kernel=time_kernel, frequency_kernel=frequency_kernel,
            gamma=gamma, module_revision=module_revision,
        )
        self.tdfc = None if enhancement == "none" else TimeFrequencyResidualCalibration(
            channels=256, reduction=reduction, time_kernel=time_kernel,
            frequency_kernel=frequency_kernel, gamma=gamma,
            adaptive=enhancement == "adaptive",
        )
        self.training_policy = "all"

    def forward(self, x, return_aux=False):
        if x.ndim != 4 or x.shape[1:] != (3, 224, 224):
            raise ValueError(f"Expected ADN input N,3,224,224; got {tuple(x.shape)}")
        aux = {}
        if self.suppressor is not None:
            x, aux = self.suppressor(x)
        detector = self.detector
        x = detector.maxpool(detector.relu(detector.bn1(detector.conv1(x))))
        x = detector.layer1(x)
        x = detector.layer2(x)
        x = detector.layer3(x)
        if self.tdfc is not None:
            if return_aux:
                x, weights = self.tdfc(x, return_weights=True)
                aux["tdfc_weights"] = weights
            else:
                x = self.tdfc(x)
        x = detector.layer4(x)
        logits = detector.fc(torch.flatten(detector.avgpool(x), 1))
        return (logits, aux) if return_aux else logits

    def load_l1_checkpoint(self, checkpoint):
        """Strictly match all original keys; only the new module is absent."""
        if checkpoint.get("method") != "L1_TAIL":
            raise ValueError("Initialization must be a genuine L1_TAIL checkpoint")
        if checkpoint.get("cfg") != self.cfg:
            raise ValueError("Checkpoint WCSG/TFCG/HTS configuration mismatch")
        source, trainer, reference = load_frozen_sources()
        expected_hashes = (
            ("source_sha256", trainer.EXPECTED_SOURCE_SHA),
            ("trainer_sha256", "7354c3d64ca7e6f4745097f117afbf1f267091a97c79f0d5c99d081c9e2ffcc5"),
        )
        for field, expected in expected_hashes:
            if checkpoint.get(field) != expected:
                raise ValueError(f"Checkpoint frozen lineage mismatch: {field}")
        state = checkpoint.get("state_dict")
        if not isinstance(state, dict):
            raise ValueError("Checkpoint is missing state_dict")
        expected = {k for k in self.state_dict() if not k.startswith("tdfc.")}
        if set(state) != expected:
            missing = sorted(expected - set(state))
            extra = sorted(set(state) - expected)
            raise ValueError(f"L1-Tail keys mismatch: missing={missing}, extra={extra}")
        incompatible = self.load_state_dict(state, strict=False)
        if incompatible.unexpected_keys or any(
            not k.startswith("tdfc.") for k in incompatible.missing_keys
        ):
            raise RuntimeError("Unexpected checkpoint incompatibility")
        return incompatible

    def configure_training(self, policy="high"):
        if policy not in ("high", "all"):
            raise ValueError("Training policy must be high or all")
        self.training_policy = policy
        for name, parameter in self.named_parameters():
            parameter.requires_grad_(
                policy == "all" or name.startswith((
                    "detector.layer3.", "detector.layer4.", "detector.fc.", "tdfc.",
                ))
            )
        self.train(self.training)
        return [p for p in self.parameters() if p.requires_grad]

    def train(self, mode=True):
        super().train(mode)
        if mode and self.training_policy == "high":
            # Frozen weights alone do not freeze BatchNorm running statistics.
            self.suppressor.eval()
            self.detector.conv1.eval()
            self.detector.bn1.eval()
            self.detector.layer1.eval()
            self.detector.layer2.eval()
        return self
