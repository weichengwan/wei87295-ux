"""LMDA-inspired axis and hybrid-pooling residual calibration for L1-Tail.

Source: Yuan et al., Digital Signal Processing 175 (2026), 105999,
doi:10.1016/j.dsp.2026.105999, sections 4.1 (ADSCM) and 4.2 (AHPM).
This is an adaptation, not an LMDA reproduction. Differences: multi-scale
learnable axis filters; stride-one hybrid-pooling contrast; per-sample routing
using axis residuals; zero-initialized bounded residual in the existing backbone.
The frozen WVD map has time on H and frequency on W. No test labels or scores
enter this module. Novelty and detection gains require research validation.
"""
from __future__ import annotations

import math
import torch
from torch import nn
import torch.nn.functional as F


class TimeFrequencyResidualCalibration(nn.Module):
    def __init__(self, channels=256, reduction=8, time_kernel=9,
                 frequency_kernel=9, gamma=0.2, adaptive=True):
        super().__init__()
        if channels < 1 or reduction < 1:
            raise ValueError("channels and reduction must be positive")
        if any(k < 1 or k % 2 != 1 for k in (time_kernel, frequency_kernel)):
            raise ValueError("Pooling kernels must be positive odd integers")
        if not math.isfinite(gamma) or not 0 < gamma < 1:
            raise ValueError("gamma must be finite and strictly between 0 and 1")
        self.channels = int(channels)
        self.time_kernel = int(time_kernel)
        self.frequency_kernel = int(frequency_kernel)
        self.gamma = float(gamma)
        self.adaptive = bool(adaptive)
        hidden = max(8, channels // reduction)
        self.reduce = nn.Sequential(
            nn.Conv2d(channels, hidden, 1, bias=False),
            nn.GroupNorm(math.gcd(8, hidden), hidden),
            nn.SiLU(),
        )
        # ADSCM idea: separate time, frequency and local receptive fields.
        # Two learned scales on each axis replace fixed average smoothing.
        self.time_short = nn.Conv2d(hidden, hidden, (3, 1), padding=(1, 0), groups=hidden, bias=False)
        self.time_long = nn.Conv2d(hidden, hidden, (time_kernel, 1), padding=(time_kernel // 2, 0), groups=hidden, bias=False)
        self.frequency_short = nn.Conv2d(hidden, hidden, (1, 3), padding=(0, 1), groups=hidden, bias=False)
        self.frequency_long = nn.Conv2d(hidden, hidden, (1, frequency_kernel), padding=(0, frequency_kernel // 2), groups=hidden, bias=False)
        self.local = nn.Conv2d(hidden, hidden, 3, padding=1, groups=hidden, bias=False)
        for convolution in (self.time_short, self.time_long, self.frequency_short, self.frequency_long, self.local):
            nn.init.constant_(convolution.weight, 1.0 / (convolution.kernel_size[0] * convolution.kernel_size[1]))
        # AHPM idea, with stride one to retain the established backbone grid.
        # Pooling contributes contrast rather than replacing its downsampling.
        pool_hidden = max(4, hidden // 2)
        self.pool_route = nn.Sequential(
            nn.Linear(2 * hidden, pool_hidden), nn.SiLU(), nn.Linear(pool_hidden, 2),
        ) if self.adaptive else None
        self.route = nn.Sequential(
            nn.Linear(4 * hidden, hidden), nn.SiLU(), nn.Linear(hidden, 4),
        ) if self.adaptive else None
        self.project = nn.Conv2d(hidden, channels, 1, bias=True)
        nn.init.zeros_(self.project.weight)
        nn.init.zeros_(self.project.bias)

    def forward(self, x, return_weights=False):
        if x.ndim != 4 or x.shape[1] != self.channels:
            raise ValueError(f"Expected N,{self.channels},H,W; got {tuple(x.shape)}")
        u = self.reduce(x)
        temporal = 0.5 * (self.time_short(u) + self.time_long(u))
        frequency = 0.5 * (self.frequency_short(u) + self.frequency_long(u))
        local = self.local(u)
        average = F.avg_pool2d(u, 3, stride=1, padding=1, count_include_pad=False)
        maximum = F.max_pool2d(u, 3, stride=1, padding=1)
        pooled_summary = torch.cat((u.mean((2, 3)), u.amax((2, 3))), dim=1)
        pool_weights = u.new_full((u.shape[0], 2), 0.5) if self.pool_route is None else self.pool_route(pooled_summary).softmax(dim=1)
        hybrid = pool_weights[:, 0, None, None, None] * average + pool_weights[:, 1, None, None, None] * maximum
        contrast = hybrid - average
        if self.route is None:
            weights = u.new_full((u.shape[0], 4), 0.25)
        else:
            summary = torch.cat((pooled_summary, (u-temporal).abs().mean((2, 3)), (u-frequency).abs().mean((2, 3))), dim=1)
            weights = self.route(summary).softmax(dim=1)
        correction = (
            weights[:, 0, None, None, None] * (local - u)
            + weights[:, 1, None, None, None] * (temporal - u)
            + weights[:, 2, None, None, None] * (frequency - u)
            + weights[:, 3, None, None, None] * contrast
        )
        scale = 1.0 + self.gamma * torch.tanh(self.project(correction))
        result = x * scale
        return (result, weights) if return_weights else result
