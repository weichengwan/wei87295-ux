"""Use the exact uploaded B215 L1-Tail objective, including original top-k."""
from source_loader import load_frozen_sources


def l1_tail_loss(logits, labels, aux):
    _, _, reference = load_frozen_sources()
    return reference.compute_loss("L1_TAIL", logits, labels, aux)
