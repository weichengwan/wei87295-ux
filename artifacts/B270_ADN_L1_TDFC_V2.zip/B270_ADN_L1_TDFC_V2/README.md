# B270 V2：基于 ADN 的 L1-Tail + TDFC，完整训练与 Pd–SCR 评分

本包包含实际训练循环、断点恢复、冻结场景评分和曲线报告。默认从现有
L1-Tail checkpoint 开始，保留 WCSG、8 个 TFCG、ADN18 和原版 L1-Tail
损失，在 layer3 后新增一个 23,094 参数的 LMDA-TDFC 特征残差校准模块。
本版根据上传的 LMDA 原文改造 ADSCM 与 AHPM，目标是优于固定
Rank mix LMDA75/L125 曲线 1 dB，目标达成情况由真实评分报告给出。

本地完成的是 CPU 功能验证。真实 AutoDL checkpoint、GPU 训练及 Pd–SCR
提升尚未在此执行；效果需要你在原服务器运行后确认。本方案是候选改进，
新颖性也需要后续核查，不能把内部测试当作研究结果。

## 直接运行

把 ZIP 上传到 `/root/autodl-tmp/MTDSP_NATIVE_LMDA_V1`，在原训练环境执行：

```bash
conda activate mpdnet-r10
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
unzip -n B270_ADN_L1_TDFC_V2.zip
cd B270_ADN_L1_TDFC_V2
bash run_b270_train.sh --epochs 15 --batch 32 --lr 3e-5
bash run_b270_score.sh --batch 32 --chunk 512
```

训练和评分是两个独立命令。第一条训练命令默认训练 **B270_TDFC 和同预算
L1_CONTROL 两个模型**，各 15 epoch；第二条比较它们和原始 L1-Tail。
默认输出到新目录 `output_b270_adn_l1_tdfc_v2`。这些源码不会覆盖原有模型、数据或旧结果。输出目录有冲突时会拒绝覆盖。
如果同名解压目录已有你修改过的旧文件，应在新目录解压并显式传 `--root`。

项目根目录默认是本包目录的父目录。脚本会在 AutoDL 上定位：

- 原 `SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1` bank 及其合同、审计文件；
- 与此 bank 同指纹的原 WVD cache；
- `output_sim_r10_b215_tpht_train_v1/trainseed_20261022/L1_TAIL/best_val_ce.pt`
  及 `training_contract.json`；
- 已完成的原 B2.13 `protocol_frozen.json` 和 `progress.json`。

不用上传数据、权重，也不用手动复制旧 Python 文件：需要的 9 个冻结来源文件
已随包附带。如果多个不同数据合同同时存在，脚本会要求显式指定目录，避免猜错。

## 改动与默认训练配置

LMDA-TDFC 在高层特征的降维空间内融合局部卷积、时间轴卷积、频率轴卷积
与自适应混合池化的峰值对比。时间、频率轴各使用短/长两个可学习尺度，
默认 kernel=3/9。混合池化使用 stride=1 保留特征网格。
融合系数由每个样本的特征生成，不依赖标签或同 batch 的其他样本。
路由输入包含均值、峰值与时间/频率轴残差幅度；固定权重控制同时关闭
分支路由与池化路由，分别使用 1/4 与 1/2。
时间轴为冻结 WVD 张量的 H，频率轴为 W。

输出形式为 `F * (1 + gamma * tanh(correction))`。最后一个投影层零初始化，
因此加载 L1-Tail 后初始输出与基线完全一致，残差幅度受限。
它由 LMDA 的 ADSCM/AHPM 思路改造而来，未使用原文的整个 Ghost L-Res
网络，也没有加入第二个完整检测模型。B259 是 WVD 输入侧的 ADSCM-lite
辅助评分头；本版模块插入主干内部，并联合训练高层。
具体继承来源、修改和待验证假设见 `MODEL_DESIGN.md`、`provenance.json`。

默认参数：

- 初始化：原 L1-Tail seed 20261022。
- TRAIN/VAL：原 30,000 / 5,000，不读 H0 CAL、AUDIT 或 DEV-H1 来训练。
- 保留原均衡、无重复 epoch sampler，原 Adam betas=(0.9,0.99)。
- 原损失：CE + 0.05×Tail；hard H0/weak H1 各取 batch 内该类别的 25%，
  margin=1、temperature=2，原样调用 B215 实现。
- 默认冻结 WCSG、stem、layer1、layer2（包括它们的 BatchNorm 状态），
  训练 layer3、layer4、分类器和新增模块。
- 主干 LR=3e-5，新增模块 LR=3e-4；clip norm=5；batch=32。
- 默认固定 15 epoch，不提前停止，保证控制模型预算相同。
- 按最小 VAL CE 保存，warm-start 的 epoch 0 也可入选。若最终选中 epoch 0，
  应如实报告没有获得更好的 VAL CE，不能声称训练已提高检测性能。

如只想先训练新模型，可以指定 `--methods adaptive`；但没有同预算控制时，
无法区分新增模块的贡献与额外训练的贡献。不同实验应指定不同输出目录。

```bash
# 只先训练新模型
bash run_b270_train.sh --methods adaptive --out-dir ../output_b270_adaptive_only
bash run_b270_score.sh --run-dir ../output_b270_adaptive_only

# 完整三个消融：自适应、继续训练控制、固定权重
bash run_b270_train.sh --methods adaptive,none,fixed --out-dir ../output_b270_ablation
bash run_b270_score.sh --run-dir ../output_b270_ablation

# 从头训练全部层；不加载旧 checkpoint，但评分仍使用原 L1-Tail 作参考
bash run_b270_train.sh --init scratch --epochs 50 --min-epochs 6 --lr 1e-4 \
  --module-lr 1e-4 --train-policy all --out-dir ../output_b270_scratch
bash run_b270_score.sh --run-dir ../output_b270_scratch

# 继续被中断的默认训练（配置必须和先前相同）
bash run_b270_train.sh --epochs 15 --batch 32 --lr 3e-5 --resume
```

断点在 epoch 边界；未完成的 epoch 会从上一个保存边界重新运行。
`--patience` 默认 0；设为正数可启用 VAL CE early stopping，但实际训练预算
可能不再完全相同。原 bank 和 cache 的 SHA 验证保持开启。

## 原评估协议

- 复用原 B2.13/B2.16：H0 CAL 3,000,000、H0 AUDIT 1,000,000。
- 每个 SCR 1,024 个相同 H1 模板；SCR=-24 到 +12 dB，共 37 点。
- 原 IQ512 生成器、seed、场景索引、目标注入、WVD 映射全部保留。
- 场景指纹：`9aab64a16dfa300a0e4398ef5d67f3132fef87c722d458ad58090615af2c95c5`
  （脚本会以实际 bank 与原协议重新核对）。
- 分数为两个 float32 logit 分别转换 float64 后做 `target - clutter`。
- 只从 H0 CAL 拟合 `Pfa=1e-4 / 1e-5` 的门限；判决为严格 `score > threshold`。
- H0 AUDIT 只报告实际虚警率及 Wilson 区间，不用于门限拟合、选 checkpoint 或训练。
- 保留原 37 点，不平滑曲线、不用 AUDIT 人为调阈值制造左移。

若找到同场景、同 checkpoint 的已完成 B216 基线 scorebank，脚本会在验证
文件 SHA 和确定性分数回放后复用原 L1-Tail 分数，减少重复计算。否则重新评分。
完整 1e-5 评分仍涉及大量样本；不承诺 GPU 时长。评分可直接再次执行同一命令续跑。
若改了 batch、模型、代码或场景，需要新的评分输出目录。

可手动指定原协议或分数缓存：

```bash
bash run_b270_score.sh --b213-dir /你的原B213输出目录 \
  --reference-score-dir /你的已完成B216输出目录
```

只重新出图和报告：

```bash
bash run_b270_score.sh --stage report
```

## 结果与判读

默认输出：

```text
../output_b270_adn_l1_tdfc_v2/
  run_manifest.json
  trainseed_20261022/
    B270_TDFC/best_val_ce.pt
    B270_TDFC/last_epoch.pt
    B270_TDFC/train_val_history.csv
    B270_TDFC/training_contract.json
    L1_CONTROL/...
  pd_scr/
    protocol_frozen.json
    progress.json
    b270_curves.csv
    b270_metrics.csv
    b270_shift_metrics.csv
    b270_vs_rankmix_1db.csv
    b270_paired_deltas.csv
    b270_report.json
    figures/b270_pd_scr_pfa_1e-4.png
    figures/b270_pd_scr_pfa_1e-4.pdf
    figures/b270_pd_scr_pfa_1e-5.png
    figures/b270_pd_scr_pfa_1e-5.pdf
```

`delta_D50_db`、`delta_D80_db`、`delta_D90_db` 为新方法减原 L1-Tail，负数
表示对应 Pd 水平所需 SCR 下降；达不到对应 Pd 时留空，不外推。
用原始曲线的第一次交叉点线性插值，单个指标下降不等于整条曲线都更好。
同时看 `actual_pfa` 和区间；按相同 nominal Pfa 标定不等于实际 Pfa 恰好相同。

旧 B229 CSV 随包保存。只有原 L1 的全部 74 个 hit count 重放一致时，才把
旧 rank mix 曲线作为历史虚线叠加；其 H1 配对来源仍标注 UNVERIFIED，不能
把聚合命中数一致升级为逐样本配对证明。

你的主要参考是 **Rank mix LMDA75/L125**，不是单独的 L1-Tail。
在 nominal Pfa=1e-5 下，上传融合曲线的原始交叉点和左移 1 dB 目标为：

| 指标 | 旧融合 SCR/dB | 新方法目标 SCR/dB |
| --- | ---: | ---: |
| D50 | -4.761905 | ≤ -5.761905 |
| D80 | 0.547059 | ≤ -0.452941 |
| D90 | 2.556757 | ≤ 1.556757 |

`b270_vs_rankmix_1db.csv` 给出各方法相对融合的 D50/D80/D90 变化、
每个 1 dB 目标是否达到，以及 SCR=-24..11 上 36 个原始点对
`Pd_fusion(SCR+1)` 的逐点比较。D90 达标不等于整条曲线都达标。
图中灰色点线是把旧融合平移 -1 dB 的目标线，标注为 target，不是实验结果。

主要目标预设为 Pfa=1e-5、D90≤1.556757 dB，同时查看 AUDIT 实际虚警率。
表中的 `D90_target_with_audit_guard` 还要求新方法实际虚警率不高于旧融合
（旧结果为 1e-5）。该字段只是 DEV 筛查；小计数下实际 Pfa 存在统计不确定性。
若基线聚合重放失败，目标达成字段留空，不能据此认定胜过旧融合。

本版复用已探索的 DEV 场景，不是独立 FINAL 测试。第一轮单个训练 seed 的
结果也不能代表跨 seed 的稳定提升。

运行结束后，给我 `b270_metrics.csv`、`b270_curves.csv`、`b270_vs_rankmix_1db.csv`、`b270_report.json`
以及训练日志/合同即可；不用上传大型 score 数组或 checkpoint。

## AutoDL 数据盘清理

本包额外提供 `tools/clean_old_training_caches.py`。它针对你列出的 B257、
B242、B268、B269 的 8 个旧 `.npy` 派生缓存，合计约 7.10 GiB；
仅在路径、文件尺寸及 NumPy 文件头符合记录时处理。
发现相关 Python 训练进程或文件仍打开时会拒绝删除。
原始数据、共享 WVD HDF5、所有权重、评分数组、CSV 与图片均保留。
如果以后继续训练这些旧实验，需要先重建相应缓存。

```bash
# 预览
python tools/clean_old_training_caches.py
# 清理这 8 个指定缓存
python tools/clean_old_training_caches.py --apply
df -h /root/autodl-tmp
```

## 功能验证与依赖

Python、PyTorch、NumPy、h5py、pandas、matplotlib 使用原 AutoDL 环境。
不要为了运行本包替换已经能训练的 CUDA PyTorch。

本地 13 项测试通过，包括原完整 L1 架构初始输出一致、轴向卷积方向、
新增卷积/池化路由的梯度、冻结层状态、保存恢复、
真实训练循环在临时人工数据上的执行及精确续跑、原生成器评分、原 B216
分数计算一致、缓存复用回放、协议/数据漂移拒绝和曲线报告。
报告数学测试使用人工构造的已知水平位移；其中的测试位移不是模型实验结果。
详细范围在 `VALIDATION.json`。测试不作为正式训练的必经步骤。

```bash
python -m unittest discover -s tests -v
```

`frozen_source/` 保存用户提供的原始源码和 SHA 清单，原文件未修改。
原始 ADN 文献与源码来源保留在原文件头中；发表时应如实说明骨干、继承模块
和新增机制的来源。

LMDA 来源：Shanliang Yuan, Hongyuan Gao, Zhiwei Zhang, Yapeng Liu,
“Small target detection in sea clutter based on lightweight multi-dimensional
adaptive network”, Digital Signal Processing 175 (2026), 105999.
DOI: https://doi.org/10.1016/j.dsp.2026.105999 。原文第 4.1/4.2 节对应
ADSCM/AHPM；这里改造后的组合是待验证的研究候选，不能把继承模块声称为原创。
