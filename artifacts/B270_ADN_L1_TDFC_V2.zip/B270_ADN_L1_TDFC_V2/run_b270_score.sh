#!/usr/bin/env bash
set -euo pipefail
b270_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
exec python -u "$b270_dir/r10_sim_stage_b270_tdfc_score.py" "$@"
