#!/usr/bin/env python3
"""Score B270 and its controls on the exact B2.13/B2.16 DEV scene bank."""
from __future__ import annotations

import argparse
import math
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

from b270_data import device_for, digest_file, find_files, fingerprint, load_checkpoint, need, read_json, resolve_data, verify_l1_checkpoint, write_json
from b270_model import B270Net
from source_loader import load_frozen_file, load_frozen_sources
from r10_sim_stage_b270_tdfc_train import PASS as TRAIN_PASS

VERSION = "B270_LMDA_TDFC_SIMR10_PDSCR_DEV_V2"
SCENE_KEYS = ("master_seed", "generator_sha", "h0_cal_n", "h0_audit_n", "h1_scenes_n", "scr_grid_db", "h0_cal_split", "h0_audit_split", "h1_split", "family_names", "scr_definition")


def cli(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, default=Path(__file__).resolve().parent.parent)
    p.add_argument("--run-dir", type=Path)
    p.add_argument("--out-dir", type=Path)
    p.add_argument("--b213-dir", type=Path)
    p.add_argument("--reference-score-dir", type=Path, help="Optional completed B216 scorebank for verified reuse of the original L1-Tail scores")
    p.add_argument("--no-reuse-baseline", action="store_true")
    p.add_argument("--stage", choices=("all", "score", "report"), default="all")
    p.add_argument("--batch", type=int, default=32)
    p.add_argument("--chunk", type=int, default=512)
    p.add_argument("--device", choices=("cuda", "cpu", "auto"), default="cuda")
    p.add_argument("--cpu-threads", type=int, default=4)
    a = p.parse_args(argv)
    need(a.chunk >= a.batch >= 1 and a.chunk % a.batch == 0, "chunk must be divisible by a positive batch")
    need(a.cpu_threads >= 1, "Invalid CPU thread count")
    a.root = a.root.resolve()
    a.run_dir = (a.run_dir or a.root / "output_b270_adn_l1_tdfc_v2").resolve()
    a.out_dir = (a.out_dir or a.run_dir / "pd_scr").resolve()
    return a


def original_protocol(root, explicit, context):
    candidates = [Path(explicit) / "protocol_frozen.json"] if explicit else find_files(root, "protocol_frozen.json")
    valid = []
    for path in candidates:
        p = read_json(path)
        if p.get("version") == "SIM_R10_B213_SCOREBANK_V1" and p.get("training_bank_sha") == context["bc"]["file_sha256"]:
            valid.append(path)
    need(valid, "Cannot find the original B213 protocol; pass --b213-dir to its existing AutoDL output directory")
    scene_ids = {read_json(p).get("scene_fingerprint") for p in valid}
    need(len(scene_ids) == 1, "Several original B213 scene banks found; provide --b213-dir")
    path = valid[0]
    p = read_json(path)
    need(fingerprint({k: p[k] for k in SCENE_KEYS}) == p.get("scene_fingerprint"), "B213 scene fingerprint mismatch")
    need(fingerprint({k: v for k, v in p.items() if k != "fingerprint"}) == p.get("fingerprint"), "B213 protocol fingerprint mismatch")
    need((p["h0_cal_n"], p["h0_audit_n"], p["h1_scenes_n"]) == (3000000, 1000000, 1024) and p["scr_grid_db"] == list(range(-24, 13)), "Scoring requires the original full 3M/1M/1024, 37-point protocol")
    need((p["h0_cal_split"], p["h0_audit_split"], p["h1_split"]) == ("h0_cal", "h0_audit", "dev_h1"), "Scene split names changed")
    generator = load_frozen_file("r10_sim_iq512_builder_v1_EARLIEST_HDF5.py")
    need(digest_file(generator.__file__) == p["generator_sha"] == context["bc"]["generator_sha256"], "Original generator checksum mismatch")
    need(p["master_seed"] == context["bc"]["seed"] and tuple(p["family_names"]) == generator.TRAIN_FAMILIES, "Original scene seed/families mismatch")
    progress = read_json(path.with_name("progress.json"))
    need(progress["fingerprint"] == p["fingerprint"] and progress["completed"] == {"h0_cal": p["h0_cal_n"], "h0_audit": p["h0_audit_n"], "h1": len(p["scr_grid_db"])}, "Original B213 scorebank is incomplete")
    return path, p, generator


def cached_baseline(root, explicit, original, checkpoint_sha, seed):
    paths = [Path(explicit) / "protocol_frozen.json"] if explicit else find_files(root, "protocol_frozen.json")
    for path in paths:
        p = read_json(path)
        if p.get("version") != "SIM_R10_B216_PDSCR_V1" or p.get("scene_fingerprint") != original["scene_fingerprint"]:
            continue
        if fingerprint({k: v for k, v in p.items() if k != "fingerprint"}) != p.get("fingerprint"):
            continue
        labels = [(z["seed"], z["method"]) for z in p.get("labels", [])]
        if (seed, "L1_TAIL") not in labels:
            continue
        i = labels.index((seed, "L1_TAIL"))
        cp = next((z for z in p["checkpoints"] if z["seed"] == seed and z["method"] == "L1_TAIL"), {})
        if cp.get("sha256") != checkpoint_sha:
            continue
        pr = read_json(path.with_name("progress.json"))
        if pr.get("fingerprint") != p["fingerprint"] or pr.get("completed") != {"h0_cal": original["h0_cal_n"], "h0_audit": original["h0_audit_n"], "h1": len(original["scr_grid_db"])}:
            continue
        shape_map = {"h0_cal_scores.npy": (original["h0_cal_n"], len(labels)), "h0_audit_scores.npy": (original["h0_audit_n"], len(labels)), "dev_h1_scores.npy": (len(original["scr_grid_db"]), original["h1_scenes_n"], len(labels))}
        if not all((path.parent / n).is_file() for n in shape_map):
            continue
        arrays = {n: np.load(path.parent / n, mmap_mode="r") for n in shape_map}
        if not all(v.shape == shape_map[n] and v.dtype == np.dtype("float64") for n, v in arrays.items()):
            continue
        need(all(np.isfinite(v[..., i]).all() for v in arrays.values()), "Cached baseline scores contain NaN/Inf")
        hashes = {n: digest_file(path.parent / n) for n in shape_map}
        return dict(path=str(path.parent), column=i, protocol_sha256=digest_file(path), score_file_sha256=hashes), arrays
    need(explicit is None, "Requested baseline score cache is missing, incomplete, or mismatched")
    return None, None


def model_scores(models, source, iq, device, batch):
    need(iq.ndim == 2 and iq.shape[1] == 512 and iq.dtype == np.complex64, "Scoring expects complex64 IQ512")
    scores = np.empty((len(iq), len(models)), np.float64)
    with torch.inference_mode():
        for start in range(0, len(iq), batch):
            stop = min(start + batch, len(iq))
            x = torch.from_numpy(np.ascontiguousarray(iq[start:stop])).to(device)
            image = source.map_to_adn_input(source.wvd_base_map(x))
            for j, model in enumerate(models):
                logits = model(image)
                need(logits.shape == (stop-start, 2), "Unexpected model output shape")
                scores[start:stop, j] = (logits[:, 1].double() - logits[:, 0].double()).cpu().numpy()
    need(np.isfinite(scores).all(), "Nonfinite detector scores")
    return scores


def verify_cached_replay(reference, arrays, original, generator, baseline, source, device, batch):
    column = reference["column"]
    for split in ("h0_cal", "h0_audit"):
        indices = sorted(set([0, min(123, original[split + "_n"] - 1), original[split + "_n"] // 2, original[split + "_n"] - 1]))
        iq = np.stack([generator.make_one(original["master_seed"], split, i, -30, 10)["base"] for i in indices]).astype(np.complex64)
        actual = model_scores([baseline], source, iq, device, batch)[:, 0]
        need(np.max(np.abs(actual - arrays[split + "_scores.npy"][indices, column])) <= 1e-5, f"Cached baseline score replay failed: {split}")
    for scr in (-24, 0, 12):
        indices = sorted(set([0, min(123, original["h1_scenes_n"] - 1), original["h1_scenes_n"] - 1]))
        samples = [generator.make_one(original["master_seed"], "dev_h1", i, -30, 10) for i in indices]
        iq = np.stack([(d["base"].astype(np.complex128) + d["unit"].astype(np.complex128) * np.sqrt(d["cp"] * 10**(scr/10))).astype(np.complex64) for d in samples])
        actual = model_scores([baseline], source, iq, device, batch)[:, 0]
        expected = arrays["dev_h1_scores.npy"][original["scr_grid_db"].index(scr), indices, column]
        need(np.max(np.abs(actual - expected)) <= 1e-5, f"Cached baseline H1 score replay failed at SCR {scr}")
    print("Original L1-Tail cached scores verified by checksum and deterministic score replay", flush=True)


def stream_scores(a, protocol, generator, models, source, device, cached=None):
    legacy = load_frozen_file("r10_sim_stage_b216_pdscr_score_v1.py")
    progress = legacy.init(a, protocol)
    n_models = len(protocol["labels"])
    reference_column = protocol["baseline_score_reuse"]["column"] if cached is not None else None
    for split in ("h0_cal", "h0_audit"):
        total = protocol[split + "_n"]
        path = a.out_dir / (split + "_scores.npy")
        scores = legacy.new_array(path, (total, n_models), path.exists())
        start = int(progress["completed"][split])
        need(0 <= start <= total, "Invalid score progress")
        for first in range(start, total, a.chunk):
            last = min(total, first + a.chunk)
            data = [generator.make_one(protocol["master_seed"], split, i, -30, 10) for i in range(first, last)]
            need(all(d["label"] == 0 and np.all(d["target"] == 0) for d in data), "H0 sample contains a target")
            iq = np.stack([d["base"] for d in data]).astype(np.complex64)
            prediction = model_scores(models, source, iq, device, a.batch)
            scores[first:last, :len(models)] = prediction
            if cached is not None:
                scores[first:last, -1] = cached[split + "_scores.npy"][first:last, reference_column]
            scores.flush()
            progress["completed"][split] = last
            write_json(a.out_dir / "progress.json", progress)
            if last == total or last % 10000 < a.chunk:
                print(f"[{split}] {last:,}/{total:,}", flush=True)
        del scores
    levels = protocol["scr_grid_db"]
    ns = protocol["h1_scenes_n"]
    path = a.out_dir / "dev_h1_scores.npy"
    scores = legacy.new_array(path, (len(levels), ns, n_models), path.exists())
    base, unit = np.empty((ns, 512), np.complex64), np.empty((ns, 512), np.complex64)
    cp = np.empty(ns, np.float64)
    for i in range(ns):
        d = generator.make_one(protocol["master_seed"], "dev_h1", i, -30, 10)
        need(d["label"] == 1, "H1 generation label drift")
        base[i], unit[i], cp[i] = d["base"], d["unit"], d["cp"]
    need(np.isfinite(cp).all() and (cp > 0).all(), "Invalid H1 clutter power")
    start = int(progress["completed"]["h1"])
    need(0 <= start <= len(levels), "Invalid H1 score progress")
    for j in range(start, len(levels)):
        scr = levels[j]
        for first in range(0, ns, a.chunk):
            last = min(ns, first + a.chunk)
            amplitude = np.sqrt(cp[first:last] * 10**(scr/10))
            iq = (base[first:last].astype(np.complex128) + unit[first:last].astype(np.complex128) * amplitude[:, None]).astype(np.complex64)
            scores[j, first:last, :len(models)] = model_scores(models, source, iq, device, a.batch)
            if cached is not None:
                scores[j, first:last, -1] = cached["dev_h1_scores.npy"][j, first:last, reference_column]
        scores.flush()
        progress["completed"]["h1"] = j + 1
        write_json(a.out_dir / "progress.json", progress)
        print(f"[dev_h1] SCR={scr:+d} dB {j+1}/{len(levels)}", flush=True)
    del scores


def main(argv=None):
    a = cli(argv)
    torch.set_num_threads(a.cpu_threads)
    if a.stage == "report":
        from b270_report import generate
        generate(a.out_dir)
        return
    run = read_json(a.run_dir / "run_manifest.json")
    context = resolve_data(a.root, run["bank_dir"], run["cache_dir"])
    original_path, original, generator = original_protocol(a.root, a.b213_dir, context)
    source = load_frozen_sources()[0]
    device = device_for(a.device)
    baseline_ck, baseline_sha = verify_l1_checkpoint(run["l1_checkpoint"], context, run["seed"])
    baseline = B270Net(enhancement="none")
    baseline.load_l1_checkpoint(baseline_ck)
    baseline.to(device).eval()
    reference, arrays = (None, None) if a.no_reuse_baseline else cached_baseline(a.root, a.reference_score_dir, original, baseline_sha, run["seed"])
    if reference is not None:
        verify_cached_replay(reference, arrays, original, generator, baseline, source, device, a.batch)
    models, labels, checkpoints = [], [], []
    for method in run["methods"]:
        directory = a.run_dir / f"trainseed_{run['seed']}" / method
        contract = read_json(directory / "training_contract.json")
        path = directory / "best_val_ce.pt"
        need(contract.get("status") == TRAIN_PASS and contract.get("method") == method and contract.get("seed") == run["seed"], f"Training incomplete/mismatched: {method}")
        need(digest_file(path) == contract["best_checkpoint_sha256"], f"Checkpoint SHA mismatch: {method}")
        ck = load_checkpoint(path)
        need(ck.get("run_fingerprint") == contract["run_fingerprint"] and ck.get("method") == method and ck.get("seed") == run["seed"], "Checkpoint internal identity mismatch")
        for key, expected in (("bank_sha256", context["bc"]["file_sha256"]), ("wvd_cache_sha256", context["cc"]["wvd_cache_sha256"]), ("source_sha256", context["b210"].SOURCE_SHA), ("trainer_sha256", context["b210"].TRAINER_SHA)):
            need(ck.get(key) == contract.get(key) == expected, f"Checkpoint lineage mismatch: {method} {key}")
        need(ck.get("cfg") == load_frozen_sources()[2].CFG and ck.get("loss_params") == load_frozen_sources()[2].PARAMS, "Checkpoint architecture/loss drift")
        model = B270Net(**ck["model_config"])
        model.load_state_dict(ck["state_dict"], strict=True)
        model.to(device).eval()
        models.append(model)
        labels.append(dict(seed=run["seed"], method=method))
        checkpoints.append(dict(method=method, seed=run["seed"], path=str(path), sha256=contract["best_checkpoint_sha256"], epoch=ck["epoch"]))
    labels.append(dict(seed=run["seed"], method="L1_TAIL"))
    checkpoints.append(dict(method="L1_TAIL", seed=run["seed"], path=run["l1_checkpoint"], sha256=baseline_sha, epoch=baseline_ck["epoch"]))
    if reference is None:
        models.append(baseline)
    else:
        del baseline
    for model in models:
        for parameter in model.parameters():
            parameter.requires_grad_(False)
    proto = dict(
        version=VERSION, **{k: original[k] for k in SCENE_KEYS},
        scene_fingerprint=original["scene_fingerprint"], bank_sha256=context["bc"]["file_sha256"],
        wvd_cache_sha256=context["cc"]["wvd_cache_sha256"],
        b213_protocol_sha256=digest_file(original_path), labels=labels, checkpoints=checkpoints,
        baseline_score_reuse=reference, source_sha256=context["b210"].SOURCE_SHA,
        trainer_sha256=context["b210"].TRAINER_SHA, scoring_batch=a.batch, device_type=device.type,
        score_definition="float64(target float32 logit) - float64(clutter float32 logit)",
        strict_decision="score > threshold", exploratory=True, independent_final=False,
        inference_code_sha256={p.name: digest_file(p) for p in sorted(Path(__file__).resolve().parent.glob("*.py"))},
    )
    proto["fingerprint"] = fingerprint(proto)
    print(f"B270 DEV-only frozen scoring | models: {[x['method'] for x in labels]}", flush=True)
    print(f"Scene fingerprint: {proto['scene_fingerprint']}\nOriginal protocol: {original_path}\nOutput: {a.out_dir}", flush=True)
    stream_scores(a, proto, generator, models, source, device, arrays)
    if a.stage == "all":
        from b270_report import generate
        generate(a.out_dir)
    print("PASS_B270_FROZEN_PDSCR_DEV_ONLY", flush=True)


if __name__ == "__main__":
    main()
