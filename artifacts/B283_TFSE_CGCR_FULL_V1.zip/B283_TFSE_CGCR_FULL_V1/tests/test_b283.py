"""Generated-IQ and synthetic checkpoint/array fixtures; no radar gain claim."""
import copy,gc,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np,torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from b283_common import ROOT,REFERENCE,LABELS,NAMES,read_json,write_json,fingerprint,digest_file,validate_reference,own_code_hashes
from b282_model import A1Core,Candidate,initial_check,ARMS
from b282_train import PASS,code_hashes as reference_hashes
from b282_source import SCENE_KEYS,metadata as a1_metadata
from b282_score import predictions as original_predictions
from b273_shared import setup
from b280_frontend import smoothing_bank
from source_loader import load_frozen_sources,load_frozen_file
from b283_source import PlainADN,ScoreCache,load_sources,collect_caches
from b283_score import make_iq,fill_predictions,compute_chunk,verify_cache_values,stream
import b283_source as source
import b283_run as runner
import b283_report as reporter
import b283_plots as plots
import paper_plots as previous_plots


def fixture(root):
    """Persist real full-network weights with synthetic training metadata.

    No optimizer/training is executed. Only file/count discovery is simulated.
    The scoring IQ is produced by the actual frozen deterministic generator.
    """
    g=load_frozen_file('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
    context=dict(bc=dict(file_sha256='synthetic-fixture-bank',generator_sha256=digest_file(g.__file__),seed=20261009))
    old=root/'b280';new=root/'b282';old.mkdir();new.mkdir()
    torch.manual_seed(12);ref=A1Core(2.).eval();a0=PlainADN().eval();contracts={}
    code=read_json(REFERENCE/'b280_release_sources.json')
    def save(folder,cfg,model,initial=None):
        folder.mkdir(parents=True);fp=fingerprint(cfg)
        torch.save(dict(state_dict=copy.deepcopy(model.state_dict()),run_config=cfg,run_fingerprint=fp,epoch=1),folder/'best.pt')
        c=dict(status=PASS if folder.parent==new else 'PASS_B280_FULL_TRAIN_VAL_ONLY',run_config=cfg,run_fingerprint=fp,best_epoch=1,
            checkpoint_sha256=digest_file(folder/'best.pt'))
        if initial is not None:c.update(initialization=initial,new_refinement_selected=cfg['arm']!='control')
        write_json(folder/'training_contract.json',c);return c
    shared=dict(scale=2.,bank_sha256=context['bc']['file_sha256'],selected_rows=dict(train=dict(count=30000),val=dict(count=5000)),
        epochs=12,seed=20261022,batch=32,code_sha256=code,factor_B_TFCG_Tail=False)
    contracts['A1_frozen']=save(old/'A1',dict(shared,arm='A1',factor_A_joint_SPWVD=True),ref)
    contracts['ADN']=save(old/'A0',dict(shared,arm='A0',factor_A_joint_SPWVD=False),a0)
    p=dict(version='B280_FULL_FACTORIAL_SCORE_V1',labels=['A0','A1','A2','A3'],checkpoints=[contracts['ADN'],contracts['A1_frozen'],{},{}],
        master_seed=20261009,generator_sha=context['bc']['generator_sha256'],h0_cal_n=3000000,h0_audit_n=1000000,h1_scenes_n=1024,
        scr_grid_db=list(range(-24,13)),h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',family_names=list(g.TRAIN_FAMILIES),
        scr_definition='synthetic fixture',device='cpu',batch=32,torch_version=str(torch.__version__),amp=False,tf32=False)
    p['scene_fingerprint']=fingerprint({k:p[k] for k in SCENE_KEYS});p['fingerprint']=fingerprint(p)
    folder=old/'pd_scr_full';folder.mkdir();write_json(folder/'protocol_frozen.json',p)
    write_json(folder/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=3000000,h0_audit=1000000,h1=37)))
    a=SimpleNamespace(root=root,b280_run=old,b282_run=new,out_dir=root/'out',device=torch.device('cpu'),batch=32,chunk=32,recompute_scores=False)
    base_info=a1_metadata(SimpleNamespace(source_run=old,device=a.device,batch=32),context)
    bank=smoothing_bank(torch.randn(2,512,dtype=torch.complex64),2.)
    models={'ADN':a0,'A1_frozen':ref}
    for arm in ARMS:
        torch.manual_seed(42);m=Candidate(ref,arm).eval();initial=initial_check(m,ref,bank)
        # Nonzero, separately saved refinements catch loading of a wrong arm.
        if arm!='control':
            with torch.no_grad():m.refiner.project.weight.normal_(0,.001)
        cfg=dict(arm=arm,seed=20261022,epochs=6,batch=32,selected_rows=dict(train=dict(count=16000),val=dict(count=5000)),
            bank_sha256=context['bc']['file_sha256'],scale=2.,source_identity=base_info['identity'],backbone_lr=1e-5,new_module_lr=3e-4,
            loss='CE only',code_sha256=reference_hashes(),device='cpu',torch_version=str(torch.__version__))
        contracts[arm]=save(new/arm,cfg,m,initial);models[arm]=m
    info=dict(models=models,contracts=contracts,p=p,generator=g)
    return a,context,info


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):setup(2)
    def tearDown(self):gc.collect()

    def test_unchanged_reference_hashes_and_no_training_cli(self):
        validate_reference();self.assertEqual(reference_hashes(),read_json(ROOT/'b282_release_sources.json'))
        with tempfile.TemporaryDirectory() as d:
            a=runner.cli(['--root',d,'--device','cpu']);self.assertEqual((a.batch,a.chunk,a.stage),(32,512,'all'))
            with self.assertRaises(SystemExit):runner.cli(['--root',d,'--device','cpu','--stage','train'])

    def test_checkpoint_loading_exact_and_reject_modified_source(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,old=fixture(Path(d));before={str(p):digest_file(p) for p in Path(d).rglob('*.pt')}
            with patch('torch.optim.Adam',side_effect=AssertionError('No optimizer allowed')):info=load_sources(a,c)
            self.assertEqual(set(info['models']),set(LABELS));self.assertEqual(before,{str(p):digest_file(p) for p in Path(d).rglob('*.pt')})
            for label in LABELS:
                self.assertTrue(all(not p.requires_grad for p in info['models'][label].parameters()))
                for key,v in old['models'][label].state_dict().items():torch.testing.assert_close(v,info['models'][label].state_dict()[key],atol=0,rtol=0)
            path=a.b282_run/'guided/training_contract.json';ct=read_json(path);ct['checkpoint_sha256']='wrong';write_json(path,ct)
            with self.assertRaisesRegex(RuntimeError,'checksum'):load_sources(a,c)

    def test_exact_original_iq_and_all_five_independent_predictions(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,info=fixture(Path(d));p=info['p'];g=info['generator'];ix=np.array([0,1])
            for split in ('h0_cal','h1'):
                j=24 if split=='h1' else None;iq=make_iq(g,p,split,ix,j)
                scenes=[g.make_one(p['master_seed'],p['h1_split'] if split=='h1' else p[split+'_split'],int(i),-30,10) for i in ix]
                if split=='h1':
                    base=np.stack([s['base'] for s in scenes]).astype('complex64');unit=np.stack([s['unit'] for s in scenes]).astype('complex64')
                    amp=np.sqrt(np.array([s['cp'] for s in scenes])*10**(p['scr_grid_db'][j]/10))
                    expected=(base.astype('complex128')+unit.astype('complex128')*amp[:,None]).astype('complex64')
                else:expected=np.stack([s['base'] for s in scenes]).astype('complex64')
                np.testing.assert_array_equal(iq,expected)
                actual=fill_predictions(info['models'],iq,np.ones((2,5),dtype=bool),np.empty((2,5)),a.device,2)
                old=original_predictions([info['models'][label] for label in LABELS[:4]],iq,a.device,2)
                np.testing.assert_array_equal(actual[:,:4],old)
                src,_,_=load_frozen_sources()
                with torch.inference_mode():
                    x=torch.from_numpy(iq);z=info['models']['ADN'].prepared_forward(src.map_to_adn_input(src.wvd_base_map(x)))
                np.testing.assert_array_equal(actual[:,4],(z[:,1]-z[:,0]).double().numpy())

    def test_cache_copy_skips_generator_and_network_and_partial_matches(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,info=fixture(Path(d));p=info['p'];iq=make_iq(info['generator'],p,'h0_cal',np.arange(4))
            full=fill_predictions(info['models'],iq,np.ones((4,5),bool),np.empty((4,5)),a.device,2)
            cache=ScoreCache()
            for col,label in enumerate(LABELS):cache.put(label,'h0_cal',full[:,col],dict(path='fixture',sha256='fixture'))
            with patch('b283_score.make_iq',side_effect=AssertionError('Must not generate cached scenes')):
                actual,reused,computed=compute_chunk(info,p,cache,'h0_cal',0,4,a.device,2)
            np.testing.assert_array_equal(actual,full);self.assertEqual((reused,computed),(20,0))
            partial=ScoreCache();partial.put('A1_frozen','h0_cal',full[:,0],dict(path='fixture',sha256='fixture'))
            partial.put('guided','h0_cal',full[:2,3],dict(path='fixture',sha256='fixture'))
            actual,reused,computed=compute_chunk(info,p,partial,'h0_cal',0,4,a.device,2)
            np.testing.assert_array_equal(actual,full);self.assertEqual((reused,computed),(6,14))

    def test_cache_rejects_disagreeing_overlap_and_numeric_replay(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,info=fixture(Path(d));p=info['p'];cache=ScoreCache()
            for split in ('h0_cal','h1'):
                shape=(37,4) if split=='h1' else (4,);v=np.zeros(shape)
                levels=[18,24,36] if split=='h1' else [None]
                for j in levels:
                    iq=make_iq(info['generator'],p,split,np.arange(4),j)
                    out=fill_predictions(info['models'],iq,np.ones((4,5),bool),np.empty((4,5)),a.device,2)[:,3]
                    if split=='h1':v[j]=out
                    else:v[:]=out
                cache.put('guided',split,v,dict(path='fixture',sha256='fixture'))
            self.assertEqual(len(verify_cache_values(info,cache,a.device,2)),2)
            with self.assertRaisesRegex(RuntimeError,'prefixes differ'):cache.put('guided','h0_cal',np.full(2,99.),dict(path='bad',sha256='bad'))
            cache.values['guided','h0_cal'][0]+=1
            with self.assertRaisesRegex(RuntimeError,'numeric replay differs'):verify_cache_values(info,cache,a.device,2)

    def test_real_stream_37_points_resume_and_missing_array(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,info=fixture(Path(d));a.out_dir=Path(d)/'score';a.batch=2;a.chunk=2
            p={k:info['p'][k] for k in SCENE_KEYS};p.update(h0_cal_n=4,h0_audit_n=4,h1_scenes_n=2)
            p['fingerprint']=fingerprint(p);cache=ScoreCache();stream(a,p,info,cache)
            before={p.name:digest_file(p) for p in a.out_dir.glob('*.npy')}
            prog=read_json(a.out_dir/'progress.json');prog['completed'].update(h0_cal=2,h1=35);write_json(a.out_dir/'progress.json',prog)
            stream(a,p,info,cache);self.assertEqual(before,{p.name:digest_file(p) for p in a.out_dir.glob('*.npy')})
            (a.out_dir/'h0_cal_scores.npy').unlink()
            with self.assertRaisesRegex(RuntimeError,'missing despite'):stream(a,p,info,cache)

    def test_dual_pfa_report_styles_titles_and_budget_table(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);cal=np.linspace(-6,6,1000000);audit=np.linspace(-6,6,20000);q=(np.arange(512)+.5)/512
            h1=np.stack([6+(scr-np.log(q/(1-q)))/3 for scr in range(-24,13)])
            contracts={label:dict(run_config=dict(selected_rows=dict(train=dict(count=16000 if label in ARMS else 30000),val=dict(count=5000)),epochs=6 if label in ARMS else 12),
                best_epoch=1,checkpoint_sha256='synthetic',new_refinement_selected=label in ('guided','unguided')) for label in LABELS}
            p=dict(version='B283_FULL_INCREMENTAL_SCORE_V1',labels=list(LABELS),nominal_pfas=[1e-4,1e-5],scr_grid_db=list(range(-24,13)),
                h0_cal_n=len(cal),h0_audit_n=len(audit),h1_scenes_n=512,training_contracts=contracts,scope='synthetic fixture')
            p['fingerprint']=fingerprint(p);write_json(root/'protocol_frozen.json',p);write_json(root/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=len(cal),h0_audit=len(audit),h1=37)))
            np.save(root/'h0_cal_scores.npy',np.stack([cal]*5,1));np.save(root/'h0_audit_scores.npy',np.stack([audit]*5,1));np.save(root/'dev_h1_scores.npy',np.stack([h1+j/3 for j in range(5)],2))
            result=reporter.generate(root);self.assertEqual((len(result['metrics']),len(result['table'])),(10,10));self.assertFalse(result['trained_new_models'])
            palette=['#1f77b4','#ff7f0e','#2ca02c','#d62728','#9467bd']
            for i,label in enumerate(LABELS[:3]):
                self.assertEqual(plots.style_for(NAMES[label],i,NAMES['guided'],False,palette),previous_plots.style_for(NAMES[label],i,NAMES['guided'],False,palette))
            for nominal,exp in [(1e-4,-4),(1e-5,-5)]:
                manifest=read_json(root/f'figures/pfa_{nominal:.0e}/b283_curves_paper_manifest.json');style=manifest['styles'][NAMES['guided']]
                self.assertEqual((style['linestyle'],style['marker'],style['color']),('-','v','black'))
                self.assertIn('10^{'+str(exp)+'}',manifest['pd_title']);self.assertFalse(manifest['smoothing'])
                self.assertTrue((root/f'figures/b283_pd_scr_pfa_{nominal:.0e}.pdf').is_file())

    def test_source_cache_fallback_without_old_arrays_and_runtime_guard(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,old=fixture(Path(d));info=load_sources(a,c);cache=collect_caches(a,info)
            self.assertEqual(cache.values,{})
            self.assertTrue(source.runtime_matches(info['p'],a))
            bad=dict(info['p'],batch=16);self.assertFalse(source.runtime_matches(bad,a))

    def test_collect_full_baselines_and_real_medium_cache_shapes(self):
        # Shape/protocol cache fixture only; score values are deliberately
        # synthetic. Numeric-cache replay has its own generated-IQ test.
        with tempfile.TemporaryDirectory() as d:
            a,c,old=fixture(Path(d));info=load_sources(a,c)
            def arrays(folder,n0,n1,nh,medium=False):
                for name,shape in [('h0_cal_scores.npy',(n0,4)),('h0_audit_scores.npy',(n1,4)),('dev_h1_scores.npy',(37,nh,4))]:
                    value=np.lib.format.open_memmap(folder/name,mode='w+',shape=shape,dtype='float64');value[:]=0
                    if medium:
                        for col in (1,2,3):value[...,col]=col
                    value.flush();del value
            arrays(a.b280_run/'pd_scr_full',3000000,1000000,1024)
            folder=a.b282_run/'pd_scr_medium';folder.mkdir()
            p={k:info['p'][k] for k in SCENE_KEYS};p.update(h0_cal_n=300000,h0_audit_n=200000,h1_scenes_n=512,
                version='B282_CFEXPERT_SCORE_V1',labels=list(LABELS[:4]),checkpoints=[info['contracts'][arm] for arm in ARMS],
                source_identity=info['contracts']['guided']['run_config']['source_identity'],code_sha256=reference_hashes(),
                device='cpu',batch=32,torch_version=str(torch.__version__),amp=False,tf32=False)
            p['scene_fingerprint']=fingerprint({k:p[k] for k in SCENE_KEYS});p['fingerprint']=fingerprint(p)
            write_json(folder/'protocol_frozen.json',p);write_json(folder/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=300000,h0_audit=200000,h1=37)))
            arrays(folder,300000,200000,512,True)
            cache=collect_caches(a,info);self.assertEqual(len(cache.values),15)
            self.assertEqual(len(cache.get('A1_frozen','h0_cal')),3000000)
            self.assertEqual(len(cache.get('guided','h0_cal')),300000)
            self.assertEqual(cache.get('ADN','h1').shape,(37,1024))
            out,missing=cache.fill('h0_cal',299984,300016)
            self.assertEqual(int(missing.sum()),48)
            np.testing.assert_array_equal(out[:16,3],np.full(16,3.))
            wrong=dict(p,scene_fingerprint='bad');wrong.pop('fingerprint');wrong['fingerprint']=fingerprint(wrong)
            write_json(folder/'protocol_frozen.json',wrong);write_json(folder/'progress.json',dict(fingerprint=wrong['fingerprint'],completed=dict(h0_cal=300000,h0_audit=200000,h1=37)))
            with self.assertRaisesRegex(RuntimeError,'scene fingerprint'):collect_caches(a,info)

    def test_real_main_no_optimizer_checkpoint_writes_or_training(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,old=fixture(Path(d));out=Path(d)/'main';before={str(p):digest_file(p) for p in Path(d).rglob('*.pt')}
            def small_stream(args,p,info,cache):
                self.assertEqual((p['h0_cal_n'],p['h0_audit_n'],p['h1_scenes_n']),(3000000,1000000,1024))
                self.assertEqual(p['nominal_pfas'],[1e-4,1e-5]);self.assertEqual(p['labels'],list(LABELS))
                local=dict(p,h0_cal_n=2,h0_audit_n=2,h1_scenes_n=2);local.pop('fingerprint');local['fingerprint']=fingerprint(local)
                args.batch=2;args.chunk=2;stream(args,local,info,cache)
            with patch.object(runner,'resolve',return_value=c),patch.object(runner,'stream',side_effect=small_stream),patch('b283_report.generate',return_value=True),patch('torch.optim.Adam',side_effect=AssertionError('No optimizer')):
                self.assertTrue(runner.main(['--root',d,'--b280-run',str(a.b280_run),'--b282-run',str(a.b282_run),'--out-dir',str(out),'--device','cpu','--cpu-threads','2']))
            self.assertEqual(before,{str(p):digest_file(p) for p in Path(d).rglob('*.pt')})
            self.assertEqual(read_json(out/'pd_scr_full/progress.json')['completed']['h1'],37)

    @unittest.skipUnless(torch.cuda.is_available(),'No local CUDA; AutoDL cache probe/first chunk exercise inference')
    def test_cuda_five_model_batch32_inference(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,info=fixture(Path(d));a.device=torch.device('cuda')
            for model in info['models'].values():model.to(a.device).eval()
            iq=make_iq(info['generator'],info['p'],'h0_cal',np.arange(32))
            out=fill_predictions(info['models'],iq,np.ones((32,5),bool),np.empty((32,5)),a.device,32)
            self.assertTrue(np.isfinite(out).all())


if __name__=='__main__':unittest.main(verbosity=2)
