"""Two grouped factors: joint SPWVD/WCSG; TFCG + original Tail objective.

This is a project ADN reconstruction, not the authors' official implementation.
The learned frontend changes the display representation, not SPWVD marginals.
"""
import hashlib
import numpy as np
import torch
from torch import nn
from b271_data import need
from source_loader import load_frozen_sources
from b280_frontend import JointTFGate, smoothing_bank, SETTINGS
from b278_loss import original_tail, ORIGINAL

ARMS=('A0','A1','A2','A3')
NAMES={'A0':'A0: ADN (WVD, SimAM, CE)',
       'A1':'A1: ADN + joint SPWVD gate',
       'A2':'A2: ADN + TFCG/Tail',
       'A3':'A3: joint SPWVD gate + ADN/TFCG/Tail'}
FACTORS={'A0':(False,False),'A1':(True,False),'A2':(False,True),'A3':(True,True)}


class AblationADN(nn.Module):
    def __init__(self,arm,scale):
        super().__init__();need(arm in ARMS and np.isfinite(scale) and scale>0,'Invalid ablation model')
        self.arm=arm;self.joint,self.tail=FACTORS[arm];self.scale=float(scale)
        source,trainer,_=load_frozen_sources()
        # Always consume RNG identically: original ADN, all TFCGs, joint gate.
        # Thus shared backbone tensors and active extra modules match by seed.
        self.detector=source.ADN18(num_classes=2)
        replacements=[]
        for stage in ('layer1','layer2','layer3','layer4'):
            for block in getattr(self.detector,stage):
                c=block.conv2.out_channels
                replacements.append((block,trainer.TFCG(c,trainer.TFCG_KERNELS[c])))
        gate=JointTFGate()
        if self.tail:
            for block,attention in replacements:block.simam=attention
        self.gate=gate if self.joint else None

    def prepared_forward(self,prepared,return_aux=False):
        aux={}
        if self.joint:prepared,aux=self.gate(prepared)
        z=self.detector(prepared)
        return (z,aux) if return_aux else z

    def forward(self,iq,return_aux=False):
        source,_,_=load_frozen_sources()
        with torch.no_grad():
            x=smoothing_bank(iq,self.scale) if self.joint else source.map_to_adn_input(source.wvd_base_map(iq))
        return self.prepared_forward(x,return_aux)


def objective(model,z,y):
    ce=torch.nn.functional.cross_entropy(z,y)
    tail=original_tail(z,y) if model.tail else z.sum()*0
    return ce,ce+ORIGINAL['weight']*tail,tail


def tensor_hash(state):
    h=hashlib.sha256()
    for name,value in sorted(state.items()):
        v=value.detach().cpu().contiguous()
        h.update(name.encode());h.update(str(v.dtype).encode());h.update(np.asarray(v.shape,dtype='<i8').tobytes());h.update(v.numpy().tobytes())
    return h.hexdigest()


def initial_identity(model):
    state=model.state_dict()
    return dict(shared_ADN_without_attention_sha256=tensor_hash({k:v for k,v in state.items() if k.startswith('detector.') and '.simam.' not in k}),
        tfcg_sha256=tensor_hash({k:v for k,v in state.items() if '.simam.' in k}) if model.tail else None,
        joint_gate_sha256=tensor_hash(model.gate.state_dict()) if model.joint else None,
        original_SimAM_vs_identity_TFCG_initial_functions_differ=True,
        initialization='from scratch; no ImageNet, historical checkpoint or warm start',
        parameters=sum(p.numel() for p in model.parameters()))


@torch.inference_mode()
def diagnostics(model,iq):
    model.eval()
    if not model.joint:return {}
    _,aux=model(iq,True)
    return dict(gain_mean=float(aux['gain'].mean()),gain_std=float(aux['gain'].std()),
        short_correction_abs_mean=float(aux['correction_short'].abs().mean()),
        long_correction_abs_mean=float(aux['correction_long'].abs().mean()),
        image_change_abs_mean=float((aux['output_gray']-aux['input_gray']).abs().mean()),
        joint_module_parameters=sum(p.numel() for p in model.gate.parameters()),
        exact_new_Wigner_distribution_claimed=False)
