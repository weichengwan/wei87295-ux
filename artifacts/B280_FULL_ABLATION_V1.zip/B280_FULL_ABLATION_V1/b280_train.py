"""Fair from-scratch four-arm training; TRAIN/VAL only, resumable epoch commits."""
import gc,time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from b271_data import digest_file,fingerprint,load_checkpoint,need,read_json,write_json
from b273_shared import atomic_save,pauc
from b273_statistics import save_csv
from b280_model import AblationADN,FACTORS,initial_identity,objective,diagnostics,ORIGINAL,SETTINGS,tensor_hash
from source_loader import load_frozen_file

PASS='PASS_B280_FULL_TRAIN_VAL_ONLY'


def code_hashes():
    root=Path(__file__).parent
    paths=list(root.glob('*.py'))+list((root/'frozen_source').glob('*.py'))+[root/'frozen_source/manifest.json']
    return {str(p.relative_to(root)):digest_file(p) for p in sorted(paths)}


@torch.inference_mode()
def evaluate(model,data,device,batch):
    model.eval();total=0.;zs=[];ys=[];n=len(data.values['val'][1])
    for start in range(0,n,batch):
        x,y=data.fetch('val',slice(start,min(start+batch,n)),device);z=model.prepared_forward(x)
        need(z.shape==(len(y),2) and torch.isfinite(z).all().item(),'Invalid validation output')
        total+=float(F.cross_entropy(z,y,reduction='sum'));zs.append((z[:,1]-z[:,0]).double().cpu().numpy());ys.append(y.cpu().numpy())
    z,y=np.concatenate(zs),np.concatenate(ys)
    return dict(val_ce=total/n,val_auc=float(load_frozen_file('r10_sim_stage_b214_ablation_train_v1.py').auc(z,y)),
                val_pauc01=pauc(z,y),n_val=n)


def configuration(a,context,data,scale,arm):
    joint,tail=FACTORS[arm]
    return dict(version='B280_FULL_FACTORIAL_TRAIN_V1',arm=arm,factor_A_joint_SPWVD=joint,factor_B_TFCG_Tail=tail,
        seed=a.seed,epochs=a.epochs,batch=a.batch,lr=a.lr,weight_decay=1e-4,optimizer='Adam',
        initialization='shared seed from scratch; original ADN first; construct all extras in all arms; no pretrained weights',
        loss='CE + 0.05 original B215 Tail' if tail else 'CE',tail_parameters=ORIGINAL if tail else None,
        joint_settings=SETTINGS if joint else None,scale=scale,scale_fit_split='first256 TRAIN only',
        selected_rows=data.selection,bank_sha256=context['bc']['file_sha256'],
        selection='minimum VAL CE, epoch0 eligible in all four groups; no H0 or DEV selection',
        code_sha256=code_hashes(),device_type=a.device.type,torch_version=str(torch.__version__),amp=False,tf32=False)


def cpu_snapshot(model):return {k:v.detach().cpu().clone() for k,v in model.state_dict().items()}


def train_arm(a,context,data,scale,arm):
    folder=a.out_dir/arm;folder.mkdir(exist_ok=True)
    cfg=configuration(a,context,data,scale,arm);fp=fingerprint(cfg)
    manifest=folder/'run_manifest.json';best_path=folder/'best.pt';last=folder/'last_epoch.pt';contract=folder/'training_contract.json'
    mv=dict(run_config=cfg,run_fingerprint=fp)
    if manifest.exists():need(read_json(manifest)==mv,'B280 training settings changed; use another output directory')
    else:
        need(not any(folder.iterdir()),'Nonempty B280 arm without manifest');write_json(manifest,mv)
    if contract.exists():
        c=read_json(contract);need(c['status']==PASS and c['run_fingerprint']==fp and digest_file(best_path)==c['checkpoint_sha256'],'Completed B280 checkpoint changed')
        print(arm+' complete; verified and skipped',flush=True);return c
    torch.manual_seed(a.seed)
    model=AblationADN(arm,scale).to(a.device);initial=initial_identity(model)
    optimizer=torch.optim.Adam(model.parameters(),lr=a.lr,weight_decay=1e-4)
    history=[];start=1
    def snapshot(epoch,metrics):return dict(state_dict=cpu_snapshot(model),epoch=epoch,run_config=cfg,run_fingerprint=fp,val_metrics=metrics)
    def commit(epoch,best):
        current=snapshot(epoch,history[-1]);current.update(optimizer=optimizer.state_dict(),best_checkpoint=best,history=history,
            initialization=initial,torch_rng=torch.get_rng_state(),cuda_rng=torch.cuda.get_rng_state_all() if a.device.type=='cuda' else [])
        # One authoritative atomic epoch commit contains BOTH last and best.
        # A crash while exporting best.pt can therefore be repaired on resume.
        atomic_save(last,current);atomic_save(best_path,best)
    if last.exists():
        state=load_checkpoint(last);need(state['run_fingerprint']==fp and state['run_config']==cfg,'B280 resume identity differs')
        best=state['best_checkpoint'];need(best['run_fingerprint']==fp,'Resume best identity differs')
        model.load_state_dict(state['state_dict'],strict=True);optimizer.load_state_dict(state['optimizer'])
        history=state['history'];initial=state['initialization'];start=state['epoch']+1
        torch.set_rng_state(state['torch_rng'])
        if a.device.type=='cuda':torch.cuda.set_rng_state_all(state['cuda_rng'])
        atomic_save(best_path,best)
        del state
    else:
        v=evaluate(model,data,a.device,a.batch);best=snapshot(0,v)
        history=[dict(epoch=0,train_ce=None,train_tail=None,train_objective=None,**v,best_epoch=0,elapsed_s=0.)];commit(0,best)
    print(f'B280 {arm}: {initial["parameters"]:,} parameters, full CNN/BN trainable, epochs {start}..{a.epochs}',flush=True)
    for epoch in range(start,a.epochs+1):
        began=time.perf_counter();model.train();seen=0;total=np.zeros(3)
        for step,index in enumerate(context['b210'].indices(data.values['train'][1],epoch,a.batch,a.seed)):
            x,y=data.fetch('train',index,a.device);optimizer.zero_grad(set_to_none=True)
            z=model.prepared_forward(x);ce,loss,tail=objective(model,z,y)
            need(torch.isfinite(loss).item(),'Nonfinite B280 objective')
            loss.backward();optimizer.step();total+=np.array([float(ce.detach()),float(tail.detach()),float(loss.detach())])*len(y);seen+=len(y)
            if (step+1)%200==0:
                elapsed=time.perf_counter()-began
                print(f'[{arm}] epoch {epoch}/{a.epochs}, TRAIN {seen:,}/{len(data.values["train"][1]):,}; {seen/max(elapsed,.001):.1f}/s',flush=True)
        v=evaluate(model,data,a.device,a.batch)
        if v['val_ce']<best['val_metrics']['val_ce']:best=snapshot(epoch,v)
        history.append(dict(epoch=epoch,train_ce=float(total[0]/seen),train_tail=float(total[1]/seen),train_objective=float(total[2]/seen),
            **v,best_epoch=best['epoch'],elapsed_s=time.perf_counter()-began))
        commit(epoch,best);save_csv(folder/'train_val_history.csv',history)
        print(f'[{arm}] {epoch}/{a.epochs} VAL_CE={v["val_ce"]:.6f} AUC={v["val_auc"]:.6f} best={best["epoch"]} time={history[-1]["elapsed_s"]:.1f}s',flush=True)
    model.load_state_dict(best['state_dict'],strict=True);replay=evaluate(model,data,a.device,a.batch)
    need(abs(replay['val_ce']-best['val_metrics']['val_ce'])<1e-6,'B280 selected VAL replay differs')
    iq,_=data.raw.fetch('train',slice(0, min(16,len(data.values['train'][1]))),a.device)
    c=dict(status=PASS,run_config=cfg,run_fingerprint=fp,checkpoint_sha256=digest_file(best_path),best_epoch=best['epoch'],
        selected_validation=replay,initialization=initial,module_diagnostics=diagnostics(model,iq),trainable_parameters=initial['parameters'],
        all_CNN_BN_trainable=True,H0_CAL_AUDIT_DEV_used_for_training=False)
    write_json(contract,c);del model,optimizer,best;gc.collect()
    if a.device.type=='cuda':torch.cuda.empty_cache()
    print(f'{PASS}; {arm}; selected epoch={c["best_epoch"]}',flush=True);return c


def gpu_canary(a,data,scale,cache):
    """Actual AutoDL steady-state optimizer check, discarded before all training."""
    from b280_data import PreparedData
    from b280_model import ARMS
    results=[]
    for arm in ARMS:
        torch.manual_seed(a.seed);model=AblationADN(arm,scale).to(a.device).train()
        prepared=PreparedData(data,cache,scale,FACTORS[arm][0]);optimizer=torch.optim.Adam(model.parameters(),lr=a.lr,weight_decay=1e-4)
        if a.device.type=='cuda':torch.cuda.reset_peak_memory_stats(a.device)
        # balanced probes; only TRAIN is read, no validation/model selection.
        y=data.values['train'][1];index=np.r_[np.flatnonzero(y==0)[:a.batch//2],np.flatnonzero(y==1)[:a.batch//2]]
        need(len(index)==a.batch,'Not enough TRAIN rows for optimizer canary')
        for _ in range(3):
            x,target=prepared.fetch('train',index,a.device);optimizer.zero_grad(set_to_none=True)
            ce,loss,tail=objective(model,model.prepared_forward(x),target);loss.backward();optimizer.step()
            need(torch.isfinite(loss).item(),'Optimizer canary nonfinite')
        results.append(dict(arm=arm,three_optimizer_steps=True,peak_allocated_GiB=torch.cuda.max_memory_allocated(a.device)/1024**3 if a.device.type=='cuda' else None))
        prepared.close();del model,optimizer,x,loss,ce,tail;gc.collect()
        if a.device.type=='cuda':torch.cuda.empty_cache()
        print('TRAIN optimizer canary passed: '+arm,flush=True)
    return results
