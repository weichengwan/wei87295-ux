"""Functional generated-IQ tests. No real radar gain or CUDA result claimed."""
import gc,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import h5py,numpy as np,torch
import torch.nn.functional as F
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from source_loader import load_frozen_file,load_frozen_sources
from b271_data import digest_file,fingerprint,read_json,write_json,load_checkpoint
from b273_shared import setup
from b274_data import Data
from b280_model import AblationADN,ARMS,NAMES,FACTORS,initial_identity,objective,original_tail
from b280_data import scale_for,cache_for,verify_cache,PreparedData
from b280_score import predictions,stream,verify_factor_initialization
from b280_report import generate
import b280_frontend as front
import b280_train as trainer
import b280_run as runner
import b280_score as scorer


def fixture(root,n=4):
    bank=root/'bank';bank.mkdir();path=bank/'iq.h5'
    generator=load_frozen_file('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
    with h5py.File(path,'w') as h:
        for split in ('train','val'):
            scenes=[generator.make_one(20261009,split,i,-30,10) for i in range(n)]
            g=h.create_group(split);g['iq']=np.stack([s['iq'] for s in scenes]).astype('complex64');g['label']=np.array([s['label'] for s in scenes],dtype='uint8');g['family_index']=np.arange(n)%2
    b=load_frozen_file('r10_sim_stage_b210_a3_adn_earlystop_v1.py')
    c=dict(root=root,bank_dir=bank,bank_path=path,b210=b,bc=dict(file_sha256=digest_file(path),generator_sha256=digest_file(generator.__file__),seed=20261009))
    write_json(bank/b.CT_NAME,dict(fixture=True))
    return c,Data(c,n,n,20261022),generator


def args(root,batch=2):
    out=root/'out';out.mkdir(exist_ok=True)
    return SimpleNamespace(root=root,out_dir=out,cache_dir=None,device=torch.device('cpu'),batch=batch,chunk=2,
        seed=20261022,epochs=1,lr=1e-3)


def scene(c,g):
    return dict(master_seed=20261009,generator_sha=c['bc']['generator_sha256'],h0_cal_n=3000000,h0_audit_n=1000000,
        h1_scenes_n=1024,scr_grid_db=list(range(-24,13)),h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',
        family_names=list(g.TRAIN_FAMILIES),scr_definition='test synthetic IQ')


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):setup(2)

    def test_factor_topology_and_identical_initialization(self):
        identities=[];counts=[];source,trainer_source,_=load_frozen_sources()
        for arm in ARMS:
            torch.manual_seed(20261022);model=AblationADN(arm,2.);identities.append(initial_identity(model));counts.append(sum(p.numel() for p in model.parameters()))
            attention=[b.simam for name in ('layer1','layer2','layer3','layer4') for b in getattr(model.detector,name)]
            self.assertEqual(len(attention),8);self.assertTrue(all(isinstance(a,trainer_source.TFCG if model.tail else source.SimAM) for a in attention))
            self.assertEqual(model.gate is not None,FACTORS[arm][0])
            self.assertTrue(all(p.requires_grad for p in model.parameters()))
        self.assertEqual(counts,[14330946,14331565,14532770,14533389])
        self.assertEqual(len({v['shared_ADN_without_attention_sha256'] for v in identities}),1)
        self.assertEqual(identities[1]['joint_gate_sha256'],identities[3]['joint_gate_sha256'])
        self.assertEqual(identities[2]['tfcg_sha256'],identities[3]['tfcg_sha256'])

    def test_frontend_one_fft_zero_phase_identity_and_bounds(self):
        iq=torch.randn(2,512,dtype=torch.complex64)
        with patch.object(front,'spwvd_torch',wraps=front.spwvd_torch) as estimator:bank=front.smoothing_bank(iq,2.);estimator.assert_called_once()
        expected=front.spwvd_torch(iq,smooth_time=5)
        torch.testing.assert_close(bank[:,1],torch.log1p(expected.abs())/2.,atol=0,rtol=0)
        torch.testing.assert_close(front.smoothing_bank(iq*torch.exp(torch.tensor(.4j)),2.),bank,atol=5e-5,rtol=2e-5)
        self.assertEqual(float(front.smoothing_bank(torch.zeros_like(iq),2.).abs().max()),0.)
        self.assertTrue(torch.isfinite(bank).all());self.assertTrue(torch.all((bank[:,3]>=0)&(bank[:,3]<=1)))
        gate=front.JointTFGate().eval();image,aux=gate(bank)
        base=F.interpolate(bank[:,1:2],size=(224,224),mode='bilinear',align_corners=False).repeat(1,3,1,1)
        torch.testing.assert_close(image,base,atol=0,rtol=0)
        with torch.no_grad():gate.head.bias.copy_(torch.tensor([10.,-10.,10.]))
        image,aux=gate(bank)
        self.assertLessEqual(float(aux['correction_short'].abs().max()),.25)
        self.assertLessEqual(float(aux['correction_long'].abs().max()),.25)
        self.assertTrue(torch.all((aux['gain']>=.8)&(aux['gain']<=1.2)));self.assertTrue(torch.all(image>=0))

    def test_joint_and_tfcg_gradients_and_exact_original_tail(self):
        torch.manual_seed(42);m=AblationADN('A3',2.).train();x=front.smoothing_bank(torch.randn(2,512,dtype=torch.complex64),2.);y=torch.tensor([0,1])
        opt=torch.optim.Adam(m.parameters(),lr=1e-3)
        for step in range(2):
            opt.zero_grad();z=m.prepared_forward(x);ce,loss,tail=objective(m,z,y);loss.backward()
            for row in m.gate.head.weight.grad:self.assertGreater(float(row.abs().sum()),0.)
            if step:self.assertGreater(float(m.gate.pre[0].weight.grad.abs().sum()),0.)
            self.assertGreater(float(m.detector.layer2[0].simam.fuse[-1].weight.grad.abs().sum()),0.);opt.step()
        source=load_frozen_file('r10_sim_stage_b215_tpht_train_v1.py')
        z=torch.randn(32,2,requires_grad=True);y=torch.arange(32)%2;s=z[:,1]-z[:,0];i,j=source.get_hard_indices(s,y,.25,.25)
        ref=(2*F.softplus((1+s[i,None]-s[None,j])/2)).mean();actual=original_tail(z,y)
        torch.testing.assert_close(actual,ref,atol=0,rtol=0)
        torch.testing.assert_close(torch.autograd.grad(actual,z,retain_graph=True)[0],torch.autograd.grad(ref,z)[0],atol=0,rtol=0)

    def test_full_cache_build_replay_reuse_and_tamper_detection(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);c,data,g=fixture(root);a=args(root);scale=scale_for(a.out_dir,c,data,a.device,a.batch)
            self.assertEqual(scale,scale_for(a.out_dir,c,data,a.device,a.batch))
            cache=cache_for(a,c,data);before=digest_file(cache)
            self.assertEqual(cache,cache_for(a,c,data));self.assertEqual(before,digest_file(cache))
            source,_,_=load_frozen_sources()
            for joint in (False,True):
                prepared=PreparedData(data,cache,scale,joint);x,y=prepared.fetch('train',np.array([3,0]),a.device)
                iq,yy=data.fetch('train',np.array([3,0]),a.device)
                expected=front.smoothing_bank(iq,scale) if joint else source.map_to_adn_input(source.wvd_base_map(iq))
                torch.testing.assert_close(x,expected,atol=0,rtol=0);torch.testing.assert_close(y,yy);prepared.close()
            with h5py.File(cache,'r+') as h:h['val/label'][0]=1-h['val/label'][0]
            with self.assertRaisesRegex(RuntimeError,'checksum'):cache_for(a,c,data)

    def test_all_four_actual_train_checkpoints_and_score_loading(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);c,data,g=fixture(root);a=args(root);cache=cache_for(a,c,data);contracts=[]
            source_hash=digest_file(c['bank_path'])
            for arm in ARMS:
                prepared=PreparedData(data,cache,2.,FACTORS[arm][0])
                contracts.append(trainer.train_arm(a,c,prepared,2.,arm));prepared.close()
            verify_factor_initialization(contracts);self.assertEqual(source_hash,digest_file(c['bank_path']))
            a.b213_dir=None
            def capture(s,p,generator,models,device):
                self.assertEqual((p['h0_cal_n'],p['h0_audit_n'],p['h1_scenes_n']),(3000000,1000000,1024))
                self.assertEqual(p['nominal_pfas'],[1e-4,1e-5]);self.assertEqual(p['scr_grid_db'],list(range(-24,13)))
                actual=predictions(models,data.values['val'][0],device,2);self.assertEqual(actual.shape,(4,4))
            old=scene(c,g)
            with patch.object(scorer,'original_protocol',return_value=(None,old,g)),patch.object(scorer,'stream',side_effect=capture) as streaming,patch('b280_report.generate',return_value=True):
                self.assertTrue(scorer.score(a,c));streaming.assert_called_once()
            self.assertEqual(contracts[0]['run_config']['loss'],'CE');self.assertIn('Tail',contracts[3]['run_config']['loss'])

    def test_epoch_atomic_resume_repairs_best_and_is_exact(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);c,data,g=fixture(root);a=args(root);a.epochs=2;cache=cache_for(a,c,data);prepared=PreparedData(data,cache,2.,True)
            save=trainer.atomic_save;stopped=[False]
            def interrupt(path,state):
                save(path,state)
                if path.name=='last_epoch.pt' and state['epoch']==1 and not stopped[0]:stopped[0]=True;raise InterruptedError('after atomic commit before best export')
            with patch.object(trainer,'atomic_save',side_effect=interrupt):
                with self.assertRaises(InterruptedError):trainer.train_arm(a,c,prepared,2.,'A3')
            (a.out_dir/'A3/best.pt').unlink()
            trainer.train_arm(a,c,prepared,2.,'A3');one=load_checkpoint(a.out_dir/'A3/last_epoch.pt')
            a.out_dir=root/'continuous';a.out_dir.mkdir();trainer.train_arm(a,c,prepared,2.,'A3');two=load_checkpoint(a.out_dir/'A3/last_epoch.pt')
            for k,v in one['state_dict'].items():self.assertTrue(torch.equal(v,two['state_dict'][k]),k)
            self.assertEqual(one['best_checkpoint']['epoch'],two['best_checkpoint']['epoch']);prepared.close()

    def test_shared_predictions_independent_match_and_render_count(self):
        models=[AblationADN(arm,2.).eval() for arm in ARMS];iq=np.random.default_rng(1).normal(size=(2,512,2)).astype('float32').view('complex64').reshape(2,512)
        source,_,_=load_frozen_sources()
        with patch.object(source,'wvd_base_map',wraps=source.wvd_base_map) as w,patch.object(scorer,'smoothing_bank',wraps=scorer.smoothing_bank) as s:
            actual=predictions(models,iq,torch.device('cpu'),2);w.assert_called_once();s.assert_called_once()
        with torch.inference_mode():
            for j,m in enumerate(models):
                z=m(torch.from_numpy(iq));expected=(z[:,1]-z[:,0]).double().numpy();np.testing.assert_array_equal(actual[:,j],expected)

    def test_real_generator_stream_resumes_and_rejects_missing_prefix(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);c,data,g=fixture(root);a=args(root);a.out_dir=root/'score'
            p=scene(c,g);p.update(h0_cal_n=4,h0_audit_n=4,h1_scenes_n=2,scr_grid_db=[-1,0,1],labels=list(ARMS));p['fingerprint']=fingerprint(p)
            models=[AblationADN(arm,2.).eval() for arm in ARMS]
            stream(a,p,g,models,a.device);hashes={f.name:digest_file(f) for f in a.out_dir.glob('*.npy')}
            stream(a,p,g,models,a.device);self.assertEqual(hashes,{f.name:digest_file(f) for f in a.out_dir.glob('*.npy')})
            progress=read_json(a.out_dir/'progress.json');progress['completed'].update(h0_cal=2,h1=1);write_json(a.out_dir/'progress.json',progress)
            stream(a,p,g,models,a.device);self.assertEqual(hashes,{f.name:digest_file(f) for f in a.out_dir.glob('*.npy')})
            (a.out_dir/'h0_cal_scores.npy').unlink()
            with self.assertRaisesRegex(RuntimeError,'missing despite'):stream(a,p,g,models,a.device)

    def test_dual_pfa_report_37_raw_points_and_factor_table(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);cal=np.linspace(-6,6,1000000);audit=np.linspace(-6,6,20000);q=(np.arange(1024)+.5)/1024
            h1=np.stack([6+(scr-np.log(q/(1-q)))/3 for scr in range(-24,13)])
            p=dict(version='B280_FULL_FACTORIAL_SCORE_V1',labels=list(ARMS),names=NAMES,nominal_pfas=[1e-4,1e-5],scr_grid_db=list(range(-24,13)),
                h0_cal_n=1000000,h0_audit_n=20000,h1_scenes_n=1024,checkpoints=[dict(trainable_parameters=1, best_epoch=1) for _ in ARMS],scope='synthetic fixture')
            p['fingerprint']=fingerprint(p);write_json(root/'protocol_frozen.json',p);write_json(root/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=1000000,h0_audit=20000,h1=37)))
            np.save(root/'h0_cal_scores.npy',np.stack([cal]*4,1));np.save(root/'h0_audit_scores.npy',np.stack([audit]*4,1));np.save(root/'dev_h1_scores.npy',np.stack([h1+j/3 for j in range(4)],2))
            report=generate(root);self.assertEqual(len(report['metrics']),8);self.assertEqual(len(report['table']),8)
            for nominal in (1e-4,1e-5):
                row=next(c for c in report['comparisons'] if c['candidate']=='A3' and c['reference']=='A0' and c['nominal_pfa']==nominal)
                self.assertAlmostEqual(row['delta_D90_db'],-3.,places=8)
                self.assertTrue((root/f'figures/b280_pd_scr_pfa_{nominal:.0e}.pdf').is_file())
                manifest=read_json(root/f'figures/pfa_{nominal:.0e}/b280_curves_paper_manifest.json');self.assertFalse(manifest['smoothing']);self.assertEqual(manifest['styles'][NAMES['A3']]['marker'],'v')

    def test_full_cli_defaults_gpu_lock_and_train_scale_identity(self):
        import fcntl
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);a=runner.cli(['--root',d,'--device','cpu'])
            self.assertEqual((a.train_limit,a.val_limit,a.epochs,a.batch,a.lr),(30000,5000,12,32,1e-3))
            with (root/'codex_b271_night.lock').open('a') as lock:
                fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
                with self.assertRaisesRegex(SystemExit,'GPU lock'):runner.main(['--root',d,'--device','cpu'])
            c,data,g=fixture(root);a=args(root);scale_for(a.out_dir,c,data,a.device,a.batch)
            data.selection['train']['count']+=1
            with self.assertRaisesRegex(RuntimeError,'scale identity'):scale_for(a.out_dir,c,data,a.device,a.batch)

    def test_actual_main_chain_batch32_canary_four_training_then_scoring(self):
        # The ONLY boundary mock is the frozen-bank contract/count discovery;
        # test IQ, cache, scale, CLI, optimizer canary, training and reload are real.
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);c,data,g=fixture(root,32);old=scene(c,g)
            old.update(version='SIM_R10_B213_SCOREBANK_V1',training_bank_sha=c['bc']['file_sha256'])
            from b280_protocol import SCENE_KEYS,original_protocol
            old['scene_fingerprint']=fingerprint({k:old[k] for k in SCENE_KEYS});old['fingerprint']=fingerprint(old)
            old_dir=root/'old_protocol';old_dir.mkdir();write_json(old_dir/'protocol_frozen.json',old)
            write_json(old_dir/'progress.json',dict(fingerprint=old['fingerprint'],completed=dict(h0_cal=3000000,h0_audit=1000000,h1=37)))
            self.assertEqual(original_protocol(root,c)[1],old)
            def tiny_stream(a,p,generator,models,device):
                self.assertEqual((p['h0_cal_n'],p['h0_audit_n']),(3000000,1000000))
                local=dict(p,h0_cal_n=2,h0_audit_n=2,h1_scenes_n=2,scr_grid_db=[0]);local.pop('fingerprint');local['fingerprint']=fingerprint(local)
                stream(a,local,generator,models,device)
            with patch.object(runner,'resolve',return_value=c),patch.object(scorer,'stream',side_effect=tiny_stream) as scoring,patch('b280_report.generate',return_value=True):
                self.assertTrue(runner.main(['--root',d,'--device','cpu','--epochs','1','--cpu-threads','2']))
                scoring.assert_called_once()
            out=root/'output_b280_full_ablation_v1';canary=read_json(out/'optimizer_canary.json')
            self.assertEqual(len(canary['results']),4);self.assertTrue(all(x['three_optimizer_steps'] for x in canary['results']))
            self.assertTrue(all((out/arm/'training_contract.json').is_file() for arm in ARMS))

    @unittest.skipUnless(torch.cuda.is_available(),'CUDA unavailable locally; AutoDL runtime canary performs this')
    def test_cuda_three_optimizer_steps_batch32_all_four_arms(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);c,data,g=fixture(root,32);a=args(root,32);a.device=torch.device('cuda');cache=cache_for(a,c,data)
            results=trainer.gpu_canary(a,data,2.,cache);self.assertEqual(len(results),4)


if __name__=='__main__':unittest.main(verbosity=2)
