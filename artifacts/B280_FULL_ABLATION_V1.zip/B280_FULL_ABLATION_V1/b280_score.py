"""Full3M/1M, 1024x37 DEV; one WVD and one SPWVD render per shared batch."""
import gc,time
from types import SimpleNamespace
import numpy as np
import torch
from b271_data import digest_file,fingerprint,load_checkpoint,need,read_json,write_json
from b280_protocol import SCENE_KEYS,original_protocol
from b280_model import AblationADN,ARMS,NAMES,SETTINGS,smoothing_bank
from b280_train import PASS,code_hashes
from source_loader import load_frozen_sources,load_frozen_file


@torch.inference_mode()
def predictions(models,iq,device,batch):
    need(iq.dtype==np.complex64 and iq.ndim==2 and iq.shape[1]==512,'Expected complex64 IQ512')
    need([m.arm for m in models]==list(ARMS) and len({m.scale for m in models})==1,'Four shared frontend models required')
    source,_,_=load_frozen_sources();out=np.empty((len(iq),4),dtype='float64')
    for start in range(0,len(iq),batch):
        x=torch.from_numpy(np.ascontiguousarray(iq[start:start+batch])).to(device)
        wvd=source.map_to_adn_input(source.wvd_base_map(x));bank=smoothing_bank(x,models[0].scale)
        for j,m in enumerate(models):
            z=m.prepared_forward(bank if m.joint else wvd)
            out[start:start+len(x),j]=(z[:,1]-z[:,0]).double().cpu().numpy()
    need(np.isfinite(out).all(),'Nonfinite B280 scores');return out


def stream(a,p,generator,models,device):
    helper=load_frozen_file('r10_sim_stage_b216_pdscr_score_v1.py');progress=helper.init(a,p)
    files=dict(h0_cal='h0_cal_scores.npy',h0_audit='h0_audit_scores.npy',h1='dev_h1_scores.npy')
    for split,name in files.items():
        total=len(p['scr_grid_db']) if split=='h1' else p[split+'_n'];done=progress['completed'][split]
        need(isinstance(done,int) and 0<=done<=total,'Invalid B280 committed prefix')
        need(done==0 or (a.out_dir/name).is_file(),'Score array missing despite committed progress; restore it or use a new output directory')
    for split in ('h0_cal','h0_audit'):
        total=p[split+'_n'];path=a.out_dir/files[split];array=helper.new_array(path,(total,4),path.exists())
        first=progress['completed'][split];began=time.perf_counter()
        for start in range(first,total,a.chunk):
            stop=min(start+a.chunk,total)
            scenes=[generator.make_one(p['master_seed'],p[split+'_split'],i,-30,10) for i in range(start,stop)]
            need(all(s['label']==0 and not np.any(s['target']) for s in scenes),'Target in H0')
            iq=np.stack([s['base'] for s in scenes]).astype('complex64')
            array[start:stop]=predictions(models,iq,device,a.batch);array.flush()
            progress['completed'][split]=stop;write_json(a.out_dir/'progress.json',progress)
            if stop==total or stop%10000<a.chunk:
                rate=(stop-first)/max(time.perf_counter()-began,1e-6)
                print(f'[{split}] {stop:,}/{total:,}; four models {rate:.1f} scenes/s; remaining~{(total-stop)/max(rate,1e-6)/60:.1f}min',flush=True)
        del array
    ns=p['h1_scenes_n'];levels=p['scr_grid_db'];path=a.out_dir/files['h1']
    array=helper.new_array(path,(len(levels),ns,4),path.exists())
    scenes=[generator.make_one(p['master_seed'],p['h1_split'],i,-30,10) for i in range(ns)]
    need(all(s['label']==1 for s in scenes),'H1 split must contain targets')
    base=np.stack([s['base'] for s in scenes]).astype('complex64');unit=np.stack([s['unit'] for s in scenes]).astype('complex64')
    power=np.array([s['cp'] for s in scenes],dtype='float64');need(np.isfinite(power).all() and (power>0).all(),'Invalid clutter power')
    for j in range(progress['completed']['h1'],len(levels)):
        scr=levels[j]
        for start in range(0,ns,a.chunk):
            stop=min(start+a.chunk,ns);amplitude=np.sqrt(power[start:stop]*10**(scr/10))
            iq=(base[start:stop].astype('complex128')+unit[start:stop].astype('complex128')*amplitude[:,None]).astype('complex64')
            array[j,start:stop]=predictions(models,iq,device,a.batch)
        array.flush();progress['completed']['h1']=j+1;write_json(a.out_dir/'progress.json',progress)
        print(f'[dev_h1] SCR={scr:+d} dB {j+1}/{len(levels)}',flush=True)
    del array


def verify_factor_initialization(contracts):
    values=[c['initialization'] for c in contracts]
    need(len({v['shared_ADN_without_attention_sha256'] for v in values})==1,'Four-arm backbone initialization differs')
    need(values[1]['joint_gate_sha256']==values[3]['joint_gate_sha256'],'A1/A3 joint initialization differs')
    need(values[2]['tfcg_sha256']==values[3]['tfcg_sha256'],'A2/A3 TFCG initialization differs')
    keys=('seed','epochs','batch','lr','weight_decay','selected_rows','bank_sha256','scale','code_sha256','device_type','torch_version')
    need(len({fingerprint({k:c['run_config'][k] for k in keys}) for c in contracts})==1,'Four-arm training budgets differ')


def score(a,context):
    _,old,generator=original_protocol(a.root,context,a.b213_dir)
    models=[];contracts=[]
    for arm in ARMS:
        folder=a.out_dir/arm;c=read_json(folder/'training_contract.json');path=folder/'best.pt'
        need(c['status']==PASS and digest_file(path)==c['checkpoint_sha256'] and c['run_config']['code_sha256']==code_hashes(),'Incomplete or changed B280 training')
        cfg=c['run_config'];state=load_checkpoint(path)
        need(cfg['bank_sha256']==context['bc']['file_sha256'] and cfg==state['run_config'] and fingerprint(cfg)==c['run_fingerprint']==state['run_fingerprint'] and state['epoch']==c['best_epoch'],'B280 internal checkpoint identity differs')
        model=AblationADN(arm,cfg['scale']);model.load_state_dict(state['state_dict'],strict=True);model.to(a.device).eval()
        models.append(model);contracts.append(c)
    verify_factor_initialization(contracts)
    scene={k:old[k] for k in SCENE_KEYS}
    p=dict(version='B280_FULL_FACTORIAL_SCORE_V1',**scene,scene_fingerprint=fingerprint(scene),labels=list(ARMS),names=NAMES,
        nominal_pfas=[1e-4,1e-5],ours_label='A3',checkpoints=contracts,
        joint_settings=SETTINGS,training_bank_sha=context['bc']['file_sha256'],code_sha256=code_hashes(),
        batch=a.batch,chunk=a.chunk,device=a.device.type,torch_version=str(torch.__version__),tf32=False,amp=False,
        score_definition='float64(float32 logit1 - float32 logit0)',strict_decision='score > own H0 CAL threshold',
        independent_final=False,scope='Full frozen SIM-R10 DEV, previously exposed; four fresh common-seed runs, grouped two-factor ablation')
    p['fingerprint']=fingerprint(p)
    args=SimpleNamespace(out_dir=a.out_dir/'pd_scr_full',batch=a.batch,chunk=a.chunk)
    print('B280 FULL CAL3M CHECK1M H1=1024x37; four fresh checkpoints; nominal Pfa1e-4 and1e-5',flush=True)
    stream(args,p,generator,models,a.device)
    del models;gc.collect()
    if a.device.type=='cuda':torch.cuda.empty_cache()
    from b280_report import generate
    return generate(args.out_dir)
