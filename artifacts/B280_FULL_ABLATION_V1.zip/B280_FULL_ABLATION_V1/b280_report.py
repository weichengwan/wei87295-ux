"""Raw37-point plots and grouped two-factor tables at both requested Pfas."""
from pathlib import Path
import shutil
import numpy as np
from b271_data import fingerprint,need,read_json,write_json
from b273_statistics import metrics_for,save_csv
from b280_model import ARMS,NAMES,FACTORS
from paper_plots import generate as paper_plot


def generate(out):
    out=Path(out);p=read_json(out/'protocol_frozen.json');progress=read_json(out/'progress.json')
    need(p['version']=='B280_FULL_FACTORIAL_SCORE_V1' and p['labels']==list(ARMS) and p['nominal_pfas']==[1e-4,1e-5] and
         p['fingerprint']==fingerprint({k:v for k,v in p.items() if k!='fingerprint'})==progress['fingerprint'],'B280 report protocol differs')
    need(progress['completed']==dict(h0_cal=p['h0_cal_n'],h0_audit=p['h0_audit_n'],h1=len(p['scr_grid_db'])),'B280 scoring incomplete')
    arrays=[]
    for name,shape in [('h0_cal_scores.npy',(p['h0_cal_n'],4)),('h0_audit_scores.npy',(p['h0_audit_n'],4)),('dev_h1_scores.npy',(len(p['scr_grid_db']),p['h1_scenes_n'],4))]:
        x=np.load(out/name,mmap_mode='r',allow_pickle=False);need(x.shape==shape and x.dtype==np.dtype('float64'),'Malformed B280 scores');arrays.append(x)
    curves=[];metrics=[];lookup={};table=[]
    for j,arm in enumerate(ARMS):
        cv,mt=metrics_for(NAMES[arm],arrays[0][:,j],arrays[1][:,j],arrays[2][:,:,j],p);curves+=cv;metrics+=mt
        for m in mt:
            lookup[arm,m['nominal_pfa']]=m
            table.append(dict(group=arm,joint_SPWVD_WCSG=FACTORS[arm][0],TFCG_plus_Tail=FACTORS[arm][1],
                parameters=p['checkpoints'][j]['trainable_parameters'],selected_epoch=p['checkpoints'][j]['best_epoch'],**m))
    comparisons=[]
    for nominal in p['nominal_pfas']:
        for candidate,reference,factor in [('A1','A0','A, B absent'),('A3','A2','A, B present'),('A2','A0','B, A absent'),('A3','A1','B, A present'),('A3','A0','both factors')]:
            c,r=lookup[candidate,nominal],lookup[reference,nominal]
            delta=lambda k:None if c[k] is None or r[k] is None else c[k]-r[k]
            comparisons.append(dict(candidate=candidate,reference=reference,contrast=factor,nominal_pfa=nominal,
                delta_D80_db=delta('D80_db'),delta_D90_db=delta('D90_db'),pd_at_0_gain_pp=100*delta('pd_at_0'),
                candidate_false_alarms=c['audit_false_alarms'],reference_false_alarms=r['audit_false_alarms'],negative_delta_means_left=True))
    for name,rows in [('b280_curves.csv',curves),('b280_metrics.csv',metrics),('b280_ablation_table.csv',table),('b280_comparisons.csv',comparisons)]:save_csv(out/name,rows)
    text='Two grouped factors; all four models retrained from scratch, matched data, initialization seed and budget.\n\n'
    fmt=lambda v:'NA' if v is None else f'{v:.3f}'
    for nominal in p['nominal_pfas']:
        text+=f'Nominal Pfa={nominal:g}\n\n|Group|Joint SPWVD/WCSG|TFCG+Tail|D80/dB|D90/dB|Pd@0|Actual Pfa|\n|---|---|---|---|---|---|---|\n'
        for row in [r for r in table if r['nominal_pfa']==nominal]:
            text+=f"|{row['group']}|{int(row['joint_SPWVD_WCSG'])}|{int(row['TFCG_plus_Tail'])}|{fmt(row['D80_db'])}|{fmt(row['D90_db'])}|{fmt(row['pd_at_0'])}|{row['actual_pfa']:.2e}|\n"
        text+='\n'
        figures=out/'figures'/f'pfa_{nominal:.0e}'
        paper_plot(out/'b280_curves.csv',figures,ours=NAMES['A3'],nominal=nominal,metrics=out/'b280_metrics.csv')
        for suffix in ('pdf','png','svg'):
            shutil.copyfile(figures/f'b280_curves_paper_pd_pfa_{nominal:.0e}.{suffix}',out/'figures'/f'b280_pd_scr_pfa_{nominal:.0e}.{suffix}')
    text+='Group B bundles TFCG and Tail, so this table cannot separate their individual contributions. Group A changes representation/normalization and joint gating together. Full exposed DEV is not independent final validation.\n'
    (out/'b280_ablation_table.md').write_text(text,encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    for nominal in p['nominal_pfas']:
        selected=[r for r in table if r['nominal_pfa']==nominal]
        fig,ax=plt.subplots(figsize=(10,3));ax.axis('off')
        display=[[r['group'],str(int(r['joint_SPWVD_WCSG'])),str(int(r['TFCG_plus_Tail'])),fmt(r['D80_db']),fmt(r['D90_db']),fmt(r['pd_at_0']),f"{r['audit_false_alarms']}/{r['audit_n']:,}"] for r in selected]
        t=ax.table(cellText=display,colLabels=['Group','Joint TF gate','TFCG+Tail','D80/dB','D90/dB','Pd at 0 dB','H0 false alarms'],cellLoc='center',loc='center');t.auto_set_font_size(False);t.set_fontsize(9);t.scale(1,1.5)
        ax.set_title(f'Two-factor ablation | nominal Pfa={nominal:g} | same training budget')
        for ext in ('pdf','png'):fig.savefig(out/f'b280_ablation_table_pfa_{nominal:.0e}.{ext}',dpi=300,bbox_inches='tight')
        plt.close(fig)
    report=dict(status='PASS_B280_FULL_FACTORIAL_DEV_REPORT',metrics=metrics,comparisons=comparisons,table=table,
        independent_final=False,equal_actual_pfa_established=False,source_Pd_unchanged=True,curve_smoothing=False,
        innovation_or_gain_automatically_established=False,scope=p['scope'])
    write_json(out/'b280_report.json',report)
    for c in comparisons:print(f"Pfa={c['nominal_pfa']:g} {c['candidate']} vs {c['reference']}: delta_D90={c['delta_D90_db']}; H0 FP={c['candidate_false_alarms']} vs {c['reference_false_alarms']}",flush=True)
    print('PASS_B280_ALL_FOUR_TRAIN_SCORE_REPORT_COMPLETE: '+str(out),flush=True);return report
