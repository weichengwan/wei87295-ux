"""Original B215 Tail and an experimental TRAIN-negative-memory reference loss.

The memory reference is a surrogate at TRAIN alpha=.01, not a calibrated
Pfa=1e-4 detector threshold or a new CVaR/Neyman-Pearson guarantee.
"""
import math
import torch
from torch import nn
import torch.nn.functional as F
from b271_data import need
from source_loader import load_frozen_file

ORIGINAL = dict(rho_h0=.25, rho_h1=.25, margin=1., temperature=2., weight=.05)
MEMORY = dict(capacity=4096, warmup_h0=256, train_tail_fraction=.01,
              positive_fraction=.25, margin_standardized=1., temperature=.25,
              scale_floor=.5, negative_excess_weight=1., weight=.05)


def original_tail(logits, labels):
    source=load_frozen_file('r10_sim_stage_b215_tpht_train_v1.py')
    z=logits[:,1]-logits[:,0]
    i,j=source.get_hard_indices(z,labels,ORIGINAL['rho_h0'],ORIGINAL['rho_h1'])
    if i is None:return logits.sum()*0
    t=ORIGINAL['temperature']
    return (F.softplus((ORIGINAL['margin']+z[i,None]-z[None,j])/t)*t).mean()


class TrainNegativeMemory(nn.Module):
    def __init__(self, **overrides):
        super().__init__();self.settings={**MEMORY,**overrides};p=self.settings
        need(2<=p['warmup_h0']<=p['capacity'] and 0<p['train_tail_fraction']<1 and
             0<p['positive_fraction']<=1 and p['scale_floor']>0 and p['temperature']>0,
             'Invalid TRAIN tail-memory settings')
        self.register_buffer('scores',torch.zeros(p['capacity']))
        for name in ('size','cursor','updates','reference_updates'):self.register_buffer(name,torch.zeros((),dtype=torch.long))
        self.register_buffer('last_reference',torch.zeros(()))
        self.register_buffer('last_scale',torch.ones(()))

    @torch.no_grad()
    def append(self, scores):
        # Only objective() in TRAIN calls this; validation/inference never do.
        value=scores.detach().flatten().to(self.scores)
        need(torch.isfinite(value).all().item(),'Nonfinite TRAIN memory scores')
        capacity=self.settings['capacity'];n=len(value)
        if n>=capacity:
            self.scores.copy_(value[-capacity:]);self.size.fill_(capacity);self.cursor.zero_()
        elif n:
            cursor=int(self.cursor);first=min(n,capacity-cursor)
            self.scores[cursor:cursor+first].copy_(value[:first])
            if first<n:self.scores[:n-first].copy_(value[first:])
            self.cursor.fill_((cursor+n)%capacity);self.size.fill_(min(capacity,int(self.size)+n))
        self.updates.add_(1)

    def forward(self, logits, labels):
        need(self.training,'Tail-memory objective may only update during TRAIN')
        z=logits[:,1]-logits[:,0];negative=z[labels==0];positive=z[labels==1]
        if not len(negative) or not len(positive):
            self.append(negative);return logits.sum()*0
        p=self.settings;n=int(self.size)
        if n<p['warmup_h0']:
            # Reuse the original loss while a TRAIN-only reference accumulates.
            value=original_tail(logits,labels)
        else:
            memory=self.scores[:n].detach()
            q=torch.quantile(memory,1-p['train_tail_fraction']).detach().clone()
            scale=memory.std(unbiased=False).clamp_min(p['scale_floor']).detach().clone()
            k=max(1,math.ceil(len(positive)*p['positive_fraction']))
            weak=positive[torch.topk(positive.detach(),k,largest=False).indices]
            t=p['temperature']
            gap=p['margin_standardized']+(q-weak)/scale
            positive_gap=(F.softplus(gap/t)*t).mean()
            # Current negatives have gradients; the prior memory is detached.
            # This penalizes normalized excess above a past TRAIN upper tail.
            negative_excess=F.relu((negative-q)/scale).square().mean()/p['train_tail_fraction']
            value=positive_gap+p['negative_excess_weight']*negative_excess
            self.last_reference.copy_(q);self.last_scale.copy_(scale)
            self.reference_updates.add_(1)
        self.append(negative)
        return value

    def diagnostics(self):
        ready=int(self.reference_updates)>0
        return dict(train_memory_size=int(self.size),train_memory_updates=int(self.updates),
                    train_reference_updates=int(self.reference_updates),
                    train_reference_score=float(self.last_reference) if ready else None,
                    train_reference_scale=float(self.last_scale) if ready else None,
                    memory_used_for_inference=False,reference_is_calibrated_pfa_threshold=False)
