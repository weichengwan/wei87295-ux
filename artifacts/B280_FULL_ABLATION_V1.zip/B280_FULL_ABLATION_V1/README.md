# B280：完整数据、两因素、四模型消融

这是训练、推理、统计和绘图齐全的独立代码包。使用 `start_on_autodl.sh` 后台启动；它调用 `run_b280.sh` 完成全部流程。不要逐个运行继承的工具文件。默认不需要 B274/B276 权重，不载入 ImageNet，不修改已有实验。

## 四组到底比较什么

|组别|因素 A：联合 SPWVD/WCSG 前端|因素 B：TFCG + 原始 Tail|分类训练目标|参数量|
|---|---|---|---|---:|
|A0|无，原项目 WVD|无，保留 8 个 SimAM|CE|14,330,946|
|A1|有|无，保留 8 个 SimAM|CE|14,331,565|
|A2|无，原项目 WVD|有，8 个 TFCG 替换 SimAM|CE + 0.05 Tail|14,532,770|
|A3|有|有，8 个 TFCG 替换 SimAM|CE + 0.05 Tail|14,533,389|

四组都保留 ADN 的 ACB、残差主干、GAP 和二分类头，均为单 CNN。没有 LMDA 分支、额外 ResNet18 分支、phase-ARS 或 AHPM。

**这里 A3 是 B280 新完整模型，不是以前 B276/B277 的 A3。A2 不含独立 WCSG；WCSG 的改造归入因素 A。** A0 是项目已有 ADN 代码在统一 SIM-R10 数据上的重建，不等于作者官方代码或原论文原始数据实验。

因素 A 叫“联合时频表征与空间门控”（暂定 JTFG）；因素 B 叫“时频上下文与尾部排序联合学习”。名称用于描述实际计算，是否构成足够创新、能否提高检测性能，需要本轮结果和后续独立数据验证。CE、SPWVD 和原有 Tail 不能仅因改名成为原创。

四组验证的是**两个组合因素**。A3-A2/A1-A0 衡量因素 A；A3-A1/A2-A0 衡量因素 B。不能从这张表分离 TFCG 和 Tail 的各自贡献，也不能分离普通 SPWVD 替换、归一化和联合门控各自贡献。

## 运行：手动上传 ZIP 后无需下载命令

在 `/root/autodl-tmp/MTDSP_NATIVE_LMDA_V1` 上传本 ZIP，终端执行：

```bash
cd /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1
unzip -n B280_FULL_ABLATION_V1.zip
bash B280_FULL_ABLATION_V1/start_on_autodl.sh
tail -F codex_b280_full.log
```

脚本默认依次执行：等待共享锁 → 验证原始数据/全量场景协议 → TRAIN 标度拟合 → 验证或建立 WVD 缓存 → 四组各 3 步真实优化器预检（丢弃这些权重）→ 四组重新训练 → 全量评分 → 双虚警率统计/绘图。

B278 若仍持有 `codex_b271_night.lock`，本轮等待并每分钟输出提示，不终止它。`Ctrl+C` 退出 `tail` 不会终止后台任务。没有日志进度或 GPU 锁等待信息，不代表已经开始训练。

运行中断后，使用**相同参数、相同代码包、相同设备类型和 PyTorch 版本**重新执行上述 `nohup` 命令即可。完成的训练组会核验后跳过；训练从上一个完整 epoch 继续，评分从已经提交的块继续。不要同时提交两个 B280：共享锁会串行等待。

同一个输出目录不允许改 epochs、lr、seed、代码或数据身份。如需另一预算，显式使用新目录，例如 `--out-dir /root/autodl-tmp/MTDSP_NATIVE_LMDA_V1/output_b280_full_ablation_e15 --epochs 15`；四组仍使用同样预算。

## 固定的最大规模

- IQ：`SIM_R10_IQ512_TRAIN30000_VAL5000_SEED20261009_V1`，TRAIN30,000 / VAL5,000，全部使用，不随机缩小。
- 训练：四组各 12 epoch，batch32，Adam lr0.001、weight decay0.0001；全部 CNN 和 BN 可训练。按相同种子、相同无放回均衡采样顺序训练。
- 初始化：全部从头训练，共享 ADN 参数初始张量一致；A1/A3 的联合门控参数一致；A2/A3 的 TFCG 参数一致。原 SimAM 和零初始化 TFCG 的初始函数不同，不能声称四组初始函数相同。
- 选择：四组都只按最低 VAL CE 选择，epoch0 亦可选。没有按 DEV Pd 或检查集虚警率选权重。
- H0 CAL3,000,000：各模型独立求阈值。
- H0 CHECK1,000,000：独立于 CAL 的虚警检查；不训练或调阈值。
- DEV H1：同 1,024 个场景，SCR=-24 到 +12 dB，步长1 dB，共37点。沿用原 B213 的种子、场景索引和生成器，避免新旧场景不匹配。
- 两档名义 Pfa：`1e-4` 和 `1e-5`，即 10 的负4/负5次方。
- float32 模型计算，logit1-logit0 在 float32 相减后存 float64；不开 AMP/TF32。严格 `score > 自己的CAL阈值`。

阈值尾部支持数分别约300/30；CHECK 预计虚警数量分别约100/10，仍须结合实际计数与95% Wilson区间看待差异。相同名义 Pfa 不等于相同实测 Pfa。37个 SCR 复用同1024场景，不能当成37份独立数据。

## 必需文件与缓存

需要原冻结30k/5k IQ HDF5、其 contract/audit，以及已完成的原 B213 `protocol_frozen.json` 和 `progress.json`。程序只读这些元数据，**不需要旧 ADN 权重或旧评分数组**。定位不到时可显式传 `--bank-dir 路径 --b213-dir 路径`。

优先只读复用 `output_sim_r10_b270_wvd_rebuilt_v1`，其次 `output_sim_r10_b210_30k_5k_wvd_cache_v1`。检查文件 SHA、数据身份、全量形状、标签顺序及 TRAIN/VAL 各3行重放。缓存不合格时保留原文件，在新输出目录建立自己的完整缓存；不使用 pilot/MID8192 冒充30k/5k。可用 `--cache-dir 路径` 指定，指定缓存不合格会停止。

已有合格 WVD 缓存时预留约2GiB；需要新缓存时预留至少4GiB。新 SPWVD 多尺度图按批计算，不写巨型图像缓存。全部旧结果保留。若原冻结缓存建立时中断，会保留临时文件并停止，避免静默覆盖；检查后可选择另一个全新输出目录。

## 输出

默认目录：`output_b280_full_ablation_v1`。

- `A0/`…`A3/`：best.pt、last_epoch.pt（含优化器和最佳权重）、训练历史、配置、训练契约。
- `pd_scr_full/figures/b280_pd_scr_pfa_1e-04.pdf` 和 `...1e-05.pdf`：四组37点 Pd 图；同时有 PNG/SVG。
- `pd_scr_full/figures/pfa_1e-04/` 和 `pfa_1e-05/`：每档独立的图源 CSV、绘图清单、空场 CUT 虚警率与95%区间图。
- `pd_scr_full/b280_ablation_table.csv`、`.md` 及每档 PDF/PNG：两个条件的四行表。
- `pd_scr_full/b280_metrics.csv`：D50/D80/D90、Pd@0/6/9/12、阈值、实际虚警率/计数/区间。
- `pd_scr_full/b280_comparisons.csv`：两个因素在对方有/无时的增量及 A3-A0，D90 差值负数代表左移。
- 原始 CAL/CHECK/H1 分数数组、冻结协议和可恢复进度。

A3 用黑色虚线、空心倒三角；横轴 `SCR (dB)`，纵轴 `P_d`。保留全部37个原始点，不平滑、不移动曲线。D80/D90 仅在原始相邻点之间做首次上穿线性插值。

仅重新出图：`bash B280_FULL_ABLATION_V1/run_b280.sh --stage report --device cpu`。仅评分：相同启动命令追加 `--stage score`。依赖沿用 mpdnet-r10，脚本不自动升级安装包。

## 时间与证据边界

这是四个模型从头训练和四模型全量评分，可能超过一晚。先看首个 epoch 耗时；H0 日志报告的是**四模型联合处理的场景/秒**，CAL/CHECK 共400万场景，按该速度估算更可靠。等待 B278 的时间另计。本地 CPU 功能测试通过不代表已在你的3080Ti上训练或证明曲线会左移；启动时会在实际设备完成 batch32 优化器预检。

全量 DEV 仍是已反复使用的开发场景，不能写成从未见过的最终测试。最后论文还需独立实测/留出场景及足够重复种子验证。有关模块来源、计算公式和可支持的表述见 `METHOD_DESIGN.md`。
