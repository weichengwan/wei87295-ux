"""Full four-arm training -> ownCAL/AUDIT/H1 -> dualPfa plots, one command."""
import argparse,fcntl,gc,shutil,time
from pathlib import Path
from b271_data import device_for,fingerprint,need,read_json,write_json
from b280_protocol import original_protocol
from b273_shared import setup
from b274_data import Data,resolve
from b280_data import PreparedData,scale_for,cache_for
from b280_model import ARMS,FACTORS
from b280_train import train_arm,gpu_canary,code_hashes


def cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    for key in ('bank-dir','cache-dir','out-dir','b213-dir'):p.add_argument('--'+key,type=Path)
    p.add_argument('--stage',choices=('all','preflight','train','score','report'),default='all')
    p.add_argument('--wait-for-gpu',action='store_true')
    p.add_argument('--epochs',type=int,default=12);p.add_argument('--batch',type=int,default=32);p.add_argument('--chunk',type=int,default=512)
    p.add_argument('--lr',type=float,default=1e-3);p.add_argument('--seed',type=int,default=20261022)
    p.add_argument('--device',choices=('cuda','cpu'),default='cuda');p.add_argument('--cpu-threads',type=int,default=4)
    a=p.parse_args(argv);a.root=a.root.resolve();a.out_dir=(a.out_dir or a.root/'output_b280_full_ablation_v1').resolve()
    need(a.root.is_dir() and a.out_dir!=a.root and a.root in a.out_dir.parents,'B280 output must be a separate directory inside root')
    need(a.epochs>0 and a.batch==32 and a.chunk>=a.batch and a.chunk%a.batch==0 and a.lr>0 and a.cpu_threads>0,'Invalid full training budget')
    # Fixed full data/evaluation; no silent pilot/medium fallback.
    a.train_limit=30000;a.val_limit=5000;a.device=device_for(a.device);return a


def acquire(lock,wait):
    attempts=0
    while True:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);return
        except BlockingIOError:
            if not wait:raise SystemExit('Another radar job holds GPU lock; use --wait-for-gpu')
            if attempts%4==0:print('Waiting for B278/other radar job; B280 has not allocated GPU memory',flush=True)
            attempts+=1;time.sleep(15)


def main(argv=None):
    a=cli(argv);setup(a.cpu_threads)
    print(f'B280 full factorial | stage={a.stage} | output={a.out_dir}',flush=True)
    if a.stage=='report':
        from b280_report import generate
        return generate(a.out_dir/'pd_scr_full')
    with (a.root/'codex_b271_night.lock').open('a') as lock:
        acquire(lock,a.wait_for_gpu)
        context=resolve(a.root,a.bank_dir)
        # Fail before training if full historical scene metadata is missing.
        path,old,_=original_protocol(a.root,context,a.b213_dir)
        if a.stage=='score':
            from b280_score import score
            return score(a,context)
        need(shutil.disk_usage(a.root).free>=2*1024**3,'Require2GiB free for new four-arm checkpoints/scores; old results are preserved')
        a.out_dir.mkdir(exist_ok=True)
        data=Data(context,30000,5000,a.seed)
        identity=dict(version='B280_FULL_ABLATION_V1',bank_sha256=context['bc']['file_sha256'],selected_rows=data.selection,
            seed=a.seed,epochs=a.epochs,batch=a.batch,lr=a.lr,code_sha256=code_hashes(),device=a.device.type,nominal_pfas=[1e-4,1e-5],
            scene_fingerprint=old['scene_fingerprint'])
        manifest=a.out_dir/'run_manifest.json'
        if manifest.exists():need(read_json(manifest)==identity,'B280 run settings changed; use a new output directory')
        else:
            need(not any(a.out_dir.iterdir()),'Nonempty B280 output without manifest');write_json(manifest,identity)
        scale=scale_for(a.out_dir,context,data,a.device,a.batch);cache=cache_for(a,context,data)
        canary=a.out_dir/'optimizer_canary.json'
        if not canary.exists():
            result=gpu_canary(a,data,scale,cache)
            write_json(canary,dict(run_fingerprint=fingerprint(identity),device=a.device.type,results=result))
        else:need(read_json(canary)['run_fingerprint']==fingerprint(identity),'Optimizer canary identity differs')
        print('Full TRAIN30,000 VAL5,000; A0/A1/A2/A3 fresh shared-seed initialization; no ARS; no historical metrics reused',flush=True)
        if a.stage=='preflight':return
        contracts=[]
        for arm in ARMS:
            prepared=PreparedData(data,cache,scale,FACTORS[arm][0])
            try:contracts.append(train_arm(a,context,prepared,scale,arm))
            finally:prepared.close()
        from b280_score import verify_factor_initialization
        verify_factor_initialization(contracts)
        del data;gc.collect()
        if a.stage=='train':return
        from b280_score import score
        return score(a,context)


if __name__=='__main__':main()
