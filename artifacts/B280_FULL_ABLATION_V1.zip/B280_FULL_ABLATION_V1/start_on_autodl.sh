#!/usr/bin/env bash
# Run this after uploading and unzipping B280_FULL_ABLATION_V1.zip.
set -euo pipefail
package_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
radar_root=$(dirname -- "$package_dir")
conda_binary=/root/miniconda3/bin/conda
test -x "$conda_binary" || { echo "Missing conda: $conda_binary" >&2; exit 1; }
cd -- "$package_dir"
sha256sum -c SHA256SUMS
cd -- "$radar_root"
nohup "$conda_binary" run --no-capture-output -n mpdnet-r10 \
  bash "$package_dir/run_b280.sh" --root "$radar_root" --wait-for-gpu "$@" \
  >> "$radar_root/codex_b280_full.log" 2>&1 < /dev/null &
printf 'B280 background PID: %s\n' "$!"
printf 'Log: %s/codex_b280_full.log\n' "$radar_root"
printf 'B280 may wait for B278; inspect the log to see the actual stage.\n'
