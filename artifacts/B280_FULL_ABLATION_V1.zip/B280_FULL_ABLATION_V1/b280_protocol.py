"""Validate original full SIM-R10 scene metadata, without reading old scores."""
from pathlib import Path
from b271_data import find_files,read_json,need,fingerprint,digest_file
from source_loader import load_frozen_file

SCENE_KEYS=("master_seed","generator_sha","h0_cal_n","h0_audit_n","h1_scenes_n","scr_grid_db",
            "h0_cal_split","h0_audit_split","h1_split","family_names","scr_definition")


def original_protocol(root, context, explicit=None):
    candidates=[Path(explicit)/"protocol_frozen.json"] if explicit else find_files(root,"protocol_frozen.json")
    valid=[]
    for path in candidates:
        p=read_json(path)
        if p.get("version")=="SIM_R10_B213_SCOREBANK_V1" and p.get("training_bank_sha")==context["bc"]["file_sha256"]:
            valid.append(path)
    need(valid,"Original B213 protocol missing; provide --b213-dir")
    need(len({read_json(p).get("scene_fingerprint") for p in valid})==1,"Several B213 scene identities; provide --b213-dir")
    path=valid[0];p=read_json(path)
    need(fingerprint({k:p[k] for k in SCENE_KEYS})==p["scene_fingerprint"],"B213 scene fingerprint differs")
    need(fingerprint({k:v for k,v in p.items() if k!="fingerprint"})==p["fingerprint"],"B213 protocol fingerprint differs")
    need((p["h0_cal_n"],p["h0_audit_n"],p["h1_scenes_n"])==(3000000,1000000,1024)
         and p["scr_grid_db"]==list(range(-24,13)),"Require full original 3M/1M/1024,37-point protocol")
    generator=load_frozen_file("r10_sim_iq512_builder_v1_EARLIEST_HDF5.py")
    need(digest_file(generator.__file__)==p["generator_sha"]==context["bc"]["generator_sha256"],"Generator differs")
    need(p["master_seed"]==context["bc"]["seed"] and tuple(p["family_names"])==generator.TRAIN_FAMILIES,"Original seed/family identity differs")
    progress=read_json(path.with_name("progress.json"))
    need(progress["fingerprint"]==p["fingerprint"] and progress["completed"]==
         dict(h0_cal=p["h0_cal_n"],h0_audit=p["h0_audit_n"],h1=37),"Original B213 incomplete")
    return path,p,generator

