"""Generated-IQ functional tests; no real radar gain or CUDA claim."""
import copy,gc,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import h5py,numpy as np,torch
import torch.nn.functional as F
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from b271_data import digest_file,fingerprint,read_json,write_json,load_checkpoint
from b273_shared import setup
from b274_data import Data
from b280_frontend import smoothing_bank
from b282_module import CrossFrequencyRefiner
from b282_model import A1Core,Candidate,make_a1,initial_check,optimizer_for,ARMS,LABELS,NAMES,tensor_hash
from b282_train import Prepared,evaluate,code_hashes,PASS
from b282_source import metadata,source_probe,SCENE_KEYS
from b282_score import predictions,stream,verify_matched
from source_loader import load_frozen_file,load_frozen_sources
import b282_train as trainer
import b282_score as scorer
import b282_run as runner
import b282_report as reporter
import b282_infer as inference


def fixture(root,n=4):
    bank=root/'bank';bank.mkdir();path=bank/'iq.h5';g=load_frozen_file('r10_sim_iq512_builder_v1_EARLIEST_HDF5.py')
    with h5py.File(path,'w') as h:
        for split in ('train','val'):
            scenes=[g.make_one(20261009,split,i,-30,10) for i in range(n)]
            v=h.create_group(split);v['iq']=np.stack([s['iq'] for s in scenes]).astype('complex64');v['label']=np.array([s['label'] for s in scenes],dtype='uint8');v['family_index']=np.arange(n)%2
    c=dict(root=root,bank_dir=bank,bank_path=path,b210=load_frozen_file('r10_sim_stage_b210_a3_adn_earlystop_v1.py'),
        bc=dict(file_sha256=digest_file(path),generator_sha256=digest_file(g.__file__),seed=20261009))
    raw=Data(c,n,n,20261022);data=Prepared(raw,2.)
    torch.manual_seed(12);reference=A1Core(2.).eval();anchor=evaluate(reference,data,torch.device('cpu'),2)
    source=root/'source';(source/'A1').mkdir(parents=True);out=source/'pd_scr_full';out.mkdir()
    # Discovery-only synthetic lineage: declared full source counts exercise
    # source metadata checks; the fixture itself is small generated IQ.
    cfg=dict(arm='A1',factor_A_joint_SPWVD=True,factor_B_TFCG_Tail=False,
        code_sha256=read_json(Path(__file__).resolve().parents[1]/'b280_release_sources.json'),
        bank_sha256=c['bc']['file_sha256'],scale=2.,selected_rows=dict(train=dict(count=30000),val=dict(count=5000)))
    state=dict(run_config=cfg,run_fingerprint=fingerprint(cfg),epoch=9,state_dict=copy.deepcopy(reference.state_dict()))
    torch.save(state,source/'A1/best.pt')
    ct=dict(status='PASS_B280_FULL_TRAIN_VAL_ONLY',run_config=cfg,run_fingerprint=fingerprint(cfg),best_epoch=9,
        checkpoint_sha256=digest_file(source/'A1/best.pt'),selected_validation=anchor)
    write_json(source/'A1/training_contract.json',ct)
    p=dict(version='B280_FULL_FACTORIAL_SCORE_V1',labels=['A0','A1','A2','A3'],checkpoints=[{},ct,{},{}],master_seed=20261009,
        generator_sha=c['bc']['generator_sha256'],h0_cal_n=3000000,h0_audit_n=1000000,h1_scenes_n=1024,
        scr_grid_db=list(range(-24,13)),h0_cal_split='h0_cal',h0_audit_split='h0_audit',h1_split='dev_h1',
        family_names=list(g.TRAIN_FAMILIES),scr_definition='synthetic fixture',device='cpu',batch=32,torch_version=str(torch.__version__),tf32=False,amp=False)
    p['scene_fingerprint']=fingerprint({k:p[k] for k in SCENE_KEYS});p['fingerprint']=fingerprint(p)
    write_json(out/'protocol_frozen.json',p);write_json(out/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=3000000,h0_audit=1000000,h1=37)))
    args=SimpleNamespace(root=root,source_run=source,out_dir=root/'out',device=torch.device('cpu'),batch=2,chunk=2,
        epochs=1,seed=20261022,lr=1e-5,new_lr=3e-4,eval_size='medium')
    args.out_dir.mkdir();info=metadata(args,c)
    return args,c,raw,data,reference,anchor,info


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):setup(2)

    def tearDown(self):gc.collect()

    def test_exact_a1_initialization_native_attention_and_parameter_matching(self):
        reference=A1Core(2.).eval();bank=smoothing_bank(torch.randn(2,512,dtype=torch.complex64),2.);records=[]
        source,_,_=load_frozen_sources()
        for arm in ARMS:
            torch.manual_seed(42);model=Candidate(reference,arm);records.append(initial_check(model,reference,bank))
            for name in ('layer1','layer2','layer3','layer4'):
                self.assertTrue(all(isinstance(b.simam,source.SimAM) for b in getattr(model.net.detector,name)))
            self.assertEqual(records[-1]['maxabs_logit_difference'],0.)
        self.assertEqual(records[1]['extra_parameters'],20214)
        self.assertEqual(records[1]['refiner_sha256'],records[2]['refiner_sha256'])
        self.assertEqual(records[1]['total_parameters'],records[2]['total_parameters'])

    def test_band_complementarity_bounds_and_guidance_isolation(self):
        x=torch.randn(3,128,28,28);zero=torch.zeros(3,1,128,128);one=torch.ones_like(zero)
        for guided in (False,True):
            torch.manual_seed(4);m=CrossFrequencyRefiner(guided);z=m.reduce(x);h,l,bw=m.bands(z)
            torch.testing.assert_close(h+l,z,atol=3e-7,rtol=1e-6)
            self.assertTrue(torch.all((bw>.08)&(bw<.5)))
            _,a=m.components(x,zero);_,b=m.components(x,one)
            torch.testing.assert_close(a['weights'].sum(-1),torch.ones(3,2))
            if guided:self.assertGreater(float((a['weights']-b['weights']).abs().max()),1e-5)
            else:torch.testing.assert_close(a['weights'],b['weights'],atol=0,rtol=0)
            torch.testing.assert_close(m(x,zero),x,atol=0,rtol=0)

    def test_real_gradients_all_new_components_and_frozen_front_bn(self):
        torch.manual_seed(42);ref=A1Core(2.).eval();m=Candidate(ref,'guided');opt=optimizer_for(m,1e-5,3e-4)
        bank=smoothing_bank(torch.randn(2,512,dtype=torch.complex64),2.);before=copy.deepcopy(m.net.state_dict());m.train()
        self.assertFalse(m.net.detector.bn1.training);self.assertFalse(m.net.gate.training)
        for step in range(3):
            opt.zero_grad(set_to_none=True);loss=F.cross_entropy(m.prepared_forward(bank),torch.tensor([0,1]));loss.backward()
            self.assertGreater(float(m.refiner.project.weight.grad.abs().sum()),0.)
            if step==2:
                for p in [m.refiner.bandwidth_logits,m.refiner.router[-1].weight,
                    m.refiner.reduce.weight,m.refiner.high_experts[0].project.weight,m.refiner.low_experts[0].project.weight]:
                    self.assertIsNotNone(p.grad);self.assertGreater(float(p.grad.abs().sum()),0.)
                self.assertGreater(float(m.refiner.router[0].weight.grad[:,-1].abs().sum()),0.)
            opt.step()
        for key,value in before.items():
            if key.startswith('gate.') or any(t in key for t in ('running_mean','running_var','num_batches_tracked')):
                torch.testing.assert_close(m.net.state_dict()[key],value,atol=0,rtol=0)
        self.assertFalse(torch.equal(before['detector.fc.weight'],m.net.detector.fc.weight))

    def test_source_metadata_checkpoint_load_and_tamper_detection(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,raw,data,ref,anchor,info=fixture(Path(d));actual=make_a1(info['state'],a.device)
            bank,_=data.fetch('val',slice(None),a.device)
            with torch.inference_mode():torch.testing.assert_close(actual.prepared_forward(bank),ref.prepared_forward(bank),atol=0,rtol=0)
            ct_path=a.source_run/'A1/training_contract.json';ct=read_json(ct_path);ct['checkpoint_sha256']='changed';write_json(ct_path,ct)
            with self.assertRaisesRegex(RuntimeError,'checksum'):metadata(a,c)

    def test_source_h0_and_h1_prefix_replay_and_reject_mismatch(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,raw,data,ref,anchor,info=fixture(Path(d));g=info['generator'];p=info['p'];arrays={}
            for split in ('h0_cal','h0_audit'):
                iq=np.stack([g.make_one(p['master_seed'],p[split+'_split'],i,-30,10)['base'] for i in range(64)]).astype('complex64')
                arrays[split]=predictions([ref],iq,a.device,32)[:,0]
            arrays['h1']=np.zeros((37,32))
            scenes=[g.make_one(p['master_seed'],p['h1_split'],i,-30,10) for i in range(32)]
            for scr in (0,12):
                iq=np.stack([(s['base'].astype('complex128')+s['unit'].astype('complex128')*np.sqrt(s['cp']*10**(scr/10))).astype('complex64') for s in scenes])
                arrays['h1'][p['scr_grid_db'].index(scr)]=predictions([ref],iq,a.device,32)[:,0]
            info['arrays']=arrays;self.assertEqual(len(source_probe(info,ref,a.device,32)['reused_score_prefix_checks']),4)
            info['arrays']['h0_cal'][0]+=1
            with self.assertRaisesRegex(RuntimeError,'prefix differs'):source_probe(info,ref,a.device,32)

    def test_all_three_train_commit_reload_budget_and_inference(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,raw,data,ref,anchor,info=fixture(Path(d));contracts=[];source_hash=digest_file(a.source_run/'A1/best.pt')
            for arm in ARMS:contracts.append(trainer.train_arm(a,c,data,info,ref,anchor,arm))
            verify_matched(contracts);self.assertEqual(source_hash,digest_file(a.source_run/'A1/best.pt'))
            for ct in contracts:self.assertEqual(ct['run_config']['loss'],'CE only')
            for arm in ARMS:self.assertEqual(trainer.train_arm(a,c,data,info,ref,anchor,arm)['status'],PASS)
            def capture(args,p,g,models,device,old):
                expected=(300000,200000,512) if a.eval_size=='medium' else (3000000,1000000,1024)
                self.assertEqual((p['h0_cal_n'],p['h0_audit_n'],p['h1_scenes_n']),expected)
                self.assertEqual(p['nominal_pfas'],[1e-4] if a.eval_size=='medium' else [1e-4,1e-5])
                self.assertEqual(predictions(models,raw.values['val'][0],device,2).shape,(4,4))
            with patch.object(scorer,'stream',side_effect=capture) as s,patch('b282_report.generate',return_value=True):
                self.assertTrue(scorer.score(a,info,ref));s.assert_called_once()
            a.eval_size='full'
            with patch.object(scorer,'stream',side_effect=capture) as s,patch('b282_report.generate',return_value=True):
                self.assertTrue(scorer.score(a,info,ref));s.assert_called_once()
            iq_path=Path(d)/'iq.npy';out=Path(d)/'infer.npz';np.save(iq_path,raw.values['val'][0])
            inference.main(['--checkpoint',str(a.out_dir/'guided/best.pt'),'--iq',str(iq_path),'--out',str(out),'--device','cpu','--batch','2','--threshold','0'])
            with np.load(out,allow_pickle=False) as z:
                self.assertEqual(z['scores'].shape,(4,));np.testing.assert_array_equal(z['decisions'],z['scores']>0)

    def test_atomic_epoch_resume_exact_and_repairs_missing_best(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,raw,data,ref,anchor,info=fixture(Path(d));a.epochs=2;save=trainer.atomic_save;stopped=[False]
            def interrupt(path,value):
                save(path,value)
                if path.name=='last_epoch.pt' and value['epoch']==1 and not stopped[0]:stopped[0]=True;raise InterruptedError('after authoritative epoch commit')
            with patch.object(trainer,'atomic_save',side_effect=interrupt):
                with self.assertRaises(InterruptedError):trainer.train_arm(a,c,data,info,ref,anchor,'guided')
            (a.out_dir/'guided/best.pt').unlink();trainer.train_arm(a,c,data,info,ref,anchor,'guided');one=load_checkpoint(a.out_dir/'guided/last_epoch.pt')
            a.out_dir=Path(d)/'continuous';a.out_dir.mkdir();trainer.train_arm(a,c,data,info,ref,anchor,'guided');two=load_checkpoint(a.out_dir/'guided/last_epoch.pt')
            for key,value in one['state_dict'].items():torch.testing.assert_close(value,two['state_dict'][key],atol=0,rtol=0)
            self.assertEqual(one['best_checkpoint']['epoch'],two['best_checkpoint']['epoch'])

    def test_shared_render_and_independent_iq_forward_match(self):
        ref=A1Core(2.).eval();models=[ref]+[Candidate(ref,arm).eval() for arm in ARMS]
        iq=np.random.default_rng(2).normal(size=(2,512,2)).astype('float32').view('complex64').reshape(2,512)
        with patch.object(scorer,'smoothing_bank',wraps=scorer.smoothing_bank) as s:
            actual=predictions(models,iq,torch.device('cpu'),2);s.assert_called_once()
        with torch.inference_mode():
            for j,m in enumerate(models):
                z=m(torch.from_numpy(iq));np.testing.assert_array_equal(actual[:,j],(z[:,1]-z[:,0]).double().numpy())

    def test_real_generator_stream_reuse_resume_and_missing_array(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,raw,data,ref,anchor,info=fixture(Path(d));a.out_dir=Path(d)/'score'
            p={k:info['p'][k] for k in SCENE_KEYS};p.update(h0_cal_n=4,h0_audit_n=4,h1_scenes_n=2,scr_grid_db=[0,1,12],labels=list(LABELS))
            p['fingerprint']=fingerprint(p);models=[ref]+[Candidate(ref,arm).eval() for arm in ARMS]
            stream(a,p,info['generator'],models,a.device,{})
            before={f.name:digest_file(f) for f in a.out_dir.glob('*.npy')}
            old={key:np.load(a.out_dir/file)[:,:,0] if key=='h1' else np.load(a.out_dir/file)[:,0] for key,file in [('h0_cal','h0_cal_scores.npy'),('h0_audit','h0_audit_scores.npy'),('h1','dev_h1_scores.npy')]}
            progress=read_json(a.out_dir/'progress.json');progress['completed'].update(h0_cal=2,h1=1);write_json(a.out_dir/'progress.json',progress)
            stream(a,p,info['generator'],models,a.device,old)
            self.assertEqual(before,{f.name:digest_file(f) for f in a.out_dir.glob('*.npy')})
            (a.out_dir/'h0_cal_scores.npy').unlink()
            with self.assertRaisesRegex(RuntimeError,'missing despite'):stream(a,p,info['generator'],models,a.device,{})

    def test_report_raw37_triangle_and_actual_pfa(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);cal=np.linspace(-6,6,1000000);audit=np.linspace(-6,6,20000);q=(np.arange(512)+.5)/512
            h1=np.stack([6+(scr-np.log(q/(1-q)))/3 for scr in range(-24,13)])
            ct=dict(best_epoch=1,initialization=dict(extra_parameters=20214),new_refinement_selected=True)
            p=dict(version='B282_CFEXPERT_SCORE_V1',labels=list(LABELS),names=NAMES,nominal_pfas=[1e-4,1e-5],scr_grid_db=list(range(-24,13)),
                h0_cal_n=1000000,h0_audit_n=20000,h1_scenes_n=512,checkpoints=[ct]*3,scope='synthetic fixture')
            p['fingerprint']=fingerprint(p);write_json(root/'protocol_frozen.json',p);write_json(root/'progress.json',dict(fingerprint=p['fingerprint'],completed=dict(h0_cal=1000000,h0_audit=20000,h1=37)))
            np.save(root/'h0_cal_scores.npy',np.stack([cal]*4,1));np.save(root/'h0_audit_scores.npy',np.stack([audit]*4,1));np.save(root/'dev_h1_scores.npy',np.stack([h1+j/3 for j in range(4)],2))
            report=reporter.generate(root);self.assertEqual(len(report['metrics']),8)
            manifest=read_json(root/'figures/pfa_1e-04/b282_curves_paper_manifest.json')
            self.assertEqual(manifest['styles'][NAMES['guided']]['marker'],'v');self.assertFalse(manifest['smoothing'])
            self.assertTrue((root/'figures/b282_pd_scr_pfa_1e-04.pdf').is_file())
            self.assertTrue((root/'figures/b282_pd_scr_pfa_1e-05.pdf').is_file())

    def test_cli_defaults_lock_and_epoch0_selection(self):
        with tempfile.TemporaryDirectory() as d:
            a=runner.cli(['--root',d,'--device','cpu']);self.assertEqual((a.epochs,a.train_limit,a.val_limit,a.eval_size),(6,16000,5000,'medium'))
            import fcntl
            with (Path(d)/'codex_b271_night.lock').open('a') as lock:
                fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
                with self.assertRaisesRegex(SystemExit,'GPU lock'):runner.main(['--root',d,'--device','cpu'])
            anchor=dict(val_ce=.5,val_pauc01=.4);bad=dict(val_ce=.6,val_pauc01=.9)
            self.assertEqual(trainer.better(bad,anchor,anchor),(False,False))

    def test_actual_main_chain_with_generated_iq_discovery_boundary(self):
        # Only contract/count discovery is reduced: real CLI, canary, all
        # optimizers, full ADN, checkpoint commits, reload and stream execute.
        with tempfile.TemporaryDirectory() as d:
            a,c,raw,data,ref,anchor,info=fixture(Path(d),32);out=Path(d)/'main_out'
            def tiny_stream(args,p,g,models,device,old):
                self.assertEqual((p['h0_cal_n'],p['h0_audit_n']),(300000,200000))
                local=dict(p,h0_cal_n=2,h0_audit_n=2,h1_scenes_n=2,scr_grid_db=[0]);local.pop('fingerprint');local['fingerprint']=fingerprint(local)
                stream(args,local,g,models,device,{})
            with patch.object(runner,'resolve',return_value=c),patch.object(scorer,'stream',side_effect=tiny_stream) as s,patch('b282_report.generate',return_value=True):
                self.assertTrue(runner.main(['--root',d,'--source-run',str(a.source_run),'--out-dir',str(out),'--train-limit','32','--epochs','1','--device','cpu','--cpu-threads','2']))
                s.assert_called_once()
            canary=read_json(out/'optimizer_canary.json');self.assertEqual(len(canary['checks']),3)
            self.assertTrue(all((out/arm/'training_contract.json').is_file() for arm in ARMS))

    @unittest.skipUnless(torch.cuda.is_available(),'No local CUDA; AutoDL startup runs real batch32 canary')
    def test_cuda_batch32_optimizer_canary(self):
        with tempfile.TemporaryDirectory() as d:
            a,c,raw,data,ref,anchor,info=fixture(Path(d),32);a.device=torch.device('cuda');a.batch=32;ref.to(a.device)
            self.assertEqual(len(runner.runtime_canary(a,data,ref)),3)


if __name__=='__main__':unittest.main(verbosity=2)
